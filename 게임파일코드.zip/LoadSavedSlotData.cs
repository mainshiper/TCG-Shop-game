﻿using System;

// Token: 0x0200007C RID: 124
[Serializable]
public struct LoadSavedSlotData
{
	// Token: 0x04000678 RID: 1656
	public bool hasSaveData;

	// Token: 0x04000679 RID: 1657
	public string name;

	// Token: 0x0400067A RID: 1658
	public int level;

	// Token: 0x0400067B RID: 1659
	public int daysPassed;

	// Token: 0x0400067C RID: 1660
	public float moneyAmount;
}
