﻿using System;
using UnityEngine;

// Token: 0x02000144 RID: 324
public class GameManager : MonoBehaviour
{
	// Token: 0x0600093A RID: 2362 RVA: 0x00043A4C File Offset: 0x00041C4C
	private void Start()
	{
		this.text_fx_name.text = "[" + (this.index_fx + 1).ToString() + "] " + this.fx_prefabs[this.index_fx].name;
	}

	// Token: 0x0600093B RID: 2363 RVA: 0x00043A98 File Offset: 0x00041C98
	private void Update()
	{
		if (Input.GetMouseButtonDown(0))
		{
			this.ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			this.ray_cast_hit = Physics2D.Raycast(new Vector2(this.ray.origin.x, this.ray.origin.y), new Vector2(0f, 0f));
			if (this.ray_cast_hit)
			{
				string name = this.ray_cast_hit.transform.name;
				if (!(name == "BG"))
				{
					if (!(name == "UI-arrow-right"))
					{
						if (!(name == "UI-arrow-left"))
						{
							if (name == "Instructions")
							{
								Object.Destroy(this.ray_cast_hit.transform.gameObject);
							}
						}
						else
						{
							this.ray_cast_hit.transform.SendMessage("Go");
							this.index_fx--;
							if (this.index_fx <= -1)
							{
								this.index_fx = this.fx_prefabs.Length - 1;
							}
							this.text_fx_name.text = "[" + (this.index_fx + 1).ToString() + "] " + this.fx_prefabs[this.index_fx].name;
						}
					}
					else
					{
						this.ray_cast_hit.transform.SendMessage("Go");
						this.index_fx++;
						if (this.index_fx >= this.fx_prefabs.Length)
						{
							this.index_fx = 0;
						}
						this.text_fx_name.text = "[" + (this.index_fx + 1).ToString() + "] " + this.fx_prefabs[this.index_fx].name;
					}
				}
				else
				{
					Object.Instantiate<GameObject>(this.fx_prefabs[this.index_fx], new Vector3(this.ray.origin.x, this.ray.origin.y, 0f), Quaternion.identity);
				}
			}
		}
		if (Input.GetKeyDown("z") || Input.GetKeyDown("left"))
		{
			GameObject.Find("UI-arrow-left").SendMessage("Go");
			this.index_fx--;
			if (this.index_fx <= -1)
			{
				this.index_fx = this.fx_prefabs.Length - 1;
			}
			this.text_fx_name.text = "[" + (this.index_fx + 1).ToString() + "] " + this.fx_prefabs[this.index_fx].name;
		}
		if (Input.GetKeyDown("x") || Input.GetKeyDown("right"))
		{
			GameObject.Find("UI-arrow-right").SendMessage("Go");
			this.index_fx++;
			if (this.index_fx >= this.fx_prefabs.Length)
			{
				this.index_fx = 0;
			}
			this.text_fx_name.text = "[" + (this.index_fx + 1).ToString() + "] " + this.fx_prefabs[this.index_fx].name;
		}
		if (Input.GetKeyDown("space"))
		{
			Object.Instantiate<GameObject>(this.fx_prefabs[this.index_fx], new Vector3(0f, 0f, 0f), Quaternion.identity);
		}
	}

	// Token: 0x0400115D RID: 4445
	public TextMesh text_fx_name;

	// Token: 0x0400115E RID: 4446
	public GameObject[] fx_prefabs;

	// Token: 0x0400115F RID: 4447
	public int index_fx;

	// Token: 0x04001160 RID: 4448
	private Ray ray;

	// Token: 0x04001161 RID: 4449
	private RaycastHit2D ray_cast_hit;
}
