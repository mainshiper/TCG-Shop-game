﻿using System;
using System.Collections.Generic;
using I2.Loc;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200000C RID: 12
public class CardUI : MonoBehaviour
{
	// Token: 0x06000051 RID: 81 RVA: 0x0000556D File Offset: 0x0000376D
	public void SetAncientArtifactCardUI(EMonsterType ancientCardType)
	{
		this.m_NormalGrp.SetActive(false);
		this.m_FullArtGrp.SetActive(false);
		this.m_AncientArtifactImage.gameObject.SetActive(true);
		this.m_AncientArtifactImage.sprite = InventoryBase.GetAncientArtifactSprite(ancientCardType);
	}

	// Token: 0x06000052 RID: 82 RVA: 0x000055AC File Offset: 0x000037AC
	public void ShowFoilList(bool isActive)
	{
		if (isActive)
		{
			Color color = Color.white * 0.95f;
			color.a = 1f;
			for (int i = 0; i < this.m_FoilDarkenImageList.Count; i++)
			{
				this.m_FoilDarkenImageList[i].color = color;
			}
			if (this.m_FullArtBGImage)
			{
				this.m_FullArtBGImage.color = color;
			}
		}
		else
		{
			for (int j = 0; j < this.m_FoilDarkenImageList.Count; j++)
			{
				this.m_FoilDarkenImageList[j].color = Color.white;
			}
			if (this.m_FullArtBGImage)
			{
				this.m_FullArtBGImage.color = Color.white;
			}
		}
		for (int k = 0; k < this.m_FoilShowList.Count; k++)
		{
			this.m_FoilShowList[k].enabled = isActive;
		}
	}

	// Token: 0x06000053 RID: 83 RVA: 0x0000568C File Offset: 0x0000388C
	public void ShowFoilBlendedList(bool isActive)
	{
		for (int i = 0; i < this.m_FoilBlendedShowList.Count; i++)
		{
			this.m_FoilBlendedShowList[i].enabled = isActive;
		}
	}

	// Token: 0x06000054 RID: 84 RVA: 0x000056C4 File Offset: 0x000038C4
	public void SetFoilCullListVisibility(bool isActive)
	{
		if (!this.m_IsFarDistanceCulled && isActive)
		{
			return;
		}
		if (this.m_IsFarDistanceCulled && !isActive)
		{
			return;
		}
		for (int i = 0; i < this.m_FoilShowList.Count; i++)
		{
			this.m_FoilShowList[i].gameObject.SetActive(isActive);
		}
		for (int j = 0; j < this.m_FoilBlendedShowList.Count; j++)
		{
			this.m_FoilBlendedShowList[j].gameObject.SetActive(isActive);
		}
	}

	// Token: 0x06000055 RID: 85 RVA: 0x00005748 File Offset: 0x00003948
	public void SetFoilMaterialList(List<Material> mat)
	{
		for (int i = 0; i < this.m_FoilShowList.Count; i++)
		{
			this.m_FoilShowList[i].material = mat[i];
		}
		if (this.m_FullArtCard)
		{
			this.m_FullArtCard.SetFoilMaterialList(mat);
		}
		if (this.m_GhostCard)
		{
			this.m_GhostCard.SetFoilMaterialList(mat);
		}
	}

	// Token: 0x06000056 RID: 86 RVA: 0x000057B8 File Offset: 0x000039B8
	public void SetFoilBlendedMaterialList(List<Material> mat)
	{
		for (int i = 0; i < this.m_FoilBlendedShowList.Count; i++)
		{
			this.m_FoilBlendedShowList[i].material = mat[i];
		}
		if (this.m_FullArtCard)
		{
			this.m_FullArtCard.SetFoilBlendedMaterialList(mat);
		}
		if (this.m_GhostCard)
		{
			this.m_GhostCard.SetFoilBlendedMaterialList(mat);
		}
	}

	// Token: 0x06000057 RID: 87 RVA: 0x00005828 File Offset: 0x00003A28
	public void SetGhostCardUI(MonsterData data, bool isBlackGhost)
	{
		this.m_GhostCard.m_MonsterNameText.text = data.GetName();
		this.m_GhostCard.m_Stat1Text.text = data.BaseStats.Strength.ToString();
		this.m_GhostCard.m_Stat2Text.text = data.BaseStats.Vitality.ToString();
		this.m_GhostCard.m_Stat3Text.text = data.BaseStats.Spirit.ToString();
		this.m_GhostCard.m_Stat4Text.text = data.BaseStats.Magic.ToString();
		this.m_GhostCard.m_FameText.text = CPlayerData.GetCardFameAmount(this.m_CardData).ToString();
		this.m_GhostCard.m_MonsterImage.sprite = data.GetIcon(ECardExpansionType.Ghost);
		this.m_GhostCard.m_MonsterMaskImage.sprite = this.m_GhostCard.m_MonsterImage.sprite;
		this.m_GhostCard.m_FoilGrp.SetActive(this.m_IsFoil);
		this.m_GhostCard.ShowFoilList(this.m_IsFoil);
		this.m_GhostCard.ShowFoilBlendedList(this.m_IsFoil);
		this.m_NormalGrp.SetActive(false);
		this.m_FullArtGrp.SetActive(false);
		this.m_SpecialCardGrp.SetActive(false);
		this.m_GhostCard.gameObject.SetActive(true);
		this.m_AncientArtifactImage.gameObject.SetActive(false);
		if (isBlackGhost)
		{
			this.m_GhostCard.m_NormalGrp.SetActive(false);
			this.m_GhostCard.m_FullArtGrp.SetActive(true);
			return;
		}
		this.m_GhostCard.m_NormalGrp.SetActive(true);
		this.m_GhostCard.m_FullArtGrp.SetActive(false);
	}

	// Token: 0x06000058 RID: 88 RVA: 0x000059EC File Offset: 0x00003BEC
	private void LoadStreamTextureCompleted(CEventPlayer_LoadStreamTextureCompleted evt)
	{
		if (evt.m_FileName == this.m_CardData.expansionType.ToString() + "_" + this.m_CardData.monsterType.ToString())
		{
			CEventManager.RemoveListener<CEventPlayer_LoadStreamTextureCompleted>(new CEventManager.EventDelegate<CEventPlayer_LoadStreamTextureCompleted>(this.LoadStreamTextureCompleted));
			if (evt.m_IsSuccess)
			{
				this.m_MonsterImage.sprite = this.m_MonsterData.GetIcon(this.m_CardData.expansionType);
			}
		}
	}

	// Token: 0x06000059 RID: 89 RVA: 0x00005A76 File Offset: 0x00003C76
	private void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_LoadStreamTextureCompleted>(new CEventManager.EventDelegate<CEventPlayer_LoadStreamTextureCompleted>(this.LoadStreamTextureCompleted));
		}
	}

	// Token: 0x0600005A RID: 90 RVA: 0x00005A98 File Offset: 0x00003C98
	public void SetCardUI(CardData cardData)
	{
		this.m_CardData = cardData;
		if (this.m_CardData.monsterType <= EMonsterType.EarlyPlayer)
		{
			this.m_SpecialCardImage.sprite = InventoryBase.GetSpecialCardImage(this.m_CardData.monsterType);
			this.m_SpecialCardGlowImage.sprite = this.m_SpecialCardImage.sprite;
			this.m_SpecialCardGrp.SetActive(true);
			this.m_NormalGrp.SetActive(false);
			this.m_FullArtGrp.SetActive(false);
			this.m_GhostCard.gameObject.SetActive(false);
			this.m_AncientArtifactImage.gameObject.SetActive(false);
			this.m_FoilGrp.SetActive(true);
			this.ShowFoilList(true);
			this.ShowFoilBlendedList(true);
			return;
		}
		this.m_MonsterData = InventoryBase.GetMonsterData(cardData.monsterType);
		this.m_CardUISetting = InventoryBase.GetCardUISetting(this.m_CardData.expansionType);
		this.m_MonsterImage.sprite = this.m_MonsterData.GetIcon(this.m_CardData.expansionType);
		if (this.m_MonsterImage.sprite == null)
		{
			this.m_MonsterImage.sprite = CSingleton<LoadStreamTexture>.Instance.m_LoadingSprite;
			CEventManager.AddListener<CEventPlayer_LoadStreamTextureCompleted>(new CEventManager.EventDelegate<CEventPlayer_LoadStreamTextureCompleted>(this.LoadStreamTextureCompleted));
		}
		this.m_CardBackImage.sprite = CSingleton<InventoryBase>.Instance.m_MonsterData_SO.GetCardBackSprite(this.m_CardData.expansionType);
		if (!this.m_IsNestedFullArt)
		{
			this.m_CardFoilMaskImage.sprite = CSingleton<InventoryBase>.Instance.m_MonsterData_SO.GetCardFoilMaskSprite(this.m_CardData.expansionType);
		}
		this.m_CardBorderType = this.m_CardData.GetCardBorderType();
		this.m_IsDimensionCard = this.m_CardData.isDestiny;
		this.m_IsFoil = this.m_CardData.isFoil;
		this.m_FoilGrp.SetActive(this.m_IsFoil);
		this.ShowFoilList(this.m_IsFoil);
		this.ShowFoilBlendedList(this.m_IsFoil);
		if (this.m_ExtraFoil)
		{
			if (this.m_CardBorderType == ECardBorderType.Base || this.m_CardBorderType == ECardBorderType.FirstEdition)
			{
				this.m_ExtraFoil.gameObject.SetActive(false);
			}
			else
			{
				this.m_ExtraFoil.gameObject.SetActive(true);
			}
		}
		this.m_IsChampionCard = this.m_CardData.isChampionCard;
		if (this.m_CardData.expansionType == ECardExpansionType.Destiny)
		{
			this.m_CardBGImage.sprite = CSingleton<InventoryBase>.Instance.m_MonsterData_SO.GetCardFrontSprite(EElementIndex.Destiny);
		}
		else if (this.m_IsChampionCard)
		{
			this.m_CardBGImage.sprite = CSingleton<InventoryBase>.Instance.m_MonsterData_SO.GetCardFrontSprite(EElementIndex.Champion);
			this.m_CardBorderType = ECardBorderType.FullArt;
		}
		else if (this.m_CardData.expansionType == ECardExpansionType.Ghost)
		{
			if (this.m_CardData.isDestiny)
			{
				this.m_CardBGImage.sprite = CSingleton<InventoryBase>.Instance.m_MonsterData_SO.GetCardFrontSprite(EElementIndex.GhostBlack);
			}
			else
			{
				this.m_CardBGImage.sprite = CSingleton<InventoryBase>.Instance.m_MonsterData_SO.GetCardFrontSprite(EElementIndex.GhostWhite);
			}
		}
		else
		{
			this.m_CardBGImage.sprite = CSingleton<InventoryBase>.Instance.m_MonsterData_SO.GetCardFrontSprite(this.m_MonsterData.ElementIndex);
		}
		this.m_CardBorderImage.sprite = this.m_CardBorderSpriteList[(int)this.m_CardBorderType];
		this.m_RarityImage.sprite = this.m_CardRaritySpriteList[(int)this.m_MonsterData.Rarity];
		this.m_MonsterNameText.text = this.m_MonsterData.GetName();
		int num = (int)((this.m_MonsterData.MonsterType - EMonsterType.PiggyA) * CPlayerData.GetCardAmountPerMonsterType(this.m_CardData.expansionType, true) + this.m_CardBorderType);
		num++;
		if (this.m_IsFoil)
		{
			num += 6;
		}
		string text;
		if (num < 10)
		{
			text = "00" + num.ToString();
		}
		else if (num < 100)
		{
			text = "0" + num.ToString();
		}
		else
		{
			text = num.ToString();
		}
		this.m_NumberText.text = text;
		if (this.m_IsChampionCard)
		{
			this.m_FameText.gameObject.SetActive(false);
			this.m_DescriptionText.gameObject.SetActive(false);
			this.m_ArtistText.gameObject.SetActive(false);
			this.m_ChampionText.enabled = true;
		}
		else
		{
			this.m_DescriptionText.text = this.m_MonsterData.GetDescription();
			this.m_DescriptionText.gameObject.SetActive(true);
			this.m_ArtistText.text = this.m_MonsterData.GetArtistName();
			this.m_ArtistText.gameObject.SetActive(true);
			if (this.m_MonsterData.PreviousEvolution == EMonsterType.None)
			{
				this.m_EvoBasicGrp.SetActive(true);
				this.m_EvoPreviousStageIcon.gameObject.SetActive(false);
				this.m_EvoPreviousStageNameText.gameObject.SetActive(false);
			}
			else
			{
				this.m_EvoBasicGrp.SetActive(false);
				MonsterData monsterData = InventoryBase.GetMonsterData(this.m_MonsterData.PreviousEvolution);
				this.m_EvoPreviousStageIcon.sprite = monsterData.GetIcon(this.m_CardData.expansionType);
				this.m_EvoPreviousStageNameText.text = monsterData.GetName();
				this.m_EvoPreviousStageNameText.gameObject.SetActive(true);
				this.m_EvoPreviousStageIcon.gameObject.SetActive(true);
			}
			this.m_ChampionText.enabled = false;
		}
		for (int i = 0; i < this.m_ChampionCardEnableObjectList.Count; i++)
		{
			this.m_ChampionCardEnableObjectList[i].SetActive(this.m_IsChampionCard);
		}
		this.m_RarityText.text = this.m_MonsterData.GetRarityName();
		this.m_Stat1Text.text = this.m_MonsterData.BaseStats.Strength.ToString();
		this.m_Stat2Text.text = this.m_MonsterData.BaseStats.Vitality.ToString();
		this.m_Stat3Text.text = this.m_MonsterData.BaseStats.Spirit.ToString();
		this.m_Stat4Text.text = this.m_MonsterData.BaseStats.Magic.ToString();
		this.EvaluateCardUISetting();
		if (this.m_IsNestedFullArt)
		{
			return;
		}
		if (this.m_CardBorderType == ECardBorderType.Base || this.m_CardBorderType == ECardBorderType.FullArt)
		{
			this.m_FirstEditionText.enabled = false;
		}
		else
		{
			if (this.m_CardBorderType == ECardBorderType.FirstEdition)
			{
				this.m_FirstEditionText.text = LocalizationManager.GetTranslation("1st Edition", true, 0, true, false, null, null, true);
			}
			else if (this.m_CardBorderType == ECardBorderType.Silver)
			{
				this.m_FirstEditionText.text = LocalizationManager.GetTranslation("Silver Edition", true, 0, true, false, null, null, true);
			}
			else if (this.m_CardBorderType == ECardBorderType.Gold)
			{
				this.m_FirstEditionText.text = LocalizationManager.GetTranslation("Gold Edition", true, 0, true, false, null, null, true);
			}
			else if (this.m_CardBorderType == ECardBorderType.EX)
			{
				this.m_FirstEditionText.text = "EX";
			}
			this.m_FirstEditionText.enabled = true;
		}
		if (this.m_CardData.expansionType == ECardExpansionType.Ghost && this.m_CardBorderType == ECardBorderType.FullArt)
		{
			this.SetGhostCardUI(this.m_MonsterData, this.m_CardData.isDestiny);
			return;
		}
		if (this.m_CardBorderType == ECardBorderType.FullArt && this.m_FullArtCard)
		{
			this.m_FullArtCard.MarkAsNestedFullArt(true);
			this.m_FullArtCard.SetCardUI(this.m_CardData);
			this.m_FullArtCard.m_MonsterMaskImage.sprite = this.m_FullArtCard.m_MonsterImage.sprite;
			if (this.m_CardData.expansionType == ECardExpansionType.Destiny)
			{
				this.m_FullArtBGImage.sprite = CSingleton<InventoryBase>.Instance.m_MonsterData_SO.GetCardBGSprite(EElementIndex.Destiny);
			}
			else if (this.m_IsChampionCard)
			{
				this.m_FullArtBGImage.sprite = CSingleton<InventoryBase>.Instance.m_MonsterData_SO.GetCardBGSprite(EElementIndex.Champion);
			}
			else if (this.m_CardData.expansionType == ECardExpansionType.Ghost)
			{
				if (this.m_CardData.isDestiny)
				{
					this.m_FullArtBGImage.sprite = CSingleton<InventoryBase>.Instance.m_MonsterData_SO.GetCardBGSprite(EElementIndex.GhostBlack);
				}
				else
				{
					this.m_FullArtBGImage.sprite = CSingleton<InventoryBase>.Instance.m_MonsterData_SO.GetCardBGSprite(EElementIndex.GhostWhite);
				}
			}
			else
			{
				this.m_FullArtBGImage.sprite = CSingleton<InventoryBase>.Instance.m_MonsterData_SO.GetCardBGSprite(this.m_MonsterData.ElementIndex);
			}
			this.m_FullArtCard.m_FoilGrp.SetActive(this.m_IsFoil);
			this.m_FullArtCard.ShowFoilList(this.m_IsFoil);
			this.m_FullArtCard.ShowFoilBlendedList(this.m_IsFoil);
			this.m_FullArtCard.m_FameText.text = this.m_FameText.text;
			this.m_FullArtCard.m_DescriptionText.text = this.m_DescriptionText.text;
			this.m_FullArtCard.m_ArtistText.text = this.m_ArtistText.text;
			this.m_FullArtCard.m_ArtistText.gameObject.SetActive(this.m_ArtistText.gameObject.activeSelf);
			if (this.m_MonsterData.PreviousEvolution == EMonsterType.None)
			{
				this.m_FullArtCard.m_EvoBasicGrp.SetActive(true);
				this.m_FullArtCard.m_EvoPreviousStageNameText.gameObject.SetActive(false);
				this.m_FullArtCard.m_EvoPreviousStageIcon.gameObject.SetActive(false);
			}
			else
			{
				this.m_FullArtCard.m_EvoBasicGrp.SetActive(false);
				MonsterData monsterData2 = InventoryBase.GetMonsterData(this.m_MonsterData.PreviousEvolution);
				this.m_FullArtCard.m_EvoPreviousStageIcon.sprite = monsterData2.GetIcon(this.m_CardData.expansionType);
				this.m_FullArtCard.m_EvoPreviousStageNameText.text = monsterData2.GetName();
				this.m_FullArtCard.m_EvoPreviousStageNameText.gameObject.SetActive(true);
				this.m_FullArtCard.m_EvoPreviousStageIcon.gameObject.SetActive(true);
			}
			this.m_NormalGrp.SetActive(false);
			this.m_FullArtGrp.SetActive(true);
			this.m_SpecialCardGrp.SetActive(false);
			this.m_GhostCard.gameObject.SetActive(false);
			this.m_AncientArtifactImage.gameObject.SetActive(false);
			return;
		}
		this.m_NormalGrp.SetActive(true);
		this.m_FullArtGrp.SetActive(false);
		this.m_SpecialCardGrp.SetActive(false);
		this.m_GhostCard.gameObject.SetActive(false);
		this.m_AncientArtifactImage.gameObject.SetActive(false);
	}

	// Token: 0x0600005B RID: 91 RVA: 0x000064C0 File Offset: 0x000046C0
	private void EvaluateCardUISetting()
	{
		if (this.m_MonsterNameText)
		{
			if (this.m_IsNestedFullArt)
			{
				this.m_MonsterNameText.enabled = this.m_CardUISetting.showNameFullArt;
			}
			else
			{
				this.m_MonsterNameText.enabled = this.m_CardUISetting.showName;
			}
		}
		this.m_Stat1Text.enabled = this.m_CardUISetting.showStat1;
		this.m_Stat2Text.enabled = this.m_CardUISetting.showStat2;
		this.m_Stat3Text.enabled = this.m_CardUISetting.showStat3;
		this.m_Stat4Text.enabled = this.m_CardUISetting.showStat4;
		this.m_Stat1Text.transform.localPosition = this.m_CardUISetting.stat1PosOffset;
		this.m_Stat1Text.transform.localScale = Vector3.one + this.m_CardUISetting.stat1ScaleOffset;
		if (this.m_ArtworkImageLocalPos != Vector3.zero)
		{
			this.m_MonsterImage.transform.localPosition = this.m_ArtworkImageLocalPos;
		}
		this.m_ArtworkImageLocalPos = this.m_MonsterImage.transform.localPosition;
		if (!this.m_IsNestedFullArt)
		{
			if (!this.m_CardUISetting.showEdition && this.m_FirstEditionText.enabled)
			{
				this.m_FirstEditionText.enabled = false;
			}
			this.m_RarityImage.enabled = this.m_CardUISetting.showRarity;
			this.m_RarityText.enabled = this.m_CardUISetting.showRarity;
			this.m_NumberText.enabled = this.m_CardUISetting.showNumber;
			this.m_NumberText.transform.localPosition = this.m_CardUISetting.numberPosOffset;
			this.m_FirstEditionText.transform.localPosition = this.m_CardUISetting.editionPosOffset;
			this.m_MonsterMask.transform.localPosition = this.m_CardUISetting.monsterImagePosOffset;
			this.m_MonsterMask.transform.localScale = Vector3.one + this.m_CardUISetting.monsterImageScaleOffset;
			this.m_MonsterImage.transform.localPosition = this.m_ArtworkImageLocalPos + this.m_CardUISetting.artworkImagePosOffset;
			this.m_MonsterImage.transform.localScale = Vector3.one + -this.m_CardUISetting.monsterImageScaleOffset;
			this.m_MonsterMaskImage.transform.localPosition = this.m_MonsterImage.transform.localPosition;
			this.m_MonsterMaskImage.transform.localScale = this.m_MonsterImage.transform.localScale;
			this.m_MonsterGlowMask.transform.localPosition = this.m_CardUISetting.monsterImagePosOffset;
			this.m_MonsterGlowMask.transform.localScale = this.m_MonsterMask.transform.localScale;
			this.m_FameText.transform.localPosition = this.m_CardUISetting.famePosOffset;
			this.m_FameText.transform.localScale = Vector3.one + this.m_CardUISetting.fameScaleOffset;
			this.m_MonsterNameText.transform.localPosition = this.m_CardUISetting.namePosOffset;
			return;
		}
		this.m_Stat1Text.enabled = this.m_CardUISetting.fullArtShowStat1;
		this.m_MonsterMask.transform.localPosition = this.m_CardUISetting.fullArtMonsterImagePosOffset;
		this.m_MonsterMask.transform.localScale = Vector3.one + this.m_CardUISetting.fullArtMonsterImageScaleOffset;
		this.m_MonsterGlowMask.transform.localPosition = this.m_CardUISetting.fullArtMonsterImagePosOffset;
		this.m_MonsterGlowMask.transform.localScale = this.m_MonsterMask.transform.localScale;
		this.m_FullArtBGImageMask.transform.localScale = this.m_MonsterMask.transform.localScale;
		this.m_FullArtBGImageMask.transform.localScale = this.m_MonsterMask.transform.localScale + this.m_CardUISetting.fullArtBGMaskScaleOffset;
		this.m_MonsterMask.sprite = this.m_CardBGImage.sprite;
		this.m_MonsterImage.transform.localPosition = this.m_ArtworkImageLocalPos + this.m_CardUISetting.fullArtArtworkImagePosOffset;
		this.m_MonsterMaskImage.transform.localPosition = this.m_MonsterImage.transform.localPosition;
		this.m_MonsterMaskImage.transform.localScale = this.m_MonsterImage.transform.localScale;
		this.m_CardFoilMaskImage.sprite = this.m_CardBGImage.sprite;
		this.m_FullArtBGImageMask.sprite = this.m_CardBGImage.sprite;
		this.m_MonsterGlowMask.sprite = this.m_CardBGImage.sprite;
		this.m_FameText.transform.localPosition = this.m_CardUISetting.fullArtFamePosOffset;
		this.m_FameText.transform.localScale = Vector3.one + this.m_CardUISetting.fullArtFameScaleOffset;
		this.m_MonsterNameText.transform.localPosition = this.m_CardUISetting.fullArtNamePosOffset;
	}

	// Token: 0x0600005C RID: 92 RVA: 0x000069F0 File Offset: 0x00004BF0
	private void MarkAsNestedFullArt(bool isNested)
	{
		this.m_IsNestedFullArt = isNested;
	}

	// Token: 0x0600005D RID: 93 RVA: 0x000069F9 File Offset: 0x00004BF9
	public void SetIsUnlocked(bool isUnlocked)
	{
		this.m_CardBack.SetActive(!isUnlocked);
		if (this.m_CardFront)
		{
			this.m_CardFront.SetActive(isUnlocked);
		}
	}

	// Token: 0x0600005E RID: 94 RVA: 0x00006A23 File Offset: 0x00004C23
	public CardData GetCardData()
	{
		return this.m_CardData;
	}

	// Token: 0x0600005F RID: 95 RVA: 0x00006A2C File Offset: 0x00004C2C
	public void SetBrightness(float brightness)
	{
		Color color = this.m_BrightnessControl.color;
		color.a = (1f - brightness) * 0.95f;
		this.m_BrightnessControl.color = color;
	}

	// Token: 0x06000060 RID: 96 RVA: 0x00006A68 File Offset: 0x00004C68
	public void SetFarDistanceCull()
	{
		if (this.m_IsFarDistanceCulled)
		{
			return;
		}
		this.m_IsFarDistanceCulled = true;
		this.m_FarDistanceCullObjVisibilityList.Clear();
		for (int i = 0; i < this.m_FarDistanceCullObjList.Count; i++)
		{
			this.m_FarDistanceCullObjVisibilityList.Add(this.m_FarDistanceCullObjList[i].activeSelf);
			this.m_FarDistanceCullObjList[i].SetActive(false);
		}
	}

	// Token: 0x06000061 RID: 97 RVA: 0x00006AD4 File Offset: 0x00004CD4
	public void ResetFarDistanceCull()
	{
		if (!this.m_IsFarDistanceCulled)
		{
			return;
		}
		this.m_IsFarDistanceCulled = false;
		for (int i = 0; i < this.m_FarDistanceCullObjVisibilityList.Count; i++)
		{
			this.m_FarDistanceCullObjList[i].SetActive(this.m_FarDistanceCullObjVisibilityList[i]);
		}
		this.m_FarDistanceCullObjVisibilityList.Clear();
	}

	// Token: 0x0400006D RID: 109
	public GameObject m_NormalGrp;

	// Token: 0x0400006E RID: 110
	public GameObject m_FullArtGrp;

	// Token: 0x0400006F RID: 111
	public GameObject m_SpecialCardGrp;

	// Token: 0x04000070 RID: 112
	public CardUI m_FullArtCard;

	// Token: 0x04000071 RID: 113
	public CardUI m_GhostCard;

	// Token: 0x04000072 RID: 114
	public GameObject m_CardFront;

	// Token: 0x04000073 RID: 115
	public GameObject m_CardBack;

	// Token: 0x04000074 RID: 116
	public GameObject m_FoilGrp;

	// Token: 0x04000075 RID: 117
	public List<Image> m_FoilShowList;

	// Token: 0x04000076 RID: 118
	public List<Image> m_FoilBlendedShowList;

	// Token: 0x04000077 RID: 119
	public List<Image> m_FoilDarkenImageList;

	// Token: 0x04000078 RID: 120
	public GameObject m_ExtraFoil;

	// Token: 0x04000079 RID: 121
	public Image m_CardBackImage;

	// Token: 0x0400007A RID: 122
	public Image m_MonsterImage;

	// Token: 0x0400007B RID: 123
	public Image m_MonsterMaskImage;

	// Token: 0x0400007C RID: 124
	public Image m_FullArtBGImage;

	// Token: 0x0400007D RID: 125
	public Image m_FullArtBGImageMask;

	// Token: 0x0400007E RID: 126
	public Image m_CardBorderImage;

	// Token: 0x0400007F RID: 127
	public Image m_CardBGImage;

	// Token: 0x04000080 RID: 128
	public Image m_CardFoilMaskImage;

	// Token: 0x04000081 RID: 129
	public Image m_MonsterMask;

	// Token: 0x04000082 RID: 130
	public Image m_MonsterGlowMask;

	// Token: 0x04000083 RID: 131
	public Image m_RarityImage;

	// Token: 0x04000084 RID: 132
	public Image m_AncientArtifactImage;

	// Token: 0x04000085 RID: 133
	public Image m_SpecialCardImage;

	// Token: 0x04000086 RID: 134
	public Image m_SpecialCardGlowImage;

	// Token: 0x04000087 RID: 135
	public Image m_BrightnessControl;

	// Token: 0x04000088 RID: 136
	public TextMeshProUGUI m_FirstEditionText;

	// Token: 0x04000089 RID: 137
	public TextMeshProUGUI m_MonsterNameText;

	// Token: 0x0400008A RID: 138
	public TextMeshProUGUI m_NumberText;

	// Token: 0x0400008B RID: 139
	public TextMeshProUGUI m_FameText;

	// Token: 0x0400008C RID: 140
	public TextMeshProUGUI m_DescriptionText;

	// Token: 0x0400008D RID: 141
	public TextMeshProUGUI m_ChampionText;

	// Token: 0x0400008E RID: 142
	public TextMeshProUGUI m_RarityText;

	// Token: 0x0400008F RID: 143
	public TextMeshProUGUI m_Stat1Text;

	// Token: 0x04000090 RID: 144
	public TextMeshProUGUI m_Stat2Text;

	// Token: 0x04000091 RID: 145
	public TextMeshProUGUI m_Stat3Text;

	// Token: 0x04000092 RID: 146
	public TextMeshProUGUI m_Stat4Text;

	// Token: 0x04000093 RID: 147
	public TextMeshProUGUI m_ArtistText;

	// Token: 0x04000094 RID: 148
	public List<Sprite> m_CardBorderSpriteList;

	// Token: 0x04000095 RID: 149
	public List<Sprite> m_CardBGSpriteList;

	// Token: 0x04000096 RID: 150
	public List<Sprite> m_CardRaritySpriteList;

	// Token: 0x04000097 RID: 151
	public List<Sprite> m_CardElementBGSpriteList;

	// Token: 0x04000098 RID: 152
	private CardData m_CardData;

	// Token: 0x04000099 RID: 153
	private MonsterData m_MonsterData;

	// Token: 0x0400009A RID: 154
	private ECardBorderType m_CardBorderType;

	// Token: 0x0400009B RID: 155
	private bool m_IsNestedFullArt;

	// Token: 0x0400009C RID: 156
	private bool m_IsFoil;

	// Token: 0x0400009D RID: 157
	private bool m_IsDimensionCard;

	// Token: 0x0400009E RID: 158
	private bool m_IsChampionCard;

	// Token: 0x0400009F RID: 159
	public List<GameObject> m_ChampionCardEnableObjectList;

	// Token: 0x040000A0 RID: 160
	private CardUISetting m_CardUISetting;

	// Token: 0x040000A1 RID: 161
	private Vector3 m_ArtworkImageLocalPos;

	// Token: 0x040000A2 RID: 162
	public List<GameObject> m_FarDistanceCullObjList;

	// Token: 0x040000A3 RID: 163
	private List<bool> m_FarDistanceCullObjVisibilityList = new List<bool>();

	// Token: 0x040000A4 RID: 164
	private bool m_IsFarDistanceCulled;

	// Token: 0x040000A5 RID: 165
	public GameObject m_EvoGrp;

	// Token: 0x040000A6 RID: 166
	public GameObject m_EvoBasicGrp;

	// Token: 0x040000A7 RID: 167
	public Image m_EvoPreviousStageIcon;

	// Token: 0x040000A8 RID: 168
	public TextMeshProUGUI m_EvoPreviousStageNameText;
}
