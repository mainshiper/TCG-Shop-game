﻿using System;
using UnityEngine;

// Token: 0x02000139 RID: 313
public class ArrowIndicatorUI : MonoBehaviour
{
	// Token: 0x06000901 RID: 2305 RVA: 0x00042B04 File Offset: 0x00040D04
	public void SetPosY(float posYOffset)
	{
		Vector3 localPosition = this.m_ArrowTransformGrp.transform.localPosition;
		localPosition.y = posYOffset;
		this.m_ArrowTransformGrp.transform.localPosition = localPosition;
	}

	// Token: 0x06000902 RID: 2306 RVA: 0x00042B3B File Offset: 0x00040D3B
	public void SetScale(float scale)
	{
		this.m_ArrowTransformGrp.localScale = Vector3.one * scale;
	}

	// Token: 0x0400112B RID: 4395
	public Transform m_ArrowTransformGrp;
}
