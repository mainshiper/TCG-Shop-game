﻿using System;

// Token: 0x02000101 RID: 257
public enum EEmoteType
{
	// Token: 0x04000EBC RID: 3772
	Angry,
	// Token: 0x04000EBD RID: 3773
	BigSmile,
	// Token: 0x04000EBE RID: 3774
	ClenchTeeth,
	// Token: 0x04000EBF RID: 3775
	ClenchTeeth2,
	// Token: 0x04000EC0 RID: 3776
	Cool,
	// Token: 0x04000EC1 RID: 3777
	Cry,
	// Token: 0x04000EC2 RID: 3778
	Cute,
	// Token: 0x04000EC3 RID: 3779
	Derp,
	// Token: 0x04000EC4 RID: 3780
	Disappoint,
	// Token: 0x04000EC5 RID: 3781
	Disappoint2,
	// Token: 0x04000EC6 RID: 3782
	Drool,
	// Token: 0x04000EC7 RID: 3783
	Happy,
	// Token: 0x04000EC8 RID: 3784
	Heart,
	// Token: 0x04000EC9 RID: 3785
	Kiss,
	// Token: 0x04000ECA RID: 3786
	Laugh,
	// Token: 0x04000ECB RID: 3787
	LaughCry,
	// Token: 0x04000ECC RID: 3788
	LaughSweat,
	// Token: 0x04000ECD RID: 3789
	Poop,
	// Token: 0x04000ECE RID: 3790
	Sad,
	// Token: 0x04000ECF RID: 3791
	Shocked,
	// Token: 0x04000ED0 RID: 3792
	Sick1,
	// Token: 0x04000ED1 RID: 3793
	Sick2,
	// Token: 0x04000ED2 RID: 3794
	Sick3,
	// Token: 0x04000ED3 RID: 3795
	Silly,
	// Token: 0x04000ED4 RID: 3796
	TearyEye,
	// Token: 0x04000ED5 RID: 3797
	Silence,
	// Token: 0x04000ED6 RID: 3798
	Exclaimation
}
