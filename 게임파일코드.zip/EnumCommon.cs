﻿using System;
using UnityEngine;

// Token: 0x020000D6 RID: 214
public class EnumCommon : MonoBehaviour
{
}
