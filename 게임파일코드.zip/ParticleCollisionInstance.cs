﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000149 RID: 329
public class ParticleCollisionInstance : MonoBehaviour
{
	// Token: 0x0600094D RID: 2381 RVA: 0x000446D6 File Offset: 0x000428D6
	private void Start()
	{
		this.part = base.GetComponent<ParticleSystem>();
	}

	// Token: 0x0600094E RID: 2382 RVA: 0x000446E4 File Offset: 0x000428E4
	private void OnParticleCollision(GameObject other)
	{
		int num = ParticlePhysicsExtensions.GetCollisionEvents(this.part, other, this.collisionEvents);
		for (int i = 0; i < num; i++)
		{
			GameObject[] effectsOnCollision = this.EffectsOnCollision;
			for (int j = 0; j < effectsOnCollision.Length; j++)
			{
				GameObject gameObject = Object.Instantiate<GameObject>(effectsOnCollision[j], this.collisionEvents[i].intersection + this.collisionEvents[i].normal * this.Offset, default(Quaternion));
				if (!this.UseWorldSpacePosition)
				{
					gameObject.transform.parent = base.transform;
				}
				if (this.UseFirePointRotation)
				{
					gameObject.transform.LookAt(base.transform.position);
				}
				else if (this.rotationOffset != Vector3.zero && this.useOnlyRotationOffset)
				{
					gameObject.transform.rotation = Quaternion.Euler(this.rotationOffset);
				}
				else
				{
					gameObject.transform.LookAt(this.collisionEvents[i].intersection + this.collisionEvents[i].normal);
					gameObject.transform.rotation *= Quaternion.Euler(this.rotationOffset);
				}
				Object.Destroy(gameObject, this.DestroyTimeDelay);
			}
		}
		if (this.DestoyMainEffect)
		{
			Object.Destroy(base.gameObject, this.DestroyTimeDelay + 0.5f);
		}
	}

	// Token: 0x04001187 RID: 4487
	public GameObject[] EffectsOnCollision;

	// Token: 0x04001188 RID: 4488
	public float DestroyTimeDelay = 5f;

	// Token: 0x04001189 RID: 4489
	public bool UseWorldSpacePosition;

	// Token: 0x0400118A RID: 4490
	public float Offset;

	// Token: 0x0400118B RID: 4491
	public Vector3 rotationOffset = new Vector3(0f, 0f, 0f);

	// Token: 0x0400118C RID: 4492
	public bool useOnlyRotationOffset = true;

	// Token: 0x0400118D RID: 4493
	public bool UseFirePointRotation;

	// Token: 0x0400118E RID: 4494
	public bool DestoyMainEffect = true;

	// Token: 0x0400118F RID: 4495
	private ParticleSystem part;

	// Token: 0x04001190 RID: 4496
	private List<ParticleCollisionEvent> collisionEvents = new List<ParticleCollisionEvent>();

	// Token: 0x04001191 RID: 4497
	private ParticleSystem ps;
}
