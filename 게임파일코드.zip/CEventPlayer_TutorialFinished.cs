﻿using System;

// Token: 0x020000AD RID: 173
public class CEventPlayer_TutorialFinished : CEvent
{
	// Token: 0x1700000B RID: 11
	// (get) Token: 0x060006F6 RID: 1782 RVA: 0x0003924B File Offset: 0x0003744B
	// (set) Token: 0x060006F7 RID: 1783 RVA: 0x00039253 File Offset: 0x00037453
	public bool m_IsFinished { get; private set; }

	// Token: 0x060006F8 RID: 1784 RVA: 0x0003925C File Offset: 0x0003745C
	public CEventPlayer_TutorialFinished(bool isFinished)
	{
		this.m_IsFinished = isFinished;
	}
}
