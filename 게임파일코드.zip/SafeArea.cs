﻿using System;
using UnityEngine;

// Token: 0x02000121 RID: 289
public class SafeArea : MonoBehaviour
{
	// Token: 0x06000874 RID: 2164 RVA: 0x0003FF20 File Offset: 0x0003E120
	private void Awake()
	{
		this.Panel = base.GetComponent<RectTransform>();
		if (!this.m_IsManual)
		{
			this.Refresh();
		}
	}

	// Token: 0x06000875 RID: 2165 RVA: 0x0003FF3C File Offset: 0x0003E13C
	private void Update()
	{
		if (this.m_IsManual)
		{
			return;
		}
		this.Refresh();
	}

	// Token: 0x06000876 RID: 2166 RVA: 0x0003FF50 File Offset: 0x0003E150
	public void Refresh()
	{
		if (!base.enabled)
		{
			return;
		}
		Rect safeArea = this.GetSafeArea();
		if (safeArea != this.LastSafeArea)
		{
			this.ApplySafeArea(safeArea);
		}
	}

	// Token: 0x06000877 RID: 2167 RVA: 0x0003FF82 File Offset: 0x0003E182
	private Rect GetSafeArea()
	{
		bool debugTestArea = this.m_DebugTestArea;
		return Screen.safeArea;
	}

	// Token: 0x06000878 RID: 2168 RVA: 0x0003FF90 File Offset: 0x0003E190
	private void ApplySafeArea(Rect r)
	{
		this.LastSafeArea = r;
		Vector2 position = r.position;
		Vector2 anchorMax = r.position + r.size;
		position.x /= (float)Screen.width;
		position.y /= (float)Screen.height;
		anchorMax.x /= (float)Screen.width;
		anchorMax.y /= (float)Screen.height;
		position.x = this.Panel.anchorMin.x;
		anchorMax.x = this.Panel.anchorMax.x;
		this.Panel.anchorMin = position;
		this.Panel.anchorMax = anchorMax;
		Debug.LogFormat("New safe area applied to {0}: x={1}, y={2}, w={3}, h={4} on full extents w={5}, h={6}", new object[]
		{
			base.name,
			r.x,
			r.y,
			r.width,
			r.height,
			Screen.width,
			Screen.height
		});
	}

	// Token: 0x0400104B RID: 4171
	private RectTransform Panel;

	// Token: 0x0400104C RID: 4172
	private Rect LastSafeArea = new Rect(0f, 0f, 0f, 0f);

	// Token: 0x0400104D RID: 4173
	public Rect m_Test;

	// Token: 0x0400104E RID: 4174
	private Rect m_OffsetUI;

	// Token: 0x0400104F RID: 4175
	public bool m_DebugTestArea;

	// Token: 0x04001050 RID: 4176
	public bool m_IsManual;
}
