﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x02000115 RID: 277
public class VirtualKeyboardScreenUI : UIScreenBase
{
	// Token: 0x06000823 RID: 2083 RVA: 0x0003D68C File Offset: 0x0003B88C
	protected override void Awake()
	{
		base.Awake();
		for (int i = 0; i < this.m_VirtualKeyboardBtnKeyList.Count; i++)
		{
			this.m_VirtualKeyboardBtnKeyList[i].Init(this);
		}
	}

	// Token: 0x06000824 RID: 2084 RVA: 0x0003D6C8 File Offset: 0x0003B8C8
	protected override void RunUpdate()
	{
		base.RunUpdate();
		this.m_Timer += Time.deltaTime;
		if (this.m_Timer >= 1f)
		{
			this.m_Timer = 0f;
			this.m_ShowLineCursor = !this.m_ShowLineCursor;
			this.UpdateOutputText();
		}
	}

	// Token: 0x06000825 RID: 2085 RVA: 0x0003D71C File Offset: 0x0003B91C
	private void UpdateOutputText()
	{
		if (this.m_ShowLineCursor)
		{
			this.m_OutputShowText.text = this.m_CurrentString + "|";
			return;
		}
		this.m_OutputShowText.text = this.m_CurrentString + "<alpha=#00>|</color>";
	}

	// Token: 0x06000826 RID: 2086 RVA: 0x0003D768 File Offset: 0x0003B968
	public void SetInitialText(string text, TMP_InputField inputText)
	{
		this.m_InputText = inputText;
		this.m_CurrentString = text;
		this.UpdateOutputText();
	}

	// Token: 0x06000827 RID: 2087 RVA: 0x0003D77E File Offset: 0x0003B97E
	public void OnPressButton(string text)
	{
		if (this.m_CurrentString.Length >= this.m_MaxLength)
		{
			return;
		}
		this.m_CurrentString += text;
		this.UpdateOutputText();
	}

	// Token: 0x06000828 RID: 2088 RVA: 0x0003D7AC File Offset: 0x0003B9AC
	public void OnPressBackKey()
	{
		if (this.m_CurrentString.Length > 0)
		{
			this.m_CurrentString = this.m_CurrentString.Remove(this.m_CurrentString.Length - 1, 1);
			this.UpdateOutputText();
		}
	}

	// Token: 0x06000829 RID: 2089 RVA: 0x0003D7E1 File Offset: 0x0003B9E1
	public void OnPressCapitalKey()
	{
		this.ToggleAltActive();
	}

	// Token: 0x0600082A RID: 2090 RVA: 0x0003D7E9 File Offset: 0x0003B9E9
	public void OnPressDoneKey()
	{
		this.m_InputText.text = this.m_CurrentString;
		this.m_InputText.onEndEdit.Invoke(this.m_CurrentString);
		base.CloseScreen();
	}

	// Token: 0x0600082B RID: 2091 RVA: 0x0003D818 File Offset: 0x0003BA18
	public void OnPressSpaceKey()
	{
		if (this.m_CurrentString.Length >= this.m_MaxLength)
		{
			return;
		}
		this.m_CurrentString += " ";
		this.UpdateOutputText();
	}

	// Token: 0x0600082C RID: 2092 RVA: 0x0003D84C File Offset: 0x0003BA4C
	public void ToggleAltActive()
	{
		this.m_IsAltActive = !this.m_IsAltActive;
		for (int i = 0; i < this.m_VirtualKeyboardBtnKeyList.Count; i++)
		{
			this.m_VirtualKeyboardBtnKeyList[i].EvaluateKey();
		}
	}

	// Token: 0x04000F77 RID: 3959
	public TextMeshProUGUI m_OutputShowText;

	// Token: 0x04000F78 RID: 3960
	private TMP_InputField m_InputText;

	// Token: 0x04000F79 RID: 3961
	public List<VirtualKeyboardBtnKey> m_VirtualKeyboardBtnKeyList;

	// Token: 0x04000F7A RID: 3962
	public bool m_IsAltActive;

	// Token: 0x04000F7B RID: 3963
	private bool m_ShowLineCursor;

	// Token: 0x04000F7C RID: 3964
	private int m_MaxLength = 30;

	// Token: 0x04000F7D RID: 3965
	private float m_Timer;

	// Token: 0x04000F7E RID: 3966
	private string m_CurrentString = "";
}
