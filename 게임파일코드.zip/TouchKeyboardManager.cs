﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x0200011F RID: 287
public class TouchKeyboardManager : CSingleton<TouchKeyboardManager>
{
	// Token: 0x06000869 RID: 2153 RVA: 0x0003FAFC File Offset: 0x0003DCFC
	public static bool StartInput(string startText, int maxLength, bool IsHidden = false, bool doSpecialCharacterCheck = true)
	{
		if (TouchKeyboardManager.m_IsWaitingInput)
		{
			return false;
		}
		if (TouchKeyboardManager.gt == null)
		{
			TouchKeyboardManager.gt = CSingleton<TouchKeyboardManager>.Instance.gameObject.AddComponent<TextMeshProUGUI>();
		}
		TouchKeyboardManager.m_IsWaitingInput = true;
		TouchKeyboardManager.m_DoSpecialCharacterCheck = doSpecialCharacterCheck;
		if (startText == null)
		{
			startText = "";
		}
		TouchKeyboardManager.gt.text = startText;
		if (maxLength == 0)
		{
			TouchKeyboardManager.m_MaxLength = 1000;
		}
		else
		{
			TouchKeyboardManager.m_MaxLength = maxLength;
		}
		TouchKeyboardManager.inputText = startText;
		TouchKeyboardManager.touchScreenKeyboard = TouchScreenKeyboard.Open(TouchKeyboardManager.inputText, TouchScreenKeyboardType.ASCIICapable, false, false, IsHidden);
		return TouchKeyboardManager.touchScreenKeyboard != null;
	}

	// Token: 0x0600086A RID: 2154 RVA: 0x0003FB8C File Offset: 0x0003DD8C
	public static void CancelInput()
	{
		TouchKeyboardManager.touchScreenKeyboard = null;
		TouchKeyboardManager.m_IsWaitingInput = false;
	}

	// Token: 0x0600086B RID: 2155 RVA: 0x0003FB9A File Offset: 0x0003DD9A
	private void Update()
	{
		if (TouchKeyboardManager.touchScreenKeyboard == null)
		{
			return;
		}
		this.DetectPCInput();
		this.DetectMobileInput();
	}

	// Token: 0x0600086C RID: 2156 RVA: 0x0003FBB0 File Offset: 0x0003DDB0
	private void DetectMobileInput()
	{
		if (!Application.isMobilePlatform)
		{
			return;
		}
		TouchKeyboardManager.inputText = TouchKeyboardManager.touchScreenKeyboard.text;
		if (TouchKeyboardManager.inputText.Length > TouchKeyboardManager.m_MaxLength)
		{
			TouchKeyboardManager.inputText = TouchKeyboardManager.inputText.Substring(0, TouchKeyboardManager.m_MaxLength);
		}
		if (TouchKeyboardManager.touchScreenKeyboard.status == TouchScreenKeyboard.Status.Done || TouchKeyboardManager.touchScreenKeyboard.status == TouchScreenKeyboard.Status.LostFocus)
		{
			string text = TouchKeyboardManager.inputText;
			if (text != null && text != "" && TouchKeyboardManager.m_DoSpecialCharacterCheck)
			{
				text = text.Replace('_', ' ');
				text = text.Replace(',', ' ');
				text = text.Replace('`', ' ');
			}
			Debug.Log("User typed in " + text);
			CEventManager.QueueEvent(new CEventPlayer_WaitForKeyboardInput(text));
			TouchKeyboardManager.touchScreenKeyboard = null;
			TouchKeyboardManager.m_IsWaitingInput = false;
			return;
		}
		if (TouchKeyboardManager.touchScreenKeyboard.status == TouchScreenKeyboard.Status.Canceled)
		{
			CEventManager.QueueEvent(new CEventPlayer_WaitForKeyboardInput(""));
			TouchKeyboardManager.touchScreenKeyboard = null;
			TouchKeyboardManager.m_IsWaitingInput = false;
		}
	}

	// Token: 0x0600086D RID: 2157 RVA: 0x0003FCA4 File Offset: 0x0003DEA4
	private void DetectPCInput()
	{
		if (Application.isMobilePlatform)
		{
			return;
		}
		Debug.Log(TouchKeyboardManager.gt.text);
		foreach (char c in Input.inputString)
		{
			if (c == '\b')
			{
				if (TouchKeyboardManager.gt.text.Length != 0)
				{
				}
			}
			else if (c == '\n' || c == '\r')
			{
				string text = TouchKeyboardManager.gt.text;
				if (text != null && text != "" && TouchKeyboardManager.m_DoSpecialCharacterCheck)
				{
					text = text.Replace('_', ' ');
					text = text.Replace(',', ' ');
					text = text.Replace('`', ' ');
				}
				Debug.Log("User typed in " + text);
				CEventManager.QueueEvent(new CEventPlayer_WaitForKeyboardInput(text));
				TouchKeyboardManager.touchScreenKeyboard = null;
				TouchKeyboardManager.m_IsWaitingInput = false;
			}
			else
			{
				TextMeshProUGUI textMeshProUGUI = TouchKeyboardManager.gt;
				textMeshProUGUI.text += c.ToString();
			}
		}
	}

	// Token: 0x04001040 RID: 4160
	private static TouchScreenKeyboard touchScreenKeyboard;

	// Token: 0x04001041 RID: 4161
	private static string inputText = string.Empty;

	// Token: 0x04001042 RID: 4162
	private static int m_MaxLength = 1000;

	// Token: 0x04001043 RID: 4163
	private static TextMeshProUGUI gt;

	// Token: 0x04001044 RID: 4164
	private static bool m_IsWaitingInput;

	// Token: 0x04001045 RID: 4165
	private static bool m_DoSpecialCharacterCheck = true;
}
