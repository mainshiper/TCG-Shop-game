﻿using System;
using System.Collections;
using System.Collections.Generic;
using I2.Loc;
using TMPro;
using UnityEngine;

// Token: 0x02000063 RID: 99
public class EndOfDayReportScreen : CSingleton<EndOfDayReportScreen>
{
	// Token: 0x0600044B RID: 1099 RVA: 0x00025A70 File Offset: 0x00023C70
	public static void OpenScreen()
	{
		if (CSingleton<EndOfDayReportScreen>.Instance.m_ScreenGrp.activeSelf)
		{
			EndOfDayReportScreen.CloseScreen();
			return;
		}
		CSingleton<EndOfDayReportScreen>.Instance.m_CurrentDayText.text = LocalizationManager.GetTranslation("Day XXX", true, 0, true, false, null, null, true).Replace("XXX", (CPlayerData.m_CurrentDay + 1).ToString());
		CSingleton<EndOfDayReportScreen>.Instance.SetAllLerpNumber(CPlayerData.m_GameReportDataCollect);
		CSingleton<EndOfDayReportScreen>.Instance.m_IsLerpingNumber = true;
		CSingleton<EndOfDayReportScreen>.Instance.m_CurrentReportTextIndex = 0;
		CSingleton<InteractionPlayerController>.Instance.ShowCursor();
		CSingleton<InteractionPlayerController>.Instance.EnterLockMoveMode();
		CSingleton<EndOfDayReportScreen>.Instance.m_NextDayButton.SetActive(false);
		CSingleton<EndOfDayReportScreen>.Instance.m_ScreenGrp.SetActive(true);
		CSingleton<EndOfDayReportScreen>.Instance.m_LoadingScreenGrp.SetActive(false);
		CSingleton<EndOfDayReportScreen>.Instance.m_IsActive = true;
		CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
		CSingleton<CGameManager>.Instance.SaveGameData(0);
	}

	// Token: 0x0600044C RID: 1100 RVA: 0x00025B58 File Offset: 0x00023D58
	private void SetAllLerpNumber(GameReportDataCollect gameReportDataCollect)
	{
		float lerpTime = 0.3f;
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[0].SetNumber(0f, (float)gameReportDataCollect.customerVisited, lerpTime, this.m_GreenColor, this.m_RedColor, this.m_WhiteColor);
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[1].SetNumber(0f, (float)gameReportDataCollect.checkoutCount, lerpTime, this.m_GreenColor, this.m_RedColor, this.m_WhiteColor);
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[2].SetNumber(0f, (float)gameReportDataCollect.customerDisatisfied, lerpTime, this.m_RedColor, this.m_GreenColor, this.m_GreenColor);
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[3].SetNumber(0f, (float)gameReportDataCollect.customerBoughtItem, lerpTime, this.m_GreenColor, this.m_RedColor, this.m_WhiteColor);
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[4].SetNumber(0f, (float)gameReportDataCollect.customerBoughtCard, lerpTime, this.m_GreenColor, this.m_RedColor, this.m_WhiteColor);
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[5].SetNumber(0f, (float)gameReportDataCollect.customerPlayed, lerpTime, this.m_GreenColor, this.m_RedColor, this.m_WhiteColor);
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[6].SetNumber(0f, (float)gameReportDataCollect.storeExpGained, lerpTime, this.m_WhiteColor, this.m_WhiteColor, this.m_WhiteColor);
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[7].SetNumber(0f, (float)gameReportDataCollect.itemAmountSold, lerpTime, this.m_GreenColor, this.m_RedColor, this.m_WhiteColor);
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[8].SetNumber(0f, (float)gameReportDataCollect.cardAmountSold, lerpTime, this.m_GreenColor, this.m_RedColor, this.m_WhiteColor);
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[9].SetNumber(0f, gameReportDataCollect.totalPlayTableTime * 60f, lerpTime, this.m_GreenColor, this.m_RedColor, this.m_WhiteColor);
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[10].SetNumber(0f, (float)gameReportDataCollect.storeLevelGained, lerpTime, this.m_WhiteColor, this.m_WhiteColor, this.m_WhiteColor);
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[11].SetNumber(0f, gameReportDataCollect.totalItemEarning, lerpTime, this.m_GreenColor, this.m_RedColor, this.m_WhiteColor);
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[12].SetNumber(0f, gameReportDataCollect.totalCardEarning, lerpTime, this.m_GreenColor, this.m_RedColor, this.m_WhiteColor);
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[13].SetNumber(0f, gameReportDataCollect.totalPlayTableEarning, lerpTime, this.m_GreenColor, this.m_RedColor, this.m_WhiteColor);
		float num = gameReportDataCollect.totalItemEarning + gameReportDataCollect.totalCardEarning + gameReportDataCollect.totalPlayTableEarning;
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[14].SetNumber(0f, num, lerpTime, this.m_GreenColor, this.m_RedColor, this.m_WhiteColor);
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[15].SetNumber(0f, gameReportDataCollect.supplyCost, lerpTime, this.m_GreenColor, this.m_RedColor, this.m_WhiteColor);
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[16].SetNumber(0f, gameReportDataCollect.upgradeCost, lerpTime, this.m_GreenColor, this.m_RedColor, this.m_WhiteColor);
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[17].SetNumber(0f, gameReportDataCollect.employeeCost, lerpTime, this.m_GreenColor, this.m_RedColor, this.m_WhiteColor);
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[18].SetNumber(0f, gameReportDataCollect.rentCost + gameReportDataCollect.billCost, lerpTime, this.m_GreenColor, this.m_RedColor, this.m_WhiteColor);
		float num2 = gameReportDataCollect.supplyCost + gameReportDataCollect.upgradeCost + gameReportDataCollect.employeeCost + gameReportDataCollect.rentCost + gameReportDataCollect.billCost;
		float num3 = num + num2;
		CSingleton<EndOfDayReportScreen>.Instance.m_EndDayReportTextUIList[19].SetNumber(0f, num3, lerpTime, this.m_GreenColor, this.m_RedColor, this.m_WhiteColor);
		this.m_TotalProfit = num3;
	}

	// Token: 0x0600044D RID: 1101 RVA: 0x00025FC4 File Offset: 0x000241C4
	public static void CloseScreen()
	{
		CSingleton<InteractionPlayerController>.Instance.HideCursor();
		CSingleton<InteractionPlayerController>.Instance.ExitLockMoveMode();
		CSingleton<EndOfDayReportScreen>.Instance.m_ScreenGrp.SetActive(false);
		CSingleton<EndOfDayReportScreen>.Instance.m_IsActive = false;
		GameReportDataCollect item = default(GameReportDataCollect);
		item.CopyData(CPlayerData.m_GameReportDataCollect);
		CPlayerData.m_GameReportDataCollectPastList.Add(item);
		if (CPlayerData.m_GameReportDataCollectPastList.Count > 30)
		{
			CPlayerData.m_GameReportDataCollectPastList.RemoveAt(0);
		}
		CPlayerData.m_GameReportDataCollect.ResetData();
	}

	// Token: 0x0600044E RID: 1102 RVA: 0x00026044 File Offset: 0x00024244
	public void OnPressGoNextDay()
	{
		if (this.m_IsLoadingNextDay)
		{
			return;
		}
		this.m_IsLoadingNextDay = true;
		CSingleton<EndOfDayReportScreen>.Instance.m_LoadingCurrentDayText.text = LocalizationManager.GetTranslation("Day XXX", true, 0, true, false, null, null, true).Replace("XXX", (CPlayerData.m_CurrentDay + 1).ToString());
		CSingleton<EndOfDayReportScreen>.Instance.m_LoadingNextDayText.text = LocalizationManager.GetTranslation("Day XXX", true, 0, true, false, null, null, true).Replace("XXX", (CPlayerData.m_CurrentDay + 2).ToString());
		base.StartCoroutine(this.DelayGoNextDay());
	}

	// Token: 0x0600044F RID: 1103 RVA: 0x000260E0 File Offset: 0x000242E0
	private IEnumerator DelayGoNextDay()
	{
		this.m_LoadingScreenGrp.SetActive(true);
		yield return new WaitForSeconds(0.5f);
		EndOfDayReportScreen.CloseScreen();
		LightManager.GoNextDay();
		yield return new WaitForSeconds(2.5f);
		this.m_LoadingScreenGrp.SetActive(false);
		this.m_IsLoadingNextDay = false;
		if (CPlayerData.m_PendingGameEventFormat != EGameEventFormat.None)
		{
			CPlayerData.m_GameEventFormat = CPlayerData.m_PendingGameEventFormat;
			CPlayerData.m_PendingGameEventFormat = EGameEventFormat.None;
		}
		if (CPlayerData.m_GameEventExpansionType != CPlayerData.m_PendingGameEventExpansionType)
		{
			CPlayerData.m_GameEventExpansionType = CPlayerData.m_PendingGameEventExpansionType;
		}
		GameEventData gameEventData = InventoryBase.GetGameEventData(CPlayerData.m_GameEventFormat);
		if (gameEventData.hostEventCost > 0)
		{
			CEventManager.QueueEvent(new CEventPlayer_ReduceCoin((float)gameEventData.hostEventCost, false));
			CPlayerData.m_GameReportDataCollect.supplyCost = CPlayerData.m_GameReportDataCollect.supplyCost - (float)gameEventData.hostEventCost;
			CPlayerData.m_GameReportDataCollectPermanent.supplyCost = CPlayerData.m_GameReportDataCollectPermanent.supplyCost - (float)gameEventData.hostEventCost;
		}
		yield break;
	}

	// Token: 0x06000450 RID: 1104 RVA: 0x000260F0 File Offset: 0x000242F0
	public void OnPressGoNextButton()
	{
		if (this.m_IsLerpingNumber)
		{
			if (this.m_CurrentReportTextIndex < this.m_EndDayReportTextUIList.Count)
			{
				this.m_EndDayReportTextUIList[this.m_CurrentReportTextIndex].EndLerpInstantly();
				return;
			}
		}
		else if (!this.m_IsLoadingNextDay && LightManager.GetHasDayEnded())
		{
			this.OnPressGoNextDay();
		}
	}

	// Token: 0x06000451 RID: 1105 RVA: 0x00026144 File Offset: 0x00024344
	private void Update()
	{
		if (this.m_IsActive)
		{
			if (InputManager.GetKeyDownAction(EGameAction.InteractLeft) || InputManager.GetKeyDownAction(EGameAction.GoNextDay))
			{
				this.m_IsHoldingMouseDown = true;
			}
			if (InputManager.GetKeyUpAction(EGameAction.InteractLeft) || InputManager.GetKeyUpAction(EGameAction.GoNextDay))
			{
				this.m_IsHoldingMouseDown = false;
			}
			if (this.m_IsHoldingMouseDown)
			{
				this.m_MouseDownTime += Time.deltaTime;
				if (this.m_MouseDownTime >= this.m_MouseHoldAutoFireRate)
				{
					this.OnPressGoNextButton();
					this.m_MouseDownTime = 0f;
				}
			}
			else if (this.m_MouseDownTime > 0f)
			{
				this.m_MouseDownTime = 0f;
				this.OnPressGoNextButton();
			}
			if (this.m_IsLerpingNumber)
			{
				if (this.m_CurrentReportTextIndex < this.m_EndDayReportTextUIList.Count)
				{
					if (!this.m_EndDayReportTextUIList[this.m_CurrentReportTextIndex].IsLerpEnded())
					{
						this.m_EndDayReportTextUIList[this.m_CurrentReportTextIndex].UpdateLerp();
						return;
					}
					this.m_CurrentReportTextIndex++;
					return;
				}
				else
				{
					this.m_MouseDownTime = 0f;
					this.m_IsLerpingNumber = false;
					this.m_IsHoldingMouseDown = false;
					this.m_NextDayButton.SetActive(true);
					AchievementManager.OnDailyProfitReached(this.m_TotalProfit);
				}
			}
		}
	}

	// Token: 0x06000452 RID: 1106 RVA: 0x00026273 File Offset: 0x00024473
	public static bool IsActive()
	{
		return CSingleton<EndOfDayReportScreen>.Instance.m_IsActive;
	}

	// Token: 0x04000537 RID: 1335
	public GameObject m_ScreenGrp;

	// Token: 0x04000538 RID: 1336
	public GameObject m_LoadingScreenGrp;

	// Token: 0x04000539 RID: 1337
	public GameObject m_NextDayButton;

	// Token: 0x0400053A RID: 1338
	public List<EndDayReportTextUI> m_EndDayReportTextUIList;

	// Token: 0x0400053B RID: 1339
	private int m_CurrentReportTextIndex;

	// Token: 0x0400053C RID: 1340
	public TextMeshProUGUI m_CurrentDayText;

	// Token: 0x0400053D RID: 1341
	public TextMeshProUGUI m_LoadingCurrentDayText;

	// Token: 0x0400053E RID: 1342
	public TextMeshProUGUI m_LoadingNextDayText;

	// Token: 0x0400053F RID: 1343
	public InputTooltipUI m_NextDayTooltipUI;

	// Token: 0x04000540 RID: 1344
	public Color m_GreenColor;

	// Token: 0x04000541 RID: 1345
	public Color m_RedColor;

	// Token: 0x04000542 RID: 1346
	public Color m_WhiteColor;

	// Token: 0x04000543 RID: 1347
	private bool m_IsActive;

	// Token: 0x04000544 RID: 1348
	private bool m_IsLoadingNextDay;

	// Token: 0x04000545 RID: 1349
	private bool m_IsLerpingNumber;

	// Token: 0x04000546 RID: 1350
	private bool m_IsHoldingMouseDown;

	// Token: 0x04000547 RID: 1351
	private float m_MouseDownTime;

	// Token: 0x04000548 RID: 1352
	private float m_MouseHoldAutoFireRate = 0.05f;

	// Token: 0x04000549 RID: 1353
	private float m_TotalProfit;
}
