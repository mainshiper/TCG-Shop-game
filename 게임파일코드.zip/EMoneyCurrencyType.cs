﻿using System;

// Token: 0x020000E7 RID: 231
public enum EMoneyCurrencyType
{
	// Token: 0x04000B2F RID: 2863
	None = -1,
	// Token: 0x04000B30 RID: 2864
	USD,
	// Token: 0x04000B31 RID: 2865
	Euro,
	// Token: 0x04000B32 RID: 2866
	Yen,
	// Token: 0x04000B33 RID: 2867
	GBP,
	// Token: 0x04000B34 RID: 2868
	CNY,
	// Token: 0x04000B35 RID: 2869
	CAD,
	// Token: 0x04000B36 RID: 2870
	AUD,
	// Token: 0x04000B37 RID: 2871
	MYR
}
