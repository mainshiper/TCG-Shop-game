﻿using System;

// Token: 0x020000B2 RID: 178
public class CEventPlayer_AddFame : CEvent
{
	// Token: 0x17000012 RID: 18
	// (get) Token: 0x06000709 RID: 1801 RVA: 0x0003931B File Offset: 0x0003751B
	// (set) Token: 0x0600070A RID: 1802 RVA: 0x00039323 File Offset: 0x00037523
	public int m_FameValue { get; private set; }

	// Token: 0x17000013 RID: 19
	// (get) Token: 0x0600070B RID: 1803 RVA: 0x0003932C File Offset: 0x0003752C
	// (set) Token: 0x0600070C RID: 1804 RVA: 0x00039334 File Offset: 0x00037534
	public bool m_NoLerp { get; private set; }

	// Token: 0x0600070D RID: 1805 RVA: 0x0003933D File Offset: 0x0003753D
	public CEventPlayer_AddFame(int fameValue, bool noLerp = false)
	{
		this.m_FameValue = fameValue;
		this.m_NoLerp = noLerp;
	}
}
