﻿using System;

// Token: 0x020000B8 RID: 184
public class CEventPlayer_ItemPriceChanged : CEvent
{
	// Token: 0x1700001A RID: 26
	// (get) Token: 0x0600071F RID: 1823 RVA: 0x0003940B File Offset: 0x0003760B
	// (set) Token: 0x06000720 RID: 1824 RVA: 0x00039413 File Offset: 0x00037613
	public EItemType m_ItemType { get; private set; }

	// Token: 0x1700001B RID: 27
	// (get) Token: 0x06000721 RID: 1825 RVA: 0x0003941C File Offset: 0x0003761C
	// (set) Token: 0x06000722 RID: 1826 RVA: 0x00039424 File Offset: 0x00037624
	public float m_Price { get; private set; }

	// Token: 0x06000723 RID: 1827 RVA: 0x0003942D File Offset: 0x0003762D
	public CEventPlayer_ItemPriceChanged(EItemType itemType, float price)
	{
		this.m_ItemType = itemType;
		this.m_Price = price;
	}
}
