﻿using System;
using UnityEngine;

// Token: 0x02000032 RID: 50
[Serializable]
public class ItemMeshData
{
	// Token: 0x04000311 RID: 785
	public string name;

	// Token: 0x04000312 RID: 786
	public Mesh mesh;

	// Token: 0x04000313 RID: 787
	public Material material;

	// Token: 0x04000314 RID: 788
	public Mesh meshSecondary;

	// Token: 0x04000315 RID: 789
	public Material materialSecondary;
}
