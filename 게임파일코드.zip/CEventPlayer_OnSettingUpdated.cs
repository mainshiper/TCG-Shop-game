﻿using System;

// Token: 0x020000C2 RID: 194
public class CEventPlayer_OnSettingUpdated : CEvent
{
}
