﻿using System;
using UnityEngine;

// Token: 0x0200001A RID: 26
public class InteractableCardPriceTag : InteractableObject
{
	// Token: 0x0600013A RID: 314 RVA: 0x0001035A File Offset: 0x0000E55A
	public void SetPriceTagUI(UI_PriceTag PriceTagUI)
	{
		this.m_PriceTagUI = PriceTagUI;
	}

	// Token: 0x0600013B RID: 315 RVA: 0x00010363 File Offset: 0x0000E563
	public UI_PriceTag GetPriceTagUI()
	{
		return this.m_PriceTagUI;
	}

	// Token: 0x0600013C RID: 316 RVA: 0x0001036B File Offset: 0x0000E56B
	public void SetCardData(CardData cardData)
	{
		this.m_PriceTagUI.SetCardData(cardData);
	}

	// Token: 0x0600013D RID: 317 RVA: 0x00010379 File Offset: 0x0000E579
	public override void OnMouseButtonUp()
	{
		CSingleton<SetItemPriceScreen>.Instance.OpenSetCardPriceScreen(this.m_PriceTagUI.GetCardData());
	}

	// Token: 0x0600013E RID: 318 RVA: 0x00010390 File Offset: 0x0000E590
	public void SetVisibility(bool isVisible)
	{
		base.gameObject.SetActive(isVisible);
		this.m_PriceTagUI.gameObject.SetActive(isVisible);
	}

	// Token: 0x0600013F RID: 319 RVA: 0x000103AF File Offset: 0x0000E5AF
	public void SetPriceText(float price)
	{
		this.m_PriceTagUI.SetPriceText(price);
	}

	// Token: 0x06000140 RID: 320 RVA: 0x000103BD File Offset: 0x0000E5BD
	public void RefreshPriceText()
	{
		this.m_PriceTagUI.RefreshPriceText();
	}

	// Token: 0x06000141 RID: 321 RVA: 0x000103CA File Offset: 0x0000E5CA
	public void SetPriceTagScale(float scale)
	{
		this.m_PriceTagUI.transform.localScale = Vector3.one * scale;
	}

	// Token: 0x040001AB RID: 427
	public UI_PriceTag m_PriceTagUI;
}
