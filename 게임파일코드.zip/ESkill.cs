﻿using System;

// Token: 0x020000EB RID: 235
public enum ESkill
{
	// Token: 0x04000B7C RID: 2940
	DoNothing = -2,
	// Token: 0x04000B7D RID: 2941
	Charging,
	// Token: 0x04000B7E RID: 2942
	None,
	// Token: 0x04000B7F RID: 2943
	FireClaw,
	// Token: 0x04000B80 RID: 2944
	BlazingClaw,
	// Token: 0x04000B81 RID: 2945
	InfernoClaw,
	// Token: 0x04000B82 RID: 2946
	HellfireClaw,
	// Token: 0x04000B83 RID: 2947
	FlamePillar,
	// Token: 0x04000B84 RID: 2948
	BlazingPillar,
	// Token: 0x04000B85 RID: 2949
	InfernoPillar,
	// Token: 0x04000B86 RID: 2950
	SunPillar,
	// Token: 0x04000B87 RID: 2951
	SpitFire,
	// Token: 0x04000B88 RID: 2952
	Fireball,
	// Token: 0x04000B89 RID: 2953
	MegaFlare,
	// Token: 0x04000B8A RID: 2954
	CometStrike,
	// Token: 0x04000B8B RID: 2955
	PiercingHit,
	// Token: 0x04000B8C RID: 2956
	PiercingStrike,
	// Token: 0x04000B8D RID: 2957
	PiercingCrash,
	// Token: 0x04000B8E RID: 2958
	OmegaPierce,
	// Token: 0x04000B8F RID: 2959
	BlitzAttack,
	// Token: 0x04000B90 RID: 2960
	BlitzStrike,
	// Token: 0x04000B91 RID: 2961
	BlitzSmash,
	// Token: 0x04000B92 RID: 2962
	BlitzCrash,
	// Token: 0x04000B93 RID: 2963
	FireWall,
	// Token: 0x04000B94 RID: 2964
	InfernoWall,
	// Token: 0x04000B95 RID: 2965
	BlazingWall,
	// Token: 0x04000B96 RID: 2966
	HellfireWall,
	// Token: 0x04000B97 RID: 2967
	PsychUp,
	// Token: 0x04000B98 RID: 2968
	CriticalWound,
	// Token: 0x04000B99 RID: 2969
	DesperadoHit,
	// Token: 0x04000B9A RID: 2970
	SolarFlare,
	// Token: 0x04000B9B RID: 2971
	Counter,
	// Token: 0x04000B9C RID: 2972
	FrenzyHit,
	// Token: 0x04000B9D RID: 2973
	Charge,
	// Token: 0x04000B9E RID: 2974
	SuperCharge,
	// Token: 0x04000B9F RID: 2975
	MegaCharge,
	// Token: 0x04000BA0 RID: 2976
	GigaCharge,
	// Token: 0x04000BA1 RID: 2977
	StoneWall,
	// Token: 0x04000BA2 RID: 2978
	RockWall,
	// Token: 0x04000BA3 RID: 2979
	GiantWall,
	// Token: 0x04000BA4 RID: 2980
	GigaWall,
	// Token: 0x04000BA5 RID: 2981
	Grow,
	// Token: 0x04000BA6 RID: 2982
	SuperGrow,
	// Token: 0x04000BA7 RID: 2983
	MegaGrow,
	// Token: 0x04000BA8 RID: 2984
	GigaGrow,
	// Token: 0x04000BA9 RID: 2985
	PebbleBlast,
	// Token: 0x04000BAA RID: 2986
	StoneBlast,
	// Token: 0x04000BAB RID: 2987
	RockSmash,
	// Token: 0x04000BAC RID: 2988
	BoulderCrush,
	// Token: 0x04000BAD RID: 2989
	Cover,
	// Token: 0x04000BAE RID: 2990
	Protection,
	// Token: 0x04000BAF RID: 2991
	Safeguard,
	// Token: 0x04000BB0 RID: 2992
	PerfectGuard,
	// Token: 0x04000BB1 RID: 2993
	HardenShell,
	// Token: 0x04000BB2 RID: 2994
	FortifyShell,
	// Token: 0x04000BB3 RID: 2995
	PowerUp,
	// Token: 0x04000BB4 RID: 2996
	Sharpen,
	// Token: 0x04000BB5 RID: 2997
	FuryStrike,
	// Token: 0x04000BB6 RID: 2998
	SwipeAttack,
	// Token: 0x04000BB7 RID: 2999
	Earthquake,
	// Token: 0x04000BB8 RID: 3000
	AncientProtection,
	// Token: 0x04000BB9 RID: 3001
	HealingMist,
	// Token: 0x04000BBA RID: 3002
	HealingShower,
	// Token: 0x04000BBB RID: 3003
	HealingRain,
	// Token: 0x04000BBC RID: 3004
	HealingWaterfall,
	// Token: 0x04000BBD RID: 3005
	EnergyPool,
	// Token: 0x04000BBE RID: 3006
	EnergyFountain,
	// Token: 0x04000BBF RID: 3007
	EnergyRain,
	// Token: 0x04000BC0 RID: 3008
	EnergyFlood,
	// Token: 0x04000BC1 RID: 3009
	DrainHit,
	// Token: 0x04000BC2 RID: 3010
	DrainStrike,
	// Token: 0x04000BC3 RID: 3011
	DrainSmash,
	// Token: 0x04000BC4 RID: 3012
	DrainCrush,
	// Token: 0x04000BC5 RID: 3013
	ColdShot,
	// Token: 0x04000BC6 RID: 3014
	IceBurst,
	// Token: 0x04000BC7 RID: 3015
	IcicleBlast,
	// Token: 0x04000BC8 RID: 3016
	SubzeroBeam,
	// Token: 0x04000BC9 RID: 3017
	RegenPool,
	// Token: 0x04000BCA RID: 3018
	RegenFountain,
	// Token: 0x04000BCB RID: 3019
	RegenRain,
	// Token: 0x04000BCC RID: 3020
	RegenFlood,
	// Token: 0x04000BCD RID: 3021
	Osmosis,
	// Token: 0x04000BCE RID: 3022
	CleansingMist,
	// Token: 0x04000BCF RID: 3023
	IcicleField,
	// Token: 0x04000BD0 RID: 3024
	MassAbsorb,
	// Token: 0x04000BD1 RID: 3025
	Consume,
	// Token: 0x04000BD2 RID: 3026
	Rejuvenate,
	// Token: 0x04000BD3 RID: 3027
	PoisonFang,
	// Token: 0x04000BD4 RID: 3028
	VenomFang,
	// Token: 0x04000BD5 RID: 3029
	ToxicFang,
	// Token: 0x04000BD6 RID: 3030
	AcidFang,
	// Token: 0x04000BD7 RID: 3031
	PoisonBlast,
	// Token: 0x04000BD8 RID: 3032
	VenomBlast,
	// Token: 0x04000BD9 RID: 3033
	ToxicBlast,
	// Token: 0x04000BDA RID: 3034
	AcidBlast,
	// Token: 0x04000BDB RID: 3035
	SandShot,
	// Token: 0x04000BDC RID: 3036
	SandBlast,
	// Token: 0x04000BDD RID: 3037
	SandStorm,
	// Token: 0x04000BDE RID: 3038
	SandHurricane,
	// Token: 0x04000BDF RID: 3039
	PowerDrip,
	// Token: 0x04000BE0 RID: 3040
	PowerLeak,
	// Token: 0x04000BE1 RID: 3041
	Discharge,
	// Token: 0x04000BE2 RID: 3042
	Meltdown,
	// Token: 0x04000BE3 RID: 3043
	AirShot,
	// Token: 0x04000BE4 RID: 3044
	AirCutter,
	// Token: 0x04000BE5 RID: 3045
	SonicBoom,
	// Token: 0x04000BE6 RID: 3046
	WindBlade,
	// Token: 0x04000BE7 RID: 3047
	Berserk,
	// Token: 0x04000BE8 RID: 3048
	FocusFire,
	// Token: 0x04000BE9 RID: 3049
	PoisonMist,
	// Token: 0x04000BEA RID: 3050
	PoisonStorm,
	// Token: 0x04000BEB RID: 3051
	BlindingSmog,
	// Token: 0x04000BEC RID: 3052
	StickyGoo,
	// Token: 0x04000BED RID: 3053
	SpeedUp,
	// Token: 0x04000BEE RID: 3054
	SpeedDown,
	// Token: 0x04000BEF RID: 3055
	SleepShot,
	// Token: 0x04000BF0 RID: 3056
	SleepBlast,
	// Token: 0x04000BF1 RID: 3057
	SleepMist,
	// Token: 0x04000BF2 RID: 3058
	SleepStorm,
	// Token: 0x04000BF3 RID: 3059
	Tornado,
	// Token: 0x04000BF4 RID: 3060
	MassBerserk,
	// Token: 0x04000BF5 RID: 3061
	Tailwind,
	// Token: 0x04000BF6 RID: 3062
	BattleCry
}
