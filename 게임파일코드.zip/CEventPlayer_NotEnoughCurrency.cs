﻿using System;

// Token: 0x020000B1 RID: 177
public class CEventPlayer_NotEnoughCurrency : CEvent
{
	// Token: 0x17000011 RID: 17
	// (get) Token: 0x06000706 RID: 1798 RVA: 0x000392FB File Offset: 0x000374FB
	// (set) Token: 0x06000707 RID: 1799 RVA: 0x00039303 File Offset: 0x00037503
	public int m_ResourceIndex { get; private set; }

	// Token: 0x06000708 RID: 1800 RVA: 0x0003930C File Offset: 0x0003750C
	public CEventPlayer_NotEnoughCurrency(int resourceIndex)
	{
		this.m_ResourceIndex = resourceIndex;
	}
}
