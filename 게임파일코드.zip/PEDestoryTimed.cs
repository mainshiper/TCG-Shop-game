﻿using System;
using UnityEngine;

// Token: 0x0200013F RID: 319
public class PEDestoryTimed : MonoBehaviour
{
	// Token: 0x06000917 RID: 2327 RVA: 0x0004342F File Offset: 0x0004162F
	private void Start()
	{
	}

	// Token: 0x06000918 RID: 2328 RVA: 0x00043431 File Offset: 0x00041631
	private void Update()
	{
	}
}
