﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000056 RID: 86
public class TutorialSubGroup : MonoBehaviour
{
	// Token: 0x060003EF RID: 1007 RVA: 0x000238B4 File Offset: 0x00021AB4
	public void AddTaskValue(float currentValue, ETutorialTaskCondition tutorialTaskCondition)
	{
		if (this.m_TutorialData.tutorialTaskCondition == tutorialTaskCondition)
		{
			this.m_TutorialData.value = this.m_TutorialData.value + currentValue;
			this.m_CurrentValue += currentValue;
			this.EvaluateValueText();
			if (this.m_CurrentValue >= this.m_MaxValue)
			{
				this.m_IsTaskFinish = true;
			}
		}
	}

	// Token: 0x060003F0 RID: 1008 RVA: 0x00023910 File Offset: 0x00021B10
	public bool IsTaskFinish()
	{
		return this.m_IsTaskFinish;
	}

	// Token: 0x060003F1 RID: 1009 RVA: 0x00023918 File Offset: 0x00021B18
	public void OpenScreen()
	{
		this.EvaluateValueText();
		base.gameObject.SetActive(true);
	}

	// Token: 0x060003F2 RID: 1010 RVA: 0x0002392C File Offset: 0x00021B2C
	public void CloseScreen()
	{
		base.gameObject.SetActive(false);
	}

	// Token: 0x060003F3 RID: 1011 RVA: 0x0002393C File Offset: 0x00021B3C
	private void EvaluateValueText()
	{
		if (this.m_IsInt)
		{
			this.m_NumberText.text = Mathf.RoundToInt(this.m_CurrentValue).ToString() + "/" + Mathf.RoundToInt(this.m_MaxValue).ToString();
		}
		else
		{
			this.m_NumberText.text = this.m_CurrentValue.ToString() + "/" + this.m_MaxValue.ToString();
		}
		this.m_NumberText.enabled = this.m_ShowValue;
	}

	// Token: 0x040004B8 RID: 1208
	public GameObject m_ScreenGrp;

	// Token: 0x040004B9 RID: 1209
	public TextMeshProUGUI m_NumberText;

	// Token: 0x040004BA RID: 1210
	public TutorialData m_TutorialData;

	// Token: 0x040004BB RID: 1211
	public bool m_ShowValue = true;

	// Token: 0x040004BC RID: 1212
	public bool m_IsInt;

	// Token: 0x040004BD RID: 1213
	public bool m_IsPrice;

	// Token: 0x040004BE RID: 1214
	private bool m_IsTaskFinish;

	// Token: 0x040004BF RID: 1215
	private float m_CurrentValue;

	// Token: 0x040004C0 RID: 1216
	public float m_MaxValue;
}
