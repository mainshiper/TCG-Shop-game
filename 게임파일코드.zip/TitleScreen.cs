﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200009E RID: 158
public class TitleScreen : MonoBehaviour
{
	// Token: 0x0600062C RID: 1580 RVA: 0x00033138 File Offset: 0x00031338
	private void Start()
	{
		if (CSaveLoad.HasSaveFile(0))
		{
			this.m_ContinueButton.interactable = true;
		}
		else
		{
			this.m_ContinueButton.interactable = false;
		}
		if (!CSaveLoad.HasSaveFile(0) && !CSaveLoad.HasSaveFile(1) && !CSaveLoad.HasSaveFile(2))
		{
			CSaveLoad.HasSaveFile(3);
		}
		this.m_VersionText.text = "v" + Application.version;
		ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension);
	}

	// Token: 0x0600062D RID: 1581 RVA: 0x000331AC File Offset: 0x000313AC
	public void OnPressStartGame()
	{
		if (this.m_IsOpeningLevel)
		{
			return;
		}
		SoundManager.GenericLightTap(1f, 1f);
		if (CSaveLoad.HasSaveFile(0))
		{
			this.m_ConfirmOverwriteSaveScreen.SetActive(true);
			ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension_OverwriteSaveScreen);
			Debug.Log("Has save file, prompt if want to overwrite");
			return;
		}
		this.m_IsOpeningLevel = true;
		CSingleton<CGameManager>.Instance.LoadMainLevelAsync("Start", -1);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension);
	}

	// Token: 0x0600062E RID: 1582 RVA: 0x00033220 File Offset: 0x00031420
	public void OnPressConfirmOverwrite()
	{
		if (this.m_IsOpeningLevel)
		{
			return;
		}
		CSaveLoad.AutoSaveMoveToEmptySaveSlot();
		SoundManager.GenericLightTap(1f, 1f);
		this.m_IsOpeningLevel = true;
		CSingleton<CGameManager>.Instance.LoadMainLevelAsync("Start", -1);
		UnityAnalytic.PressOverwriteSave();
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension_OverwriteSaveScreen);
	}

	// Token: 0x0600062F RID: 1583 RVA: 0x0003327C File Offset: 0x0003147C
	public void OnPressCloseOverwrite()
	{
		SoundManager.GenericLightTap(1f, 1f);
		this.m_ConfirmOverwriteSaveScreen.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension_OverwriteSaveScreen);
	}

	// Token: 0x06000630 RID: 1584 RVA: 0x000332A4 File Offset: 0x000314A4
	public void OnPressLoadGame()
	{
		if (this.m_IsOpeningLevel)
		{
			return;
		}
		SoundManager.GenericLightTap(1f, 1f);
		this.m_IsOpeningLevel = true;
		CSingleton<CGameManager>.Instance.LoadMainLevelAsync("Start", 0);
		UnityAnalytic.PressLoadGame();
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension);
	}

	// Token: 0x06000631 RID: 1585 RVA: 0x000332F0 File Offset: 0x000314F0
	public void OpenLoadGameSlotScreen()
	{
		if (this.m_IsOpeningLevel)
		{
			return;
		}
		SoundManager.GenericLightTap(1f, 1f);
		SaveLoadGameSlotSelectScreen.OpenScreen(false);
	}

	// Token: 0x06000632 RID: 1586 RVA: 0x00033310 File Offset: 0x00031510
	public void OnPressSetting()
	{
		SoundManager.GenericLightTap(1f, 1f);
		SettingScreen.OpenScreen(true);
	}

	// Token: 0x06000633 RID: 1587 RVA: 0x00033327 File Offset: 0x00031527
	public void OnPressQuit()
	{
		SoundManager.GenericLightTap(1f, 1f);
		Application.Quit();
	}

	// Token: 0x06000634 RID: 1588 RVA: 0x0003333D File Offset: 0x0003153D
	public void OnPressWishlistOnSteam()
	{
		Application.OpenURL("https://store.steampowered.com/app/3070070?utm_source=prologue&utm_campaign=prologue1&utm_medium=game");
		UnityAnalytic.PressWishlist(0);
	}

	// Token: 0x06000635 RID: 1589 RVA: 0x0003334F File Offset: 0x0003154F
	public void OnPressFeedbackBtn()
	{
		Application.OpenURL("https://steamcommunity.com/app/3070070/discussions/");
		UnityAnalytic.PressFeedback(0);
	}

	// Token: 0x06000636 RID: 1590 RVA: 0x00033361 File Offset: 0x00031561
	public void OnPressDiscordBtn()
	{
		Application.OpenURL("https://discord.gg/2YaaUZzrRY");
		UnityAnalytic.JoinDiscord();
	}

	// Token: 0x040007FA RID: 2042
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x040007FB RID: 2043
	public ControllerScreenUIExtension m_ControllerScreenUIExtension_OverwriteSaveScreen;

	// Token: 0x040007FC RID: 2044
	public GameObject m_ConfirmOverwriteSaveScreen;

	// Token: 0x040007FD RID: 2045
	public Button m_ContinueButton;

	// Token: 0x040007FE RID: 2046
	public Button m_LoadGameButton;

	// Token: 0x040007FF RID: 2047
	public TextMeshProUGUI m_VersionText;

	// Token: 0x04000800 RID: 2048
	private bool m_IsOpeningLevel;
}
