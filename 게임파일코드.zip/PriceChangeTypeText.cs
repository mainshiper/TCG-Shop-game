﻿using System;
using I2.Loc;

// Token: 0x02000136 RID: 310
[Serializable]
public class PriceChangeTypeText
{
	// Token: 0x060008F9 RID: 2297 RVA: 0x000427C4 File Offset: 0x000409C4
	public string GetName(bool isIncrease)
	{
		if (isIncrease)
		{
			string translation = LocalizationManager.GetTranslation("increase", true, 0, true, false, null, null, true);
			return LocalizationManager.GetTranslation(this.name, true, 0, true, false, null, null, true).Replace("XXX", translation);
		}
		string translation2 = LocalizationManager.GetTranslation("decrease", true, 0, true, false, null, null, true);
		return LocalizationManager.GetTranslation(this.name, true, 0, true, false, null, null, true).Replace("XXX", translation2);
	}

	// Token: 0x04001114 RID: 4372
	public string name;

	// Token: 0x04001115 RID: 4373
	public EPriceChangeType priceChangeType;
}
