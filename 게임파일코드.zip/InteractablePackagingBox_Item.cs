﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000024 RID: 36
public class InteractablePackagingBox_Item : InteractablePackagingBox
{
	// Token: 0x060001C3 RID: 451 RVA: 0x00013B30 File Offset: 0x00011D30
	protected override void Awake()
	{
		base.Awake();
		RestockManager.InitItemPackageBox(this);
		this.m_StaticMeshGrp.gameObject.SetActive(true);
		this.m_RigMeshGrp.gameObject.SetActive(false);
		this.m_ClosedBox.SetActive(!this.m_IsBoxOpened);
		this.m_OpenBox.SetActive(this.m_IsBoxOpened);
		this.m_OutlineClosedBox.SetActive(!this.m_IsBoxOpened);
		this.m_OutlineOpenBox.SetActive(this.m_IsBoxOpened);
	}

	// Token: 0x060001C4 RID: 452 RVA: 0x00013BB8 File Offset: 0x00011DB8
	public override void StartHoldBox(bool isPlayer, Transform holdItemPos)
	{
		if (this.m_IsBeingHold)
		{
			return;
		}
		base.StartHoldBox(isPlayer, holdItemPos);
		this.m_IsStored = false;
		if (!this.m_IsBoxOpened && this.m_ItemCompartment.GetItemType() != EItemType.None && this.m_ItemCompartment.GetItemCount() > 0)
		{
			this.SetPriceTagVisibility(true);
		}
		if (isPlayer)
		{
			this.UpdateToolTip();
			TutorialManager.AddTaskValue(ETutorialTaskCondition.PickupBox, 1f);
			this.m_ItemCompartment.SetIgnoreCull(true);
		}
	}

	// Token: 0x060001C5 RID: 453 RVA: 0x00013C28 File Offset: 0x00011E28
	public override void ThrowBox(bool isPlayer)
	{
		base.ThrowBox(isPlayer);
		this.m_ItemCompartment.SetIgnoreCull(false);
	}

	// Token: 0x060001C6 RID: 454 RVA: 0x00013C3D File Offset: 0x00011E3D
	public override void DropBox(bool isPlayer)
	{
		base.DropBox(isPlayer);
		this.m_ItemCompartment.SetIgnoreCull(false);
	}

	// Token: 0x060001C7 RID: 455 RVA: 0x00013C54 File Offset: 0x00011E54
	protected override void SpawnPriceTag()
	{
		base.SpawnPriceTag();
		for (int i = 0; i < this.m_ItemCompartment.m_InteractablePriceTagList.Count; i++)
		{
			UI_PriceTag priceTagUI = PriceTagUISpawner.SpawnPriceTagItemBoxWorldUIGrp(this.m_Shelf_WorldUIGrp, this.m_ItemCompartment.m_InteractablePriceTagList[i].transform);
			this.m_ItemCompartment.m_InteractablePriceTagList[i].SetPriceTagUI(priceTagUI);
			this.m_ItemCompartment.m_InteractablePriceTagList[i].SetVisibility(true);
		}
	}

	// Token: 0x060001C8 RID: 456 RVA: 0x00013CD4 File Offset: 0x00011ED4
	public void FillBoxWithItem(EItemType itemType, int amount)
	{
		this.SpawnPriceTag();
		this.m_ItemType = itemType;
		this.m_ItemDimension = InventoryBase.GetItemData(this.m_ItemType).itemDimension;
		this.m_ItemCompartment.gameObject.SetActive(false);
		this.m_ItemCompartment.SetCompartmentItemType(this.m_ItemType);
		this.m_ItemCompartment.CalculatePositionList();
		this.m_ItemCompartment.SpawnItem(amount, false);
		this.m_ItemCount = this.m_ItemCompartment.GetItemCount();
		if (amount <= 0)
		{
			this.SetPriceTagVisibility(false);
		}
	}

	// Token: 0x060001C9 RID: 457 RVA: 0x00013D5A File Offset: 0x00011F5A
	public void SetItemType(EItemType itemType)
	{
		this.m_ItemType = itemType;
	}

	// Token: 0x060001CA RID: 458 RVA: 0x00013D63 File Offset: 0x00011F63
	public EItemType GetItemType()
	{
		return this.m_ItemType;
	}

	// Token: 0x060001CB RID: 459 RVA: 0x00013D6B File Offset: 0x00011F6B
	public override void OnHoldStateLeftMousePress(bool isPlayer, ShelfCompartment targetItemCompartment)
	{
		base.OnHoldStateLeftMousePress(isPlayer, targetItemCompartment);
		this.DispenseItem(isPlayer, targetItemCompartment);
	}

	// Token: 0x060001CC RID: 460 RVA: 0x00013D7D File Offset: 0x00011F7D
	public override void OnHoldStateRightMousePress(bool isPlayer, ShelfCompartment targetItemCompartment)
	{
		base.OnHoldStateRightMousePress(isPlayer, targetItemCompartment);
		this.RemoveItemFromShelf(isPlayer, targetItemCompartment);
	}

	// Token: 0x060001CD RID: 461 RVA: 0x00013D90 File Offset: 0x00011F90
	public void DispenseItem(bool isPlayer, ShelfCompartment targetItemCompartment)
	{
		if (!base.CanPickup())
		{
			return;
		}
		if (!targetItemCompartment || !targetItemCompartment.m_CanPutBox)
		{
			this.m_BoxStoredCompartment = null;
			if (this.m_IsBoxOpened && targetItemCompartment)
			{
				if (!targetItemCompartment.m_CanPutItem)
				{
					if (isPlayer)
					{
						NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.CanOnlyStoreBoxOnThisShelf);
					}
					return;
				}
				if (this.m_ItemCompartment.GetItemCount() <= 0)
				{
					if (isPlayer)
					{
						NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.BoxNoItem);
					}
					return;
				}
				EItemType eitemType = targetItemCompartment.CheckItemType(this.m_ItemType);
				if (!targetItemCompartment.HasEnoughSlot())
				{
					if (isPlayer)
					{
						NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.ShelfNoSlot);
					}
					return;
				}
				if (eitemType != this.m_ItemType)
				{
					if (isPlayer)
					{
						NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.ShelfWrongItemType);
					}
					return;
				}
				Transform emptySlotTransform = targetItemCompartment.GetEmptySlotTransform();
				Transform emptySlotParent = targetItemCompartment.GetEmptySlotParent();
				Item firstItem = this.m_ItemCompartment.GetFirstItem();
				firstItem.LerpToTransform(emptySlotTransform, emptySlotParent, false);
				targetItemCompartment.AddItem(firstItem, false);
				this.m_ItemCompartment.RemoveItem(firstItem);
				if (isPlayer)
				{
					TutorialManager.AddTaskValue(ETutorialTaskCondition.PutItemOnShelf, 1f);
					SoundManager.GenericPop(1f, 1f);
				}
			}
			return;
		}
		if (this.m_IsLerpingToPos)
		{
			return;
		}
		if (this.m_ItemCompartment.GetItemType() == EItemType.None || this.m_ItemCompartment.GetItemCount() <= 0)
		{
			if (isPlayer)
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.CannotStoreEmptyBox);
			}
			return;
		}
		bool flag = targetItemCompartment.CheckBoxType(this.m_IsBigBox);
		if (!targetItemCompartment.HasEnoughSlot())
		{
			if (isPlayer)
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.ShelfNoSlot);
			}
			return;
		}
		if (flag != this.m_IsBigBox)
		{
			if (isPlayer)
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.CannotMixDifferentBoxSizes);
			}
			return;
		}
		if (!targetItemCompartment.CheckBoxItemType(this.m_ItemType))
		{
			if (isPlayer)
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.ShelfWrongItemType);
			}
			return;
		}
		if (this.m_IsBoxOpened)
		{
			this.m_IsTogglingOpenClose = false;
			this.SetOpenCloseBox(false, isPlayer);
		}
		Transform emptySlotTransform2 = targetItemCompartment.GetEmptySlotTransform();
		Transform emptySlotParent2 = targetItemCompartment.GetEmptySlotParent();
		base.LerpToTransform(emptySlotTransform2, emptySlotParent2);
		targetItemCompartment.AddBox(this);
		this.SetPriceTagVisibility(false);
		this.m_MoveStateValidArea.gameObject.SetActive(false);
		this.m_IsStored = true;
		this.m_IsBeingHold = false;
		this.m_StoredWarehouseShelfIndex = targetItemCompartment.GetWarehouseIndex();
		this.m_StorageCompartmentIndex = targetItemCompartment.GetIndex();
		this.m_BoxStoredCompartment = targetItemCompartment;
		if (isPlayer)
		{
			CSingleton<InteractionPlayerController>.Instance.OnExitHoldBoxMode();
			SoundManager.GenericPop(1f, 1f);
		}
	}

	// Token: 0x060001CE RID: 462 RVA: 0x00013FA4 File Offset: 0x000121A4
	public void RemoveItemFromShelf(bool isPlayer, ShelfCompartment targetItemCompartment)
	{
		if (this.m_IsBoxOpened && targetItemCompartment && targetItemCompartment.m_CanPutItem)
		{
			if (targetItemCompartment.GetItemCount() <= 0)
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.ShelfNoItem);
				return;
			}
			EItemType eitemType = targetItemCompartment.CheckItemType(this.m_ItemType);
			EItemType eitemType2 = this.m_ItemCompartment.CheckItemType(eitemType);
			if (eitemType2 != this.m_ItemType)
			{
				this.m_ItemType = eitemType2;
			}
			if (eitemType != this.m_ItemType)
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.BoxWrongItemType);
				return;
			}
			if (this.m_ItemCompartment.HasEnoughSlot())
			{
				Transform lastEmptySlotTransform = this.m_ItemCompartment.GetLastEmptySlotTransform();
				Transform emptySlotParent = this.m_ItemCompartment.GetEmptySlotParent();
				Item lastItem = targetItemCompartment.GetLastItem();
				lastItem.LerpToTransform(lastEmptySlotTransform, emptySlotParent, false);
				targetItemCompartment.RemoveItem(lastItem);
				this.m_ItemCompartment.AddItem(lastItem, true);
				this.SetPriceTagVisibility(false);
				if (isPlayer)
				{
					SoundManager.GenericPop(1f, 0.9f);
					return;
				}
			}
			else
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.BoxNoSlot);
				this.SetPriceTagVisibility(false);
			}
		}
	}

	// Token: 0x060001CF RID: 463 RVA: 0x00014092 File Offset: 0x00012292
	protected override void OnFinishLerp()
	{
		base.OnFinishLerp();
		if (this.m_IsStored)
		{
			this.m_BoxStoredCompartment.ArrangeBoxItemBasedOnItemCount();
			return;
		}
		this.m_BoxStoredCompartment = null;
	}

	// Token: 0x060001D0 RID: 464 RVA: 0x000140B8 File Offset: 0x000122B8
	public override bool IsValidObject()
	{
		if (this.m_IsStored && this.m_BoxStoredCompartment && this.m_BoxStoredCompartment.GetWarehouseShelf())
		{
			return base.IsValidObject() && this.m_BoxStoredCompartment.GetWarehouseShelf().IsValidObject();
		}
		return base.IsValidObject();
	}

	// Token: 0x060001D1 RID: 465 RVA: 0x0001410D File Offset: 0x0001230D
	public bool CanWorkerTakeBox()
	{
		return !this.m_PreventWorkerTakeBox;
	}

	// Token: 0x060001D2 RID: 466 RVA: 0x00014118 File Offset: 0x00012318
	public override void OnPressOpenBox()
	{
		base.OnPressOpenBox();
		this.SetOpenCloseBox(!this.m_IsBoxOpened, true);
	}

	// Token: 0x060001D3 RID: 467 RVA: 0x00014130 File Offset: 0x00012330
	public void SetOpenCloseBox(bool isOpen, bool isPlayer)
	{
		if (this.m_IsTogglingOpenClose)
		{
			return;
		}
		this.m_IsTogglingOpenClose = true;
		base.StartCoroutine(this.DelayResetToggleOpenClose());
		this.m_IsBoxOpened = isOpen;
		if (!this.m_IsBoxOpened)
		{
			this.m_BoxAnim.Play("Close");
			if (this.m_ItemCompartment.GetItemType() != EItemType.None && this.m_ItemCompartment.GetItemCount() > 0)
			{
				base.StartCoroutine(base.DelaySetPriceTagVisibility(0.85f, true));
			}
			if (isPlayer)
			{
				SoundManager.PlayAudio("SFX_BoxClose", 0.5f, 1f);
			}
			this.m_PreventWorkerTakeBox = false;
		}
		else
		{
			this.m_BoxAnim.Play("Open");
			this.SetPriceTagVisibility(false);
			if (!this.m_IsFirstOpenDone)
			{
				this.m_IsFirstOpenDone = true;
				this.m_ItemCompartment.CalculatePositionList();
				this.m_ItemCompartment.RefreshItemPosition(false);
			}
			this.m_ItemCompartment.gameObject.SetActive(true);
			if (isPlayer)
			{
				this.m_PreventWorkerTakeBox = true;
				SoundManager.PlayAudio("SFX_BoxOpen", 0.5f, 1f);
			}
		}
		if (isPlayer)
		{
			this.UpdateToolTip();
		}
	}

	// Token: 0x060001D4 RID: 468 RVA: 0x0001423F File Offset: 0x0001243F
	protected IEnumerator DelayResetToggleOpenClose()
	{
		this.m_StaticMeshGrp.gameObject.SetActive(false);
		this.m_RigMeshGrp.gameObject.SetActive(true);
		yield return new WaitForSeconds(0.85f);
		this.m_IsTogglingOpenClose = false;
		if (!this.m_IsBoxOpened)
		{
			this.m_ItemCompartment.gameObject.SetActive(false);
		}
		this.m_StaticMeshGrp.gameObject.SetActive(true);
		this.m_RigMeshGrp.gameObject.SetActive(false);
		this.m_ClosedBox.SetActive(!this.m_IsBoxOpened);
		this.m_OpenBox.SetActive(this.m_IsBoxOpened);
		this.m_OutlineClosedBox.SetActive(!this.m_IsBoxOpened);
		this.m_OutlineOpenBox.SetActive(this.m_IsBoxOpened);
		yield break;
	}

	// Token: 0x060001D5 RID: 469 RVA: 0x0001424E File Offset: 0x0001244E
	private void UpdateToolTip()
	{
		InteractionPlayerController.RemoveToolTip(EGameAction.OpenBox);
		InteractionPlayerController.RemoveToolTip(EGameAction.CloseBox);
		if (this.m_IsBoxOpened)
		{
			InteractionPlayerController.AddToolTip(EGameAction.CloseBox, false, false);
			return;
		}
		InteractionPlayerController.AddToolTip(EGameAction.OpenBox, false, false);
	}

	// Token: 0x060001D6 RID: 470 RVA: 0x00014279 File Offset: 0x00012479
	public override void OnDestroyed()
	{
		this.m_ItemCompartment.SetIgnoreCull(false);
		this.m_ItemCompartment.DisableAllItem();
		RestockManager.RemoveItemPackageBox(this);
		base.OnDestroyed();
	}

	// Token: 0x060001D7 RID: 471 RVA: 0x000142A0 File Offset: 0x000124A0
	protected override void SetPriceTagVisibility(bool isVisible)
	{
		if (isVisible && this.m_IsStored)
		{
			return;
		}
		base.SetPriceTagVisibility(isVisible);
		for (int i = 0; i < this.m_ItemCompartment.m_InteractablePriceTagList.Count; i++)
		{
			this.m_ItemCompartment.m_InteractablePriceTagList[i].SetVisibility(isVisible);
		}
	}

	// Token: 0x060001D8 RID: 472 RVA: 0x000142F2 File Offset: 0x000124F2
	public void UpdateStoredWarehouseShelfIndex()
	{
		if (this.m_BoxStoredCompartment)
		{
			this.m_StoredWarehouseShelfIndex = this.m_BoxStoredCompartment.GetWarehouseIndex();
			this.m_StorageCompartmentIndex = this.m_BoxStoredCompartment.GetIndex();
		}
	}

	// Token: 0x060001D9 RID: 473 RVA: 0x00014323 File Offset: 0x00012523
	public int GeStoredWarehouseShelfIndex()
	{
		return this.m_StoredWarehouseShelfIndex;
	}

	// Token: 0x060001DA RID: 474 RVA: 0x0001432B File Offset: 0x0001252B
	public int GetStorageCompartmentIndex()
	{
		return this.m_StorageCompartmentIndex;
	}

	// Token: 0x060001DB RID: 475 RVA: 0x00014333 File Offset: 0x00012533
	public override bool IsBoxOpened()
	{
		return this.m_IsBoxOpened && !this.m_IsTogglingOpenClose;
	}

	// Token: 0x060001DC RID: 476 RVA: 0x00014348 File Offset: 0x00012548
	public ShelfCompartment GetBoxStoredCompartment()
	{
		return this.m_BoxStoredCompartment;
	}

	// Token: 0x04000235 RID: 565
	public bool m_IsBigBox;

	// Token: 0x04000236 RID: 566
	public bool m_IsStored;

	// Token: 0x04000237 RID: 567
	public ShelfCompartment m_ItemCompartment;

	// Token: 0x04000238 RID: 568
	public GameObject m_StaticMeshGrp;

	// Token: 0x04000239 RID: 569
	public GameObject m_RigMeshGrp;

	// Token: 0x0400023A RID: 570
	public GameObject m_ClosedBox;

	// Token: 0x0400023B RID: 571
	public GameObject m_OpenBox;

	// Token: 0x0400023C RID: 572
	public GameObject m_OutlineClosedBox;

	// Token: 0x0400023D RID: 573
	public GameObject m_OutlineOpenBox;

	// Token: 0x0400023E RID: 574
	private EItemType m_ItemType;

	// Token: 0x0400023F RID: 575
	private Vector3 m_ItemDimension;

	// Token: 0x04000240 RID: 576
	private bool m_IsBoxOpened;

	// Token: 0x04000241 RID: 577
	private bool m_IsTogglingOpenClose;

	// Token: 0x04000242 RID: 578
	private bool m_IsFirstOpenDone;

	// Token: 0x04000243 RID: 579
	private bool m_PreventWorkerTakeBox;

	// Token: 0x04000244 RID: 580
	private int m_ItemCount;

	// Token: 0x04000245 RID: 581
	private int m_StoredWarehouseShelfIndex;

	// Token: 0x04000246 RID: 582
	private int m_StorageCompartmentIndex;

	// Token: 0x04000247 RID: 583
	private ShelfCompartment m_BoxStoredCompartment;
}
