﻿using System;

// Token: 0x02000060 RID: 96
public class ConfirmTrashScreen : UIScreenBase
{
	// Token: 0x0600043F RID: 1087 RVA: 0x00025518 File Offset: 0x00023718
	protected override void OnOpenScreen()
	{
		SoundManager.GenericMenuOpen(1f, 1f);
		CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.SetStopMovement(true);
		CSingleton<InteractionPlayerController>.Instance.EnterUIMode();
		base.OnOpenScreen();
	}

	// Token: 0x06000440 RID: 1088 RVA: 0x00025549 File Offset: 0x00023749
	protected override void OnCloseScreen()
	{
		SoundManager.GenericMenuClose(1f, 1f);
		CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.SetStopMovement(false);
		CSingleton<InteractionPlayerController>.Instance.ExitUIMode();
		base.OnCloseScreen();
	}

	// Token: 0x06000441 RID: 1089 RVA: 0x0002557A File Offset: 0x0002377A
	public void OnPressConfirmBtn()
	{
		CSingleton<InteractionPlayerController>.Instance.ConfirmDiscardBox();
		SoundManager.GenericConfirm(1f, 1f);
		base.CloseScreen();
	}

	// Token: 0x06000442 RID: 1090 RVA: 0x0002559B File Offset: 0x0002379B
	public void OnPressCancelBtn()
	{
		SoundManager.GenericCancel(1f, 1f);
		base.CloseScreen();
	}
}
