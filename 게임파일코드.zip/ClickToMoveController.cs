﻿using System;
using CMF;
using UnityEngine;

// Token: 0x0200014A RID: 330
public class ClickToMoveController : Controller
{
	// Token: 0x06000950 RID: 2384 RVA: 0x000448D0 File Offset: 0x00042AD0
	private void Start()
	{
		this.mover = base.GetComponent<Mover>();
		this.tr = base.transform;
		if (this.playerCamera == null)
		{
			Debug.LogWarning("No camera has been assigned to this controller!", this);
		}
		this.lastPosition = this.tr.position;
		this.currentTargetPosition = base.transform.position;
		this.groundPlane = new Plane(this.tr.up, this.tr.position);
	}

	// Token: 0x06000951 RID: 2385 RVA: 0x00044951 File Offset: 0x00042B51
	private void Update()
	{
		this.HandleMouseInput();
	}

	// Token: 0x06000952 RID: 2386 RVA: 0x0004495C File Offset: 0x00042B5C
	private void FixedUpdate()
	{
		this.mover.CheckForGround();
		this.isGrounded = this.mover.IsGrounded();
		this.HandleTimeOut();
		Vector3 vector = Vector3.zero;
		vector = this.CalculateMovementVelocity();
		this.lastMovementVelocity = vector;
		this.HandleGravity();
		vector += this.tr.up * this.currentVerticalSpeed;
		this.mover.SetExtendSensorRange(this.isGrounded);
		this.mover.SetVelocity(vector);
		this.lastVelocity = vector;
	}

	// Token: 0x06000953 RID: 2387 RVA: 0x000449E8 File Offset: 0x00042BE8
	private Vector3 CalculateMovementVelocity()
	{
		if (!this.hasTarget)
		{
			return Vector3.zero;
		}
		Vector3 vector = this.currentTargetPosition - this.tr.position;
		vector = VectorMath.RemoveDotVector(vector, this.tr.up);
		float magnitude = vector.magnitude;
		if (magnitude <= this.reachTargetThreshold)
		{
			this.hasTarget = false;
			return Vector3.zero;
		}
		Vector3 result = vector.normalized * this.movementSpeed;
		if (this.movementSpeed * Time.fixedDeltaTime > magnitude)
		{
			result = vector.normalized * magnitude;
			this.hasTarget = false;
		}
		return result;
	}

	// Token: 0x06000954 RID: 2388 RVA: 0x00044A84 File Offset: 0x00042C84
	private void HandleGravity()
	{
		if (!this.isGrounded)
		{
			this.currentVerticalSpeed -= this.gravity * Time.deltaTime;
			return;
		}
		if (this.currentVerticalSpeed < 0f && this.OnLand != null)
		{
			this.OnLand(this.tr.up * this.currentVerticalSpeed);
		}
		this.currentVerticalSpeed = 0f;
	}

	// Token: 0x06000955 RID: 2389 RVA: 0x00044AF4 File Offset: 0x00042CF4
	private void HandleMouseInput()
	{
		if (this.playerCamera == null)
		{
			return;
		}
		if ((!this.holdMouseButtonToMove && this.WasMouseButtonJustPressed()) || (this.holdMouseButtonToMove && this.IsMouseButtonPressed()))
		{
			Ray ray = this.playerCamera.ScreenPointToRay(this.GetMousePosition());
			if (this.mouseDetectionType == ClickToMoveController.MouseDetectionType.AbstractPlane)
			{
				this.groundPlane.SetNormalAndPosition(this.tr.up, this.tr.position);
				float distance = 0f;
				if (this.groundPlane.Raycast(ray, out distance))
				{
					this.currentTargetPosition = ray.GetPoint(distance);
					this.hasTarget = true;
					return;
				}
				this.hasTarget = false;
				return;
			}
			else if (this.mouseDetectionType == ClickToMoveController.MouseDetectionType.Raycast)
			{
				RaycastHit raycastHit;
				if (Physics.Raycast(ray, ref raycastHit, 100f, this.raycastLayerMask, 1))
				{
					this.currentTargetPosition = raycastHit.point;
					this.hasTarget = true;
					return;
				}
				this.hasTarget = false;
			}
		}
	}

	// Token: 0x06000956 RID: 2390 RVA: 0x00044BEC File Offset: 0x00042DEC
	private void HandleTimeOut()
	{
		if (!this.hasTarget)
		{
			this.currentTimeOutTime = 0f;
			return;
		}
		if (Vector3.Distance(this.tr.position, this.lastPosition) > this.timeOutDistanceThreshold)
		{
			this.currentTimeOutTime = 0f;
			this.lastPosition = this.tr.position;
			return;
		}
		this.currentTimeOutTime += Time.deltaTime;
		if (this.currentTimeOutTime >= this.timeOutTime)
		{
			this.hasTarget = false;
		}
	}

	// Token: 0x06000957 RID: 2391 RVA: 0x00044C6F File Offset: 0x00042E6F
	protected Vector2 GetMousePosition()
	{
		return Input.mousePosition;
	}

	// Token: 0x06000958 RID: 2392 RVA: 0x00044C7B File Offset: 0x00042E7B
	protected bool IsMouseButtonPressed()
	{
		return Input.GetMouseButton(0);
	}

	// Token: 0x06000959 RID: 2393 RVA: 0x00044C83 File Offset: 0x00042E83
	protected bool WasMouseButtonJustPressed()
	{
		return Input.GetMouseButtonDown(0);
	}

	// Token: 0x0600095A RID: 2394 RVA: 0x00044C8B File Offset: 0x00042E8B
	public override bool IsGrounded()
	{
		return this.isGrounded;
	}

	// Token: 0x0600095B RID: 2395 RVA: 0x00044C93 File Offset: 0x00042E93
	public override Vector3 GetMovementVelocity()
	{
		return this.lastMovementVelocity;
	}

	// Token: 0x0600095C RID: 2396 RVA: 0x00044C9B File Offset: 0x00042E9B
	public override Vector3 GetVelocity()
	{
		return this.lastVelocity;
	}

	// Token: 0x04001192 RID: 4498
	public float movementSpeed = 10f;

	// Token: 0x04001193 RID: 4499
	public float gravity = 30f;

	// Token: 0x04001194 RID: 4500
	private float currentVerticalSpeed;

	// Token: 0x04001195 RID: 4501
	private bool isGrounded;

	// Token: 0x04001196 RID: 4502
	private Vector3 currentTargetPosition;

	// Token: 0x04001197 RID: 4503
	private float reachTargetThreshold = 0.001f;

	// Token: 0x04001198 RID: 4504
	public bool holdMouseButtonToMove;

	// Token: 0x04001199 RID: 4505
	public ClickToMoveController.MouseDetectionType mouseDetectionType;

	// Token: 0x0400119A RID: 4506
	public LayerMask raycastLayerMask = -1;

	// Token: 0x0400119B RID: 4507
	public float timeOutTime = 1f;

	// Token: 0x0400119C RID: 4508
	private float currentTimeOutTime = 1f;

	// Token: 0x0400119D RID: 4509
	public float timeOutDistanceThreshold = 0.05f;

	// Token: 0x0400119E RID: 4510
	private Vector3 lastPosition;

	// Token: 0x0400119F RID: 4511
	public Camera playerCamera;

	// Token: 0x040011A0 RID: 4512
	private bool hasTarget;

	// Token: 0x040011A1 RID: 4513
	private Vector3 lastVelocity = Vector3.zero;

	// Token: 0x040011A2 RID: 4514
	private Vector3 lastMovementVelocity = Vector3.zero;

	// Token: 0x040011A3 RID: 4515
	private Plane groundPlane;

	// Token: 0x040011A4 RID: 4516
	private Mover mover;

	// Token: 0x040011A5 RID: 4517
	private Transform tr;

	// Token: 0x0200023C RID: 572
	public enum MouseDetectionType
	{
		// Token: 0x040015FD RID: 5629
		AbstractPlane,
		// Token: 0x040015FE RID: 5630
		Raycast
	}
}
