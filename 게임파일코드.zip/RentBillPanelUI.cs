﻿using System;
using I2.Loc;
using TMPro;
using UnityEngine;

// Token: 0x02000071 RID: 113
public class RentBillPanelUI : MonoBehaviour
{
	// Token: 0x060004B2 RID: 1202 RVA: 0x0002925E File Offset: 0x0002745E
	public void Init(RentBillScreen rentBillScreen, EBillType billType)
	{
		this.m_RentBillScreen = rentBillScreen;
		this.m_BillType = billType;
	}

	// Token: 0x060004B3 RID: 1203 RVA: 0x00029270 File Offset: 0x00027470
	public void EvaluateUI()
	{
		BillData bill = CPlayerData.GetBill(this.m_BillType);
		if (bill == null)
		{
			this.m_DueDay = 0;
			this.m_AmountDue = 0f;
			this.m_BillDayPassed = 0;
		}
		else
		{
			this.m_DueDay = this.m_RentBillScreen.GetDueDayMax() - bill.billDayPassed;
			this.m_AmountDue = bill.amountToPay;
			this.m_BillDayPassed = bill.billDayPassed;
		}
		if (this.m_AmountDue <= 0f && this.m_BillDayPassed == 0)
		{
			this.m_DayDueText.text = "";
			this.m_AmountDueText.text = "";
			this.m_LockBtnGrp.SetActive(true);
			this.m_LatePaymentText.enabled = false;
			this.m_DayDueText.color = this.m_RentBillScreen.m_NormalDayColor;
			this.m_TickIcon.gameObject.SetActive(true);
			return;
		}
		if (this.m_AmountDue > 0f)
		{
			this.m_AmountDueText.text = GameInstance.GetPriceString(this.m_AmountDue, false, true, false, "F2");
			this.m_LockBtnGrp.SetActive(false);
			this.m_TickIcon.gameObject.SetActive(false);
			if (this.m_DueDay < 0)
			{
				this.m_DayDueText.color = this.m_RentBillScreen.m_LateDayColor;
				this.m_LatePaymentText.enabled = true;
				int num = Mathf.Abs(this.m_DueDay);
				if (num == 1)
				{
					this.m_DayDueText.text = LocalizationManager.GetTranslation("Late By XXX Day", true, 0, true, false, null, null, true).Replace("XXX", num.ToString());
					return;
				}
				this.m_DayDueText.text = LocalizationManager.GetTranslation("Late By XXX Days", true, 0, true, false, null, null, true).Replace("XXX", num.ToString());
				return;
			}
			else
			{
				if (this.m_DueDay < 3)
				{
					this.m_DayDueText.color = this.m_RentBillScreen.m_WarningDayColor;
				}
				else
				{
					this.m_DayDueText.color = this.m_RentBillScreen.m_NormalDayColor;
				}
				this.m_LatePaymentText.enabled = false;
				if (this.m_DueDay == 1)
				{
					this.m_DayDueText.text = this.m_DueDay.ToString() + " " + LocalizationManager.GetTranslation("Day", true, 0, true, false, null, null, true);
					return;
				}
				if (this.m_DueDay == 0)
				{
					this.m_DayDueText.text = LocalizationManager.GetTranslation("Today", true, 0, true, false, null, null, true);
					return;
				}
				this.m_DayDueText.text = this.m_DueDay.ToString() + " " + LocalizationManager.GetTranslation("Days", true, 0, true, false, null, null, true);
			}
		}
	}

	// Token: 0x060004B4 RID: 1204 RVA: 0x00029508 File Offset: 0x00027708
	public void OnPressButton()
	{
		if (this.m_BillType == EBillType.Rent)
		{
			this.m_RentBillScreen.OnPressPayRentBill(false);
			return;
		}
		if (this.m_BillType == EBillType.Electric)
		{
			this.m_RentBillScreen.OnPressPayElectricBill(false);
			return;
		}
		if (this.m_BillType == EBillType.Employee)
		{
			this.m_RentBillScreen.OnPressPaySalaryBill(false);
		}
	}

	// Token: 0x04000619 RID: 1561
	public TextMeshProUGUI m_DayDueText;

	// Token: 0x0400061A RID: 1562
	public TextMeshProUGUI m_AmountDueText;

	// Token: 0x0400061B RID: 1563
	public TextMeshProUGUI m_LatePaymentText;

	// Token: 0x0400061C RID: 1564
	public GameObject m_LockBtnGrp;

	// Token: 0x0400061D RID: 1565
	public GameObject m_TickIcon;

	// Token: 0x0400061E RID: 1566
	private EBillType m_BillType;

	// Token: 0x0400061F RID: 1567
	private RentBillScreen m_RentBillScreen;

	// Token: 0x04000620 RID: 1568
	private int m_DueDay;

	// Token: 0x04000621 RID: 1569
	private int m_BillDayPassed;

	// Token: 0x04000622 RID: 1570
	private float m_AmountDue;
}
