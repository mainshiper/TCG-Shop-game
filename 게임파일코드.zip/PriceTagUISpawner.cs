﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000043 RID: 67
public class PriceTagUISpawner : CSingleton<PriceTagUISpawner>
{
	// Token: 0x0600032E RID: 814 RVA: 0x0001DA25 File Offset: 0x0001BC25
	private void Awake()
	{
		if (PriceTagUISpawner.m_Instance == null)
		{
			PriceTagUISpawner.m_Instance = this;
		}
		else if (PriceTagUISpawner.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
	}

	// Token: 0x0600032F RID: 815 RVA: 0x0001DA5C File Offset: 0x0001BC5C
	private void Update()
	{
		this.m_CullLoopCount = 0;
		for (int i = 0; i < this.m_UI_PriceTagList.Count; i++)
		{
			if (this.m_UI_PriceTagList[this.m_CullIndex] && !this.m_UI_PriceTagList[this.m_CullIndex].m_IgnoreCull)
			{
				float num = Vector3.Dot((this.m_UI_PriceTagList[this.m_CullIndex].m_UIGrp.position - CSingleton<InteractionPlayerController>.Instance.m_Cam.transform.position).normalized, CSingleton<InteractionPlayerController>.Instance.m_Cam.transform.forward);
				float magnitude = (this.m_UI_PriceTagList[this.m_CullIndex].m_UIGrp.position - CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.transform.position).magnitude;
				float num2 = Vector3.Angle(this.m_UI_PriceTagList[this.m_CullIndex].m_UIGrp.TransformDirection(Vector3.forward), CSingleton<InteractionPlayerController>.Instance.m_Cam.transform.TransformDirection(Vector3.forward));
				if (magnitude > 6f || (magnitude > 1f && num < this.m_DotCullLimit) || num2 > 110f)
				{
					this.m_UI_PriceTagList[this.m_CullIndex].m_UIGrp.gameObject.SetActive(false);
				}
				else
				{
					this.m_UI_PriceTagList[this.m_CullIndex].m_UIGrp.gameObject.SetActive(true);
				}
			}
			this.m_CullIndex++;
			if (this.m_CullIndex >= this.m_UI_PriceTagList.Count)
			{
				this.m_CullIndex = 0;
			}
			this.m_CullLoopCount++;
			if (this.m_CullLoopCount >= this.m_CullLoopCountMaxPerFrame)
			{
				this.m_CullLoopCount = 0;
				return;
			}
		}
	}

	// Token: 0x06000330 RID: 816 RVA: 0x0001DC48 File Offset: 0x0001BE48
	public static Transform SpawnShelfWorldUIGrp(Transform shelf)
	{
		Transform transform = Object.Instantiate<Transform>(CSingleton<PriceTagUISpawner>.Instance.m_Shelf_WorldUIGrpPrefab, shelf.position, shelf.rotation, CSingleton<PriceTagUISpawner>.Instance.transform);
		CSingleton<PriceTagUISpawner>.Instance.m_WorldUIGrpList.Add(transform);
		return transform;
	}

	// Token: 0x06000331 RID: 817 RVA: 0x0001DC8C File Offset: 0x0001BE8C
	public static UI_PriceTag SpawnPriceTagWorldUIGrp(Transform parent, Transform priceTagLoc)
	{
		UI_PriceTag ui_PriceTag = Object.Instantiate<UI_PriceTag>(CSingleton<PriceTagUISpawner>.Instance.m_UIPriceTagPrefab, priceTagLoc.position, priceTagLoc.rotation, parent);
		CSingleton<PriceTagUISpawner>.Instance.m_UI_PriceTagList.Add(ui_PriceTag);
		return ui_PriceTag;
	}

	// Token: 0x06000332 RID: 818 RVA: 0x0001DCC8 File Offset: 0x0001BEC8
	public static UI_PriceTag SpawnPriceTagItemBoxWorldUIGrp(Transform parent, Transform priceTagLoc)
	{
		UI_PriceTag ui_PriceTag = Object.Instantiate<UI_PriceTag>(CSingleton<PriceTagUISpawner>.Instance.m_UIPriceTagItemBoxPrefab, priceTagLoc.position, priceTagLoc.rotation, parent);
		CSingleton<PriceTagUISpawner>.Instance.m_UI_PriceTagList.Add(ui_PriceTag);
		return ui_PriceTag;
	}

	// Token: 0x06000333 RID: 819 RVA: 0x0001DD04 File Offset: 0x0001BF04
	public static UI_PriceTag SpawnPriceTagPackageBoxWorldUIGrp(Transform parent, Transform priceTagLoc)
	{
		UI_PriceTag ui_PriceTag = Object.Instantiate<UI_PriceTag>(CSingleton<PriceTagUISpawner>.Instance.m_UIPriceTagPackageBoxPrefab, priceTagLoc.position, priceTagLoc.rotation, parent);
		CSingleton<PriceTagUISpawner>.Instance.m_UI_PriceTagList.Add(ui_PriceTag);
		return ui_PriceTag;
	}

	// Token: 0x06000334 RID: 820 RVA: 0x0001DD40 File Offset: 0x0001BF40
	public static UI_PriceTag SpawnPriceTagWarehouseRakWorldUIGrp(Transform parent, Transform priceTagLoc)
	{
		UI_PriceTag ui_PriceTag = Object.Instantiate<UI_PriceTag>(CSingleton<PriceTagUISpawner>.Instance.m_UIPriceTagWarehouseRackPrefab, priceTagLoc.position, priceTagLoc.rotation, parent);
		CSingleton<PriceTagUISpawner>.Instance.m_UI_PriceTagList.Add(ui_PriceTag);
		return ui_PriceTag;
	}

	// Token: 0x06000335 RID: 821 RVA: 0x0001DD7C File Offset: 0x0001BF7C
	public static UI_PriceTag SpawnPriceTagCardWorldUIGrp(Transform parent, Transform priceTagLoc)
	{
		UI_PriceTag ui_PriceTag = Object.Instantiate<UI_PriceTag>(CSingleton<PriceTagUISpawner>.Instance.m_UIPriceTagCardPrefab, priceTagLoc.position, priceTagLoc.rotation, parent);
		CSingleton<PriceTagUISpawner>.Instance.m_UI_PriceTagList.Add(ui_PriceTag);
		return ui_PriceTag;
	}

	// Token: 0x06000336 RID: 822 RVA: 0x0001DDB8 File Offset: 0x0001BFB8
	public static void SetAllPriceTagUIBrightness(float brightness)
	{
		for (int i = 0; i < CSingleton<PriceTagUISpawner>.Instance.m_UI_PriceTagList.Count; i++)
		{
			if (CSingleton<PriceTagUISpawner>.Instance.m_UI_PriceTagList[i])
			{
				CSingleton<PriceTagUISpawner>.Instance.m_UI_PriceTagList[i].SetBrightness(brightness);
			}
		}
	}

	// Token: 0x06000337 RID: 823 RVA: 0x0001DE0C File Offset: 0x0001C00C
	protected virtual void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_OnSettingUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnSettingUpdated>(this.OnSettingUpdated));
		}
	}

	// Token: 0x06000338 RID: 824 RVA: 0x0001DE2D File Offset: 0x0001C02D
	protected virtual void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_OnSettingUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnSettingUpdated>(this.OnSettingUpdated));
		}
	}

	// Token: 0x06000339 RID: 825 RVA: 0x0001DE4E File Offset: 0x0001C04E
	protected void OnSettingUpdated(CEventPlayer_OnSettingUpdated evt)
	{
		this.m_DotCullLimit = Mathf.Lerp(0.75f, 0.35f, CSingleton<CGameManager>.Instance.m_CameraFOVSlider);
	}

	// Token: 0x040003DB RID: 987
	public static PriceTagUISpawner m_Instance;

	// Token: 0x040003DC RID: 988
	public Transform m_Shelf_WorldUIGrpPrefab;

	// Token: 0x040003DD RID: 989
	public UI_PriceTag m_UIPriceTagPrefab;

	// Token: 0x040003DE RID: 990
	public UI_PriceTag m_UIPriceTagItemBoxPrefab;

	// Token: 0x040003DF RID: 991
	public UI_PriceTag m_UIPriceTagPackageBoxPrefab;

	// Token: 0x040003E0 RID: 992
	public UI_PriceTag m_UIPriceTagWarehouseRackPrefab;

	// Token: 0x040003E1 RID: 993
	public UI_PriceTag m_UIPriceTagCardPrefab;

	// Token: 0x040003E2 RID: 994
	private List<Transform> m_WorldUIGrpList = new List<Transform>();

	// Token: 0x040003E3 RID: 995
	private List<UI_PriceTag> m_UI_PriceTagList = new List<UI_PriceTag>();

	// Token: 0x040003E4 RID: 996
	private int m_CullIndex;

	// Token: 0x040003E5 RID: 997
	private int m_CullLoopCount;

	// Token: 0x040003E6 RID: 998
	private int m_CullLoopCountMaxPerFrame = 100;

	// Token: 0x040003E7 RID: 999
	private float m_DotCullLimit = 0.65f;

	// Token: 0x040003E8 RID: 1000
	private float m_CullTimer;
}
