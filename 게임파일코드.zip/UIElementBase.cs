﻿using System;
using UnityEngine;

// Token: 0x02000083 RID: 131
public class UIElementBase : MonoBehaviour
{
	// Token: 0x06000526 RID: 1318 RVA: 0x0002C824 File Offset: 0x0002AA24
	public void SetActive(bool isActive)
	{
		this.m_IsActive = isActive;
		this.m_TopUIGrp.SetActive(isActive);
	}

	// Token: 0x06000527 RID: 1319 RVA: 0x0002C839 File Offset: 0x0002AA39
	public virtual void OnPressButton()
	{
	}

	// Token: 0x06000528 RID: 1320 RVA: 0x0002C83B File Offset: 0x0002AA3B
	public bool IsActive()
	{
		return this.m_IsActive;
	}

	// Token: 0x040006CE RID: 1742
	public GameObject m_TopUIGrp;

	// Token: 0x040006CF RID: 1743
	public GameObject m_UIGrp;

	// Token: 0x040006D0 RID: 1744
	protected bool m_IsActive = true;
}
