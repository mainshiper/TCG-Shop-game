﻿using System;
using UnityEngine;

// Token: 0x02000125 RID: 293
public class LerpSlider : MonoBehaviour
{
	// Token: 0x060008A1 RID: 2209 RVA: 0x00040BEC File Offset: 0x0003EDEC
	private void Start()
	{
		this.m_StartPos = base.transform.localPosition;
	}

	// Token: 0x060008A2 RID: 2210 RVA: 0x00040BFF File Offset: 0x0003EDFF
	private void Update()
	{
		base.transform.localPosition = Vector3.Lerp(base.transform.localPosition, this.m_LerpPos, Time.deltaTime * this.m_LerpSpeed);
	}

	// Token: 0x060008A3 RID: 2211 RVA: 0x00040C2E File Offset: 0x0003EE2E
	public void SetLerpPos(float posX)
	{
		this.m_LerpPos = new Vector3(posX, this.m_StartPos.y, 0f);
		this.m_IsLerping = true;
	}

	// Token: 0x060008A4 RID: 2212 RVA: 0x00040C53 File Offset: 0x0003EE53
	public void SetLerpPosY(float posY)
	{
		this.m_LerpPos = new Vector3(this.m_StartPos.x, posY, 0f);
		this.m_IsLerping = true;
	}

	// Token: 0x060008A5 RID: 2213 RVA: 0x00040C78 File Offset: 0x0003EE78
	public void StopLerp()
	{
		this.m_IsLerping = false;
	}

	// Token: 0x0400107E RID: 4222
	private Vector3 m_StartPos;

	// Token: 0x0400107F RID: 4223
	private bool m_IsLerping;

	// Token: 0x04001080 RID: 4224
	private Vector3 m_LerpPos;

	// Token: 0x04001081 RID: 4225
	private float m_LerpSpeed = 7f;
}
