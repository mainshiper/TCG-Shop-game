﻿using System;

// Token: 0x020000CE RID: 206
public class CEventPlayer_OnSaveStatusUpdated : CEvent
{
	// Token: 0x1700002A RID: 42
	// (get) Token: 0x06000755 RID: 1877 RVA: 0x0003963B File Offset: 0x0003783B
	// (set) Token: 0x06000756 RID: 1878 RVA: 0x00039643 File Offset: 0x00037843
	public bool m_IsSuccess { get; private set; }

	// Token: 0x1700002B RID: 43
	// (get) Token: 0x06000757 RID: 1879 RVA: 0x0003964C File Offset: 0x0003784C
	// (set) Token: 0x06000758 RID: 1880 RVA: 0x00039654 File Offset: 0x00037854
	public bool m_IsAutosaving { get; private set; }

	// Token: 0x06000759 RID: 1881 RVA: 0x0003965D File Offset: 0x0003785D
	public CEventPlayer_OnSaveStatusUpdated(bool isSuccess, bool isAutosaving)
	{
		this.m_IsSuccess = isSuccess;
		this.m_IsAutosaving = isAutosaving;
	}
}
