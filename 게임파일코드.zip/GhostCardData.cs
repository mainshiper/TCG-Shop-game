﻿using System;

// Token: 0x0200003D RID: 61
[Serializable]
public class GhostCardData
{
	// Token: 0x040003B6 RID: 950
	public string Name;

	// Token: 0x040003B7 RID: 951
	public EMonsterType MonsterType;

	// Token: 0x040003B8 RID: 952
	public EGhostCardEffect GhostCardEffect;
}
