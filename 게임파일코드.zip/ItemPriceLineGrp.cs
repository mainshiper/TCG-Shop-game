﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200006E RID: 110
public class ItemPriceLineGrp : MonoBehaviour
{
	// Token: 0x060004AA RID: 1194 RVA: 0x0002909A File Offset: 0x0002729A
	public void SetActive(bool isActive)
	{
		this.m_IsActive = isActive;
		base.gameObject.SetActive(isActive);
	}

	// Token: 0x060004AB RID: 1195 RVA: 0x000290AF File Offset: 0x000272AF
	public void SetColor(Color color)
	{
		this.m_Line.color = color;
	}

	// Token: 0x060004AC RID: 1196 RVA: 0x000290BD File Offset: 0x000272BD
	public void SetScaleLerp(float lerp)
	{
		this.m_Lerp = lerp;
		this.m_Scale = Vector3.one;
		this.m_Scale.z = this.m_Lerp;
		this.m_LineScaleTransform.localScale = this.m_Scale;
	}

	// Token: 0x060004AD RID: 1197 RVA: 0x000290F4 File Offset: 0x000272F4
	public void AddScaleLerp(float lerp)
	{
		this.m_Lerp += lerp;
		if (this.m_Lerp > 1f)
		{
			this.m_Lerp = 1f;
		}
		this.m_Scale = Vector3.one;
		this.m_Scale.z = this.m_Lerp;
		this.m_LineScaleTransform.localScale = this.m_Scale;
	}

	// Token: 0x040005EB RID: 1515
	public Image m_Line;

	// Token: 0x040005EC RID: 1516
	public Transform m_LineScaleTransform;

	// Token: 0x040005ED RID: 1517
	public bool m_IsActive;

	// Token: 0x040005EE RID: 1518
	public float m_Lerp;

	// Token: 0x040005EF RID: 1519
	private Vector3 m_Scale;
}
