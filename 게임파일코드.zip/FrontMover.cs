﻿using System;
using UnityEngine;

// Token: 0x02000147 RID: 327
public class FrontMover : MonoBehaviour
{
	// Token: 0x06000946 RID: 2374 RVA: 0x00044551 File Offset: 0x00042751
	private void Start()
	{
		base.InvokeRepeating("StartAgain", 0f, this.repeatingTime);
		this.effect.Play();
		this.startSpeed = this.speed;
	}

	// Token: 0x06000947 RID: 2375 RVA: 0x00044580 File Offset: 0x00042780
	private void StartAgain()
	{
		this.startSpeed = this.speed;
		base.transform.position = this.pivot.position;
	}

	// Token: 0x06000948 RID: 2376 RVA: 0x000445A4 File Offset: 0x000427A4
	private void Update()
	{
		this.startSpeed *= this.drug;
		base.transform.position += base.transform.forward * (this.startSpeed * Time.deltaTime);
	}

	// Token: 0x04001179 RID: 4473
	public Transform pivot;

	// Token: 0x0400117A RID: 4474
	public ParticleSystem effect;

	// Token: 0x0400117B RID: 4475
	public float speed = 15f;

	// Token: 0x0400117C RID: 4476
	public float drug = 1f;

	// Token: 0x0400117D RID: 4477
	public float repeatingTime = 1f;

	// Token: 0x0400117E RID: 4478
	private float startSpeed;
}
