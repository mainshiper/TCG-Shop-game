﻿using System;
using I2.Loc;
using TMPro;
using UnityEngine;

// Token: 0x0200007E RID: 126
public class SaveLoadSlotPanelUI : MonoBehaviour
{
	// Token: 0x060004FB RID: 1275 RVA: 0x0002B564 File Offset: 0x00029764
	public void SetSaveOrLoadState(bool isSave)
	{
		this.m_IsSaveState = isSave;
		if (this.m_IsSaveState)
		{
			this.m_SaveBtn.SetActive(true);
			this.m_LoadBtn.SetActive(false);
			if (this.m_SlotIndex == 0)
			{
				this.m_SaveBtn.SetActive(false);
				return;
			}
		}
		else
		{
			this.m_SaveBtn.SetActive(false);
			this.m_LoadBtn.SetActive(true);
		}
	}

	// Token: 0x060004FC RID: 1276 RVA: 0x0002B5C8 File Offset: 0x000297C8
	public void LoadSlotData(LoadSavedSlotData loadSavedSlotData)
	{
		if (loadSavedSlotData.hasSaveData)
		{
			this.m_ShopName.text = loadSavedSlotData.name;
			this.m_Money.text = GameInstance.GetPriceString(loadSavedSlotData.moneyAmount, false, true, false, "F2");
			this.m_Level.text = "Lv " + (loadSavedSlotData.level + 1).ToString();
			this.m_DaysPassed.text = LocalizationManager.GetTranslation("Day XXX", true, 0, true, false, null, null, true).Replace("XXX", (loadSavedSlotData.daysPassed + 1).ToString());
			return;
		}
		this.m_ShopName.text = "-";
		this.m_Money.text = "-";
		this.m_Level.text = "-";
		this.m_DaysPassed.text = "-";
	}

	// Token: 0x060004FD RID: 1277 RVA: 0x0002B6AB File Offset: 0x000298AB
	public void OnPressLoadGame()
	{
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.OnPressLoadGame(this.m_SlotIndex);
	}

	// Token: 0x060004FE RID: 1278 RVA: 0x0002B6BD File Offset: 0x000298BD
	public void OnPressSaveGame()
	{
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.OnPressSaveGame(this.m_SlotIndex);
	}

	// Token: 0x0400068D RID: 1677
	public int m_SlotIndex;

	// Token: 0x0400068E RID: 1678
	public GameObject m_SaveBtn;

	// Token: 0x0400068F RID: 1679
	public GameObject m_LoadBtn;

	// Token: 0x04000690 RID: 1680
	public TextMeshProUGUI m_ShopName;

	// Token: 0x04000691 RID: 1681
	public TextMeshProUGUI m_Money;

	// Token: 0x04000692 RID: 1682
	public TextMeshProUGUI m_Level;

	// Token: 0x04000693 RID: 1683
	public TextMeshProUGUI m_DaysPassed;

	// Token: 0x04000694 RID: 1684
	private bool m_IsSaveState;
}
