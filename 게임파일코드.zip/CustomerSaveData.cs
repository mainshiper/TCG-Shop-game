﻿using System;
using System.Collections.Generic;

// Token: 0x02000014 RID: 20
[Serializable]
public class CustomerSaveData
{
	// Token: 0x0400014F RID: 335
	public ECustomerState currentState;

	// Token: 0x04000150 RID: 336
	public bool hasPlayedGame;

	// Token: 0x04000151 RID: 337
	public bool hasCheckedOut;

	// Token: 0x04000152 RID: 338
	public bool hasTookItemFromShelf;

	// Token: 0x04000153 RID: 339
	public bool hasTookCardFromShelf;

	// Token: 0x04000154 RID: 340
	public bool isInsideShop;

	// Token: 0x04000155 RID: 341
	public bool isSmelly;

	// Token: 0x04000156 RID: 342
	public int smellyMeter;

	// Token: 0x04000157 RID: 343
	public float currentCostTotal;

	// Token: 0x04000158 RID: 344
	public float maxMoney;

	// Token: 0x04000159 RID: 345
	public float totalScannedItemCost;

	// Token: 0x0400015A RID: 346
	public float currentPlayTableFee;

	// Token: 0x0400015B RID: 347
	public Vector3Serializer pos;

	// Token: 0x0400015C RID: 348
	public QuaternionSerializer rot;

	// Token: 0x0400015D RID: 349
	public List<EItemType> itemInBagList;

	// Token: 0x0400015E RID: 350
	public List<float> itemInBagPriceList;

	// Token: 0x0400015F RID: 351
	public List<CardData> cardInBagList;

	// Token: 0x04000160 RID: 352
	public List<float> cardInBagPriceList;
}
