﻿using System;
using System.Collections.Generic;

// Token: 0x0200004B RID: 75
[Serializable]
public class WarehouseShelfSaveData
{
	// Token: 0x04000445 RID: 1093
	public Vector3Serializer pos;

	// Token: 0x04000446 RID: 1094
	public QuaternionSerializer rot;

	// Token: 0x04000447 RID: 1095
	public bool isBoxed;

	// Token: 0x04000448 RID: 1096
	public Vector3Serializer boxedPackagePos;

	// Token: 0x04000449 RID: 1097
	public QuaternionSerializer boxedPackageRot;

	// Token: 0x0400044A RID: 1098
	public EObjectType objectType;

	// Token: 0x0400044B RID: 1099
	public List<EItemType> compartmentItemType;
}
