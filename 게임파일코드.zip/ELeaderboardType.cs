﻿using System;

// Token: 0x020000FF RID: 255
public enum ELeaderboardType
{
	// Token: 0x04000EB6 RID: 3766
	GlobalPoint
}
