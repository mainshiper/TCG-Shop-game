﻿using System;
using System.Collections.Generic;

// Token: 0x0200006C RID: 108
public class HireWorkerScreen : GenericSliderScreen
{
	// Token: 0x060004A0 RID: 1184 RVA: 0x000284F8 File Offset: 0x000266F8
	protected override void Init()
	{
		base.Init();
		for (int i = 0; i < this.m_HireWorkerPanelUIList.Count; i++)
		{
			this.m_HireWorkerPanelUIList[i].SetActive(false);
		}
		for (int j = 0; j < CSingleton<WorkerManager>.Instance.m_WorkerDataList.Count; j++)
		{
			this.m_HireWorkerPanelUIList[j].Init(this, j);
			this.m_HireWorkerPanelUIList[j].SetActive(true);
			this.m_ScrollEndPosParent = this.m_HireWorkerPanelUIList[j].gameObject;
		}
	}

	// Token: 0x060004A1 RID: 1185 RVA: 0x00028589 File Offset: 0x00026789
	protected override void OnOpenScreen()
	{
		this.Init();
		base.OnOpenScreen();
	}

	// Token: 0x040005CD RID: 1485
	public List<HireWorkerPanelUI> m_HireWorkerPanelUIList;
}
