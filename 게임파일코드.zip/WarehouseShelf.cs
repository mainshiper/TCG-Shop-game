﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200008E RID: 142
public class WarehouseShelf : InteractableObject
{
	// Token: 0x06000594 RID: 1428 RVA: 0x0002E702 File Offset: 0x0002C902
	protected override void Awake()
	{
		base.Awake();
		ShelfManager.InitWarehouseShelf(this);
	}

	// Token: 0x06000595 RID: 1429 RVA: 0x0002E710 File Offset: 0x0002C910
	public override void Init()
	{
		if (this.m_HasInit)
		{
			return;
		}
		base.Init();
		for (int i = 0; i < this.m_ShelfCompartmentGrpList.Count; i++)
		{
			for (int j = 0; j < this.m_ShelfCompartmentGrpList[i].childCount; j++)
			{
				this.m_ItemCompartmentList.Add(this.m_ShelfCompartmentGrpList[i].GetChild(j).GetComponent<ShelfCompartment>());
				this.m_StorageCompartmentList.Add(this.m_ShelfCompartmentGrpList[i].GetChild(j).GetComponent<InteractableStorageCompartment>());
			}
		}
		this.m_Shelf_WorldUIGrp = PriceTagUISpawner.SpawnShelfWorldUIGrp(base.transform);
		for (int k = 0; k < this.m_StorageCompartmentList.Count; k++)
		{
			this.m_StorageCompartmentList[k].InitWarehouseShelf(this, this.m_ItemCompartmentList[k], k);
			for (int l = 0; l < this.m_ItemCompartmentList[k].m_InteractablePriceTagList.Count; l++)
			{
				UI_PriceTag ui_PriceTag = PriceTagUISpawner.SpawnPriceTagWarehouseRakWorldUIGrp(this.m_Shelf_WorldUIGrp, this.m_ItemCompartmentList[k].m_InteractablePriceTagList[l].transform);
				this.m_UIPriceTagList.Add(ui_PriceTag);
				this.m_ItemCompartmentList[k].m_InteractablePriceTagList[l].SetPriceTagUI(ui_PriceTag);
				this.m_ItemCompartmentList[k].m_InteractablePriceTagList[l].SetVisibility(false);
			}
		}
	}

	// Token: 0x06000596 RID: 1430 RVA: 0x0002E884 File Offset: 0x0002CA84
	protected override void LateUpdate()
	{
		base.LateUpdate();
		if (this.m_IsMovingObject && this.m_Shelf_WorldUIGrp)
		{
			this.m_Shelf_WorldUIGrp.transform.position = base.transform.position;
			this.m_Shelf_WorldUIGrp.transform.rotation = base.transform.rotation;
		}
	}

	// Token: 0x06000597 RID: 1431 RVA: 0x0002E8E2 File Offset: 0x0002CAE2
	protected override void OnPlacedMovedObject()
	{
		base.OnPlacedMovedObject();
	}

	// Token: 0x06000598 RID: 1432 RVA: 0x0002E8EA File Offset: 0x0002CAEA
	public override void BoxUpObject(bool holdBox)
	{
		base.BoxUpObject(holdBox);
	}

	// Token: 0x06000599 RID: 1433 RVA: 0x0002E8F4 File Offset: 0x0002CAF4
	public override void OnDestroyed()
	{
		ShelfManager.RemoveWarehouseShelf(this);
		for (int i = 0; i < this.m_StorageCompartmentList.Count; i++)
		{
			if (this.m_StorageCompartmentList[i])
			{
				this.m_StorageCompartmentList[i].DisableAllItem();
			}
		}
		base.OnDestroyed();
	}

	// Token: 0x0600059A RID: 1434 RVA: 0x0002E947 File Offset: 0x0002CB47
	public ShelfCompartment GetWarehouseCompartment(int index)
	{
		if (index >= this.m_StorageCompartmentList.Count)
		{
			return null;
		}
		return this.m_StorageCompartmentList[index].GetShelfCompartment();
	}

	// Token: 0x0600059B RID: 1435 RVA: 0x0002E96A File Offset: 0x0002CB6A
	public void SetIndex(int index)
	{
		this.m_Index = index;
	}

	// Token: 0x0600059C RID: 1436 RVA: 0x0002E973 File Offset: 0x0002CB73
	public int GetIndex()
	{
		return this.m_Index;
	}

	// Token: 0x0600059D RID: 1437 RVA: 0x0002E97B File Offset: 0x0002CB7B
	public List<InteractableStorageCompartment> GetStorageCompartmentList()
	{
		return this.m_StorageCompartmentList;
	}

	// Token: 0x0600059E RID: 1438 RVA: 0x0002E984 File Offset: 0x0002CB84
	public ShelfCompartment GetNonFullItemCompartment(EItemType itemType, bool isBigBox, bool ignoreNoneType = false)
	{
		for (int i = 0; i < this.m_ItemCompartmentList.Count; i++)
		{
			if (!ignoreNoneType && (this.m_ItemCompartmentList[i].GetItemType() == EItemType.None || this.m_ItemCompartmentList[i].GetItemCount() == 0))
			{
				return this.m_ItemCompartmentList[i];
			}
			if (this.m_ItemCompartmentList[i].GetItemType() == itemType && this.m_ItemCompartmentList[i].CheckBoxType(isBigBox) == isBigBox && this.m_ItemCompartmentList[i].GetItemCount() < this.m_ItemCompartmentList[i].GetMaxItemCount())
			{
				return this.m_ItemCompartmentList[i];
			}
		}
		return null;
	}

	// Token: 0x0600059F RID: 1439 RVA: 0x0002EA40 File Offset: 0x0002CC40
	public List<ShelfCompartment> GetNonFullItemCompartmentList(EItemType itemType, bool isBigBox, bool ignoreNoneType = false)
	{
		List<ShelfCompartment> list = new List<ShelfCompartment>();
		for (int i = 0; i < this.m_ItemCompartmentList.Count; i++)
		{
			if (!ignoreNoneType && (this.m_ItemCompartmentList[i].GetItemType() == EItemType.None || this.m_ItemCompartmentList[i].GetItemCount() == 0))
			{
				list.Add(this.m_ItemCompartmentList[i]);
			}
			else if (this.m_ItemCompartmentList[i].GetItemType() == itemType && this.m_ItemCompartmentList[i].CheckBoxType(isBigBox) == isBigBox && this.m_ItemCompartmentList[i].GetItemCount() < this.m_ItemCompartmentList[i].GetMaxItemCount())
			{
				list.Add(this.m_ItemCompartmentList[i]);
			}
		}
		return list;
	}

	// Token: 0x04000736 RID: 1846
	public List<Transform> m_ShelfCompartmentGrpList;

	// Token: 0x04000737 RID: 1847
	private List<InteractableStorageCompartment> m_StorageCompartmentList = new List<InteractableStorageCompartment>();

	// Token: 0x04000738 RID: 1848
	private List<UI_PriceTag> m_UIPriceTagList = new List<UI_PriceTag>();

	// Token: 0x04000739 RID: 1849
	private int m_Index;
}
