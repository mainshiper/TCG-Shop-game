﻿using System;
using System.Collections;
using TMPro;
using UnityEngine;

// Token: 0x0200009D RID: 157
public class LoadingScreen : CSingleton<LoadingScreen>
{
	// Token: 0x06000624 RID: 1572 RVA: 0x0003301F File Offset: 0x0003121F
	private void Awake()
	{
		if (LoadingScreen.m_Instance == null)
		{
			LoadingScreen.m_Instance = this;
		}
		else if (LoadingScreen.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
	}

	// Token: 0x06000625 RID: 1573 RVA: 0x00033054 File Offset: 0x00031254
	public static void OpenScreen()
	{
		CSingleton<LoadingScreen>.Instance.m_PercentText.text = "0%";
		CSingleton<LoadingScreen>.Instance.m_ScreenGrp.SetActive(true);
		CSingleton<LoadingScreen>.Instance.m_ScreenAnim.Play("Loading_FadeIn");
		GameInstance.m_HasFinishHideLoadingScreen = false;
	}

	// Token: 0x06000626 RID: 1574 RVA: 0x000330A0 File Offset: 0x000312A0
	public static void CloseScreen()
	{
		CSingleton<LoadingScreen>.Instance.HideLoadingScreen();
	}

	// Token: 0x06000627 RID: 1575 RVA: 0x000330AC File Offset: 0x000312AC
	public static void SetPercentDone(int percent)
	{
		CSingleton<LoadingScreen>.Instance.m_PercentText.text = percent.ToString() + "%";
	}

	// Token: 0x06000628 RID: 1576 RVA: 0x000330CE File Offset: 0x000312CE
	private void HideLoadingScreen()
	{
		this.m_ScreenGrp.SetActive(true);
		this.m_PercentText.text = "100%";
	}

	// Token: 0x06000629 RID: 1577 RVA: 0x000330EC File Offset: 0x000312EC
	public void FinishLoading()
	{
		if (this.m_DelayHide != null)
		{
			base.StopCoroutine(this.m_DelayHide);
		}
		this.m_DelayHide = base.StartCoroutine(this.DelayHide(0.1f));
	}

	// Token: 0x0600062A RID: 1578 RVA: 0x00033119 File Offset: 0x00031319
	private IEnumerator DelayHide(float delayTime)
	{
		yield return new WaitForSeconds(delayTime);
		this.m_ScreenAnim.Play("Loading_FadeOut");
		yield return new WaitForSeconds(1f);
		CEventManager.QueueEvent(new CEventPlayer_FinishHideLoadingScreen());
		this.m_ScreenGrp.SetActive(false);
		GameInstance.m_HasFinishHideLoadingScreen = true;
		yield break;
	}

	// Token: 0x040007F5 RID: 2037
	public static LoadingScreen m_Instance;

	// Token: 0x040007F6 RID: 2038
	public GameObject m_ScreenGrp;

	// Token: 0x040007F7 RID: 2039
	public Animation m_ScreenAnim;

	// Token: 0x040007F8 RID: 2040
	public TextMeshProUGUI m_PercentText;

	// Token: 0x040007F9 RID: 2041
	private Coroutine m_DelayHide;
}
