﻿using System;

// Token: 0x0200010D RID: 269
public enum ECtrlBtnXChangeMethod
{
	// Token: 0x04000F2A RID: 3882
	Normal,
	// Token: 0x04000F2B RID: 3883
	AlwaysZeroifGoDown,
	// Token: 0x04000F2C RID: 3884
	RememberIndexX,
	// Token: 0x04000F2D RID: 3885
	AlwaysGoIndexYOne,
	// Token: 0x04000F2E RID: 3886
	SettingScreenSkipSideButtonIndexY
}
