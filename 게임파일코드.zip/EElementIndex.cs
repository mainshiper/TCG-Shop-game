﻿using System;

// Token: 0x020000E9 RID: 233
public enum EElementIndex
{
	// Token: 0x04000B65 RID: 2917
	None = -1,
	// Token: 0x04000B66 RID: 2918
	Fire,
	// Token: 0x04000B67 RID: 2919
	Earth,
	// Token: 0x04000B68 RID: 2920
	Water,
	// Token: 0x04000B69 RID: 2921
	Wind,
	// Token: 0x04000B6A RID: 2922
	Destiny,
	// Token: 0x04000B6B RID: 2923
	Champion,
	// Token: 0x04000B6C RID: 2924
	GhostWhite,
	// Token: 0x04000B6D RID: 2925
	GhostBlack,
	// Token: 0x04000B6E RID: 2926
	Megabot,
	// Token: 0x04000B6F RID: 2927
	FantasyRPG,
	// Token: 0x04000B70 RID: 2928
	CatJob,
	// Token: 0x04000B71 RID: 2929
	FoodieGO,
	// Token: 0x04000B72 RID: 2930
	FoodieGOBW,
	// Token: 0x04000B73 RID: 2931
	FoodieGOJP
}
