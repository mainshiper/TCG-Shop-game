﻿using System;

// Token: 0x020000DC RID: 220
public enum ECardExpansionType
{
	// Token: 0x04000A37 RID: 2615
	None = -1,
	// Token: 0x04000A38 RID: 2616
	Tetramon,
	// Token: 0x04000A39 RID: 2617
	Destiny,
	// Token: 0x04000A3A RID: 2618
	Ghost,
	// Token: 0x04000A3B RID: 2619
	Megabot,
	// Token: 0x04000A3C RID: 2620
	FantasyRPG,
	// Token: 0x04000A3D RID: 2621
	CatJob,
	// Token: 0x04000A3E RID: 2622
	FoodieGO,
	// Token: 0x04000A3F RID: 2623
	MAX
}
