﻿using System;

// Token: 0x020000FB RID: 251
public enum EGameMode
{
	// Token: 0x04000E2D RID: 3629
	Base,
	// Token: 0x04000E2E RID: 3630
	ManaFlux,
	// Token: 0x04000E2F RID: 3631
	ManaRamp,
	// Token: 0x04000E30 RID: 3632
	DoubleDamage,
	// Token: 0x04000E31 RID: 3633
	DoubleMana,
	// Token: 0x04000E32 RID: 3634
	TripleMana,
	// Token: 0x04000E33 RID: 3635
	Draft,
	// Token: 0x04000E34 RID: 3636
	AllAttackIsPoison,
	// Token: 0x04000E35 RID: 3637
	PowerSurge,
	// Token: 0x04000E36 RID: 3638
	DrilcerosBattle,
	// Token: 0x04000E37 RID: 3639
	SlumberParty,
	// Token: 0x04000E38 RID: 3640
	PreMadeTeam
}
