﻿using System;
using UnityEngine;

// Token: 0x02000084 RID: 132
public class UIScreenBase : MonoBehaviour
{
	// Token: 0x0600052A RID: 1322 RVA: 0x0002C852 File Offset: 0x0002AA52
	protected virtual void Awake()
	{
		this.m_ControllerScreenUIExtension = base.GetComponent<ControllerScreenUIExtension>();
	}

	// Token: 0x0600052B RID: 1323 RVA: 0x0002C860 File Offset: 0x0002AA60
	protected virtual void Start()
	{
		this.m_ScreenGroup.SetActive(false);
	}

	// Token: 0x0600052C RID: 1324 RVA: 0x0002C86E File Offset: 0x0002AA6E
	protected void Update()
	{
		if (!this.m_FinishLoading)
		{
			return;
		}
		if (this.m_CurrentChildScreen)
		{
			return;
		}
		if (this.m_IsScreenOpen)
		{
			this.RunUpdate();
		}
	}

	// Token: 0x0600052D RID: 1325 RVA: 0x0002C895 File Offset: 0x0002AA95
	protected virtual void RunUpdate()
	{
	}

	// Token: 0x0600052E RID: 1326 RVA: 0x0002C897 File Offset: 0x0002AA97
	protected virtual void Init()
	{
		this.m_FinishLoading = true;
	}

	// Token: 0x0600052F RID: 1327 RVA: 0x0002C8A0 File Offset: 0x0002AAA0
	public void SetParentScreen(UIScreenBase parentScreen)
	{
		this.m_ParentScreen = parentScreen;
	}

	// Token: 0x06000530 RID: 1328 RVA: 0x0002C8A9 File Offset: 0x0002AAA9
	protected void OpenChildScreen(UIScreenBase childScreen)
	{
		this.m_CurrentChildScreen = childScreen;
		this.m_CurrentChildScreen.SetParentScreen(this);
		childScreen.OpenScreen();
	}

	// Token: 0x06000531 RID: 1329 RVA: 0x0002C8C4 File Offset: 0x0002AAC4
	protected void CloseChildScreen(UIScreenBase childScreen)
	{
		if (this.m_CurrentChildScreen == childScreen)
		{
			this.m_CurrentChildScreen = null;
			this.OnChildScreenClosed(childScreen);
		}
	}

	// Token: 0x06000532 RID: 1330 RVA: 0x0002C8E2 File Offset: 0x0002AAE2
	protected virtual void OnChildScreenClosed(UIScreenBase childScreen)
	{
	}

	// Token: 0x06000533 RID: 1331 RVA: 0x0002C8E4 File Offset: 0x0002AAE4
	public void OpenScreen()
	{
		if (this.m_CloseIfScreenOpened && this.m_IsScreenOpen)
		{
			this.CloseScreen();
			return;
		}
		this.OnOpenScreen();
		ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension);
	}

	// Token: 0x06000534 RID: 1332 RVA: 0x0002C90E File Offset: 0x0002AB0E
	protected virtual void OnOpenScreen()
	{
		this.m_IsScreenOpen = true;
		this.m_ScreenGroup.SetActive(true);
	}

	// Token: 0x06000535 RID: 1333 RVA: 0x0002C923 File Offset: 0x0002AB23
	public void CloseScreen()
	{
		if (!CSingleton<TouchManager>.Instance.m_AllowButtonPress)
		{
			return;
		}
		if (!this.m_IsScreenOpen)
		{
			return;
		}
		this.OnCloseScreen();
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension);
	}

	// Token: 0x06000536 RID: 1334 RVA: 0x0002C94C File Offset: 0x0002AB4C
	protected virtual void OnCloseScreen()
	{
		this.m_IsScreenOpen = false;
		this.m_ScreenGroup.SetActive(false);
		if (this.m_ParentScreen)
		{
			this.m_ParentScreen.CloseChildScreen(this);
			this.m_ParentScreen = null;
		}
	}

	// Token: 0x06000537 RID: 1335 RVA: 0x0002C981 File Offset: 0x0002AB81
	public void OnPressBack()
	{
		if (this.m_CurrentChildScreen)
		{
			this.m_CurrentChildScreen.OnPressBack();
			return;
		}
		this.CloseScreen();
	}

	// Token: 0x06000538 RID: 1336 RVA: 0x0002C9A2 File Offset: 0x0002ABA2
	protected virtual void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.AddListener<CEventPlayer_FinishHideLoadingScreen>(new CEventManager.EventDelegate<CEventPlayer_FinishHideLoadingScreen>(this.OnFinishHideLoadingScreen));
		}
	}

	// Token: 0x06000539 RID: 1337 RVA: 0x0002C9D6 File Offset: 0x0002ABD6
	protected virtual void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.RemoveListener<CEventPlayer_FinishHideLoadingScreen>(new CEventManager.EventDelegate<CEventPlayer_FinishHideLoadingScreen>(this.OnFinishHideLoadingScreen));
		}
	}

	// Token: 0x0600053A RID: 1338 RVA: 0x0002CA0A File Offset: 0x0002AC0A
	protected virtual void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.Init();
	}

	// Token: 0x0600053B RID: 1339 RVA: 0x0002CA12 File Offset: 0x0002AC12
	protected virtual void OnFinishHideLoadingScreen(CEventPlayer_FinishHideLoadingScreen evt)
	{
		this.m_FinishHideLoadingScreen = true;
		if (this.m_FinishLoading)
		{
			return;
		}
		this.Init();
	}

	// Token: 0x040006D1 RID: 1745
	public GameObject m_ScreenGroup;

	// Token: 0x040006D2 RID: 1746
	public bool m_CloseIfScreenOpened = true;

	// Token: 0x040006D3 RID: 1747
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x040006D4 RID: 1748
	protected UIScreenBase m_ParentScreen;

	// Token: 0x040006D5 RID: 1749
	protected bool m_IsScreenOpen;

	// Token: 0x040006D6 RID: 1750
	protected bool m_FinishLoading;

	// Token: 0x040006D7 RID: 1751
	protected bool m_FinishHideLoadingScreen;

	// Token: 0x040006D8 RID: 1752
	protected UIScreenBase m_CurrentChildScreen;
}
