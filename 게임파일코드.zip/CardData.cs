﻿using System;

// Token: 0x0200002E RID: 46
[Serializable]
public class CardData
{
	// Token: 0x060002A1 RID: 673 RVA: 0x0001A05A File Offset: 0x0001825A
	public ECardBorderType GetCardBorderType()
	{
		return CPlayerData.GetCardBorderType((int)this.borderType, this.expansionType);
	}

	// Token: 0x040002D8 RID: 728
	public ECardExpansionType expansionType;

	// Token: 0x040002D9 RID: 729
	public EMonsterType monsterType;

	// Token: 0x040002DA RID: 730
	public ECardBorderType borderType;

	// Token: 0x040002DB RID: 731
	public bool isFoil;

	// Token: 0x040002DC RID: 732
	public bool isDestiny;

	// Token: 0x040002DD RID: 733
	public bool isChampionCard;

	// Token: 0x040002DE RID: 734
	public bool isNew;
}
