﻿using System;

// Token: 0x020000C1 RID: 193
public class CEventPlayer_NewRoomUnlocked : CEvent
{
}
