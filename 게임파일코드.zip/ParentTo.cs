﻿using System;
using UnityEngine;

// Token: 0x02000108 RID: 264
public class ParentTo : MonoBehaviour
{
	// Token: 0x060007C4 RID: 1988 RVA: 0x0003ADA8 File Offset: 0x00038FA8
	private void Awake()
	{
		if (this.m_AutoParent)
		{
			this.StartParent();
		}
	}

	// Token: 0x060007C5 RID: 1989 RVA: 0x0003ADB8 File Offset: 0x00038FB8
	public void StartParent()
	{
		base.transform.parent = this.m_Parent;
	}

	// Token: 0x04000F0E RID: 3854
	public bool m_AutoParent;

	// Token: 0x04000F0F RID: 3855
	public Transform m_Parent;
}
