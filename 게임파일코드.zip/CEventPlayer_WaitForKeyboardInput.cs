﻿using System;

// Token: 0x020000CA RID: 202
public class CEventPlayer_WaitForKeyboardInput : CEvent
{
	// Token: 0x17000025 RID: 37
	// (get) Token: 0x06000747 RID: 1863 RVA: 0x000395A3 File Offset: 0x000377A3
	// (set) Token: 0x06000748 RID: 1864 RVA: 0x000395AB File Offset: 0x000377AB
	public string m_Text { get; private set; }

	// Token: 0x06000749 RID: 1865 RVA: 0x000395B4 File Offset: 0x000377B4
	public CEventPlayer_WaitForKeyboardInput(string Text)
	{
		this.m_Text = Text;
	}
}
