﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x0200000A RID: 10
public class CardOpeningSequenceUI : MonoBehaviour
{
	// Token: 0x0600003C RID: 60 RVA: 0x00004EBF File Offset: 0x000030BF
	public void ShowSingleCardValue(float cardValue)
	{
		if (!this.m_ScreenGrp.activeSelf)
		{
			this.m_ScreenGrp.SetActive(true);
		}
		this.m_CardValueText.text = GameInstance.GetPriceString(cardValue, false, true, false, "F2");
		this.m_CardValueTextGrp.SetActive(true);
	}

	// Token: 0x0600003D RID: 61 RVA: 0x00004EFF File Offset: 0x000030FF
	public void HideSingleCardValue()
	{
		this.m_CardValueTextGrp.SetActive(false);
		this.m_ScreenGrp.SetActive(false);
	}

	// Token: 0x0600003E RID: 62 RVA: 0x00004F1C File Offset: 0x0000311C
	public void StartShowTotalValue(float totalValue, bool hasFoilCard)
	{
		this.m_IsShowingTotalValue = true;
		this.m_TotalValueLerpTimer = 0f;
		this.m_CurrentTotalCardValueLerp = 0f;
		this.m_TotalCardValueText.text = GameInstance.GetPriceString(0f, false, true, false, "F2");
		this.m_TargetTotalCardValueLerp = totalValue;
		this.m_TotalCardValueTextGrp.SetActive(true);
		this.m_FoilRainbowGlowingBG.SetActive(hasFoilCard);
		SoundManager.SetEnableSound_ExpIncrease(true);
		this.m_ScreenGrp.SetActive(true);
	}

	// Token: 0x0600003F RID: 63 RVA: 0x00004F94 File Offset: 0x00003194
	public void HideTotalValue()
	{
		this.m_TotalValueLerpTimer = 0f;
		this.m_CurrentTotalCardValueLerp = 0f;
		this.m_IsShowingTotalValue = false;
		this.m_TotalCardValueTextGrp.SetActive(false);
		this.m_FoilRainbowGlowingBG.SetActive(false);
		SoundManager.SetEnableSound_ExpIncrease(false);
		this.m_ScreenGrp.SetActive(false);
	}

	// Token: 0x06000040 RID: 64 RVA: 0x00004FE8 File Offset: 0x000031E8
	private void Update()
	{
		if (this.m_IsShowingTotalValue)
		{
			this.m_TotalValueLerpTimer += Time.deltaTime * 0.5f;
			this.m_CurrentTotalCardValueLerp = Mathf.Lerp(0f, this.m_TargetTotalCardValueLerp, this.m_TotalValueLerpTimer);
			this.m_TotalCardValueText.text = GameInstance.GetPriceString(this.m_CurrentTotalCardValueLerp, false, true, false, "F2");
			if (this.m_TotalValueLerpTimer >= 1f)
			{
				this.m_IsShowingTotalValue = false;
				SoundManager.SetEnableSound_ExpIncrease(false);
			}
		}
	}

	// Token: 0x0400005E RID: 94
	public GameObject m_ScreenGrp;

	// Token: 0x0400005F RID: 95
	public GameObject m_CardValueTextGrp;

	// Token: 0x04000060 RID: 96
	public GameObject m_FoilRainbowGlowingBG;

	// Token: 0x04000061 RID: 97
	public TextMeshProUGUI m_CardValueText;

	// Token: 0x04000062 RID: 98
	public GameObject m_TotalCardValueTextGrp;

	// Token: 0x04000063 RID: 99
	public TextMeshProUGUI m_TotalCardValueText;

	// Token: 0x04000064 RID: 100
	private float m_CurrentTotalCardValueLerp;

	// Token: 0x04000065 RID: 101
	private float m_TargetTotalCardValueLerp;

	// Token: 0x04000066 RID: 102
	private float m_TotalValueLerpTimer;

	// Token: 0x04000067 RID: 103
	private bool m_IsShowingTotalValue;
}
