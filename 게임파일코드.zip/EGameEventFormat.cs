﻿using System;

// Token: 0x020000DD RID: 221
public enum EGameEventFormat
{
	// Token: 0x04000A41 RID: 2625
	None = -1,
	// Token: 0x04000A42 RID: 2626
	Standard,
	// Token: 0x04000A43 RID: 2627
	Pauper,
	// Token: 0x04000A44 RID: 2628
	FireCup,
	// Token: 0x04000A45 RID: 2629
	EarthCup,
	// Token: 0x04000A46 RID: 2630
	WaterCup,
	// Token: 0x04000A47 RID: 2631
	WindCup,
	// Token: 0x04000A48 RID: 2632
	FirstEditionVintage,
	// Token: 0x04000A49 RID: 2633
	SilverBorder,
	// Token: 0x04000A4A RID: 2634
	GoldBorder,
	// Token: 0x04000A4B RID: 2635
	ExBorder,
	// Token: 0x04000A4C RID: 2636
	FullArtBorder,
	// Token: 0x04000A4D RID: 2637
	Foil,
	// Token: 0x04000A4E RID: 2638
	MAX
}
