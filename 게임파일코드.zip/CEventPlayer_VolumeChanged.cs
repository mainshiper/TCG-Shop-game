﻿using System;

// Token: 0x020000CB RID: 203
public class CEventPlayer_VolumeChanged : CEvent
{
}
