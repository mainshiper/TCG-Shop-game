﻿using System;
using UnityEngine;

// Token: 0x02000037 RID: 55
public class Item : MonoBehaviour
{
	// Token: 0x060002C9 RID: 713 RVA: 0x0001A804 File Offset: 0x00018A04
	public void SetMesh(Mesh mesh, Material material, EItemType itemType, Mesh meshSecondary = null, Material materialSecondary = null)
	{
		this.m_ItemType = itemType;
		this.m_MeshFilter.mesh = mesh;
		if (meshSecondary == null && materialSecondary == null && this.m_Mesh.materials.Length > 1)
		{
			Material[] materials = new Material[]
			{
				material
			};
			this.m_Mesh.materials = materials;
		}
		else if (meshSecondary != null && this.m_Mesh.materials.Length > 1)
		{
			Material[] materials2 = new Material[]
			{
				material
			};
			this.m_Mesh.materials = materials2;
		}
		else
		{
			this.m_Mesh.material = material;
		}
		this.m_MeshFilterSecondary.gameObject.SetActive(false);
		if (meshSecondary != null)
		{
			this.m_MeshFilterSecondary.mesh = meshSecondary;
			this.m_MeshSecondary.material = materialSecondary;
			this.m_MeshFilterSecondary.gameObject.SetActive(true);
		}
		else if (meshSecondary == null && materialSecondary != null)
		{
			Material[] materials3 = new Material[]
			{
				material,
				materialSecondary
			};
			this.m_Mesh.materials = materials3;
		}
		this.m_OutlineMeshFilter.mesh = mesh;
		this.m_Collider.size = InventoryBase.GetItemData(itemType).colliderScale;
		this.m_Collider.center = InventoryBase.GetItemData(itemType).colliderPosOffset;
		this.m_ItemVolume = InventoryBase.GetItemData(itemType).GetItemVolume();
		this.m_InteractableScanItem.enabled = false;
		this.m_ItemContentFill = 1f;
	}

	// Token: 0x060002CA RID: 714 RVA: 0x0001A978 File Offset: 0x00018B78
	public void LerpToTransform(Transform targetTransform, Transform targetParent, bool ignoreUpForce = false)
	{
		this.m_Timer = 0f;
		this.m_UpTimer = 0f;
		this.m_Accelration = 0f;
		base.transform.parent = targetParent;
		this.m_StartPos = base.transform.position;
		this.m_StartRot = base.transform.rotation;
		this.m_StartScale = base.transform.localScale;
		this.m_TargetTransform = targetTransform;
		this.m_IsLerpingToPos = true;
		this.m_IsSmoothLerpingToPos = false;
		this.m_IsIgnoreUpForce = ignoreUpForce;
		this.m_Mesh.enabled = true;
	}

	// Token: 0x060002CB RID: 715 RVA: 0x0001AA10 File Offset: 0x00018C10
	public void SmoothLerpToTransform(Transform targetTransform, Transform targetParent, bool ignoreUpForce = false)
	{
		this.m_Timer = 0f;
		this.m_UpTimer = 0f;
		this.m_Accelration = 0f;
		base.transform.parent = targetParent;
		this.m_StartPos = base.transform.position;
		this.m_StartRot = base.transform.rotation;
		this.m_StartScale = base.transform.localScale;
		this.m_TargetTransform = targetTransform;
		this.m_IsLerpingToPos = false;
		this.m_IsSmoothLerpingToPos = true;
		this.m_IsIgnoreUpForce = ignoreUpForce;
		this.m_Mesh.enabled = true;
	}

	// Token: 0x060002CC RID: 716 RVA: 0x0001AAA8 File Offset: 0x00018CA8
	private void Update()
	{
		if (this.m_IsLerpingToPos)
		{
			this.m_UpTimer += Time.deltaTime * this.m_UpLerpSpeed;
			if (this.m_UpTimer > 0.2f)
			{
				this.m_Timer += Time.deltaTime * this.m_LerpSpeed * (1f + this.m_Accelration);
				this.m_Accelration += Time.deltaTime;
			}
			else
			{
				this.m_Timer += Time.deltaTime * this.m_LerpSpeed * 0.1f;
			}
			Vector3 b = Vector3.up * (Mathf.PingPong(Mathf.Clamp(this.m_UpTimer, 0f, 2f), 1f) * this.m_UpLerpHeight);
			if (this.m_IsIgnoreUpForce)
			{
				b = Vector3.zero;
				this.m_UpTimer = 2f;
			}
			base.transform.position = Vector3.Lerp(this.m_StartPos, this.m_TargetTransform.position + b, this.m_Timer) + b;
			base.transform.rotation = Quaternion.Lerp(this.m_StartRot, this.m_TargetTransform.rotation, this.m_Timer);
			base.transform.localScale = Vector3.Lerp(this.m_StartScale, this.m_TargetTransform.localScale, this.m_Timer);
			if (this.m_Timer >= 1f && this.m_UpTimer >= 2f)
			{
				this.m_Timer = 0f;
				this.m_UpTimer = 0f;
				this.m_Accelration = 0f;
				this.m_IsLerpingToPos = false;
				if (this.m_IsHideAfterFinishLerp)
				{
					this.m_IsHideAfterFinishLerp = false;
					base.gameObject.SetActive(false);
					return;
				}
			}
		}
		else if (this.m_IsSmoothLerpingToPos)
		{
			this.m_UpTimer += Time.deltaTime * this.m_UpLerpSpeed * 0.75f;
			Vector3 b2 = Vector3.up * (Mathf.PingPong(Mathf.Clamp(this.m_UpTimer, 0f, 2f), 1f) * this.m_UpLerpHeight);
			if (this.m_UpTimer > 0.2f)
			{
				this.m_Timer += Time.deltaTime * this.m_LerpSpeed * (1f + this.m_Accelration);
				this.m_Accelration += Time.deltaTime;
				base.transform.position = Vector3.Lerp(base.transform.position, this.m_TargetTransform.position + b2, Time.deltaTime * 10f);
				base.transform.rotation = Quaternion.Lerp(base.transform.rotation, this.m_TargetTransform.rotation, Time.deltaTime * 10f);
				base.transform.localScale = Vector3.Lerp(base.transform.localScale, this.m_TargetTransform.localScale, Time.deltaTime * 10f);
			}
			else
			{
				this.m_Timer += Time.deltaTime * this.m_LerpSpeed * 0.1f;
				base.transform.position = Vector3.Lerp(base.transform.position, this.m_TargetTransform.position + b2, Time.deltaTime * 2f) + b2;
				base.transform.rotation = Quaternion.Lerp(base.transform.rotation, this.m_TargetTransform.rotation, Time.deltaTime * 2f);
				base.transform.localScale = Vector3.Lerp(base.transform.localScale, this.m_TargetTransform.localScale, Time.deltaTime * 2f);
			}
			if (this.m_IsIgnoreUpForce)
			{
				b2 = Vector3.zero;
				this.m_UpTimer = 2f;
			}
		}
	}

	// Token: 0x060002CD RID: 717 RVA: 0x0001AE89 File Offset: 0x00019089
	public void DepleteContent(float amount)
	{
		this.m_ItemContentFill -= amount;
		if (this.m_ItemContentFill <= 0f)
		{
			this.m_ItemContentFill = 0f;
		}
	}

	// Token: 0x060002CE RID: 718 RVA: 0x0001AEB1 File Offset: 0x000190B1
	public float GetContentFill()
	{
		return this.m_ItemContentFill;
	}

	// Token: 0x060002CF RID: 719 RVA: 0x0001AEB9 File Offset: 0x000190B9
	public void SetContentFill(float itemContentFill)
	{
		this.m_ItemContentFill = itemContentFill;
	}

	// Token: 0x060002D0 RID: 720 RVA: 0x0001AEC2 File Offset: 0x000190C2
	public void SetHideItemAfterFinishLerp()
	{
		this.m_IsHideAfterFinishLerp = true;
	}

	// Token: 0x060002D1 RID: 721 RVA: 0x0001AECB File Offset: 0x000190CB
	public void SetCurrentPrice(float price)
	{
		this.m_CurrentPrice = price;
	}

	// Token: 0x060002D2 RID: 722 RVA: 0x0001AED4 File Offset: 0x000190D4
	public float GetCurrentPrice()
	{
		return this.m_CurrentPrice;
	}

	// Token: 0x060002D3 RID: 723 RVA: 0x0001AEDC File Offset: 0x000190DC
	public float GetItemVolume()
	{
		return this.m_ItemVolume;
	}

	// Token: 0x060002D4 RID: 724 RVA: 0x0001AEE4 File Offset: 0x000190E4
	public EItemType GetItemType()
	{
		return this.m_ItemType;
	}

	// Token: 0x060002D5 RID: 725 RVA: 0x0001AEEC File Offset: 0x000190EC
	public void DisableItem()
	{
		this.m_TargetTransform = null;
		this.m_IsLerpingToPos = false;
		this.m_IsSmoothLerpingToPos = false;
		ItemSpawnManager.DisableItem(this);
	}

	// Token: 0x04000331 RID: 817
	public MeshFilter m_MeshFilter;

	// Token: 0x04000332 RID: 818
	public MeshRenderer m_Mesh;

	// Token: 0x04000333 RID: 819
	public MeshFilter m_MeshFilterSecondary;

	// Token: 0x04000334 RID: 820
	public MeshRenderer m_MeshSecondary;

	// Token: 0x04000335 RID: 821
	public MeshFilter m_OutlineMeshFilter;

	// Token: 0x04000336 RID: 822
	public BoxCollider m_Collider;

	// Token: 0x04000337 RID: 823
	public Rigidbody m_Rigidbody;

	// Token: 0x04000338 RID: 824
	public InteractableScanItem m_InteractableScanItem;

	// Token: 0x04000339 RID: 825
	private bool m_IsLerpingToPos;

	// Token: 0x0400033A RID: 826
	private bool m_IsSmoothLerpingToPos;

	// Token: 0x0400033B RID: 827
	private bool m_IsHideAfterFinishLerp;

	// Token: 0x0400033C RID: 828
	private bool m_IsIgnoreUpForce;

	// Token: 0x0400033D RID: 829
	private float m_ItemVolume;

	// Token: 0x0400033E RID: 830
	private float m_Timer;

	// Token: 0x0400033F RID: 831
	private float m_UpTimer;

	// Token: 0x04000340 RID: 832
	private float m_LerpSpeed = 3f;

	// Token: 0x04000341 RID: 833
	private float m_Accelration;

	// Token: 0x04000342 RID: 834
	private float m_UpLerpSpeed = 5f;

	// Token: 0x04000343 RID: 835
	private float m_UpLerpHeight = 0.1f;

	// Token: 0x04000344 RID: 836
	private float m_CurrentPrice;

	// Token: 0x04000345 RID: 837
	private float m_ItemContentFill = 1f;

	// Token: 0x04000346 RID: 838
	private Vector3 m_StartPos;

	// Token: 0x04000347 RID: 839
	private Quaternion m_StartRot;

	// Token: 0x04000348 RID: 840
	private Vector3 m_StartScale;

	// Token: 0x04000349 RID: 841
	private Transform m_TargetTransform;

	// Token: 0x0400034A RID: 842
	private EItemType m_ItemType;
}
