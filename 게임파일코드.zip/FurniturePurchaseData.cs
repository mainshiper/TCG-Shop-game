﻿using System;
using I2.Loc;
using UnityEngine;

// Token: 0x02000132 RID: 306
[Serializable]
public class FurniturePurchaseData
{
	// Token: 0x060008F3 RID: 2291 RVA: 0x0004277A File Offset: 0x0004097A
	public string GetName()
	{
		return LocalizationManager.GetTranslation(this.name, true, 0, true, false, null, null, true);
	}

	// Token: 0x060008F4 RID: 2292 RVA: 0x0004278E File Offset: 0x0004098E
	public string GetDescription()
	{
		return LocalizationManager.GetTranslation(this.description, true, 0, true, false, null, null, true);
	}

	// Token: 0x040010FB RID: 4347
	public string name;

	// Token: 0x040010FC RID: 4348
	public string description;

	// Token: 0x040010FD RID: 4349
	public int levelRequirement;

	// Token: 0x040010FE RID: 4350
	public float price;

	// Token: 0x040010FF RID: 4351
	public EObjectType objectType;

	// Token: 0x04001100 RID: 4352
	public Sprite icon;
}
