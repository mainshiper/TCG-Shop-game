﻿using System;

// Token: 0x020000AE RID: 174
public class CEventPlayer_AddCoin : CEvent
{
	// Token: 0x1700000C RID: 12
	// (get) Token: 0x060006F9 RID: 1785 RVA: 0x0003926B File Offset: 0x0003746B
	// (set) Token: 0x060006FA RID: 1786 RVA: 0x00039273 File Offset: 0x00037473
	public float m_CoinValue { get; private set; }

	// Token: 0x1700000D RID: 13
	// (get) Token: 0x060006FB RID: 1787 RVA: 0x0003927C File Offset: 0x0003747C
	// (set) Token: 0x060006FC RID: 1788 RVA: 0x00039284 File Offset: 0x00037484
	public bool m_NoLerp { get; private set; }

	// Token: 0x060006FD RID: 1789 RVA: 0x0003928D File Offset: 0x0003748D
	public CEventPlayer_AddCoin(float coinValue, bool noLerp = false)
	{
		this.m_CoinValue = coinValue;
		this.m_NoLerp = noLerp;
	}
}
