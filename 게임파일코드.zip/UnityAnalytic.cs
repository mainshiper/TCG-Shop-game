﻿using System;
using Unity.Services.Analytics;
using UnityEngine;

// Token: 0x0200010A RID: 266
public class UnityAnalytic : CSingleton<UnityAnalytic>
{
	// Token: 0x060007CC RID: 1996 RVA: 0x0003AFC6 File Offset: 0x000391C6
	private void Awake()
	{
		if (UnityAnalytic.m_Instance == null)
		{
			UnityAnalytic.m_Instance = this;
		}
		else if (UnityAnalytic.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
	}

	// Token: 0x060007CD RID: 1997 RVA: 0x0003AFFB File Offset: 0x000391FB
	private void StartCollection()
	{
		if (!this.m_HasStart)
		{
			this.m_HasStart = true;
		}
	}

	// Token: 0x060007CE RID: 1998 RVA: 0x0003B00C File Offset: 0x0003920C
	public static void StartTutorial(int index)
	{
	}

	// Token: 0x060007CF RID: 1999 RVA: 0x0003B019 File Offset: 0x00039219
	public static void SetUserSegmentIndex(int index)
	{
	}

	// Token: 0x060007D0 RID: 2000 RVA: 0x0003B01C File Offset: 0x0003921C
	public static void JoinDiscord()
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent customEvent = new CustomEvent("JoinDiscord");
		AnalyticsService.Instance.RecordEvent(customEvent);
	}

	// Token: 0x060007D1 RID: 2001 RVA: 0x0003B054 File Offset: 0x00039254
	public static void PressFeedback(int index)
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent customEvent = new CustomEvent("PressFeedback");
		customEvent.Add("Index", index);
		CustomEvent customEvent2 = customEvent;
		AnalyticsService.Instance.RecordEvent(customEvent2);
	}

	// Token: 0x060007D2 RID: 2002 RVA: 0x0003B09C File Offset: 0x0003929C
	public static void PressWishlist(int index)
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent customEvent = new CustomEvent("PressWishlist");
		customEvent.Add("Index", index);
		CustomEvent customEvent2 = customEvent;
		AnalyticsService.Instance.RecordEvent(customEvent2);
	}

	// Token: 0x060007D3 RID: 2003 RVA: 0x0003B0E4 File Offset: 0x000392E4
	public static void PressLoadGame()
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent customEvent = new CustomEvent("PressLoadGame");
		AnalyticsService.Instance.RecordEvent(customEvent);
	}

	// Token: 0x060007D4 RID: 2004 RVA: 0x0003B11C File Offset: 0x0003931C
	public static void PressOverwriteSave()
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent customEvent = new CustomEvent("PressOverwriteSave");
		AnalyticsService.Instance.RecordEvent(customEvent);
	}

	// Token: 0x060007D5 RID: 2005 RVA: 0x0003B154 File Offset: 0x00039354
	public static void GoNextDay(int index)
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent customEvent = new CustomEvent("GoNextDay");
		customEvent.Add("Day", index);
		CustomEvent customEvent2 = customEvent;
		AnalyticsService.Instance.RecordEvent(customEvent2);
	}

	// Token: 0x060007D6 RID: 2006 RVA: 0x0003B19C File Offset: 0x0003939C
	public static void ShopLevelUp(int index)
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent customEvent = new CustomEvent("ShopLevelUp");
		customEvent.Add("Level", index);
		CustomEvent customEvent2 = customEvent;
		AnalyticsService.Instance.RecordEvent(customEvent2);
	}

	// Token: 0x060007D7 RID: 2007 RVA: 0x0003B1E4 File Offset: 0x000393E4
	public static void UnlockNewRoom(int index)
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent customEvent = new CustomEvent("UnlockNewRoom");
		customEvent.Add("roomUnlocked", index);
		CustomEvent customEvent2 = customEvent;
		AnalyticsService.Instance.RecordEvent(customEvent2);
	}

	// Token: 0x060007D8 RID: 2008 RVA: 0x0003B22C File Offset: 0x0003942C
	public static void OpenPack()
	{
	}

	// Token: 0x060007D9 RID: 2009 RVA: 0x0003B23C File Offset: 0x0003943C
	public static void OpenAlbum()
	{
	}

	// Token: 0x060007DA RID: 2010 RVA: 0x0003B24C File Offset: 0x0003944C
	public static void OpenPhone()
	{
	}

	// Token: 0x060007DB RID: 2011 RVA: 0x0003B25C File Offset: 0x0003945C
	public static void PhoneRestock()
	{
	}

	// Token: 0x060007DC RID: 2012 RVA: 0x0003B26C File Offset: 0x0003946C
	public static void PhoneBuyShelf()
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent customEvent = new CustomEvent("PhoneBuyShelf");
		AnalyticsService.Instance.RecordEvent(customEvent);
	}

	// Token: 0x060007DD RID: 2013 RVA: 0x0003B2A4 File Offset: 0x000394A4
	public static void PhoneShopExpansion()
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent customEvent = new CustomEvent("PhoneShopExpansion");
		AnalyticsService.Instance.RecordEvent(customEvent);
	}

	// Token: 0x060007DE RID: 2014 RVA: 0x0003B2DC File Offset: 0x000394DC
	public static void PhoneManageEvent()
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent customEvent = new CustomEvent("PhoneManageEvent");
		AnalyticsService.Instance.RecordEvent(customEvent);
	}

	// Token: 0x060007DF RID: 2015 RVA: 0x0003B314 File Offset: 0x00039514
	public static void PhoneHireWorker()
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent customEvent = new CustomEvent("PhoneHireWorker");
		AnalyticsService.Instance.RecordEvent(customEvent);
	}

	// Token: 0x060007E0 RID: 2016 RVA: 0x0003B34C File Offset: 0x0003954C
	public static void PhoneCheckPrice()
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent customEvent = new CustomEvent("PhoneCheckPrice");
		AnalyticsService.Instance.RecordEvent(customEvent);
	}

	// Token: 0x04000F1A RID: 3866
	public static UnityAnalytic m_Instance;

	// Token: 0x04000F1B RID: 3867
	private static bool m_CanUseAnalytic;

	// Token: 0x04000F1C RID: 3868
	private bool m_HasStart;
}
