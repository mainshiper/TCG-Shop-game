﻿using System;
using UnityEngine;

// Token: 0x0200012A RID: 298
public class TouchManager : CSingleton<TouchManager>
{
	// Token: 0x060008C5 RID: 2245 RVA: 0x00041412 File Offset: 0x0003F612
	private void Awake()
	{
		if (TouchManager.m_Instance == null)
		{
			TouchManager.m_Instance = this;
		}
		else if (TouchManager.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
	}

	// Token: 0x060008C6 RID: 2246 RVA: 0x00041448 File Offset: 0x0003F648
	private void Update()
	{
		if (!this.m_IsEnabled)
		{
			return;
		}
		if (Input.touchSupported && Input.touchCount > 1)
		{
			this.ResetSwipe();
			return;
		}
		if (!this.m_IsPressed)
		{
			this.m_DragRatioX = Mathf.Lerp(this.m_DragRatioX, 0f, Time.deltaTime * 6f);
			this.m_DragRatioY = Mathf.Lerp(this.m_DragRatioY, 0f, Time.deltaTime * 6f);
			this.m_FreeDragRatioX = Mathf.Lerp(this.m_FreeDragRatioX, 0f, Time.deltaTime * 6f);
			this.m_FreeDragRatioY = Mathf.Lerp(this.m_FreeDragRatioY, 0f, Time.deltaTime * 6f);
			if (InputManager.GetKeyDownAction(EGameAction.InteractLeft))
			{
				this.m_AllowButtonPressTimer = 0f;
				this.m_AllowButtonPress = true;
				this.m_IsQuickSwipeX = false;
				this.m_IsQuickSwipeY = false;
				this.m_IsQuickSwipeXn = false;
				this.m_IsQuickSwipeYn = false;
				this.m_ScreenWidth = (float)Screen.width;
				this.m_ScreenHeight = (float)Screen.height;
				this.m_IsPressed = true;
				this.m_IsDragging = false;
				this.m_IsDraggingHorizontally = false;
				this.m_LastPosX = Input.mousePosition.x;
				this.m_FreeLastPosX = Input.mousePosition.x;
				this.m_StartPosX = this.m_LastPosX;
				this.m_LastPosY = Input.mousePosition.y;
				this.m_FreeLastPosY = Input.mousePosition.y;
				this.m_StartPosY = this.m_LastPosY;
				this.m_DragRatioX = 0f;
				this.m_DragRatioY = 0f;
				this.m_FreeDragRatioX = 0f;
				this.m_FreeDragRatioY = 0f;
				this.m_IsSnapping = true;
				this.m_IsSnappingHorizontally = true;
			}
		}
		else
		{
			this.m_QuickSwipeTimer += Time.deltaTime;
			if (!this.m_IsDraggingHorizontally && !this.m_IsDragging && Mathf.Abs(this.m_LastPosY - this.m_StartPosY) > 20f)
			{
				this.m_IsDragging = true;
				RaycasterManager.SetUIRaycastEnabled(false);
			}
			else if (!this.m_IsDraggingHorizontally && !this.m_IsDragging && Mathf.Abs(this.m_LastPosX - this.m_StartPosX) > 20f)
			{
				this.m_IsDraggingHorizontally = true;
				RaycasterManager.SetUIRaycastEnabled(false);
			}
			if ((this.m_IsDragging || this.m_IsDraggingHorizontally) && this.m_QuickSwipeTimer > 0.02f && this.m_TargetLerpSpeed != 100f)
			{
				this.m_DragRatioX = 0f;
				this.m_DragRatioY = 0f;
				this.m_TargetLerpSpeed = 100f;
				this.m_LerpSpeed = 100f;
				if (this.m_IsDragging)
				{
					this.m_IsSnapping = true;
				}
				else if (this.m_IsDraggingHorizontally)
				{
					this.m_IsSnappingHorizontally = true;
				}
			}
			if (this.m_IsDraggingHorizontally)
			{
				this.m_DragRatioX = (Input.mousePosition.x - this.m_LastPosX) / this.m_ScreenWidth;
			}
			else if (this.m_IsDragging)
			{
				this.m_DragRatioY = (Input.mousePosition.y - this.m_LastPosY) / this.m_ScreenHeight;
			}
			this.m_FreeDragRatioX = (Input.mousePosition.x - this.m_FreeLastPosX) / this.m_ScreenWidth;
			this.m_FreeDragRatioY = (Input.mousePosition.y - this.m_FreeLastPosY) / this.m_ScreenHeight;
			if (!this.m_IsDragging)
			{
				this.m_LastPosX = Input.mousePosition.x;
			}
			if (!this.m_IsDraggingHorizontally)
			{
				this.m_LastPosY = Input.mousePosition.y;
			}
			this.m_FreeLastPosX = Input.mousePosition.x;
			this.m_FreeLastPosY = Input.mousePosition.y;
			if (Input.GetMouseButtonUp(0))
			{
				if (this.m_QuickSwipeTimer < 0.4f)
				{
					if (this.m_LastPosX - this.m_StartPosX > 150f)
					{
						this.m_IsQuickSwipeX = true;
					}
					if (this.m_LastPosY - this.m_StartPosY > 150f)
					{
						this.m_IsQuickSwipeY = true;
					}
					if (this.m_LastPosX - this.m_StartPosX < -150f)
					{
						this.m_IsQuickSwipeXn = true;
					}
					if (this.m_LastPosY - this.m_StartPosY < -150f)
					{
						this.m_IsQuickSwipeYn = true;
					}
				}
				float num = Mathf.Clamp((0.5f - this.m_QuickSwipeTimer) * 0.15f, 0f, 0.1f);
				if (this.m_IsQuickSwipeX)
				{
					this.m_DragRatioX += num;
				}
				if (this.m_IsQuickSwipeXn)
				{
					this.m_DragRatioX -= num;
				}
				if (this.m_IsQuickSwipeY)
				{
					this.m_DragRatioY += num;
				}
				if (this.m_IsQuickSwipeYn)
				{
					this.m_DragRatioY -= num;
				}
				this.m_QuickSwipeTimer = 0f;
				this.m_IsDragging = false;
				this.m_IsDraggingHorizontally = false;
				this.m_IsPressed = false;
				this.m_ReleasePos = Input.mousePosition;
				this.m_TargetLerpSpeed = this.m_DefaultLerpSpeed;
				this.m_LerpSpeed = this.m_DefaultLerpSpeed;
				this.m_AllowButtonPress = true;
				RaycasterManager.SetUIRaycastEnabled(true);
			}
		}
		if (this.m_AllowButtonPress && (TouchManager.IsDragging() || TouchManager.IsDraggingHorizontally()))
		{
			this.m_AllowButtonPress = false;
		}
		if (!this.m_IsPressed && !this.m_AllowButtonPress)
		{
			this.m_AllowButtonPressTimer += Time.deltaTime;
			float allowButtonPressTimer = this.m_AllowButtonPressTimer;
		}
	}

	// Token: 0x060008C7 RID: 2247 RVA: 0x00041970 File Offset: 0x0003FB70
	public void ResetSwipe()
	{
		this.m_AllowButtonPress = false;
		this.m_QuickSwipeTimer = 0f;
		this.m_IsDragging = false;
		this.m_IsDraggingHorizontally = false;
		this.m_IsSnapping = false;
		this.m_IsSnappingHorizontally = false;
		this.m_DragRatioX = 0f;
		this.m_DragRatioY = 0f;
		this.m_FreeDragRatioX = 0f;
		this.m_FreeDragRatioY = 0f;
		this.m_LastPosX = Input.mousePosition.x;
		this.m_LastPosY = Input.mousePosition.y;
		this.m_FreeLastPosX = Input.mousePosition.x;
		this.m_FreeLastPosY = Input.mousePosition.y;
		this.m_IsQuickSwipeX = false;
		this.m_IsQuickSwipeY = false;
		this.m_IsQuickSwipeXn = false;
		this.m_IsQuickSwipeYn = false;
		this.m_IsPressed = false;
		this.m_ReleasePos = Input.mousePosition;
		this.m_TargetLerpSpeed = this.m_DefaultLerpSpeed;
		this.m_LerpSpeed = this.m_DefaultLerpSpeed;
		RaycasterManager.SetUIRaycastEnabled(true);
	}

	// Token: 0x060008C8 RID: 2248 RVA: 0x00041A68 File Offset: 0x0003FC68
	public static bool IsDragging()
	{
		return CSingleton<TouchManager>.Instance.m_IsDragging;
	}

	// Token: 0x060008C9 RID: 2249 RVA: 0x00041A74 File Offset: 0x0003FC74
	public static bool IsDraggingHorizontally()
	{
		return CSingleton<TouchManager>.Instance.m_IsDraggingHorizontally;
	}

	// Token: 0x060008CA RID: 2250 RVA: 0x00041A80 File Offset: 0x0003FC80
	public static int GetTouchFingerID()
	{
		if (Input.touchCount > 0)
		{
			return Input.GetTouch(Input.touchCount - 1).fingerId;
		}
		return -1;
	}

	// Token: 0x060008CB RID: 2251 RVA: 0x00041AAB File Offset: 0x0003FCAB
	public static bool IsSnappingToFinger()
	{
		if (CSingleton<TouchManager>.Instance.m_IsSnapping)
		{
			CSingleton<TouchManager>.Instance.m_IsSnapping = false;
			return true;
		}
		return false;
	}

	// Token: 0x060008CC RID: 2252 RVA: 0x00041AC7 File Offset: 0x0003FCC7
	public static bool IsSnappingToFingerHorizontally()
	{
		if (CSingleton<TouchManager>.Instance.m_IsSnappingHorizontally)
		{
			CSingleton<TouchManager>.Instance.m_IsSnappingHorizontally = false;
			return true;
		}
		return false;
	}

	// Token: 0x060008CD RID: 2253 RVA: 0x00041AE3 File Offset: 0x0003FCE3
	public static void ResetFingerSnapping()
	{
		CSingleton<TouchManager>.Instance.m_IsSnapping = false;
		CSingleton<TouchManager>.Instance.m_IsSnappingHorizontally = false;
	}

	// Token: 0x060008CE RID: 2254 RVA: 0x00041AFC File Offset: 0x0003FCFC
	public static Vector3 GetTouchPositionUsingID(int fingerID)
	{
		if ((!Input.touchSupported && !Input.multiTouchEnabled) || fingerID == -1)
		{
			return Input.mousePosition;
		}
		for (int i = 0; i < Input.touchCount; i++)
		{
			if (Input.GetTouch(i).fingerId == fingerID)
			{
				return Input.GetTouch(i).position;
			}
		}
		return Vector3.zero;
	}

	// Token: 0x040010A4 RID: 4260
	public static TouchManager m_Instance;

	// Token: 0x040010A5 RID: 4261
	public float m_ScrollSpeedMultiplier = 1f;

	// Token: 0x040010A6 RID: 4262
	public bool m_IsEnabled = true;

	// Token: 0x040010A7 RID: 4263
	public bool m_IsPressed;

	// Token: 0x040010A8 RID: 4264
	public bool m_IsDragging;

	// Token: 0x040010A9 RID: 4265
	public bool m_IsDraggingHorizontally;

	// Token: 0x040010AA RID: 4266
	public bool m_IsQuickSwipeX;

	// Token: 0x040010AB RID: 4267
	public bool m_IsQuickSwipeY;

	// Token: 0x040010AC RID: 4268
	public bool m_IsQuickSwipeXn;

	// Token: 0x040010AD RID: 4269
	public bool m_IsQuickSwipeYn;

	// Token: 0x040010AE RID: 4270
	public bool m_IsSnapping;

	// Token: 0x040010AF RID: 4271
	public bool m_IsSnappingHorizontally;

	// Token: 0x040010B0 RID: 4272
	private float m_StartPosX;

	// Token: 0x040010B1 RID: 4273
	private float m_LastPosX;

	// Token: 0x040010B2 RID: 4274
	private float m_StartPosY;

	// Token: 0x040010B3 RID: 4275
	private float m_LastPosY;

	// Token: 0x040010B4 RID: 4276
	public float m_DragRatioX;

	// Token: 0x040010B5 RID: 4277
	public float m_DragRatioY;

	// Token: 0x040010B6 RID: 4278
	public float m_FreeDragRatioX;

	// Token: 0x040010B7 RID: 4279
	public float m_FreeDragRatioY;

	// Token: 0x040010B8 RID: 4280
	private float m_FreeLastPosX;

	// Token: 0x040010B9 RID: 4281
	private float m_FreeLastPosY;

	// Token: 0x040010BA RID: 4282
	private float m_ScreenWidth;

	// Token: 0x040010BB RID: 4283
	private float m_ScreenHeight;

	// Token: 0x040010BC RID: 4284
	public Vector2 m_ReleasePos;

	// Token: 0x040010BD RID: 4285
	private float m_QuickSwipeTimer;

	// Token: 0x040010BE RID: 4286
	public float m_LerpSpeed = 5f;

	// Token: 0x040010BF RID: 4287
	public float m_TargetLerpSpeed = 5f;

	// Token: 0x040010C0 RID: 4288
	public float m_DefaultLerpSpeed = 7f;

	// Token: 0x040010C1 RID: 4289
	public bool m_AllowButtonPress = true;

	// Token: 0x040010C2 RID: 4290
	private float m_AllowButtonPressTimer;
}
