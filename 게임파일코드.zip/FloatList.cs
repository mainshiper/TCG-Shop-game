﻿using System;
using System.Collections.Generic;

// Token: 0x0200003F RID: 63
[Serializable]
public class FloatList
{
	// Token: 0x040003CB RID: 971
	public List<float> floatDataList;
}
