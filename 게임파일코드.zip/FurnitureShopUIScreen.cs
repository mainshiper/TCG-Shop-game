﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000068 RID: 104
public class FurnitureShopUIScreen : GenericSliderScreen
{
	// Token: 0x06000466 RID: 1126 RVA: 0x00026C40 File Offset: 0x00024E40
	protected override void Init()
	{
		for (int i = 0; i < this.m_FurnitureShopPanelUIList.Count; i++)
		{
			this.m_FurnitureShopPanelUIList[i].SetActive(false);
		}
		int count = CSingleton<InventoryBase>.Instance.m_ObjectData_SO.m_FurniturePurchaseDataList.Count;
		for (int j = 0; j < count; j++)
		{
			this.m_FurnitureShopPanelUIList[j].Init(this, j);
			this.m_FurnitureShopPanelUIList[j].SetActive(true);
			this.m_ScrollEndPosParent = this.m_FurnitureShopPanelUIList[j].gameObject;
		}
		base.Init();
	}

	// Token: 0x06000467 RID: 1127 RVA: 0x00026CD8 File Offset: 0x00024ED8
	protected override void OnOpenScreen()
	{
		this.Init();
		base.OnOpenScreen();
	}

	// Token: 0x06000468 RID: 1128 RVA: 0x00026CE6 File Offset: 0x00024EE6
	public void OnPressPanelUIButton(int index)
	{
		this.m_ConfirmPurchaseScreen.UpdateData(this, index);
		base.OpenChildScreen(this.m_ConfirmPurchaseScreen);
	}

	// Token: 0x06000469 RID: 1129 RVA: 0x00026D04 File Offset: 0x00024F04
	private void SpawnPackageItemBox(EObjectType objectType)
	{
		Transform randomPackageSpawnPos = RestockManager.GetRandomPackageSpawnPos();
		ShelfManager.SpawnInteractableObjectInPackageBox(objectType, randomPackageSpawnPos.position, randomPackageSpawnPos.rotation);
	}

	// Token: 0x0600046A RID: 1130 RVA: 0x00026D2C File Offset: 0x00024F2C
	public void EvaluateCartCheckout(float totalCost, int index)
	{
		CEventManager.QueueEvent(new CEventPlayer_ReduceCoin(totalCost, false));
		FurniturePurchaseData furniturePurchaseData = InventoryBase.GetFurniturePurchaseData(index);
		this.SpawnPackageItemBox(furniturePurchaseData.objectType);
		base.StartCoroutine(this.DelaySaveShelfData());
		CEventManager.QueueEvent(new CEventPlayer_AddShopExp(Mathf.Clamp(Mathf.RoundToInt(totalCost / 100f), 5, 100), false));
		CPlayerData.m_GameReportDataCollect.upgradeCost = CPlayerData.m_GameReportDataCollect.upgradeCost - totalCost;
		CPlayerData.m_GameReportDataCollectPermanent.upgradeCost = CPlayerData.m_GameReportDataCollectPermanent.upgradeCost - totalCost;
		SoundManager.PlayAudio("SFX_CustomerBuy", 0.6f, 1f);
	}

	// Token: 0x0600046B RID: 1131 RVA: 0x00026DB6 File Offset: 0x00024FB6
	private IEnumerator DelaySaveShelfData()
	{
		yield return new WaitForSeconds(1f);
		CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
		yield break;
	}

	// Token: 0x04000576 RID: 1398
	public List<FurnitureShopPanelUI> m_FurnitureShopPanelUIList;

	// Token: 0x04000577 RID: 1399
	public FurnitureShopConfirmPurchaseScreen m_ConfirmPurchaseScreen;
}
