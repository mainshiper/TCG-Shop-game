﻿using System;

// Token: 0x020000F9 RID: 249
public enum EDialogueImageIndex
{
	// Token: 0x04000DB8 RID: 3512
	None,
	// Token: 0x04000DB9 RID: 3513
	RobotProxy
}
