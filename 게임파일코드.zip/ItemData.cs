﻿using System;
using System.Collections.Generic;
using I2.Loc;
using UnityEngine;

// Token: 0x02000031 RID: 49
[Serializable]
public class ItemData
{
	// Token: 0x060002A4 RID: 676 RVA: 0x0001A07D File Offset: 0x0001827D
	public string GetName()
	{
		return LocalizationManager.GetTranslation(this.name, true, 0, true, false, null, null, true);
	}

	// Token: 0x060002A5 RID: 677 RVA: 0x0001A094 File Offset: 0x00018294
	public float GetItemVolume()
	{
		if (this.isTallItem)
		{
			return this.itemDimension.x * this.itemDimension.y * this.itemDimension.z * 2f;
		}
		return this.itemDimension.x * this.itemDimension.y * this.itemDimension.z;
	}

	// Token: 0x04000301 RID: 769
	public string name;

	// Token: 0x04000302 RID: 770
	public Sprite icon;

	// Token: 0x04000303 RID: 771
	public float iconScale;

	// Token: 0x04000304 RID: 772
	public float baseCost;

	// Token: 0x04000305 RID: 773
	public float marketPriceMinPercent;

	// Token: 0x04000306 RID: 774
	public float marketPriceMaxPercent;

	// Token: 0x04000307 RID: 775
	public EItemType boxFollowItemPrice;

	// Token: 0x04000308 RID: 776
	public bool isNotBoosterPack;

	// Token: 0x04000309 RID: 777
	public bool isTallItem;

	// Token: 0x0400030A RID: 778
	public bool isHideItemUntilUnlocked;

	// Token: 0x0400030B RID: 779
	public float posYOffsetInBox;

	// Token: 0x0400030C RID: 780
	public float scaleOffsetInBox;

	// Token: 0x0400030D RID: 781
	public Vector3 itemDimension;

	// Token: 0x0400030E RID: 782
	public Vector3 colliderPosOffset;

	// Token: 0x0400030F RID: 783
	public Vector3 colliderScale;

	// Token: 0x04000310 RID: 784
	public List<EPriceChangeType> affectedPriceChangeType;
}
