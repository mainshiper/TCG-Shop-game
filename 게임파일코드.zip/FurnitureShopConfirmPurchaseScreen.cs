﻿using System;
using TMPro;
using UnityEngine.UI;

// Token: 0x02000066 RID: 102
public class FurnitureShopConfirmPurchaseScreen : UIScreenBase
{
	// Token: 0x06000460 RID: 1120 RVA: 0x000269CC File Offset: 0x00024BCC
	public void UpdateData(FurnitureShopUIScreen furnitureShopUIScreen, int index)
	{
		this.m_FurnitureShopUIScreen = furnitureShopUIScreen;
		this.m_Index = index;
		FurniturePurchaseData furniturePurchaseData = InventoryBase.GetFurniturePurchaseData(index);
		this.m_TotalCost = furniturePurchaseData.price;
		this.m_Image.sprite = furniturePurchaseData.icon;
		this.m_NameText.text = furniturePurchaseData.GetName();
		this.m_DescriptionText.text = furniturePurchaseData.GetDescription();
		this.m_PriceText.text = GameInstance.GetPriceString(this.m_TotalCost, false, true, false, "F2");
	}

	// Token: 0x06000461 RID: 1121 RVA: 0x00026A4C File Offset: 0x00024C4C
	public void OnPressConfirmCheckout()
	{
		if (this.m_TotalCost <= 0f)
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.NothingInCart);
			return;
		}
		if (CPlayerData.m_CoinAmount >= this.m_TotalCost)
		{
			this.m_FurnitureShopUIScreen.EvaluateCartCheckout(this.m_TotalCost, this.m_Index);
			base.CloseScreen();
			return;
		}
		NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.Money);
	}

	// Token: 0x04000564 RID: 1380
	public Image m_Image;

	// Token: 0x04000565 RID: 1381
	public TextMeshProUGUI m_NameText;

	// Token: 0x04000566 RID: 1382
	public TextMeshProUGUI m_DescriptionText;

	// Token: 0x04000567 RID: 1383
	public TextMeshProUGUI m_PriceText;

	// Token: 0x04000568 RID: 1384
	private FurnitureShopUIScreen m_FurnitureShopUIScreen;

	// Token: 0x04000569 RID: 1385
	private int m_Index;

	// Token: 0x0400056A RID: 1386
	private float m_TotalCost;
}
