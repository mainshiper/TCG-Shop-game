﻿using System;

// Token: 0x020000D0 RID: 208
public class CEventPlayer_OnKeybindChanged : CEvent
{
}
