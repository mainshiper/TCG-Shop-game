﻿using System;
using Pathfinding;
using UnityEngine;

// Token: 0x0200009F RID: 159
public class SeekerTest : MonoBehaviour
{
	// Token: 0x06000638 RID: 1592 RVA: 0x0003337A File Offset: 0x0003157A
	public void Start()
	{
		this.seeker = base.GetComponent<Seeker>();
		this.seeker.StartPath(base.transform.position, this.targetPosition.position, new OnPathDelegate(this.OnPathComplete));
	}

	// Token: 0x06000639 RID: 1593 RVA: 0x000333B8 File Offset: 0x000315B8
	public void OnPathComplete(Path p)
	{
		Debug.Log("A path was calculated. Did it fail with an error? " + p.error.ToString());
		p.Claim(this);
		if (!p.error)
		{
			if (this.path != null)
			{
				this.path.Release(this, false);
			}
			this.path = p;
			this.currentWaypoint = 0;
			return;
		}
		p.Release(this, false);
	}

	// Token: 0x0600063A RID: 1594 RVA: 0x00033420 File Offset: 0x00031620
	public void Update()
	{
		if (Time.time > this.lastRepath + this.repathRate && this.seeker.IsDone())
		{
			this.lastRepath = Time.time;
			this.seeker.StartPath(base.transform.position, this.targetPosition.position, new OnPathDelegate(this.OnPathComplete));
		}
		if (this.path == null)
		{
			return;
		}
		this.reachedEndOfPath = false;
		float num;
		for (;;)
		{
			num = Vector3.Distance(base.transform.position, this.path.vectorPath[this.currentWaypoint]);
			if (num >= this.nextWaypointDistance)
			{
				goto IL_CB;
			}
			if (this.currentWaypoint + 1 >= this.path.vectorPath.Count)
			{
				break;
			}
			this.currentWaypoint++;
		}
		this.reachedEndOfPath = true;
		IL_CB:
		float d = this.reachedEndOfPath ? Mathf.Sqrt(num / this.nextWaypointDistance) : 1f;
		(this.path.vectorPath[this.currentWaypoint] - base.transform.position).normalized * this.speed * d;
		base.transform.position = Vector3.MoveTowards(base.transform.position, this.path.vectorPath[this.currentWaypoint], this.speed);
	}

	// Token: 0x04000801 RID: 2049
	public Transform targetPosition;

	// Token: 0x04000802 RID: 2050
	private Seeker seeker;

	// Token: 0x04000803 RID: 2051
	public Path path;

	// Token: 0x04000804 RID: 2052
	public float speed = 2f;

	// Token: 0x04000805 RID: 2053
	public float nextWaypointDistance = 3f;

	// Token: 0x04000806 RID: 2054
	private int currentWaypoint;

	// Token: 0x04000807 RID: 2055
	public float repathRate = 0.5f;

	// Token: 0x04000808 RID: 2056
	private float lastRepath = float.NegativeInfinity;

	// Token: 0x04000809 RID: 2057
	public bool reachedEndOfPath;
}
