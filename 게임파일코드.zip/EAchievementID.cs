﻿using System;

// Token: 0x020000FA RID: 250
public enum EAchievementID
{
	// Token: 0x04000DBB RID: 3515
	Main1,
	// Token: 0x04000DBC RID: 3516
	Main2,
	// Token: 0x04000DBD RID: 3517
	Main3,
	// Token: 0x04000DBE RID: 3518
	Main4,
	// Token: 0x04000DBF RID: 3519
	Main5,
	// Token: 0x04000DC0 RID: 3520
	TetramonCollector1,
	// Token: 0x04000DC1 RID: 3521
	TetramonCollector2,
	// Token: 0x04000DC2 RID: 3522
	TetramonCollector3,
	// Token: 0x04000DC3 RID: 3523
	TetramonCollector4,
	// Token: 0x04000DC4 RID: 3524
	TetramonCollector5,
	// Token: 0x04000DC5 RID: 3525
	TetramonCollector6,
	// Token: 0x04000DC6 RID: 3526
	BasicCardBox,
	// Token: 0x04000DC7 RID: 3527
	LegendaryPack,
	// Token: 0x04000DC8 RID: 3528
	BasicPackSales1,
	// Token: 0x04000DC9 RID: 3529
	BasicPackSales2,
	// Token: 0x04000DCA RID: 3530
	BasicPackSales3,
	// Token: 0x04000DCB RID: 3531
	RareBoxSales1,
	// Token: 0x04000DCC RID: 3532
	RareBoxSales2,
	// Token: 0x04000DCD RID: 3533
	RareBoxSales3,
	// Token: 0x04000DCE RID: 3534
	EpicPackSales1,
	// Token: 0x04000DCF RID: 3535
	EpicPackSales2,
	// Token: 0x04000DD0 RID: 3536
	EpicPackSales3,
	// Token: 0x04000DD1 RID: 3537
	LegendaryBoxSales1,
	// Token: 0x04000DD2 RID: 3538
	LegendaryBoxSales2,
	// Token: 0x04000DD3 RID: 3539
	LegendaryBoxSales3,
	// Token: 0x04000DD4 RID: 3540
	Customer1,
	// Token: 0x04000DD5 RID: 3541
	Customer2,
	// Token: 0x04000DD6 RID: 3542
	Customer3,
	// Token: 0x04000DD7 RID: 3543
	Global1,
	// Token: 0x04000DD8 RID: 3544
	Global2,
	// Token: 0x04000DD9 RID: 3545
	Global3,
	// Token: 0x04000DDA RID: 3546
	ShopExpand1,
	// Token: 0x04000DDB RID: 3547
	ShopExpand2,
	// Token: 0x04000DDC RID: 3548
	ShopExpand3,
	// Token: 0x04000DDD RID: 3549
	ShopAttract1,
	// Token: 0x04000DDE RID: 3550
	ShopAttract2,
	// Token: 0x04000DDF RID: 3551
	ShopAttract3,
	// Token: 0x04000DE0 RID: 3552
	ShopAttract4,
	// Token: 0x04000DE1 RID: 3553
	Shelf1,
	// Token: 0x04000DE2 RID: 3554
	Shelf2,
	// Token: 0x04000DE3 RID: 3555
	Shelf3,
	// Token: 0x04000DE4 RID: 3556
	SmTable1,
	// Token: 0x04000DE5 RID: 3557
	SmTable2,
	// Token: 0x04000DE6 RID: 3558
	SmTable3,
	// Token: 0x04000DE7 RID: 3559
	MediumTable1,
	// Token: 0x04000DE8 RID: 3560
	MediumTable2,
	// Token: 0x04000DE9 RID: 3561
	MediumTable3,
	// Token: 0x04000DEA RID: 3562
	LongShelf1,
	// Token: 0x04000DEB RID: 3563
	LongShelf2,
	// Token: 0x04000DEC RID: 3564
	LongShelf3,
	// Token: 0x04000DED RID: 3565
	ATM1,
	// Token: 0x04000DEE RID: 3566
	ATM2,
	// Token: 0x04000DEF RID: 3567
	ATM3,
	// Token: 0x04000DF0 RID: 3568
	Loudspeaker1,
	// Token: 0x04000DF1 RID: 3569
	Loudspeaker2,
	// Token: 0x04000DF2 RID: 3570
	Loudspeaker3,
	// Token: 0x04000DF3 RID: 3571
	Trolley1,
	// Token: 0x04000DF4 RID: 3572
	Trolley2,
	// Token: 0x04000DF5 RID: 3573
	Trolley3,
	// Token: 0x04000DF6 RID: 3574
	PackStorage1,
	// Token: 0x04000DF7 RID: 3575
	PackStorage2,
	// Token: 0x04000DF8 RID: 3576
	PackStorage3,
	// Token: 0x04000DF9 RID: 3577
	Pigni1,
	// Token: 0x04000DFA RID: 3578
	Pigni2,
	// Token: 0x04000DFB RID: 3579
	Pigni3,
	// Token: 0x04000DFC RID: 3580
	Trickstar1,
	// Token: 0x04000DFD RID: 3581
	Trickstar2,
	// Token: 0x04000DFE RID: 3582
	Trickstar3,
	// Token: 0x04000DFF RID: 3583
	Meganite1,
	// Token: 0x04000E00 RID: 3584
	Meganite2,
	// Token: 0x04000E01 RID: 3585
	Meganite3,
	// Token: 0x04000E02 RID: 3586
	Dracunix1,
	// Token: 0x04000E03 RID: 3587
	Dracunix2,
	// Token: 0x04000E04 RID: 3588
	Dracunix3,
	// Token: 0x04000E05 RID: 3589
	Vehicle1,
	// Token: 0x04000E06 RID: 3590
	Vehicle2,
	// Token: 0x04000E07 RID: 3591
	Vehicle3,
	// Token: 0x04000E08 RID: 3592
	Bike1,
	// Token: 0x04000E09 RID: 3593
	Bike2,
	// Token: 0x04000E0A RID: 3594
	Bike3,
	// Token: 0x04000E0B RID: 3595
	Van1,
	// Token: 0x04000E0C RID: 3596
	Van2,
	// Token: 0x04000E0D RID: 3597
	Van3,
	// Token: 0x04000E0E RID: 3598
	Helicopter1,
	// Token: 0x04000E0F RID: 3599
	Helicopter2,
	// Token: 0x04000E10 RID: 3600
	Helicopter3,
	// Token: 0x04000E11 RID: 3601
	DestinyCard1,
	// Token: 0x04000E12 RID: 3602
	DestinyCard2,
	// Token: 0x04000E13 RID: 3603
	DestinyCard3,
	// Token: 0x04000E14 RID: 3604
	DestinyCard4,
	// Token: 0x04000E15 RID: 3605
	DestinyCard5,
	// Token: 0x04000E16 RID: 3606
	DestinyCard6,
	// Token: 0x04000E17 RID: 3607
	DestinyBasic1,
	// Token: 0x04000E18 RID: 3608
	DestinyBasic2,
	// Token: 0x04000E19 RID: 3609
	DestinyBasic3,
	// Token: 0x04000E1A RID: 3610
	DestinyRare1,
	// Token: 0x04000E1B RID: 3611
	DestinyRare2,
	// Token: 0x04000E1C RID: 3612
	DestinyRare3,
	// Token: 0x04000E1D RID: 3613
	DestinyEpic1,
	// Token: 0x04000E1E RID: 3614
	DestinyEpic2,
	// Token: 0x04000E1F RID: 3615
	DestinyEpic3,
	// Token: 0x04000E20 RID: 3616
	DestinyLegendary1,
	// Token: 0x04000E21 RID: 3617
	DestinyLegendary2,
	// Token: 0x04000E22 RID: 3618
	DestinyLegendary3,
	// Token: 0x04000E23 RID: 3619
	GhostCard1,
	// Token: 0x04000E24 RID: 3620
	GhostCard2,
	// Token: 0x04000E25 RID: 3621
	GhostCard3,
	// Token: 0x04000E26 RID: 3622
	GhostCard4,
	// Token: 0x04000E27 RID: 3623
	GhostCard5,
	// Token: 0x04000E28 RID: 3624
	GhostCard6,
	// Token: 0x04000E29 RID: 3625
	GhostPack1,
	// Token: 0x04000E2A RID: 3626
	GhostPack2,
	// Token: 0x04000E2B RID: 3627
	GhostPack3
}
