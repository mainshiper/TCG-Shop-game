﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E1 RID: 481
	public class FlipAtRightAngle : MonoBehaviour
	{
		// Token: 0x06000D98 RID: 3480 RVA: 0x0005EF05 File Offset: 0x0005D105
		private void Start()
		{
			this.tr = base.transform;
			this.audioSource = base.GetComponent<AudioSource>();
		}

		// Token: 0x06000D99 RID: 3481 RVA: 0x0005EF1F File Offset: 0x0005D11F
		private void OnTriggerEnter(Collider col)
		{
			if (col.GetComponent<Controller>() == null)
			{
				return;
			}
			this.SwitchDirection(this.tr.forward, col.GetComponent<Controller>());
		}

		// Token: 0x06000D9A RID: 3482 RVA: 0x0005EF48 File Offset: 0x0005D148
		private void SwitchDirection(Vector3 _newUpDirection, Controller _controller)
		{
			float num = 0.001f;
			if (Vector3.Angle(_newUpDirection, _controller.transform.up) < num)
			{
				return;
			}
			this.audioSource.Play();
			Transform transform = _controller.transform;
			Quaternion lhs = Quaternion.FromToRotation(transform.up, _newUpDirection);
			transform.rotation = lhs * transform.rotation;
		}

		// Token: 0x040014AE RID: 5294
		private AudioSource audioSource;

		// Token: 0x040014AF RID: 5295
		private Transform tr;
	}
}
