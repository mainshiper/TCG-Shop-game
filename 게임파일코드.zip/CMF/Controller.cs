﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001DC RID: 476
	public abstract class Controller : MonoBehaviour
	{
		// Token: 0x06000D62 RID: 3426
		public abstract Vector3 GetVelocity();

		// Token: 0x06000D63 RID: 3427
		public abstract Vector3 GetMovementVelocity();

		// Token: 0x06000D64 RID: 3428
		public abstract bool IsGrounded();

		// Token: 0x04001470 RID: 5232
		public Controller.VectorEvent OnJump;

		// Token: 0x04001471 RID: 5233
		public Controller.VectorEvent OnLand;

		// Token: 0x02000281 RID: 641
		// (Invoke) Token: 0x0600102D RID: 4141
		public delegate void VectorEvent(Vector3 v);
	}
}
