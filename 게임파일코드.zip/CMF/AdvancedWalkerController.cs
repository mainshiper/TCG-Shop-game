﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001DB RID: 475
	public class AdvancedWalkerController : Controller
	{
		// Token: 0x06000D47 RID: 3399 RVA: 0x0005CCF0 File Offset: 0x0005AEF0
		private void Awake()
		{
			this.mover = base.GetComponent<Mover>();
			this.tr = base.transform;
			this.characterInput = base.GetComponent<CharacterInput>();
			this.ceilingDetector = base.GetComponent<CeilingDetector>();
			if (this.characterInput == null)
			{
				Debug.LogWarning("No character input script has been attached to this gameobject", base.gameObject);
			}
			this.Setup();
			this.movementSpeedModified = this.movementSpeed;
		}

		// Token: 0x06000D48 RID: 3400 RVA: 0x0005CD5D File Offset: 0x0005AF5D
		protected virtual void Setup()
		{
		}

		// Token: 0x06000D49 RID: 3401 RVA: 0x0005CD5F File Offset: 0x0005AF5F
		private void Update()
		{
			if (this.isStopMovement)
			{
				return;
			}
			this.HandleJumpKeyInput();
		}

		// Token: 0x06000D4A RID: 3402 RVA: 0x0005CD70 File Offset: 0x0005AF70
		private void HandleJumpKeyInput()
		{
			bool flag = this.IsJumpKeyPressed();
			if (!this.jumpKeyIsPressed && flag)
			{
				this.jumpKeyWasPressed = true;
			}
			if (this.jumpKeyIsPressed && !flag)
			{
				this.jumpKeyWasLetGo = true;
				this.jumpInputIsLocked = false;
			}
			this.jumpKeyIsPressed = flag;
		}

		// Token: 0x06000D4B RID: 3403 RVA: 0x0005CDB6 File Offset: 0x0005AFB6
		private void FixedUpdate()
		{
			this.ControllerUpdate();
		}

		// Token: 0x06000D4C RID: 3404 RVA: 0x0005CDC0 File Offset: 0x0005AFC0
		private void ControllerUpdate()
		{
			this.mover.CheckForGround();
			this.currentControllerState = this.DetermineControllerState();
			this.HandleMomentum();
			this.HandleJumping();
			if (InputManager.GetKeyHoldAction(EGameAction.Sprint))
			{
				this.movementSpeedModified = this.movementSpeed * 1.5f;
			}
			else
			{
				this.movementSpeedModified = this.movementSpeed;
			}
			Vector3 vector = Vector3.zero;
			if (!this.isStopMovement && this.currentControllerState == AdvancedWalkerController.ControllerState.Grounded)
			{
				vector = this.CalculateMovementVelocity();
			}
			Vector3 b = this.momentum;
			if (this.useLocalMomentum)
			{
				b = this.tr.localToWorldMatrix * this.momentum;
			}
			vector += b;
			this.mover.SetExtendSensorRange(this.IsGrounded());
			this.mover.SetVelocity(vector);
			this.savedVelocity = vector;
			this.savedMovementVelocity = this.CalculateMovementVelocity();
			this.jumpKeyWasLetGo = false;
			this.jumpKeyWasPressed = false;
			if (this.ceilingDetector != null)
			{
				this.ceilingDetector.ResetFlags();
			}
		}

		// Token: 0x06000D4D RID: 3405 RVA: 0x0005CEC8 File Offset: 0x0005B0C8
		protected virtual Vector3 CalculateMovementDirection()
		{
			if (this.characterInput == null)
			{
				return Vector3.zero;
			}
			Vector3 vector = Vector3.zero;
			if (this.cameraTransform == null)
			{
				vector += this.tr.right * this.characterInput.GetHorizontalMovementInput();
				vector += this.tr.forward * this.characterInput.GetVerticalMovementInput();
			}
			else
			{
				vector += Vector3.ProjectOnPlane(this.cameraTransform.right, this.tr.up).normalized * this.characterInput.GetHorizontalMovementInput();
				vector += Vector3.ProjectOnPlane(this.cameraTransform.forward, this.tr.up).normalized * this.characterInput.GetVerticalMovementInput();
			}
			if (vector.magnitude > 1f)
			{
				vector.Normalize();
			}
			return vector;
		}

		// Token: 0x06000D4E RID: 3406 RVA: 0x0005CFCD File Offset: 0x0005B1CD
		protected virtual Vector3 CalculateMovementVelocity()
		{
			return this.CalculateMovementDirection() * this.movementSpeedModified;
		}

		// Token: 0x06000D4F RID: 3407 RVA: 0x0005CFE0 File Offset: 0x0005B1E0
		protected virtual bool IsJumpKeyPressed()
		{
			return !(this.characterInput == null) && this.characterInput.IsJumpKeyPressed();
		}

		// Token: 0x06000D50 RID: 3408 RVA: 0x0005D000 File Offset: 0x0005B200
		private AdvancedWalkerController.ControllerState DetermineControllerState()
		{
			bool flag = this.IsRisingOrFalling() && VectorMath.GetDotProduct(this.GetMomentum(), this.tr.up) > 0f;
			bool flag2 = this.mover.IsGrounded() && this.IsGroundTooSteep();
			if (this.currentControllerState == AdvancedWalkerController.ControllerState.Grounded)
			{
				if (flag)
				{
					this.OnGroundContactLost();
					return AdvancedWalkerController.ControllerState.Rising;
				}
				if (!this.mover.IsGrounded())
				{
					this.OnGroundContactLost();
					return AdvancedWalkerController.ControllerState.Falling;
				}
				if (flag2)
				{
					this.OnGroundContactLost();
					return AdvancedWalkerController.ControllerState.Sliding;
				}
				return AdvancedWalkerController.ControllerState.Grounded;
			}
			else if (this.currentControllerState == AdvancedWalkerController.ControllerState.Falling)
			{
				this.m_MagicAirJumpTimer += Time.deltaTime;
				if (flag)
				{
					return AdvancedWalkerController.ControllerState.Rising;
				}
				if (this.mover.IsGrounded() && !flag2)
				{
					this.OnGroundContactRegained();
					return AdvancedWalkerController.ControllerState.Grounded;
				}
				if (flag2)
				{
					return AdvancedWalkerController.ControllerState.Sliding;
				}
				return AdvancedWalkerController.ControllerState.Falling;
			}
			else if (this.currentControllerState == AdvancedWalkerController.ControllerState.Sliding)
			{
				if (flag)
				{
					this.OnGroundContactLost();
					return AdvancedWalkerController.ControllerState.Rising;
				}
				if (!this.mover.IsGrounded())
				{
					this.OnGroundContactLost();
					return AdvancedWalkerController.ControllerState.Falling;
				}
				if (this.mover.IsGrounded() && !flag2)
				{
					this.OnGroundContactRegained();
					return AdvancedWalkerController.ControllerState.Grounded;
				}
				return AdvancedWalkerController.ControllerState.Sliding;
			}
			else if (this.currentControllerState == AdvancedWalkerController.ControllerState.Rising)
			{
				if (!flag)
				{
					if (this.mover.IsGrounded() && !flag2)
					{
						this.OnGroundContactRegained();
						return AdvancedWalkerController.ControllerState.Grounded;
					}
					if (flag2)
					{
						return AdvancedWalkerController.ControllerState.Sliding;
					}
					if (!this.mover.IsGrounded())
					{
						return AdvancedWalkerController.ControllerState.Falling;
					}
				}
				if (this.ceilingDetector != null && this.ceilingDetector.HitCeiling())
				{
					this.OnCeilingContact();
					return AdvancedWalkerController.ControllerState.Falling;
				}
				return AdvancedWalkerController.ControllerState.Rising;
			}
			else
			{
				if (this.currentControllerState != AdvancedWalkerController.ControllerState.Jumping)
				{
					return AdvancedWalkerController.ControllerState.Falling;
				}
				if (Time.time - this.currentJumpStartTime > this.jumpDuration)
				{
					return AdvancedWalkerController.ControllerState.Rising;
				}
				if (this.jumpKeyWasLetGo)
				{
					return AdvancedWalkerController.ControllerState.Rising;
				}
				if (this.ceilingDetector != null && this.ceilingDetector.HitCeiling())
				{
					this.OnCeilingContact();
					return AdvancedWalkerController.ControllerState.Falling;
				}
				return AdvancedWalkerController.ControllerState.Jumping;
			}
		}

		// Token: 0x06000D51 RID: 3409 RVA: 0x0005D1B0 File Offset: 0x0005B3B0
		private void HandleJumping()
		{
			if ((this.currentControllerState == AdvancedWalkerController.ControllerState.Grounded || this.m_MagicAirJumpTimer < this.m_MagicAirJumpTime) && (this.jumpKeyIsPressed || this.jumpKeyWasPressed) && !this.jumpInputIsLocked)
			{
				this.OnGroundContactLost();
				this.OnJumpStart();
				this.currentControllerState = AdvancedWalkerController.ControllerState.Jumping;
			}
		}

		// Token: 0x06000D52 RID: 3410 RVA: 0x0005D200 File Offset: 0x0005B400
		private void HandleMomentum()
		{
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.localToWorldMatrix * this.momentum;
			}
			Vector3 vector = Vector3.zero;
			Vector3 vector2 = Vector3.zero;
			if (this.momentum != Vector3.zero)
			{
				vector = VectorMath.ExtractDotVector(this.momentum, this.tr.up);
				vector2 = this.momentum - vector;
			}
			vector -= this.tr.up * this.gravity * Time.deltaTime;
			if (this.currentControllerState == AdvancedWalkerController.ControllerState.Grounded && VectorMath.GetDotProduct(vector, this.tr.up) < 0f)
			{
				vector = Vector3.zero;
			}
			if (!this.IsGrounded())
			{
				Vector3 vector3 = this.CalculateMovementVelocity();
				if (vector2.magnitude > this.movementSpeedModified)
				{
					if (VectorMath.GetDotProduct(vector3, vector2.normalized) > 0f)
					{
						vector3 = VectorMath.RemoveDotVector(vector3, vector2.normalized);
					}
					float d = 0.25f;
					vector2 += vector3 * Time.deltaTime * this.airControlRate * d;
				}
				else
				{
					vector2 += vector3 * Time.deltaTime * this.airControlRate;
					vector2 = Vector3.ClampMagnitude(vector2, this.movementSpeedModified);
				}
			}
			if (this.currentControllerState == AdvancedWalkerController.ControllerState.Sliding)
			{
				Vector3 normalized = Vector3.ProjectOnPlane(this.mover.GetGroundNormal(), this.tr.up).normalized;
				Vector3 vector4 = this.CalculateMovementVelocity();
				vector4 = VectorMath.RemoveDotVector(vector4, normalized);
				vector2 += vector4 * Time.fixedDeltaTime;
			}
			if (this.currentControllerState == AdvancedWalkerController.ControllerState.Grounded)
			{
				vector2 = VectorMath.IncrementVectorTowardTargetVector(vector2, this.groundFriction, Time.deltaTime, Vector3.zero);
			}
			else
			{
				vector2 = VectorMath.IncrementVectorTowardTargetVector(vector2, this.airFriction, Time.deltaTime, Vector3.zero);
			}
			this.momentum = vector2 + vector;
			if (this.currentControllerState == AdvancedWalkerController.ControllerState.Sliding)
			{
				this.momentum = Vector3.ProjectOnPlane(this.momentum, this.mover.GetGroundNormal());
				if (VectorMath.GetDotProduct(this.momentum, this.tr.up) > 0f)
				{
					this.momentum = VectorMath.RemoveDotVector(this.momentum, this.tr.up);
				}
				Vector3 normalized2 = Vector3.ProjectOnPlane(-this.tr.up, this.mover.GetGroundNormal()).normalized;
				this.momentum += normalized2 * this.slideGravity * Time.deltaTime;
			}
			if (this.currentControllerState == AdvancedWalkerController.ControllerState.Jumping)
			{
				this.momentum = VectorMath.RemoveDotVector(this.momentum, this.tr.up);
				this.momentum += this.tr.up * this.jumpSpeed;
			}
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.worldToLocalMatrix * this.momentum;
			}
		}

		// Token: 0x06000D53 RID: 3411 RVA: 0x0005D52C File Offset: 0x0005B72C
		private void OnJumpStart()
		{
			this.m_MagicAirJumpTimer = this.m_MagicAirJumpTime;
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.localToWorldMatrix * this.momentum;
			}
			this.momentum += this.tr.up * this.jumpSpeed;
			this.currentJumpStartTime = Time.time;
			this.jumpInputIsLocked = true;
			if (this.OnJump != null)
			{
				this.OnJump(this.momentum);
			}
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.worldToLocalMatrix * this.momentum;
			}
		}

		// Token: 0x06000D54 RID: 3412 RVA: 0x0005D5F4 File Offset: 0x0005B7F4
		private void OnGroundContactLost()
		{
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.localToWorldMatrix * this.momentum;
			}
			Vector3 vector = this.GetMovementVelocity();
			if (vector.sqrMagnitude >= 0f && this.momentum.sqrMagnitude > 0f)
			{
				Vector3 b = Vector3.Project(this.momentum, vector.normalized);
				float dotProduct = VectorMath.GetDotProduct(b.normalized, vector.normalized);
				if (b.sqrMagnitude >= vector.sqrMagnitude && dotProduct > 0f)
				{
					vector = Vector3.zero;
				}
				else if (dotProduct > 0f)
				{
					vector -= b;
				}
			}
			this.momentum += vector;
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.worldToLocalMatrix * this.momentum;
			}
		}

		// Token: 0x06000D55 RID: 3413 RVA: 0x0005D6F0 File Offset: 0x0005B8F0
		private void OnGroundContactRegained()
		{
			if (this.OnLand != null)
			{
				Vector3 v = this.momentum;
				if (this.useLocalMomentum)
				{
					v = this.tr.localToWorldMatrix * v;
				}
				this.OnLand(v);
				this.m_MagicAirJumpTimer = 0f;
			}
		}

		// Token: 0x06000D56 RID: 3414 RVA: 0x0005D748 File Offset: 0x0005B948
		private void OnCeilingContact()
		{
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.localToWorldMatrix * this.momentum;
			}
			this.momentum = VectorMath.RemoveDotVector(this.momentum, this.tr.up);
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.worldToLocalMatrix * this.momentum;
			}
		}

		// Token: 0x06000D57 RID: 3415 RVA: 0x0005D7D0 File Offset: 0x0005B9D0
		private bool IsRisingOrFalling()
		{
			Vector3 vector = VectorMath.ExtractDotVector(this.GetMomentum(), this.tr.up);
			float num = 0.001f;
			return vector.magnitude > num;
		}

		// Token: 0x06000D58 RID: 3416 RVA: 0x0005D804 File Offset: 0x0005BA04
		private bool IsGroundTooSteep()
		{
			return !this.mover.IsGrounded() || Vector3.Angle(this.mover.GetGroundNormal(), this.tr.up) > this.slopeLimit;
		}

		// Token: 0x06000D59 RID: 3417 RVA: 0x0005D838 File Offset: 0x0005BA38
		public override Vector3 GetVelocity()
		{
			return this.savedVelocity;
		}

		// Token: 0x06000D5A RID: 3418 RVA: 0x0005D840 File Offset: 0x0005BA40
		public override Vector3 GetMovementVelocity()
		{
			return this.savedMovementVelocity;
		}

		// Token: 0x06000D5B RID: 3419 RVA: 0x0005D848 File Offset: 0x0005BA48
		public Vector3 GetMomentum()
		{
			Vector3 result = this.momentum;
			if (this.useLocalMomentum)
			{
				result = this.tr.localToWorldMatrix * this.momentum;
			}
			return result;
		}

		// Token: 0x06000D5C RID: 3420 RVA: 0x0005D886 File Offset: 0x0005BA86
		public override bool IsGrounded()
		{
			return this.currentControllerState == AdvancedWalkerController.ControllerState.Grounded || this.currentControllerState == AdvancedWalkerController.ControllerState.Sliding;
		}

		// Token: 0x06000D5D RID: 3421 RVA: 0x0005D89B File Offset: 0x0005BA9B
		public bool IsSliding()
		{
			return this.currentControllerState == AdvancedWalkerController.ControllerState.Sliding;
		}

		// Token: 0x06000D5E RID: 3422 RVA: 0x0005D8A8 File Offset: 0x0005BAA8
		public void AddMomentum(Vector3 _momentum)
		{
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.localToWorldMatrix * this.momentum;
			}
			this.momentum += _momentum;
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.worldToLocalMatrix * this.momentum;
			}
		}

		// Token: 0x06000D5F RID: 3423 RVA: 0x0005D923 File Offset: 0x0005BB23
		public void SetMomentum(Vector3 _newMomentum)
		{
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.worldToLocalMatrix * _newMomentum;
				return;
			}
			this.momentum = _newMomentum;
		}

		// Token: 0x06000D60 RID: 3424 RVA: 0x0005D956 File Offset: 0x0005BB56
		public void SetStopMovement(bool isStop)
		{
			this.isStopMovement = isStop;
		}

		// Token: 0x04001454 RID: 5204
		protected Transform tr;

		// Token: 0x04001455 RID: 5205
		protected Mover mover;

		// Token: 0x04001456 RID: 5206
		protected CharacterInput characterInput;

		// Token: 0x04001457 RID: 5207
		protected CeilingDetector ceilingDetector;

		// Token: 0x04001458 RID: 5208
		private bool jumpInputIsLocked;

		// Token: 0x04001459 RID: 5209
		private bool jumpKeyWasPressed;

		// Token: 0x0400145A RID: 5210
		private bool jumpKeyWasLetGo;

		// Token: 0x0400145B RID: 5211
		private bool jumpKeyIsPressed;

		// Token: 0x0400145C RID: 5212
		private bool isStopMovement;

		// Token: 0x0400145D RID: 5213
		public float m_MagicAirJumpTime = 1f;

		// Token: 0x0400145E RID: 5214
		public float m_MagicAirJumpTimer;

		// Token: 0x0400145F RID: 5215
		public float movementSpeed = 7f;

		// Token: 0x04001460 RID: 5216
		private float movementSpeedModified = 7f;

		// Token: 0x04001461 RID: 5217
		public float airControlRate = 2f;

		// Token: 0x04001462 RID: 5218
		public float jumpSpeed = 10f;

		// Token: 0x04001463 RID: 5219
		public float jumpDuration = 0.2f;

		// Token: 0x04001464 RID: 5220
		private float currentJumpStartTime;

		// Token: 0x04001465 RID: 5221
		public float airFriction = 0.5f;

		// Token: 0x04001466 RID: 5222
		public float groundFriction = 100f;

		// Token: 0x04001467 RID: 5223
		protected Vector3 momentum = Vector3.zero;

		// Token: 0x04001468 RID: 5224
		private Vector3 savedVelocity = Vector3.zero;

		// Token: 0x04001469 RID: 5225
		private Vector3 savedMovementVelocity = Vector3.zero;

		// Token: 0x0400146A RID: 5226
		public float gravity = 30f;

		// Token: 0x0400146B RID: 5227
		[Tooltip("How fast the character will slide down steep slopes.")]
		public float slideGravity = 5f;

		// Token: 0x0400146C RID: 5228
		public float slopeLimit = 80f;

		// Token: 0x0400146D RID: 5229
		[Tooltip("Whether to calculate and apply momentum relative to the controller's transform.")]
		public bool useLocalMomentum;

		// Token: 0x0400146E RID: 5230
		private AdvancedWalkerController.ControllerState currentControllerState = AdvancedWalkerController.ControllerState.Falling;

		// Token: 0x0400146F RID: 5231
		[Tooltip("Optional camera transform used for calculating movement direction. If assigned, character movement will take camera view into account.")]
		public Transform cameraTransform;

		// Token: 0x02000280 RID: 640
		public enum ControllerState
		{
			// Token: 0x040016CA RID: 5834
			Grounded,
			// Token: 0x040016CB RID: 5835
			Sliding,
			// Token: 0x040016CC RID: 5836
			Falling,
			// Token: 0x040016CD RID: 5837
			Rising,
			// Token: 0x040016CE RID: 5838
			Jumping
		}
	}
}
