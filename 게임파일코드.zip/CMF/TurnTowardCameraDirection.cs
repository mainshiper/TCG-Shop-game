﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001D5 RID: 469
	public class TurnTowardCameraDirection : MonoBehaviour
	{
		// Token: 0x06000D1F RID: 3359 RVA: 0x0005C071 File Offset: 0x0005A271
		private void Start()
		{
			this.tr = base.transform;
			if (this.cameraController == null)
			{
				Debug.LogWarning("No camera controller reference has been assigned to this script.", this);
			}
		}

		// Token: 0x06000D20 RID: 3360 RVA: 0x0005C098 File Offset: 0x0005A298
		private void LateUpdate()
		{
			if (!this.cameraController)
			{
				return;
			}
			Vector3 facingDirection = this.cameraController.GetFacingDirection();
			Vector3 upDirection = this.cameraController.GetUpDirection();
			this.tr.rotation = Quaternion.LookRotation(facingDirection, upDirection);
		}

		// Token: 0x04001426 RID: 5158
		public CameraController cameraController;

		// Token: 0x04001427 RID: 5159
		private Transform tr;
	}
}
