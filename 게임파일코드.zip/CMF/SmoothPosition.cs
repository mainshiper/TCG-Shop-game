﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001F2 RID: 498
	public class SmoothPosition : MonoBehaviour
	{
		// Token: 0x06000DDD RID: 3549 RVA: 0x0005FED8 File Offset: 0x0005E0D8
		private void Awake()
		{
			if (this.target == null)
			{
				this.target = base.transform.parent;
			}
			this.tr = base.transform;
			this.currentPosition = base.transform.position;
			this.localPositionOffset = this.tr.localPosition;
		}

		// Token: 0x06000DDE RID: 3550 RVA: 0x0005FF32 File Offset: 0x0005E132
		private void OnEnable()
		{
			this.ResetCurrentPosition();
		}

		// Token: 0x06000DDF RID: 3551 RVA: 0x0005FF3A File Offset: 0x0005E13A
		private void Update()
		{
			if (this.updateType == SmoothPosition.UpdateType.LateUpdate)
			{
				return;
			}
			this.SmoothUpdate();
		}

		// Token: 0x06000DE0 RID: 3552 RVA: 0x0005FF4C File Offset: 0x0005E14C
		private void LateUpdate()
		{
			if (this.updateType == SmoothPosition.UpdateType.Update)
			{
				return;
			}
			this.SmoothUpdate();
		}

		// Token: 0x06000DE1 RID: 3553 RVA: 0x0005FF5D File Offset: 0x0005E15D
		private void SmoothUpdate()
		{
			this.currentPosition = this.Smooth(this.currentPosition, this.target.position, this.lerpSpeed);
			this.tr.position = this.currentPosition;
		}

		// Token: 0x06000DE2 RID: 3554 RVA: 0x0005FF94 File Offset: 0x0005E194
		private Vector3 Smooth(Vector3 _start, Vector3 _target, float _smoothTime)
		{
			Vector3 b = this.tr.localToWorldMatrix * this.localPositionOffset;
			if (this.extrapolatePosition)
			{
				Vector3 b2 = _target - (_start - b);
				_target += b2;
			}
			_target += b;
			SmoothPosition.SmoothType smoothType = this.smoothType;
			if (smoothType == SmoothPosition.SmoothType.Lerp)
			{
				return Vector3.Lerp(_start, _target, Time.deltaTime * _smoothTime);
			}
			if (smoothType != SmoothPosition.SmoothType.SmoothDamp)
			{
				return Vector3.zero;
			}
			return Vector3.SmoothDamp(_start, _target, ref this.refVelocity, this.smoothDampTime);
		}

		// Token: 0x06000DE3 RID: 3555 RVA: 0x00060024 File Offset: 0x0005E224
		public void ResetCurrentPosition()
		{
			Vector3 b = this.tr.localToWorldMatrix * this.localPositionOffset;
			this.currentPosition = this.target.position + b;
		}

		// Token: 0x040014ED RID: 5357
		public Transform target;

		// Token: 0x040014EE RID: 5358
		private Transform tr;

		// Token: 0x040014EF RID: 5359
		private Vector3 currentPosition;

		// Token: 0x040014F0 RID: 5360
		public float lerpSpeed = 20f;

		// Token: 0x040014F1 RID: 5361
		public float smoothDampTime = 0.02f;

		// Token: 0x040014F2 RID: 5362
		public bool extrapolatePosition;

		// Token: 0x040014F3 RID: 5363
		public SmoothPosition.UpdateType updateType;

		// Token: 0x040014F4 RID: 5364
		public SmoothPosition.SmoothType smoothType;

		// Token: 0x040014F5 RID: 5365
		private Vector3 localPositionOffset;

		// Token: 0x040014F6 RID: 5366
		private Vector3 refVelocity;

		// Token: 0x02000286 RID: 646
		public enum UpdateType
		{
			// Token: 0x040016E3 RID: 5859
			Update,
			// Token: 0x040016E4 RID: 5860
			LateUpdate
		}

		// Token: 0x02000287 RID: 647
		public enum SmoothType
		{
			// Token: 0x040016E6 RID: 5862
			Lerp,
			// Token: 0x040016E7 RID: 5863
			SmoothDamp
		}
	}
}
