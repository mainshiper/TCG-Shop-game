﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace CMF
{
	// Token: 0x020001EC RID: 492
	public class DemoMenu : MonoBehaviour
	{
		// Token: 0x06000DC7 RID: 3527 RVA: 0x0005FA74 File Offset: 0x0005DC74
		private void Start()
		{
			this.disableShadows = base.GetComponent<DisableShadows>();
			this.fpsCounter = base.GetComponent<FPSCounter>();
			this.SetMenuEnabled(false);
			this.disableShadows.SetShadows(PlayerData.enableShadows);
			this.shadowToggle.isOn = PlayerData.enableShadows;
			for (int i = 0; i < this.controllers.Count; i++)
			{
				this.controllers[i].SetActive(false);
			}
			this.controllers[PlayerData.controllerIndex].SetActive(true);
			if (PlayerData.controllerIndex >= 4)
			{
				this.regularArea.SetActive(false);
			}
			else
			{
				this.topDownArea.SetActive(false);
			}
			ColorBlock colors = this.buttons[PlayerData.controllerIndex].colors;
			colors.normalColor = this.activeButtonColor;
			colors.highlightedColor = this.activeButtonColor;
			colors.pressedColor = this.activeButtonColor;
			this.buttons[PlayerData.controllerIndex].colors = colors;
		}

		// Token: 0x06000DC8 RID: 3528 RVA: 0x0005FB74 File Offset: 0x0005DD74
		private void Update()
		{
			if (Input.GetKeyDown(this.menuKey))
			{
				this.SetMenuEnabled(!this.demoMenuObject.activeSelf);
			}
			if (Input.GetKeyDown(KeyCode.Escape))
			{
				this.SetMenuEnabled(!this.demoMenuObject.activeSelf);
			}
			if (Input.GetMouseButtonDown(0) && !this.demoMenuObject.activeSelf)
			{
				Cursor.lockState = CursorLockMode.Locked;
			}
		}

		// Token: 0x06000DC9 RID: 3529 RVA: 0x0005FBDC File Offset: 0x0005DDDC
		public void RestartScene()
		{
			SceneManager.LoadScene(SceneManager.GetActiveScene().name);
		}

		// Token: 0x06000DCA RID: 3530 RVA: 0x0005FBFB File Offset: 0x0005DDFB
		public void QuitGame()
		{
			Application.Quit();
		}

		// Token: 0x06000DCB RID: 3531 RVA: 0x0005FC02 File Offset: 0x0005DE02
		public void OnControllerPresetChosen(int _presetIndex)
		{
			PlayerData.controllerIndex = _presetIndex;
			this.RestartScene();
		}

		// Token: 0x06000DCC RID: 3532 RVA: 0x0005FC10 File Offset: 0x0005DE10
		public void SetMenuEnabled(bool _isEnabled)
		{
			this.demoMenuObject.SetActive(_isEnabled);
			if (_isEnabled)
			{
				Cursor.lockState = CursorLockMode.None;
				return;
			}
			Cursor.lockState = CursorLockMode.Locked;
		}

		// Token: 0x06000DCD RID: 3533 RVA: 0x0005FC2E File Offset: 0x0005DE2E
		public void SetShadowsEnabled(bool _isEnabled)
		{
			this.disableShadows.SetShadows(_isEnabled);
			PlayerData.enableShadows = _isEnabled;
		}

		// Token: 0x06000DCE RID: 3534 RVA: 0x0005FC42 File Offset: 0x0005DE42
		public void SetFrameRateEnabled(bool _isEnabled)
		{
			this.fpsCounter.enabled = _isEnabled;
		}

		// Token: 0x040014D4 RID: 5332
		public KeyCode menuKey = KeyCode.C;

		// Token: 0x040014D5 RID: 5333
		private DisableShadows disableShadows;

		// Token: 0x040014D6 RID: 5334
		private FPSCounter fpsCounter;

		// Token: 0x040014D7 RID: 5335
		public GameObject demoMenuObject;

		// Token: 0x040014D8 RID: 5336
		public List<GameObject> controllers = new List<GameObject>();

		// Token: 0x040014D9 RID: 5337
		public List<Button> buttons = new List<Button>();

		// Token: 0x040014DA RID: 5338
		public Toggle shadowToggle;

		// Token: 0x040014DB RID: 5339
		public GameObject regularArea;

		// Token: 0x040014DC RID: 5340
		public GameObject topDownArea;

		// Token: 0x040014DD RID: 5341
		public Color activeButtonColor = Color.cyan;
	}
}
