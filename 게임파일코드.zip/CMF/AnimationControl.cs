﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001D3 RID: 467
	public class AnimationControl : MonoBehaviour
	{
		// Token: 0x06000D11 RID: 3345 RVA: 0x0005BBA1 File Offset: 0x00059DA1
		private void Awake()
		{
			this.controller = base.GetComponent<Controller>();
			this.animator = base.GetComponentInChildren<Animator>();
			this.animatorTransform = this.animator.transform;
			this.tr = base.transform;
		}

		// Token: 0x06000D12 RID: 3346 RVA: 0x0005BBD8 File Offset: 0x00059DD8
		private void OnEnable()
		{
			Controller controller = this.controller;
			controller.OnLand = (Controller.VectorEvent)Delegate.Combine(controller.OnLand, new Controller.VectorEvent(this.OnLand));
			Controller controller2 = this.controller;
			controller2.OnJump = (Controller.VectorEvent)Delegate.Combine(controller2.OnJump, new Controller.VectorEvent(this.OnJump));
		}

		// Token: 0x06000D13 RID: 3347 RVA: 0x0005BC34 File Offset: 0x00059E34
		private void OnDisable()
		{
			Controller controller = this.controller;
			controller.OnLand = (Controller.VectorEvent)Delegate.Remove(controller.OnLand, new Controller.VectorEvent(this.OnLand));
			Controller controller2 = this.controller;
			controller2.OnJump = (Controller.VectorEvent)Delegate.Remove(controller2.OnJump, new Controller.VectorEvent(this.OnJump));
		}

		// Token: 0x06000D14 RID: 3348 RVA: 0x0005BC90 File Offset: 0x00059E90
		private void Update()
		{
			Vector3 velocity = this.controller.GetVelocity();
			Vector3 vector = VectorMath.RemoveDotVector(velocity, this.tr.up);
			Vector3 vector2 = velocity - vector;
			vector = Vector3.Lerp(this.oldMovementVelocity, vector, this.smoothingFactor * Time.deltaTime);
			this.oldMovementVelocity = vector;
			this.animator.SetFloat("VerticalSpeed", vector2.magnitude * VectorMath.GetDotProduct(vector2.normalized, this.tr.up));
			this.animator.SetFloat("HorizontalSpeed", vector.magnitude);
			if (this.useStrafeAnimations)
			{
				Vector3 vector3 = this.animatorTransform.InverseTransformVector(vector);
				this.animator.SetFloat("ForwardSpeed", vector3.z);
				this.animator.SetFloat("StrafeSpeed", vector3.x);
			}
			this.animator.SetBool("IsGrounded", this.controller.IsGrounded());
			this.animator.SetBool("IsStrafing", this.useStrafeAnimations);
		}

		// Token: 0x06000D15 RID: 3349 RVA: 0x0005BD99 File Offset: 0x00059F99
		private void OnLand(Vector3 _v)
		{
			if (VectorMath.GetDotProduct(_v, this.tr.up) > -this.landVelocityThreshold)
			{
				return;
			}
			this.animator.SetTrigger("OnLand");
		}

		// Token: 0x06000D16 RID: 3350 RVA: 0x0005BDC6 File Offset: 0x00059FC6
		private void OnJump(Vector3 _v)
		{
		}

		// Token: 0x0400140F RID: 5135
		private Controller controller;

		// Token: 0x04001410 RID: 5136
		private Animator animator;

		// Token: 0x04001411 RID: 5137
		private Transform animatorTransform;

		// Token: 0x04001412 RID: 5138
		private Transform tr;

		// Token: 0x04001413 RID: 5139
		public bool useStrafeAnimations;

		// Token: 0x04001414 RID: 5140
		public float landVelocityThreshold = 5f;

		// Token: 0x04001415 RID: 5141
		private float smoothingFactor = 40f;

		// Token: 0x04001416 RID: 5142
		private Vector3 oldMovementVelocity = Vector3.zero;
	}
}
