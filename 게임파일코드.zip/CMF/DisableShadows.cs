﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001ED RID: 493
	public class DisableShadows : MonoBehaviour
	{
		// Token: 0x06000DD0 RID: 3536 RVA: 0x0005FC81 File Offset: 0x0005DE81
		private void Start()
		{
			this.sceneLight = base.GetComponent<Light>();
		}

		// Token: 0x06000DD1 RID: 3537 RVA: 0x0005FC8F File Offset: 0x0005DE8F
		public void SetShadows(bool _isActivated)
		{
			this.shadowsAreActive = _isActivated;
			if (!this.shadowsAreActive)
			{
				this.sceneLight.shadows = LightShadows.None;
				return;
			}
			this.sceneLight.shadows = LightShadows.Hard;
		}

		// Token: 0x040014DE RID: 5342
		private bool shadowsAreActive = true;

		// Token: 0x040014DF RID: 5343
		public Light sceneLight;
	}
}
