﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E4 RID: 484
	public class TriggerArea : MonoBehaviour
	{
		// Token: 0x06000DA8 RID: 3496 RVA: 0x0005F437 File Offset: 0x0005D637
		private void OnTriggerEnter(Collider col)
		{
			if (col.attachedRigidbody != null && col.GetComponent<Mover>() != null)
			{
				this.rigidbodiesInTriggerArea.Add(col.attachedRigidbody);
			}
		}

		// Token: 0x06000DA9 RID: 3497 RVA: 0x0005F466 File Offset: 0x0005D666
		private void OnTriggerExit(Collider col)
		{
			if (col.attachedRigidbody != null && col.GetComponent<Mover>() != null)
			{
				this.rigidbodiesInTriggerArea.Remove(col.attachedRigidbody);
			}
		}

		// Token: 0x040014BA RID: 5306
		public List<Rigidbody> rigidbodiesInTriggerArea = new List<Rigidbody>();
	}
}
