﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001EB RID: 491
	public class CharacterKeyboardInput : CharacterInput
	{
		// Token: 0x06000DC3 RID: 3523 RVA: 0x0005F944 File Offset: 0x0005DB44
		public unsafe override float GetHorizontalMovementInput()
		{
			if (InputManager.GetKeyHoldAction(EGameAction.MoveLeft) || InputManager.GetKeyHoldAction(EGameAction.MoveLeftAlt))
			{
				return -1f;
			}
			if (InputManager.GetKeyHoldAction(EGameAction.MoveRight) || InputManager.GetKeyHoldAction(EGameAction.MoveRightAlt))
			{
				return 1f;
			}
			if (CSingleton<InputManager>.Instance.m_IsControllerActive)
			{
				bool flag = this.useRawInput;
				return *CSingleton<InputManager>.Instance.m_CurrentGamepad.leftStick.x.value;
			}
			return 0f;
		}

		// Token: 0x06000DC4 RID: 3524 RVA: 0x0005F9B4 File Offset: 0x0005DBB4
		public unsafe override float GetVerticalMovementInput()
		{
			if (InputManager.GetKeyHoldAction(EGameAction.MoveForward) || InputManager.GetKeyHoldAction(EGameAction.MoveForwardAlt))
			{
				return 1f;
			}
			if (InputManager.GetKeyHoldAction(EGameAction.MoveBackward) || InputManager.GetKeyHoldAction(EGameAction.MoveBackwardAlt))
			{
				return -1f;
			}
			if (CSingleton<InputManager>.Instance.m_IsControllerActive)
			{
				bool flag = this.useRawInput;
				return *CSingleton<InputManager>.Instance.m_CurrentGamepad.leftStick.y.value;
			}
			return 0f;
		}

		// Token: 0x06000DC5 RID: 3525 RVA: 0x0005FA24 File Offset: 0x0005DC24
		public override bool IsJumpKeyPressed()
		{
			return CSingleton<InteractionPlayerController>.Instance.CanJump() && InputManager.GetKeyHoldAction(EGameAction.Jump);
		}

		// Token: 0x040014CF RID: 5327
		public string horizontalInputAxis = "Horizontal";

		// Token: 0x040014D0 RID: 5328
		public string verticalInputAxis = "Vertical";

		// Token: 0x040014D1 RID: 5329
		public KeyCode jumpKey = KeyCode.Space;

		// Token: 0x040014D2 RID: 5330
		public KeyCode jumpKey2 = KeyCode.JoystickButton0;

		// Token: 0x040014D3 RID: 5331
		public bool useRawInput = true;
	}
}
