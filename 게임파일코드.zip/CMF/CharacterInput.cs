﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E9 RID: 489
	public abstract class CharacterInput : MonoBehaviour
	{
		// Token: 0x06000DBB RID: 3515
		public abstract float GetHorizontalMovementInput();

		// Token: 0x06000DBC RID: 3516
		public abstract float GetVerticalMovementInput();

		// Token: 0x06000DBD RID: 3517
		public abstract bool IsJumpKeyPressed();
	}
}
