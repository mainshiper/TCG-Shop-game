﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001F3 RID: 499
	public class SmoothRotation : MonoBehaviour
	{
		// Token: 0x06000DE5 RID: 3557 RVA: 0x00060087 File Offset: 0x0005E287
		private void Awake()
		{
			if (this.target == null)
			{
				this.target = base.transform.parent;
			}
			this.tr = base.transform;
			this.currentRotation = base.transform.rotation;
		}

		// Token: 0x06000DE6 RID: 3558 RVA: 0x000600C5 File Offset: 0x0005E2C5
		private void OnEnable()
		{
			this.ResetCurrentRotation();
		}

		// Token: 0x06000DE7 RID: 3559 RVA: 0x000600CD File Offset: 0x0005E2CD
		private void Update()
		{
			if (this.updateType == SmoothRotation.UpdateType.LateUpdate)
			{
				return;
			}
			this.SmoothUpdate();
		}

		// Token: 0x06000DE8 RID: 3560 RVA: 0x000600DF File Offset: 0x0005E2DF
		private void LateUpdate()
		{
			if (this.updateType == SmoothRotation.UpdateType.Update)
			{
				return;
			}
			this.SmoothUpdate();
		}

		// Token: 0x06000DE9 RID: 3561 RVA: 0x000600F0 File Offset: 0x0005E2F0
		private void SmoothUpdate()
		{
			this.currentRotation = this.Smooth(this.currentRotation, this.target.rotation, this.smoothSpeed);
			this.tr.rotation = this.currentRotation;
		}

		// Token: 0x06000DEA RID: 3562 RVA: 0x00060128 File Offset: 0x0005E328
		private Quaternion Smooth(Quaternion _currentRotation, Quaternion _targetRotation, float _smoothSpeed)
		{
			if (this.extrapolateRotation && Quaternion.Angle(_currentRotation, _targetRotation) < 90f)
			{
				Quaternion rhs = _targetRotation * Quaternion.Inverse(_currentRotation);
				_targetRotation *= rhs;
			}
			return Quaternion.Slerp(_currentRotation, _targetRotation, Time.deltaTime * _smoothSpeed);
		}

		// Token: 0x06000DEB RID: 3563 RVA: 0x0006016F File Offset: 0x0005E36F
		public void ResetCurrentRotation()
		{
			this.currentRotation = this.target.rotation;
		}

		// Token: 0x040014F7 RID: 5367
		public Transform target;

		// Token: 0x040014F8 RID: 5368
		private Transform tr;

		// Token: 0x040014F9 RID: 5369
		private Quaternion currentRotation;

		// Token: 0x040014FA RID: 5370
		public float smoothSpeed = 20f;

		// Token: 0x040014FB RID: 5371
		public bool extrapolateRotation;

		// Token: 0x040014FC RID: 5372
		public SmoothRotation.UpdateType updateType;

		// Token: 0x02000288 RID: 648
		public enum UpdateType
		{
			// Token: 0x040016E9 RID: 5865
			Update,
			// Token: 0x040016EA RID: 5866
			LateUpdate
		}
	}
}
