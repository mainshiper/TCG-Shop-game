﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001DE RID: 478
	public class SimpleWalkerController : Controller
	{
		// Token: 0x06000D68 RID: 3432 RVA: 0x0005DAB8 File Offset: 0x0005BCB8
		private void Start()
		{
			this.tr = base.transform;
			this.mover = base.GetComponent<Mover>();
			this.characterInput = base.GetComponent<CharacterInput>();
		}

		// Token: 0x06000D69 RID: 3433 RVA: 0x0005DAE0 File Offset: 0x0005BCE0
		private void FixedUpdate()
		{
			this.mover.CheckForGround();
			if (!this.isGrounded && this.mover.IsGrounded())
			{
				this.OnGroundContactRegained(this.lastVelocity);
			}
			this.isGrounded = this.mover.IsGrounded();
			Vector3 vector = Vector3.zero;
			vector += this.CalculateMovementDirection() * this.movementSpeed;
			if (!this.isGrounded)
			{
				this.currentVerticalSpeed -= this.gravity * Time.deltaTime;
			}
			else if (this.currentVerticalSpeed <= 0f)
			{
				this.currentVerticalSpeed = 0f;
			}
			if (this.characterInput != null && this.isGrounded && this.characterInput.IsJumpKeyPressed())
			{
				this.OnJumpStart();
				this.currentVerticalSpeed = this.jumpSpeed;
				this.isGrounded = false;
			}
			vector += this.tr.up * this.currentVerticalSpeed;
			this.lastVelocity = vector;
			this.mover.SetExtendSensorRange(this.isGrounded);
			this.mover.SetVelocity(vector);
		}

		// Token: 0x06000D6A RID: 3434 RVA: 0x0005DC00 File Offset: 0x0005BE00
		private Vector3 CalculateMovementDirection()
		{
			if (this.characterInput == null)
			{
				return Vector3.zero;
			}
			Vector3 vector = Vector3.zero;
			if (this.cameraTransform == null)
			{
				vector += this.tr.right * this.characterInput.GetHorizontalMovementInput();
				vector += this.tr.forward * this.characterInput.GetVerticalMovementInput();
			}
			else
			{
				vector += Vector3.ProjectOnPlane(this.cameraTransform.right, this.tr.up).normalized * this.characterInput.GetHorizontalMovementInput();
				vector += Vector3.ProjectOnPlane(this.cameraTransform.forward, this.tr.up).normalized * this.characterInput.GetVerticalMovementInput();
			}
			if (vector.magnitude > 1f)
			{
				vector.Normalize();
			}
			return vector;
		}

		// Token: 0x06000D6B RID: 3435 RVA: 0x0005DD05 File Offset: 0x0005BF05
		private void OnGroundContactRegained(Vector3 _collisionVelocity)
		{
			if (this.OnLand != null)
			{
				this.OnLand(_collisionVelocity);
			}
		}

		// Token: 0x06000D6C RID: 3436 RVA: 0x0005DD1B File Offset: 0x0005BF1B
		private void OnJumpStart()
		{
			if (this.OnJump != null)
			{
				this.OnJump(this.lastVelocity);
			}
		}

		// Token: 0x06000D6D RID: 3437 RVA: 0x0005DD36 File Offset: 0x0005BF36
		public override Vector3 GetVelocity()
		{
			return this.lastVelocity;
		}

		// Token: 0x06000D6E RID: 3438 RVA: 0x0005DD3E File Offset: 0x0005BF3E
		public override Vector3 GetMovementVelocity()
		{
			return this.lastVelocity;
		}

		// Token: 0x06000D6F RID: 3439 RVA: 0x0005DD46 File Offset: 0x0005BF46
		public override bool IsGrounded()
		{
			return this.isGrounded;
		}

		// Token: 0x04001472 RID: 5234
		private Mover mover;

		// Token: 0x04001473 RID: 5235
		private float currentVerticalSpeed;

		// Token: 0x04001474 RID: 5236
		private bool isGrounded;

		// Token: 0x04001475 RID: 5237
		public float movementSpeed = 7f;

		// Token: 0x04001476 RID: 5238
		public float jumpSpeed = 10f;

		// Token: 0x04001477 RID: 5239
		public float gravity = 10f;

		// Token: 0x04001478 RID: 5240
		private Vector3 lastVelocity = Vector3.zero;

		// Token: 0x04001479 RID: 5241
		public Transform cameraTransform;

		// Token: 0x0400147A RID: 5242
		private CharacterInput characterInput;

		// Token: 0x0400147B RID: 5243
		private Transform tr;
	}
}
