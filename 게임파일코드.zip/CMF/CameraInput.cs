﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E6 RID: 486
	public abstract class CameraInput : MonoBehaviour
	{
		// Token: 0x06000DB2 RID: 3506
		public abstract float GetHorizontalCameraInput();

		// Token: 0x06000DB3 RID: 3507
		public abstract float GetVerticalCameraInput();
	}
}
