﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E2 RID: 482
	public class GravityTunnel : MonoBehaviour
	{
		// Token: 0x06000D9C RID: 3484 RVA: 0x0005EFAC File Offset: 0x0005D1AC
		private void FixedUpdate()
		{
			for (int i = 0; i < this.rigidbodies.Count; i++)
			{
				Vector3 a = Vector3.Project(this.rigidbodies[i].transform.position - base.transform.position, base.transform.position + base.transform.forward - base.transform.position) + base.transform.position;
				this.RotateRigidbody(this.rigidbodies[i].transform, (a - this.rigidbodies[i].transform.position).normalized);
			}
		}

		// Token: 0x06000D9D RID: 3485 RVA: 0x0005F078 File Offset: 0x0005D278
		private void OnTriggerEnter(Collider col)
		{
			Rigidbody component = col.GetComponent<Rigidbody>();
			if (!component)
			{
				return;
			}
			if (col.GetComponent<Mover>() == null)
			{
				return;
			}
			this.rigidbodies.Add(component);
		}

		// Token: 0x06000D9E RID: 3486 RVA: 0x0005F0B0 File Offset: 0x0005D2B0
		private void OnTriggerExit(Collider col)
		{
			Rigidbody component = col.GetComponent<Rigidbody>();
			if (!component)
			{
				return;
			}
			if (col.GetComponent<Mover>() == null)
			{
				return;
			}
			this.rigidbodies.Remove(component);
			this.RotateRigidbody(component.transform, Vector3.up);
			Vector3 eulerAngles = component.rotation.eulerAngles;
			eulerAngles.z = 0f;
			eulerAngles.x = 0f;
			component.MoveRotation(Quaternion.Euler(eulerAngles));
		}

		// Token: 0x06000D9F RID: 3487 RVA: 0x0005F130 File Offset: 0x0005D330
		private void RotateRigidbody(Transform _transform, Vector3 _targetDirection)
		{
			Rigidbody component = _transform.GetComponent<Rigidbody>();
			_targetDirection.Normalize();
			Quaternion lhs = Quaternion.FromToRotation(_transform.up, _targetDirection);
			Quaternion rotation = _transform.rotation;
			Quaternion quaternion = lhs * _transform.rotation;
			component.MoveRotation(quaternion);
		}

		// Token: 0x06000DA0 RID: 3488 RVA: 0x0005F170 File Offset: 0x0005D370
		private Quaternion GetCounterRotation(Quaternion _rotation)
		{
			float f;
			Vector3 axis;
			_rotation.ToAngleAxis(out f, out axis);
			Quaternion rotation = Quaternion.AngleAxis(Mathf.Sign(f) * 180f, axis);
			return _rotation * Quaternion.Inverse(rotation);
		}

		// Token: 0x040014B0 RID: 5296
		private List<Rigidbody> rigidbodies = new List<Rigidbody>();
	}
}
