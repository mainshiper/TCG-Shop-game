﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001DF RID: 479
	public class Mover : MonoBehaviour
	{
		// Token: 0x06000D71 RID: 3441 RVA: 0x0005DD82 File Offset: 0x0005BF82
		private void Awake()
		{
			this.Setup();
			this.sensor = new Sensor(this.tr, this.col);
			this.RecalculateColliderDimensions();
			this.RecalibrateSensor();
		}

		// Token: 0x06000D72 RID: 3442 RVA: 0x0005DDAD File Offset: 0x0005BFAD
		private void Reset()
		{
			this.Setup();
		}

		// Token: 0x06000D73 RID: 3443 RVA: 0x0005DDB5 File Offset: 0x0005BFB5
		private void OnValidate()
		{
			if (base.gameObject.activeInHierarchy)
			{
				this.RecalculateColliderDimensions();
			}
			if (this.sensorType == Sensor.CastType.RaycastArray)
			{
				this.raycastArrayPreviewPositions = Sensor.GetRaycastStartPositions(this.sensorArrayRows, this.sensorArrayRayCount, this.sensorArrayRowsAreOffset, 1f);
			}
		}

		// Token: 0x06000D74 RID: 3444 RVA: 0x0005DDF8 File Offset: 0x0005BFF8
		private void Setup()
		{
			this.tr = base.transform;
			this.col = base.GetComponent<Collider>();
			if (this.col == null)
			{
				this.tr.gameObject.AddComponent<CapsuleCollider>();
				this.col = base.GetComponent<Collider>();
			}
			this.rig = base.GetComponent<Rigidbody>();
			if (this.rig == null)
			{
				this.tr.gameObject.AddComponent<Rigidbody>();
				this.rig = base.GetComponent<Rigidbody>();
			}
			this.boxCollider = base.GetComponent<BoxCollider>();
			this.sphereCollider = base.GetComponent<SphereCollider>();
			this.capsuleCollider = base.GetComponent<CapsuleCollider>();
			this.rig.freezeRotation = true;
			this.rig.useGravity = false;
		}

		// Token: 0x06000D75 RID: 3445 RVA: 0x0005DEBB File Offset: 0x0005C0BB
		private void LateUpdate()
		{
			if (this.isInDebugMode)
			{
				this.sensor.DrawDebug();
			}
		}

		// Token: 0x06000D76 RID: 3446 RVA: 0x0005DED0 File Offset: 0x0005C0D0
		public void RecalculateColliderDimensions()
		{
			if (this.col == null)
			{
				this.Setup();
				if (this.col == null)
				{
					Debug.LogWarning("There is no collider attached to " + base.gameObject.name + "!");
					return;
				}
			}
			if (this.boxCollider)
			{
				Vector3 zero = Vector3.zero;
				zero.x = this.colliderThickness;
				zero.z = this.colliderThickness;
				this.boxCollider.center = this.colliderOffset * this.colliderHeight;
				zero.y = this.colliderHeight * (1f - this.stepHeightRatio);
				this.boxCollider.size = zero;
				this.boxCollider.center = this.boxCollider.center + new Vector3(0f, this.stepHeightRatio * this.colliderHeight / 2f, 0f);
			}
			else if (this.sphereCollider)
			{
				this.sphereCollider.radius = this.colliderHeight / 2f;
				this.sphereCollider.center = this.colliderOffset * this.colliderHeight;
				this.sphereCollider.center = this.sphereCollider.center + new Vector3(0f, this.stepHeightRatio * this.sphereCollider.radius, 0f);
				this.sphereCollider.radius *= 1f - this.stepHeightRatio;
			}
			else if (this.capsuleCollider)
			{
				this.capsuleCollider.height = this.colliderHeight;
				this.capsuleCollider.center = this.colliderOffset * this.colliderHeight;
				this.capsuleCollider.radius = this.colliderThickness / 2f;
				this.capsuleCollider.center = this.capsuleCollider.center + new Vector3(0f, this.stepHeightRatio * this.capsuleCollider.height / 2f, 0f);
				this.capsuleCollider.height *= 1f - this.stepHeightRatio;
				if (this.capsuleCollider.height / 2f < this.capsuleCollider.radius)
				{
					this.capsuleCollider.radius = this.capsuleCollider.height / 2f;
				}
			}
			if (this.sensor != null)
			{
				this.RecalibrateSensor();
			}
		}

		// Token: 0x06000D77 RID: 3447 RVA: 0x0005E174 File Offset: 0x0005C374
		private void RecalibrateSensor()
		{
			this.sensor.SetCastOrigin(this.GetColliderCenter());
			this.sensor.SetCastDirection(Sensor.CastDirection.Down);
			this.RecalculateSensorLayerMask();
			this.sensor.castType = this.sensorType;
			float num = this.colliderThickness / 2f * this.sensorRadiusModifier;
			float num2 = 0.001f;
			if (this.boxCollider)
			{
				num = Mathf.Clamp(num, num2, this.boxCollider.size.y / 2f * (1f - num2));
			}
			else if (this.sphereCollider)
			{
				num = Mathf.Clamp(num, num2, this.sphereCollider.radius * (1f - num2));
			}
			else if (this.capsuleCollider)
			{
				num = Mathf.Clamp(num, num2, this.capsuleCollider.height / 2f * (1f - num2));
			}
			this.sensor.sphereCastRadius = num * this.tr.localScale.x;
			float num3 = 0f;
			num3 += this.colliderHeight * (1f - this.stepHeightRatio) * 0.5f;
			num3 += this.colliderHeight * this.stepHeightRatio;
			this.baseSensorRange = num3 * (1f + num2) * this.tr.localScale.x;
			this.sensor.castLength = num3 * this.tr.localScale.x;
			this.sensor.ArrayRows = this.sensorArrayRows;
			this.sensor.arrayRayCount = this.sensorArrayRayCount;
			this.sensor.offsetArrayRows = this.sensorArrayRowsAreOffset;
			this.sensor.isInDebugMode = this.isInDebugMode;
			this.sensor.calculateRealDistance = true;
			this.sensor.calculateRealSurfaceNormal = true;
			this.sensor.RecalibrateRaycastArrayPositions();
		}

		// Token: 0x06000D78 RID: 3448 RVA: 0x0005E350 File Offset: 0x0005C550
		private void RecalculateSensorLayerMask()
		{
			int num = 0;
			int layer = base.gameObject.layer;
			for (int i = 0; i < 32; i++)
			{
				if (!Physics.GetIgnoreLayerCollision(layer, i))
				{
					num |= 1 << i;
				}
			}
			if (num == (num | 1 << LayerMask.NameToLayer("Ignore Raycast")))
			{
				num ^= 1 << LayerMask.NameToLayer("Ignore Raycast");
			}
			this.sensor.layermask = num;
			this.currentLayer = layer;
		}

		// Token: 0x06000D79 RID: 3449 RVA: 0x0005E3C8 File Offset: 0x0005C5C8
		private Vector3 GetColliderCenter()
		{
			if (this.col == null)
			{
				this.Setup();
			}
			return this.col.bounds.center;
		}

		// Token: 0x06000D7A RID: 3450 RVA: 0x0005E3FC File Offset: 0x0005C5FC
		private void Check()
		{
			this.currentGroundAdjustmentVelocity = Vector3.zero;
			if (this.IsUsingExtendedSensorRange)
			{
				this.sensor.castLength = this.baseSensorRange + this.colliderHeight * this.tr.localScale.x * this.stepHeightRatio;
			}
			else
			{
				this.sensor.castLength = this.baseSensorRange;
			}
			this.sensor.Cast();
			if (!this.sensor.HasDetectedHit())
			{
				this.isGrounded = false;
				return;
			}
			this.isGrounded = true;
			float distance = this.sensor.GetDistance();
			float num = this.colliderHeight * this.tr.localScale.x * (1f - this.stepHeightRatio) * 0.5f + this.colliderHeight * this.tr.localScale.x * this.stepHeightRatio - distance;
			this.currentGroundAdjustmentVelocity = this.tr.up * (num / Time.fixedDeltaTime);
		}

		// Token: 0x06000D7B RID: 3451 RVA: 0x0005E4FB File Offset: 0x0005C6FB
		public void CheckForGround()
		{
			if (this.currentLayer != base.gameObject.layer)
			{
				this.RecalculateSensorLayerMask();
			}
			this.Check();
		}

		// Token: 0x06000D7C RID: 3452 RVA: 0x0005E51C File Offset: 0x0005C71C
		public void SetVelocity(Vector3 _velocity)
		{
			this.rig.velocity = _velocity + this.currentGroundAdjustmentVelocity;
		}

		// Token: 0x06000D7D RID: 3453 RVA: 0x0005E535 File Offset: 0x0005C735
		public bool IsGrounded()
		{
			return this.isGrounded;
		}

		// Token: 0x06000D7E RID: 3454 RVA: 0x0005E53D File Offset: 0x0005C73D
		public void SetExtendSensorRange(bool _isExtended)
		{
			this.IsUsingExtendedSensorRange = _isExtended;
		}

		// Token: 0x06000D7F RID: 3455 RVA: 0x0005E546 File Offset: 0x0005C746
		public void SetColliderHeight(float _newColliderHeight)
		{
			if (this.colliderHeight == _newColliderHeight)
			{
				return;
			}
			this.colliderHeight = _newColliderHeight;
			this.RecalculateColliderDimensions();
		}

		// Token: 0x06000D80 RID: 3456 RVA: 0x0005E55F File Offset: 0x0005C75F
		public void SetColliderThickness(float _newColliderThickness)
		{
			if (this.colliderThickness == _newColliderThickness)
			{
				return;
			}
			if (_newColliderThickness < 0f)
			{
				_newColliderThickness = 0f;
			}
			this.colliderThickness = _newColliderThickness;
			this.RecalculateColliderDimensions();
		}

		// Token: 0x06000D81 RID: 3457 RVA: 0x0005E587 File Offset: 0x0005C787
		public void SetStepHeightRatio(float _newStepHeightRatio)
		{
			_newStepHeightRatio = Mathf.Clamp(_newStepHeightRatio, 0f, 1f);
			this.stepHeightRatio = _newStepHeightRatio;
			this.RecalculateColliderDimensions();
		}

		// Token: 0x06000D82 RID: 3458 RVA: 0x0005E5A8 File Offset: 0x0005C7A8
		public Vector3 GetGroundNormal()
		{
			return this.sensor.GetNormal();
		}

		// Token: 0x06000D83 RID: 3459 RVA: 0x0005E5B5 File Offset: 0x0005C7B5
		public Vector3 GetGroundPoint()
		{
			return this.sensor.GetPosition();
		}

		// Token: 0x06000D84 RID: 3460 RVA: 0x0005E5C2 File Offset: 0x0005C7C2
		public Collider GetGroundCollider()
		{
			return this.sensor.GetCollider();
		}

		// Token: 0x0400147C RID: 5244
		[Header("Mover Options :")]
		[Range(0f, 1f)]
		[SerializeField]
		private float stepHeightRatio = 0.25f;

		// Token: 0x0400147D RID: 5245
		[Header("Collider Options :")]
		[SerializeField]
		private float colliderHeight = 2f;

		// Token: 0x0400147E RID: 5246
		[SerializeField]
		private float colliderThickness = 1f;

		// Token: 0x0400147F RID: 5247
		[SerializeField]
		private Vector3 colliderOffset = Vector3.zero;

		// Token: 0x04001480 RID: 5248
		private BoxCollider boxCollider;

		// Token: 0x04001481 RID: 5249
		private SphereCollider sphereCollider;

		// Token: 0x04001482 RID: 5250
		private CapsuleCollider capsuleCollider;

		// Token: 0x04001483 RID: 5251
		[Header("Sensor Options :")]
		[SerializeField]
		public Sensor.CastType sensorType;

		// Token: 0x04001484 RID: 5252
		private float sensorRadiusModifier = 0.8f;

		// Token: 0x04001485 RID: 5253
		private int currentLayer;

		// Token: 0x04001486 RID: 5254
		[SerializeField]
		private bool isInDebugMode;

		// Token: 0x04001487 RID: 5255
		[Header("Sensor Array Options :")]
		[SerializeField]
		[Range(1f, 5f)]
		private int sensorArrayRows = 1;

		// Token: 0x04001488 RID: 5256
		[SerializeField]
		[Range(3f, 10f)]
		private int sensorArrayRayCount = 6;

		// Token: 0x04001489 RID: 5257
		[SerializeField]
		private bool sensorArrayRowsAreOffset;

		// Token: 0x0400148A RID: 5258
		[HideInInspector]
		public Vector3[] raycastArrayPreviewPositions;

		// Token: 0x0400148B RID: 5259
		private bool isGrounded;

		// Token: 0x0400148C RID: 5260
		private bool IsUsingExtendedSensorRange = true;

		// Token: 0x0400148D RID: 5261
		private float baseSensorRange;

		// Token: 0x0400148E RID: 5262
		private Vector3 currentGroundAdjustmentVelocity = Vector3.zero;

		// Token: 0x0400148F RID: 5263
		private Collider col;

		// Token: 0x04001490 RID: 5264
		private Rigidbody rig;

		// Token: 0x04001491 RID: 5265
		private Transform tr;

		// Token: 0x04001492 RID: 5266
		private Sensor sensor;
	}
}
