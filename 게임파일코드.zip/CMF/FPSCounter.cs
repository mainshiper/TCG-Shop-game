﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001EE RID: 494
	public class FPSCounter : MonoBehaviour
	{
		// Token: 0x06000DD3 RID: 3539 RVA: 0x0005FCC8 File Offset: 0x0005DEC8
		private void Update()
		{
			this.currentPassedFrames++;
			this.currentPassedTime += Time.deltaTime;
			if (this.currentPassedTime >= this.checkInterval)
			{
				this.currentFrameRate = (float)this.currentPassedFrames / this.currentPassedTime;
				this.currentPassedTime = 0f;
				this.currentPassedFrames = 0;
				this.currentFrameRate *= 100f;
				this.currentFrameRate = (float)((int)this.currentFrameRate);
				this.currentFrameRate /= 100f;
				this.currentFrameRateString = this.currentFrameRate.ToString();
			}
		}

		// Token: 0x06000DD4 RID: 3540 RVA: 0x0005FD6C File Offset: 0x0005DF6C
		private void OnGUI()
		{
			GUI.contentColor = Color.black;
			float num = 40f;
			float num2 = 2f;
			GUI.Label(new Rect((float)Screen.width - num + num2, num2, num, 30f), this.currentFrameRateString);
			GUI.contentColor = Color.white;
			GUI.Label(new Rect((float)Screen.width - num, 0f, num, 30f), this.currentFrameRateString);
		}

		// Token: 0x040014E0 RID: 5344
		public float checkInterval = 1f;

		// Token: 0x040014E1 RID: 5345
		private int currentPassedFrames;

		// Token: 0x040014E2 RID: 5346
		private float currentPassedTime;

		// Token: 0x040014E3 RID: 5347
		public float currentFrameRate;

		// Token: 0x040014E4 RID: 5348
		private string currentFrameRateString = "";
	}
}
