﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001DD RID: 477
	public class SidescrollerController : AdvancedWalkerController
	{
		// Token: 0x06000D66 RID: 3430 RVA: 0x0005DA1C File Offset: 0x0005BC1C
		protected override Vector3 CalculateMovementDirection()
		{
			if (this.characterInput == null)
			{
				return Vector3.zero;
			}
			Vector3 vector = Vector3.zero;
			if (this.cameraTransform == null)
			{
				vector += this.tr.right * this.characterInput.GetHorizontalMovementInput();
			}
			else
			{
				vector += Vector3.ProjectOnPlane(this.cameraTransform.right, this.tr.up).normalized * this.characterInput.GetHorizontalMovementInput();
			}
			return vector;
		}
	}
}
