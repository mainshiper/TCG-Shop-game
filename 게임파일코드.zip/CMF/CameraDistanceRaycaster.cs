﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001D9 RID: 473
	public class CameraDistanceRaycaster : MonoBehaviour
	{
		// Token: 0x06000D3F RID: 3391 RVA: 0x0005C87C File Offset: 0x0005AA7C
		private void Awake()
		{
			this.tr = base.transform;
			this.ignoreListLayers = new int[this.ignoreList.Length];
			this.ignoreRaycastLayer = LayerMask.NameToLayer("Ignore Raycast");
			if (this.layerMask == (this.layerMask | 1 << this.ignoreRaycastLayer))
			{
				this.layerMask ^= 1 << this.ignoreRaycastLayer;
			}
			if (this.cameraTransform == null)
			{
				Debug.LogWarning("No camera transform has been assigned.", this);
			}
			if (this.cameraTargetTransform == null)
			{
				Debug.LogWarning("No camera target transform has been assigned.", this);
			}
			if (this.cameraTransform == null || this.cameraTargetTransform == null)
			{
				base.enabled = false;
				return;
			}
			this.currentDistance = (this.cameraTargetTransform.position - this.tr.position).magnitude;
		}

		// Token: 0x06000D40 RID: 3392 RVA: 0x0005C980 File Offset: 0x0005AB80
		private void LateUpdate()
		{
			if (this.ignoreListLayers.Length != this.ignoreList.Length)
			{
				this.ignoreListLayers = new int[this.ignoreList.Length];
			}
			for (int i = 0; i < this.ignoreList.Length; i++)
			{
				this.ignoreListLayers[i] = this.ignoreList[i].gameObject.layer;
				this.ignoreList[i].gameObject.layer = this.ignoreRaycastLayer;
			}
			float cameraDistance = this.GetCameraDistance();
			for (int j = 0; j < this.ignoreList.Length; j++)
			{
				this.ignoreList[j].gameObject.layer = this.ignoreListLayers[j];
			}
			this.currentDistance = Mathf.Lerp(this.currentDistance, cameraDistance, Time.deltaTime * this.smoothingFactor);
			this.cameraTransform.position = this.tr.position + (this.cameraTargetTransform.position - this.tr.position).normalized * this.currentDistance;
		}

		// Token: 0x06000D41 RID: 3393 RVA: 0x0005CA94 File Offset: 0x0005AC94
		private float GetCameraDistance()
		{
			Vector3 direction = this.cameraTargetTransform.position - this.tr.position;
			RaycastHit raycastHit;
			if (this.castType == CameraDistanceRaycaster.CastType.Raycast)
			{
				if (Physics.Raycast(new Ray(this.tr.position, direction), ref raycastHit, direction.magnitude + this.minimumDistanceFromObstacles, this.layerMask, 1))
				{
					if (raycastHit.distance - this.minimumDistanceFromObstacles < 0f)
					{
						return raycastHit.distance;
					}
					return raycastHit.distance - this.minimumDistanceFromObstacles;
				}
			}
			else if (Physics.SphereCast(new Ray(this.tr.position, direction), this.spherecastRadius, ref raycastHit, direction.magnitude, this.layerMask, 1))
			{
				return raycastHit.distance;
			}
			return direction.magnitude;
		}

		// Token: 0x04001444 RID: 5188
		public Transform cameraTransform;

		// Token: 0x04001445 RID: 5189
		public Transform cameraTargetTransform;

		// Token: 0x04001446 RID: 5190
		private Transform tr;

		// Token: 0x04001447 RID: 5191
		public CameraDistanceRaycaster.CastType castType;

		// Token: 0x04001448 RID: 5192
		public LayerMask layerMask = -1;

		// Token: 0x04001449 RID: 5193
		private int ignoreRaycastLayer;

		// Token: 0x0400144A RID: 5194
		public Collider[] ignoreList;

		// Token: 0x0400144B RID: 5195
		private int[] ignoreListLayers;

		// Token: 0x0400144C RID: 5196
		private float currentDistance;

		// Token: 0x0400144D RID: 5197
		public float minimumDistanceFromObstacles = 0.1f;

		// Token: 0x0400144E RID: 5198
		public float smoothingFactor = 25f;

		// Token: 0x0400144F RID: 5199
		public float spherecastRadius = 0.2f;

		// Token: 0x0200027F RID: 639
		public enum CastType
		{
			// Token: 0x040016C7 RID: 5831
			Raycast,
			// Token: 0x040016C8 RID: 5832
			Spherecast
		}
	}
}
