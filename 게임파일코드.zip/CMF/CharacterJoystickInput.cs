﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001EA RID: 490
	public class CharacterJoystickInput : CharacterInput
	{
		// Token: 0x06000DBF RID: 3519 RVA: 0x0005F874 File Offset: 0x0005DA74
		public override float GetHorizontalMovementInput()
		{
			float num;
			if (this.useRawInput)
			{
				num = Input.GetAxisRaw(this.horizontalInputAxis);
			}
			else
			{
				num = Input.GetAxis(this.horizontalInputAxis);
			}
			if (Mathf.Abs(num) < this.deadZoneThreshold)
			{
				num = 0f;
			}
			return num;
		}

		// Token: 0x06000DC0 RID: 3520 RVA: 0x0005F8B8 File Offset: 0x0005DAB8
		public override float GetVerticalMovementInput()
		{
			float num;
			if (this.useRawInput)
			{
				num = Input.GetAxisRaw(this.verticalInputAxis);
			}
			else
			{
				num = Input.GetAxis(this.verticalInputAxis);
			}
			if (Mathf.Abs(num) < this.deadZoneThreshold)
			{
				num = 0f;
			}
			return num;
		}

		// Token: 0x06000DC1 RID: 3521 RVA: 0x0005F8FC File Offset: 0x0005DAFC
		public override bool IsJumpKeyPressed()
		{
			return Input.GetKey(this.jumpKey);
		}

		// Token: 0x040014CA RID: 5322
		public string horizontalInputAxis = "Horizontal";

		// Token: 0x040014CB RID: 5323
		public string verticalInputAxis = "Vertical";

		// Token: 0x040014CC RID: 5324
		public KeyCode jumpKey = KeyCode.Joystick1Button0;

		// Token: 0x040014CD RID: 5325
		public bool useRawInput = true;

		// Token: 0x040014CE RID: 5326
		public float deadZoneThreshold = 0.2f;
	}
}
