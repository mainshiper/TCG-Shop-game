﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001D4 RID: 468
	public class AudioControl : MonoBehaviour
	{
		// Token: 0x06000D18 RID: 3352 RVA: 0x0005BDF4 File Offset: 0x00059FF4
		private void Start()
		{
			this.controller = base.GetComponent<Controller>();
			this.animator = base.GetComponentInChildren<Animator>();
			this.mover = base.GetComponent<Mover>();
			this.tr = base.transform;
			Controller controller = this.controller;
			controller.OnLand = (Controller.VectorEvent)Delegate.Combine(controller.OnLand, new Controller.VectorEvent(this.OnLand));
			Controller controller2 = this.controller;
			controller2.OnJump = (Controller.VectorEvent)Delegate.Combine(controller2.OnJump, new Controller.VectorEvent(this.OnJump));
			if (!this.animator)
			{
				this.useAnimationBasedFootsteps = false;
			}
		}

		// Token: 0x06000D19 RID: 3353 RVA: 0x0005BE94 File Offset: 0x0005A094
		private void Update()
		{
			this.FootStepUpdate(VectorMath.RemoveDotVector(this.controller.GetVelocity(), this.tr.up).magnitude);
		}

		// Token: 0x06000D1A RID: 3354 RVA: 0x0005BECC File Offset: 0x0005A0CC
		private void FootStepUpdate(float _movementSpeed)
		{
			float num = 0.05f;
			if (this.useAnimationBasedFootsteps)
			{
				float @float = this.animator.GetFloat("FootStep");
				if (((this.currentFootStepValue <= 0f && @float > 0f) || (this.currentFootStepValue >= 0f && @float < 0f)) && this.mover.IsGrounded() && _movementSpeed > num)
				{
					this.PlayFootstepSound(_movementSpeed);
				}
				this.currentFootStepValue = @float;
				return;
			}
			this.currentFootstepDistance += Time.deltaTime * _movementSpeed;
			if (this.currentFootstepDistance > this.footstepDistance)
			{
				if (this.mover.IsGrounded() && _movementSpeed > num)
				{
					this.PlayFootstepSound(_movementSpeed);
				}
				this.currentFootstepDistance = 0f;
			}
		}

		// Token: 0x06000D1B RID: 3355 RVA: 0x0005BF88 File Offset: 0x0005A188
		private void PlayFootstepSound(float _movementSpeed)
		{
			int num = Random.Range(0, this.footStepClips.Length);
			this.audioSource.PlayOneShot(this.footStepClips[num], SoundManager.SFXVolume * (this.audioClipVolume + this.audioClipVolume * Random.Range(-this.relativeRandomizedVolumeRange, this.relativeRandomizedVolumeRange)));
		}

		// Token: 0x06000D1C RID: 3356 RVA: 0x0005BFDD File Offset: 0x0005A1DD
		private void OnLand(Vector3 _v)
		{
			if (VectorMath.GetDotProduct(_v, this.tr.up) > -this.landVelocityThreshold)
			{
				return;
			}
			this.audioSource.PlayOneShot(this.landClip, SoundManager.SFXVolume * this.audioClipVolume);
		}

		// Token: 0x06000D1D RID: 3357 RVA: 0x0005C017 File Offset: 0x0005A217
		private void OnJump(Vector3 _v)
		{
			this.audioSource.PlayOneShot(this.jumpClip, SoundManager.SFXVolume * this.audioClipVolume);
		}

		// Token: 0x04001417 RID: 5143
		private Controller controller;

		// Token: 0x04001418 RID: 5144
		private Animator animator;

		// Token: 0x04001419 RID: 5145
		private Mover mover;

		// Token: 0x0400141A RID: 5146
		private Transform tr;

		// Token: 0x0400141B RID: 5147
		public AudioSource audioSource;

		// Token: 0x0400141C RID: 5148
		public bool useAnimationBasedFootsteps = true;

		// Token: 0x0400141D RID: 5149
		public float landVelocityThreshold = 5f;

		// Token: 0x0400141E RID: 5150
		public float footstepDistance = 0.2f;

		// Token: 0x0400141F RID: 5151
		private float currentFootstepDistance;

		// Token: 0x04001420 RID: 5152
		private float currentFootStepValue;

		// Token: 0x04001421 RID: 5153
		[Range(0f, 1f)]
		public float audioClipVolume = 0.1f;

		// Token: 0x04001422 RID: 5154
		public float relativeRandomizedVolumeRange = 0.2f;

		// Token: 0x04001423 RID: 5155
		public AudioClip[] footStepClips;

		// Token: 0x04001424 RID: 5156
		public AudioClip jumpClip;

		// Token: 0x04001425 RID: 5157
		public AudioClip landClip;
	}
}
