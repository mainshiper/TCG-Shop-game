﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001EF RID: 495
	public class MouseCursorLock : MonoBehaviour
	{
		// Token: 0x06000DD6 RID: 3542 RVA: 0x0005FDFB File Offset: 0x0005DFFB
		private void Start()
		{
			if (this.lockCursorAtGameStart)
			{
				Cursor.lockState = CursorLockMode.Locked;
				Cursor.visible = false;
			}
		}

		// Token: 0x06000DD7 RID: 3543 RVA: 0x0005FE11 File Offset: 0x0005E011
		private void Update()
		{
			if (Input.GetKeyDown(this.unlockKeyCode))
			{
				Cursor.lockState = CursorLockMode.None;
				Cursor.visible = true;
			}
			if (Input.GetKeyDown(this.lockKeyCode))
			{
				Cursor.lockState = CursorLockMode.Locked;
				Cursor.visible = false;
			}
		}

		// Token: 0x040014E5 RID: 5349
		public bool lockCursorAtGameStart = true;

		// Token: 0x040014E6 RID: 5350
		public KeyCode unlockKeyCode = KeyCode.Escape;

		// Token: 0x040014E7 RID: 5351
		public KeyCode lockKeyCode = KeyCode.Mouse0;
	}
}
