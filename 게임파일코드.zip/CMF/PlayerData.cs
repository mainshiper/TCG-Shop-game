﻿using System;

namespace CMF
{
	// Token: 0x020001F0 RID: 496
	public static class PlayerData
	{
		// Token: 0x040014E8 RID: 5352
		public static int controllerIndex = 0;

		// Token: 0x040014E9 RID: 5353
		public static bool enableShadows = true;
	}
}
