﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001D7 RID: 471
	public class TurnTowardTransformDirection : MonoBehaviour
	{
		// Token: 0x06000D27 RID: 3367 RVA: 0x0005C28F File Offset: 0x0005A48F
		private void Start()
		{
			this.tr = base.transform;
			this.parentTransform = base.transform.parent;
			if (this.targetTransform == null)
			{
				Debug.LogWarning("No target transform has been assigned to this script.", this);
			}
		}

		// Token: 0x06000D28 RID: 3368 RVA: 0x0005C2C8 File Offset: 0x0005A4C8
		private void LateUpdate()
		{
			if (!this.targetTransform)
			{
				return;
			}
			Vector3 normalized = Vector3.ProjectOnPlane(this.targetTransform.forward, this.parentTransform.up).normalized;
			Vector3 up = this.parentTransform.up;
			this.tr.rotation = Quaternion.LookRotation(normalized, up);
		}

		// Token: 0x0400142F RID: 5167
		public Transform targetTransform;

		// Token: 0x04001430 RID: 5168
		private Transform tr;

		// Token: 0x04001431 RID: 5169
		private Transform parentTransform;
	}
}
