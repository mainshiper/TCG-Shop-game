﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001D8 RID: 472
	public class CameraController : MonoBehaviour
	{
		// Token: 0x06000D2A RID: 3370 RVA: 0x0005C330 File Offset: 0x0005A530
		private void Awake()
		{
			this.tr = base.transform;
			this.cam = base.GetComponent<Camera>();
			this.cameraInput = base.GetComponent<CameraInput>();
			if (this.cameraInput == null)
			{
				Debug.LogWarning("No camera input script has been attached to this gameobject", base.gameObject);
			}
			if (this.cam == null)
			{
				this.cam = base.GetComponentInChildren<Camera>();
			}
			this.currentXAngle = this.tr.localRotation.eulerAngles.x;
			this.currentYAngle = this.tr.localRotation.eulerAngles.y;
			this.RotateCamera(0f, 0f);
			this.Setup();
		}

		// Token: 0x06000D2B RID: 3371 RVA: 0x0005C3EB File Offset: 0x0005A5EB
		protected virtual void Setup()
		{
		}

		// Token: 0x06000D2C RID: 3372 RVA: 0x0005C3ED File Offset: 0x0005A5ED
		private void Update()
		{
			this.HandleCameraRotation();
		}

		// Token: 0x06000D2D RID: 3373 RVA: 0x0005C3F8 File Offset: 0x0005A5F8
		protected virtual void HandleCameraRotation()
		{
			if (this.cameraInput == null)
			{
				return;
			}
			float horizontalCameraInput = this.cameraInput.GetHorizontalCameraInput();
			float verticalCameraInput = this.cameraInput.GetVerticalCameraInput();
			this.RotateCamera(horizontalCameraInput, verticalCameraInput);
		}

		// Token: 0x06000D2E RID: 3374 RVA: 0x0005C434 File Offset: 0x0005A634
		protected void RotateCamera(float _newHorizontalInput, float _newVerticalInput)
		{
			if (this.smoothCameraRotation)
			{
				this.oldHorizontalInput = Mathf.Lerp(this.oldHorizontalInput, _newHorizontalInput, Time.deltaTime * this.cameraSmoothingFactor);
				this.oldVerticalInput = Mathf.Lerp(this.oldVerticalInput, _newVerticalInput, Time.deltaTime * this.cameraSmoothingFactor);
			}
			else
			{
				this.oldHorizontalInput = _newHorizontalInput;
				this.oldVerticalInput = _newVerticalInput;
			}
			this.currentXAngle += this.oldVerticalInput * this.cameraSpeed * Time.deltaTime * CSingleton<CGameManager>.Instance.m_MouseSensitivityLerp;
			this.currentYAngle += this.oldHorizontalInput * this.cameraSpeed * Time.deltaTime * CSingleton<CGameManager>.Instance.m_MouseSensitivityLerp;
			this.currentXAngle = Mathf.Clamp(this.currentXAngle, -this.upperVerticalLimit, this.lowerVerticalLimit);
			if (this.isViewCardAlbumMode)
			{
				this.currentYAngle = Mathf.Clamp(this.currentYAngle, this.viewCardAlbumYAngle - 34f - 33f * this.viewCardAlbumAngleOffsetMultiplier, this.viewCardAlbumYAngle + 34f + 33f * this.viewCardAlbumAngleOffsetMultiplier);
				this.currentXAngle = Mathf.Clamp(this.currentXAngle, this.viewCardAlbumXAngle - 10f - 15f * this.viewCardAlbumAngleOffsetMultiplier, this.viewCardAlbumXAngle + 10f + 15f * this.viewCardAlbumAngleOffsetMultiplier);
			}
			this.UpdateRotation();
		}

		// Token: 0x06000D2F RID: 3375 RVA: 0x0005C5A0 File Offset: 0x0005A7A0
		protected void UpdateRotation()
		{
			this.tr.localRotation = Quaternion.Euler(new Vector3(0f, this.currentYAngle, 0f));
			this.facingDirection = this.tr.forward;
			this.upwardsDirection = this.tr.up;
			this.tr.localRotation = Quaternion.Euler(new Vector3(this.currentXAngle, this.currentYAngle, 0f));
		}

		// Token: 0x06000D30 RID: 3376 RVA: 0x0005C61A File Offset: 0x0005A81A
		public void SetFOV(float _fov)
		{
			if (this.cam)
			{
				this.cam.fieldOfView = _fov;
			}
		}

		// Token: 0x06000D31 RID: 3377 RVA: 0x0005C635 File Offset: 0x0005A835
		public void SetRotationAngles(float _xAngle, float _yAngle)
		{
			this.currentXAngle = _xAngle;
			this.currentYAngle = _yAngle;
			this.UpdateRotation();
		}

		// Token: 0x06000D32 RID: 3378 RVA: 0x0005C64C File Offset: 0x0005A84C
		public void RotateTowardPosition(Vector3 _position, float _lookSpeed)
		{
			Vector3 direction = _position - this.tr.position;
			this.RotateTowardDirection(direction, _lookSpeed);
		}

		// Token: 0x06000D33 RID: 3379 RVA: 0x0005C674 File Offset: 0x0005A874
		public void RotateTowardDirection(Vector3 _direction, float _lookSpeed)
		{
			_direction.Normalize();
			_direction = this.tr.parent.InverseTransformDirection(_direction);
			Vector3 vector = this.GetAimingDirection();
			vector = this.tr.parent.InverseTransformDirection(vector);
			float angle = VectorMath.GetAngle(new Vector3(0f, vector.y, 1f), new Vector3(0f, _direction.y, 1f), Vector3.right);
			vector.y = 0f;
			_direction.y = 0f;
			float angle2 = VectorMath.GetAngle(vector, _direction, Vector3.up);
			Vector2 vector2 = new Vector2(this.currentXAngle, this.currentYAngle);
			Vector2 a = new Vector2(angle, angle2);
			float magnitude = a.magnitude;
			if (magnitude == 0f)
			{
				return;
			}
			Vector2 a2 = a / magnitude;
			if (_lookSpeed * Time.deltaTime > magnitude)
			{
				vector2 += a2 * magnitude;
			}
			else
			{
				vector2 += a2 * _lookSpeed * Time.deltaTime;
			}
			this.currentYAngle = vector2.y;
			this.currentXAngle = Mathf.Clamp(vector2.x, -this.upperVerticalLimit, this.lowerVerticalLimit);
			this.UpdateRotation();
		}

		// Token: 0x06000D34 RID: 3380 RVA: 0x0005C7AE File Offset: 0x0005A9AE
		public void EnterViewCardAlbumMode()
		{
			this.isViewCardAlbumMode = true;
			this.viewCardAlbumXAngle = this.currentXAngle;
			this.viewCardAlbumYAngle = this.currentYAngle;
			this.viewCardAlbumAngleOffsetMultiplier = Mathf.Abs(this.currentXAngle) / this.upperVerticalLimit;
		}

		// Token: 0x06000D35 RID: 3381 RVA: 0x0005C7E7 File Offset: 0x0005A9E7
		public float GetViewCardDeltaAngleX()
		{
			return this.currentXAngle - this.viewCardAlbumXAngle;
		}

		// Token: 0x06000D36 RID: 3382 RVA: 0x0005C7F6 File Offset: 0x0005A9F6
		public float GetViewCardDeltaAngleY()
		{
			return this.currentYAngle - this.viewCardAlbumYAngle;
		}

		// Token: 0x06000D37 RID: 3383 RVA: 0x0005C805 File Offset: 0x0005AA05
		public void ExitViewCardAlbumMode()
		{
			this.isViewCardAlbumMode = false;
		}

		// Token: 0x06000D38 RID: 3384 RVA: 0x0005C80E File Offset: 0x0005AA0E
		public float GetCurrentXAngle()
		{
			return this.currentXAngle;
		}

		// Token: 0x06000D39 RID: 3385 RVA: 0x0005C816 File Offset: 0x0005AA16
		public float GetCurrentYAngle()
		{
			return this.currentYAngle;
		}

		// Token: 0x06000D3A RID: 3386 RVA: 0x0005C81E File Offset: 0x0005AA1E
		public Vector3 GetFacingDirection()
		{
			return this.facingDirection;
		}

		// Token: 0x06000D3B RID: 3387 RVA: 0x0005C826 File Offset: 0x0005AA26
		public Vector3 GetAimingDirection()
		{
			return this.tr.forward;
		}

		// Token: 0x06000D3C RID: 3388 RVA: 0x0005C833 File Offset: 0x0005AA33
		public Vector3 GetStrafeDirection()
		{
			return this.tr.right;
		}

		// Token: 0x06000D3D RID: 3389 RVA: 0x0005C840 File Offset: 0x0005AA40
		public Vector3 GetUpDirection()
		{
			return this.upwardsDirection;
		}

		// Token: 0x04001432 RID: 5170
		public float currentXAngle;

		// Token: 0x04001433 RID: 5171
		public float currentYAngle;

		// Token: 0x04001434 RID: 5172
		[Range(0f, 90f)]
		public float upperVerticalLimit = 60f;

		// Token: 0x04001435 RID: 5173
		[Range(0f, 90f)]
		public float lowerVerticalLimit = 60f;

		// Token: 0x04001436 RID: 5174
		public float oldHorizontalInput;

		// Token: 0x04001437 RID: 5175
		public float oldVerticalInput;

		// Token: 0x04001438 RID: 5176
		public float cameraSpeed = 250f;

		// Token: 0x04001439 RID: 5177
		public bool smoothCameraRotation;

		// Token: 0x0400143A RID: 5178
		[Range(1f, 50f)]
		public float cameraSmoothingFactor = 25f;

		// Token: 0x0400143B RID: 5179
		private Vector3 facingDirection;

		// Token: 0x0400143C RID: 5180
		private Vector3 upwardsDirection;

		// Token: 0x0400143D RID: 5181
		protected Transform tr;

		// Token: 0x0400143E RID: 5182
		protected Camera cam;

		// Token: 0x0400143F RID: 5183
		protected CameraInput cameraInput;

		// Token: 0x04001440 RID: 5184
		protected bool isViewCardAlbumMode;

		// Token: 0x04001441 RID: 5185
		protected float viewCardAlbumXAngle;

		// Token: 0x04001442 RID: 5186
		protected float viewCardAlbumYAngle;

		// Token: 0x04001443 RID: 5187
		protected float viewCardAlbumAngleOffsetMultiplier;
	}
}
