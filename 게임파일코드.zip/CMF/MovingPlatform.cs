﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E3 RID: 483
	public class MovingPlatform : MonoBehaviour
	{
		// Token: 0x06000DA2 RID: 3490 RVA: 0x0005F1BC File Offset: 0x0005D3BC
		private void Start()
		{
			this.r = base.GetComponent<Rigidbody>();
			this.triggerArea = base.GetComponentInChildren<TriggerArea>();
			this.r.freezeRotation = true;
			this.r.useGravity = false;
			this.r.isKinematic = true;
			if (this.waypoints.Count <= 0)
			{
				Debug.LogWarning("No waypoints have been assigned to 'MovingPlatform'!");
			}
			else
			{
				this.currentWaypoint = this.waypoints[this.currentWaypointIndex];
			}
			base.StartCoroutine(this.WaitRoutine());
			base.StartCoroutine(this.LateFixedUpdate());
		}

		// Token: 0x06000DA3 RID: 3491 RVA: 0x0005F250 File Offset: 0x0005D450
		private IEnumerator LateFixedUpdate()
		{
			WaitForFixedUpdate _instruction = new WaitForFixedUpdate();
			for (;;)
			{
				yield return _instruction;
				this.MovePlatform();
			}
			yield break;
		}

		// Token: 0x06000DA4 RID: 3492 RVA: 0x0005F260 File Offset: 0x0005D460
		private void MovePlatform()
		{
			if (this.waypoints.Count <= 0)
			{
				return;
			}
			if (this.isWaiting)
			{
				return;
			}
			Vector3 vector = this.currentWaypoint.position - base.transform.position;
			Vector3 vector2 = vector.normalized;
			vector2 *= this.movementSpeed * Time.deltaTime;
			if (vector2.magnitude >= vector.magnitude || vector2.magnitude == 0f)
			{
				this.r.transform.position = this.currentWaypoint.position;
				this.UpdateWaypoint();
			}
			else
			{
				this.r.transform.position += vector2;
			}
			if (this.triggerArea == null)
			{
				return;
			}
			for (int i = 0; i < this.triggerArea.rigidbodiesInTriggerArea.Count; i++)
			{
				this.triggerArea.rigidbodiesInTriggerArea[i].MovePosition(this.triggerArea.rigidbodiesInTriggerArea[i].position + vector2);
			}
		}

		// Token: 0x06000DA5 RID: 3493 RVA: 0x0005F378 File Offset: 0x0005D578
		private void UpdateWaypoint()
		{
			if (this.reverseDirection)
			{
				this.currentWaypointIndex--;
			}
			else
			{
				this.currentWaypointIndex++;
			}
			if (this.currentWaypointIndex >= this.waypoints.Count)
			{
				this.currentWaypointIndex = 0;
			}
			if (this.currentWaypointIndex < 0)
			{
				this.currentWaypointIndex = this.waypoints.Count - 1;
			}
			this.currentWaypoint = this.waypoints[this.currentWaypointIndex];
			this.isWaiting = true;
		}

		// Token: 0x06000DA6 RID: 3494 RVA: 0x0005F3FF File Offset: 0x0005D5FF
		private IEnumerator WaitRoutine()
		{
			WaitForSeconds _waitInstruction = new WaitForSeconds(this.waitTime);
			for (;;)
			{
				if (this.isWaiting)
				{
					yield return _waitInstruction;
					this.isWaiting = false;
				}
				yield return null;
			}
			yield break;
		}

		// Token: 0x040014B1 RID: 5297
		public float movementSpeed = 10f;

		// Token: 0x040014B2 RID: 5298
		public bool reverseDirection;

		// Token: 0x040014B3 RID: 5299
		public float waitTime = 1f;

		// Token: 0x040014B4 RID: 5300
		private bool isWaiting;

		// Token: 0x040014B5 RID: 5301
		private Rigidbody r;

		// Token: 0x040014B6 RID: 5302
		private TriggerArea triggerArea;

		// Token: 0x040014B7 RID: 5303
		public List<Transform> waypoints = new List<Transform>();

		// Token: 0x040014B8 RID: 5304
		private int currentWaypointIndex;

		// Token: 0x040014B9 RID: 5305
		private Transform currentWaypoint;
	}
}
