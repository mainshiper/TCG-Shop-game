﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E7 RID: 487
	public class CameraJoystickInput : CameraInput
	{
		// Token: 0x06000DB5 RID: 3509 RVA: 0x0005F5B0 File Offset: 0x0005D7B0
		public override float GetHorizontalCameraInput()
		{
			float num = Input.GetAxisRaw(this.joystickHorizontalAxis);
			if (Mathf.Abs(num) < this.deadZoneThreshold)
			{
				num = 0f;
			}
			if (this.invertHorizontalInput)
			{
				return num * -1f;
			}
			return num;
		}

		// Token: 0x06000DB6 RID: 3510 RVA: 0x0005F5F0 File Offset: 0x0005D7F0
		public override float GetVerticalCameraInput()
		{
			float num = Input.GetAxisRaw(this.joystickVerticalAxis);
			if (Mathf.Abs(num) < this.deadZoneThreshold)
			{
				num = 0f;
			}
			if (this.invertVerticalInput)
			{
				return num;
			}
			return num * -1f;
		}

		// Token: 0x040014BB RID: 5307
		public string joystickHorizontalAxis = "Joystick X";

		// Token: 0x040014BC RID: 5308
		public string joystickVerticalAxis = "Joystick Y";

		// Token: 0x040014BD RID: 5309
		public bool invertHorizontalInput;

		// Token: 0x040014BE RID: 5310
		public bool invertVerticalInput;

		// Token: 0x040014BF RID: 5311
		public float deadZoneThreshold = 0.2f;
	}
}
