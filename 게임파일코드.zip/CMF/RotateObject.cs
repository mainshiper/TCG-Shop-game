﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001F1 RID: 497
	public class RotateObject : MonoBehaviour
	{
		// Token: 0x06000DDA RID: 3546 RVA: 0x0005FE75 File Offset: 0x0005E075
		private void Start()
		{
			this.tr = base.transform;
		}

		// Token: 0x06000DDB RID: 3547 RVA: 0x0005FE83 File Offset: 0x0005E083
		private void Update()
		{
			this.tr.Rotate(this.rotationAxis * this.rotationSpeed * Time.deltaTime);
		}

		// Token: 0x040014EA RID: 5354
		private Transform tr;

		// Token: 0x040014EB RID: 5355
		public float rotationSpeed = 20f;

		// Token: 0x040014EC RID: 5356
		public Vector3 rotationAxis = new Vector3(0f, 1f, 0f);
	}
}
