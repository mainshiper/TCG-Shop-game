﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001D6 RID: 470
	public class TurnTowardControllerVelocity : MonoBehaviour
	{
		// Token: 0x06000D22 RID: 3362 RVA: 0x0005C0E5 File Offset: 0x0005A2E5
		private void Start()
		{
			this.tr = base.transform;
			this.parentTransform = this.tr.parent;
			if (this.controller == null)
			{
				Debug.LogWarning("No controller script has been assigned to this 'TurnTowardControllerVelocity' component!", this);
				base.enabled = false;
			}
		}

		// Token: 0x06000D23 RID: 3363 RVA: 0x0005C124 File Offset: 0x0005A324
		private void LateUpdate()
		{
			Vector3 vector;
			if (this.ignoreControllerMomentum)
			{
				vector = this.controller.GetMovementVelocity();
			}
			else
			{
				vector = this.controller.GetVelocity();
			}
			vector = Vector3.ProjectOnPlane(vector, this.parentTransform.up);
			float num = 0.001f;
			if (vector.magnitude < num)
			{
				return;
			}
			vector.Normalize();
			float angle = VectorMath.GetAngle(this.tr.forward, vector, this.parentTransform.up);
			float num2 = Mathf.InverseLerp(0f, this.fallOffAngle, Mathf.Abs(angle));
			float num3 = Mathf.Sign(angle) * num2 * Time.deltaTime * this.turnSpeed;
			if (angle < 0f && num3 < angle)
			{
				num3 = angle;
			}
			else if (angle > 0f && num3 > angle)
			{
				num3 = angle;
			}
			this.currentYRotation += num3;
			if (this.currentYRotation > 360f)
			{
				this.currentYRotation -= 360f;
			}
			if (this.currentYRotation < -360f)
			{
				this.currentYRotation += 360f;
			}
			this.tr.localRotation = Quaternion.Euler(0f, this.currentYRotation, 0f);
		}

		// Token: 0x06000D24 RID: 3364 RVA: 0x0005C257 File Offset: 0x0005A457
		private void OnDisable()
		{
		}

		// Token: 0x06000D25 RID: 3365 RVA: 0x0005C259 File Offset: 0x0005A459
		private void OnEnable()
		{
			this.currentYRotation = base.transform.localEulerAngles.y;
		}

		// Token: 0x04001428 RID: 5160
		public Controller controller;

		// Token: 0x04001429 RID: 5161
		public float turnSpeed = 500f;

		// Token: 0x0400142A RID: 5162
		private Transform parentTransform;

		// Token: 0x0400142B RID: 5163
		private Transform tr;

		// Token: 0x0400142C RID: 5164
		private float currentYRotation;

		// Token: 0x0400142D RID: 5165
		private float fallOffAngle = 90f;

		// Token: 0x0400142E RID: 5166
		public bool ignoreControllerMomentum;
	}
}
