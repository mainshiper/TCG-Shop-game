﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001DA RID: 474
	public class ThirdPersonCameraController : CameraController
	{
		// Token: 0x06000D43 RID: 3395 RVA: 0x0005CB9C File Offset: 0x0005AD9C
		protected override void Setup()
		{
			if (this.controller == null)
			{
				Debug.LogWarning("No controller reference has been assigned to this script.", base.gameObject);
			}
		}

		// Token: 0x06000D44 RID: 3396 RVA: 0x0005CBBC File Offset: 0x0005ADBC
		protected override void HandleCameraRotation()
		{
			base.HandleCameraRotation();
			if (this.controller == null)
			{
				return;
			}
			if (this.turnCameraTowardMovementDirection && this.controller != null)
			{
				Vector3 velocity = this.controller.GetVelocity();
				this.RotateTowardsVelocity(velocity, this.cameraTurnSpeed);
			}
		}

		// Token: 0x06000D45 RID: 3397 RVA: 0x0005CC10 File Offset: 0x0005AE10
		public void RotateTowardsVelocity(Vector3 _velocity, float _speed)
		{
			_velocity = VectorMath.RemoveDotVector(_velocity, base.GetUpDirection());
			float angle = VectorMath.GetAngle(base.GetFacingDirection(), _velocity, base.GetUpDirection());
			float num = Mathf.Sign(angle);
			float num2 = Time.deltaTime * _speed * num * Mathf.Abs(angle / 90f);
			if (Mathf.Abs(angle) > 90f)
			{
				num2 = Time.deltaTime * _speed * num * (Mathf.Abs(180f - Mathf.Abs(angle)) / 90f);
			}
			if (Mathf.Abs(num2) > Mathf.Abs(angle))
			{
				num2 = angle;
			}
			num2 *= Mathf.InverseLerp(0f, this.maximumMovementSpeed, _velocity.magnitude);
			base.SetRotationAngles(base.GetCurrentXAngle(), base.GetCurrentYAngle() + num2);
		}

		// Token: 0x04001450 RID: 5200
		public bool turnCameraTowardMovementDirection = true;

		// Token: 0x04001451 RID: 5201
		public Controller controller;

		// Token: 0x04001452 RID: 5202
		public float maximumMovementSpeed = 7f;

		// Token: 0x04001453 RID: 5203
		public float cameraTurnSpeed = 120f;
	}
}
