﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E8 RID: 488
	public class CameraMouseInput : CameraInput
	{
		// Token: 0x06000DB8 RID: 3512 RVA: 0x0005F65C File Offset: 0x0005D85C
		public unsafe override float GetHorizontalCameraInput()
		{
			float num = Input.GetAxisRaw(this.joystickHorizontalAxis);
			if (CSingleton<InputManager>.Instance.m_CurrentGamepad != null && CSingleton<InputManager>.Instance.m_IsControllerActive)
			{
				num = *CSingleton<InputManager>.Instance.m_CurrentGamepad.rightStick.x.value;
			}
			bool flag = false;
			if (Mathf.Abs(num) > 0f && CSingleton<InputManager>.Instance.m_IsControllerActive)
			{
				flag = true;
			}
			else
			{
				num = Input.GetAxisRaw(this.mouseHorizontalAxis);
			}
			if (Time.timeScale > 0f && Time.deltaTime > 0f)
			{
				num /= Time.deltaTime;
				num *= Time.timeScale;
			}
			else
			{
				num = 0f;
			}
			if (flag)
			{
				num *= this.joystickInputMultiplier;
			}
			else
			{
				num *= this.mouseInputMultiplier;
			}
			if (this.invertHorizontalInput)
			{
				num *= -1f;
			}
			return num;
		}

		// Token: 0x06000DB9 RID: 3513 RVA: 0x0005F72C File Offset: 0x0005D92C
		public unsafe override float GetVerticalCameraInput()
		{
			float num = -Input.GetAxisRaw(this.joystickVerticalAxis);
			if (CSingleton<InputManager>.Instance.m_CurrentGamepad != null && CSingleton<InputManager>.Instance.m_IsControllerActive)
			{
				num = -(*CSingleton<InputManager>.Instance.m_CurrentGamepad.rightStick.y.value);
			}
			bool flag = false;
			if (Mathf.Abs(num) > 0f && CSingleton<InputManager>.Instance.m_IsControllerActive)
			{
				flag = true;
			}
			else
			{
				num = -Input.GetAxisRaw(this.mouseVerticalAxis);
			}
			if (Time.timeScale > 0f && Time.deltaTime > 0f)
			{
				num /= Time.deltaTime;
				num *= Time.timeScale;
			}
			else
			{
				num = 0f;
			}
			if (flag)
			{
				num *= this.joystickInputMultiplier;
			}
			else
			{
				num *= this.mouseInputMultiplier;
			}
			if (this.invertVerticalInput)
			{
				num *= -1f;
			}
			return num;
		}

		// Token: 0x040014C0 RID: 5312
		public string mouseHorizontalAxis = "Mouse X";

		// Token: 0x040014C1 RID: 5313
		public string mouseVerticalAxis = "Mouse Y";

		// Token: 0x040014C2 RID: 5314
		public string joystickHorizontalAxis = "RJoystick X";

		// Token: 0x040014C3 RID: 5315
		public string joystickVerticalAxis = "RJoystick Y";

		// Token: 0x040014C4 RID: 5316
		public string joystickHorizontalAxisPS = "RJoystick X PS";

		// Token: 0x040014C5 RID: 5317
		public string joystickVerticalAxisPS = "RJoystick Y PS";

		// Token: 0x040014C6 RID: 5318
		public bool invertHorizontalInput;

		// Token: 0x040014C7 RID: 5319
		public bool invertVerticalInput;

		// Token: 0x040014C8 RID: 5320
		public float mouseInputMultiplier = 0.01f;

		// Token: 0x040014C9 RID: 5321
		public float joystickInputMultiplier = 1f;
	}
}
