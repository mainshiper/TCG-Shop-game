﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E0 RID: 480
	[Serializable]
	public class Sensor
	{
		// Token: 0x06000D86 RID: 3462 RVA: 0x0005E63C File Offset: 0x0005C83C
		public Sensor(Transform _transform, Collider _collider)
		{
			this.tr = _transform;
			if (_collider == null)
			{
				return;
			}
			this.ignoreList = new Collider[1];
			this.ignoreList[0] = _collider;
			this.ignoreRaycastLayer = LayerMask.NameToLayer("Ignore Raycast");
			this.ignoreListLayers = new int[this.ignoreList.Length];
		}

		// Token: 0x06000D87 RID: 3463 RVA: 0x0005E704 File Offset: 0x0005C904
		private void ResetFlags()
		{
			this.hasDetectedHit = false;
			this.hitPosition = Vector3.zero;
			this.hitNormal = -this.GetCastDirection();
			this.hitDistance = 0f;
			if (this.hitColliders.Count > 0)
			{
				this.hitColliders.Clear();
			}
			if (this.hitTransforms.Count > 0)
			{
				this.hitTransforms.Clear();
			}
		}

		// Token: 0x06000D88 RID: 3464 RVA: 0x0005E774 File Offset: 0x0005C974
		public static Vector3[] GetRaycastStartPositions(int sensorRows, int sensorRayCount, bool offsetRows, float sensorRadius)
		{
			List<Vector3> list = new List<Vector3>();
			Vector3 zero = Vector3.zero;
			list.Add(zero);
			for (int i = 0; i < sensorRows; i++)
			{
				float num = (float)(i + 1) / (float)sensorRows;
				for (int j = 0; j < sensorRayCount * (i + 1); j++)
				{
					float num2 = 360f / (float)(sensorRayCount * (i + 1)) * (float)j;
					if (offsetRows && i % 2 == 0)
					{
						num2 += 360f / (float)(sensorRayCount * (i + 1)) / 2f;
					}
					float x = num * Mathf.Cos(0.017453292f * num2);
					float z = num * Mathf.Sin(0.017453292f * num2);
					list.Add(new Vector3(x, 0f, z) * sensorRadius);
				}
			}
			return list.ToArray();
		}

		// Token: 0x06000D89 RID: 3465 RVA: 0x0005E838 File Offset: 0x0005CA38
		public void Cast()
		{
			this.ResetFlags();
			Vector3 direction = this.GetCastDirection();
			Vector3 vector = this.tr.TransformPoint(this.origin);
			if (this.ignoreListLayers.Length != this.ignoreList.Length)
			{
				this.ignoreListLayers = new int[this.ignoreList.Length];
			}
			for (int i = 0; i < this.ignoreList.Length; i++)
			{
				this.ignoreListLayers[i] = this.ignoreList[i].gameObject.layer;
				this.ignoreList[i].gameObject.layer = this.ignoreRaycastLayer;
			}
			switch (this.castType)
			{
			case Sensor.CastType.Raycast:
				this.CastRay(vector, direction);
				break;
			case Sensor.CastType.RaycastArray:
				this.CastRayArray(vector, direction);
				break;
			case Sensor.CastType.Spherecast:
				this.CastSphere(vector, direction);
				break;
			default:
				this.hasDetectedHit = false;
				break;
			}
			for (int j = 0; j < this.ignoreList.Length; j++)
			{
				this.ignoreList[j].gameObject.layer = this.ignoreListLayers[j];
			}
		}

		// Token: 0x06000D8A RID: 3466 RVA: 0x0005E944 File Offset: 0x0005CB44
		private void CastRayArray(Vector3 _origin, Vector3 _direction)
		{
			Vector3 zero = Vector3.zero;
			Vector3 vector = this.GetCastDirection();
			this.arrayNormals.Clear();
			this.arrayPoints.Clear();
			for (int i = 0; i < this.raycastArrayStartPositions.Length; i++)
			{
				RaycastHit raycastHit;
				if (Physics.Raycast(_origin + this.tr.TransformDirection(this.raycastArrayStartPositions[i]), vector, ref raycastHit, this.castLength, this.layermask, 1))
				{
					if (this.isInDebugMode)
					{
						Debug.DrawRay(raycastHit.point, raycastHit.normal, Color.red, Time.fixedDeltaTime * 1.01f);
					}
					this.hitColliders.Add(raycastHit.collider);
					this.hitTransforms.Add(raycastHit.transform);
					this.arrayNormals.Add(raycastHit.normal);
					this.arrayPoints.Add(raycastHit.point);
				}
			}
			this.hasDetectedHit = (this.arrayPoints.Count > 0);
			if (this.hasDetectedHit)
			{
				Vector3 a = Vector3.zero;
				for (int j = 0; j < this.arrayNormals.Count; j++)
				{
					a += this.arrayNormals[j];
				}
				a.Normalize();
				Vector3 a2 = Vector3.zero;
				for (int k = 0; k < this.arrayPoints.Count; k++)
				{
					a2 += this.arrayPoints[k];
				}
				a2 /= (float)this.arrayPoints.Count;
				this.hitPosition = a2;
				this.hitNormal = a;
				this.hitDistance = VectorMath.ExtractDotVector(_origin - this.hitPosition, _direction).magnitude;
			}
		}

		// Token: 0x06000D8B RID: 3467 RVA: 0x0005EB10 File Offset: 0x0005CD10
		private void CastRay(Vector3 _origin, Vector3 _direction)
		{
			RaycastHit raycastHit;
			this.hasDetectedHit = Physics.Raycast(_origin, _direction, ref raycastHit, this.castLength, this.layermask, 1);
			if (this.hasDetectedHit)
			{
				this.hitPosition = raycastHit.point;
				this.hitNormal = raycastHit.normal;
				this.hitColliders.Add(raycastHit.collider);
				this.hitTransforms.Add(raycastHit.transform);
				this.hitDistance = raycastHit.distance;
			}
		}

		// Token: 0x06000D8C RID: 3468 RVA: 0x0005EB94 File Offset: 0x0005CD94
		private void CastSphere(Vector3 _origin, Vector3 _direction)
		{
			RaycastHit raycastHit;
			this.hasDetectedHit = Physics.SphereCast(_origin, this.sphereCastRadius, _direction, ref raycastHit, this.castLength - this.sphereCastRadius, this.layermask, 1);
			if (this.hasDetectedHit)
			{
				this.hitPosition = raycastHit.point;
				this.hitNormal = raycastHit.normal;
				this.hitColliders.Add(raycastHit.collider);
				this.hitTransforms.Add(raycastHit.transform);
				this.hitDistance = raycastHit.distance;
				this.hitDistance += this.sphereCastRadius;
				if (this.calculateRealDistance)
				{
					this.hitDistance = VectorMath.ExtractDotVector(_origin - this.hitPosition, _direction).magnitude;
				}
				Collider collider = this.hitColliders[0];
				if (this.calculateRealSurfaceNormal)
				{
					if (collider.Raycast(new Ray(this.hitPosition - _direction, _direction), ref raycastHit, 1.5f))
					{
						if (Vector3.Angle(raycastHit.normal, -_direction) >= 89f)
						{
							this.hitNormal = this.backupNormal;
						}
						else
						{
							this.hitNormal = raycastHit.normal;
						}
					}
					else
					{
						this.hitNormal = this.backupNormal;
					}
					this.backupNormal = this.hitNormal;
				}
			}
		}

		// Token: 0x06000D8D RID: 3469 RVA: 0x0005ECE4 File Offset: 0x0005CEE4
		private Vector3 GetCastDirection()
		{
			switch (this.castDirection)
			{
			case Sensor.CastDirection.Forward:
				return this.tr.forward;
			case Sensor.CastDirection.Right:
				return this.tr.right;
			case Sensor.CastDirection.Up:
				return this.tr.up;
			case Sensor.CastDirection.Backward:
				return -this.tr.forward;
			case Sensor.CastDirection.Left:
				return -this.tr.right;
			case Sensor.CastDirection.Down:
				return -this.tr.up;
			default:
				return Vector3.one;
			}
		}

		// Token: 0x06000D8E RID: 3470 RVA: 0x0005ED74 File Offset: 0x0005CF74
		public void DrawDebug()
		{
			if (this.hasDetectedHit && this.isInDebugMode)
			{
				Debug.DrawRay(this.hitPosition, this.hitNormal, Color.red, Time.deltaTime);
				float d = 0.2f;
				Debug.DrawLine(this.hitPosition + Vector3.up * d, this.hitPosition - Vector3.up * d, Color.green, Time.deltaTime);
				Debug.DrawLine(this.hitPosition + Vector3.right * d, this.hitPosition - Vector3.right * d, Color.green, Time.deltaTime);
				Debug.DrawLine(this.hitPosition + Vector3.forward * d, this.hitPosition - Vector3.forward * d, Color.green, Time.deltaTime);
			}
		}

		// Token: 0x06000D8F RID: 3471 RVA: 0x0005EE69 File Offset: 0x0005D069
		public bool HasDetectedHit()
		{
			return this.hasDetectedHit;
		}

		// Token: 0x06000D90 RID: 3472 RVA: 0x0005EE71 File Offset: 0x0005D071
		public float GetDistance()
		{
			return this.hitDistance;
		}

		// Token: 0x06000D91 RID: 3473 RVA: 0x0005EE79 File Offset: 0x0005D079
		public Vector3 GetNormal()
		{
			return this.hitNormal;
		}

		// Token: 0x06000D92 RID: 3474 RVA: 0x0005EE81 File Offset: 0x0005D081
		public Vector3 GetPosition()
		{
			return this.hitPosition;
		}

		// Token: 0x06000D93 RID: 3475 RVA: 0x0005EE89 File Offset: 0x0005D089
		public Collider GetCollider()
		{
			return this.hitColliders[0];
		}

		// Token: 0x06000D94 RID: 3476 RVA: 0x0005EE97 File Offset: 0x0005D097
		public Transform GetTransform()
		{
			return this.hitTransforms[0];
		}

		// Token: 0x06000D95 RID: 3477 RVA: 0x0005EEA5 File Offset: 0x0005D0A5
		public void SetCastOrigin(Vector3 _origin)
		{
			if (this.tr == null)
			{
				return;
			}
			this.origin = this.tr.InverseTransformPoint(_origin);
		}

		// Token: 0x06000D96 RID: 3478 RVA: 0x0005EEC8 File Offset: 0x0005D0C8
		public void SetCastDirection(Sensor.CastDirection _direction)
		{
			if (this.tr == null)
			{
				return;
			}
			this.castDirection = _direction;
		}

		// Token: 0x06000D97 RID: 3479 RVA: 0x0005EEE0 File Offset: 0x0005D0E0
		public void RecalibrateRaycastArrayPositions()
		{
			this.raycastArrayStartPositions = Sensor.GetRaycastStartPositions(this.ArrayRows, this.arrayRayCount, this.offsetArrayRows, this.sphereCastRadius);
		}

		// Token: 0x04001493 RID: 5267
		public float castLength = 1f;

		// Token: 0x04001494 RID: 5268
		public float sphereCastRadius = 0.2f;

		// Token: 0x04001495 RID: 5269
		private Vector3 origin = Vector3.zero;

		// Token: 0x04001496 RID: 5270
		private Sensor.CastDirection castDirection;

		// Token: 0x04001497 RID: 5271
		private bool hasDetectedHit;

		// Token: 0x04001498 RID: 5272
		private Vector3 hitPosition;

		// Token: 0x04001499 RID: 5273
		private Vector3 hitNormal;

		// Token: 0x0400149A RID: 5274
		private float hitDistance;

		// Token: 0x0400149B RID: 5275
		private List<Collider> hitColliders = new List<Collider>();

		// Token: 0x0400149C RID: 5276
		private List<Transform> hitTransforms = new List<Transform>();

		// Token: 0x0400149D RID: 5277
		private Vector3 backupNormal;

		// Token: 0x0400149E RID: 5278
		private Transform tr;

		// Token: 0x0400149F RID: 5279
		private Collider col;

		// Token: 0x040014A0 RID: 5280
		public Sensor.CastType castType;

		// Token: 0x040014A1 RID: 5281
		public LayerMask layermask = 255;

		// Token: 0x040014A2 RID: 5282
		private int ignoreRaycastLayer;

		// Token: 0x040014A3 RID: 5283
		public bool calculateRealSurfaceNormal;

		// Token: 0x040014A4 RID: 5284
		public bool calculateRealDistance;

		// Token: 0x040014A5 RID: 5285
		public int arrayRayCount = 9;

		// Token: 0x040014A6 RID: 5286
		public int ArrayRows = 3;

		// Token: 0x040014A7 RID: 5287
		public bool offsetArrayRows;

		// Token: 0x040014A8 RID: 5288
		private Vector3[] raycastArrayStartPositions;

		// Token: 0x040014A9 RID: 5289
		private Collider[] ignoreList;

		// Token: 0x040014AA RID: 5290
		private int[] ignoreListLayers;

		// Token: 0x040014AB RID: 5291
		public bool isInDebugMode;

		// Token: 0x040014AC RID: 5292
		private List<Vector3> arrayNormals = new List<Vector3>();

		// Token: 0x040014AD RID: 5293
		private List<Vector3> arrayPoints = new List<Vector3>();

		// Token: 0x02000282 RID: 642
		public enum CastDirection
		{
			// Token: 0x040016D0 RID: 5840
			Forward,
			// Token: 0x040016D1 RID: 5841
			Right,
			// Token: 0x040016D2 RID: 5842
			Up,
			// Token: 0x040016D3 RID: 5843
			Backward,
			// Token: 0x040016D4 RID: 5844
			Left,
			// Token: 0x040016D5 RID: 5845
			Down
		}

		// Token: 0x02000283 RID: 643
		[SerializeField]
		public enum CastType
		{
			// Token: 0x040016D7 RID: 5847
			Raycast,
			// Token: 0x040016D8 RID: 5848
			RaycastArray,
			// Token: 0x040016D9 RID: 5849
			Spherecast
		}
	}
}
