﻿using System;

// Token: 0x020000AB RID: 171
public class CEventPlayer_PlayerQuiting : CEvent
{
}
