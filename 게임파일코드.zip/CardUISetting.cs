﻿using System;
using UnityEngine;

// Token: 0x0200002F RID: 47
[Serializable]
public class CardUISetting
{
	// Token: 0x040002DF RID: 735
	public ECardExpansionType expansionType;

	// Token: 0x040002E0 RID: 736
	public bool openPackCanUseRarity;

	// Token: 0x040002E1 RID: 737
	public bool openPackCanHaveDuplicate;

	// Token: 0x040002E2 RID: 738
	public bool showName;

	// Token: 0x040002E3 RID: 739
	public bool showNameFullArt;

	// Token: 0x040002E4 RID: 740
	public bool showNumber;

	// Token: 0x040002E5 RID: 741
	public bool showRarity;

	// Token: 0x040002E6 RID: 742
	public bool showEdition;

	// Token: 0x040002E7 RID: 743
	public bool showStat1;

	// Token: 0x040002E8 RID: 744
	public bool showStat2;

	// Token: 0x040002E9 RID: 745
	public bool showStat3;

	// Token: 0x040002EA RID: 746
	public bool showStat4;

	// Token: 0x040002EB RID: 747
	public bool fullArtShowStat1;

	// Token: 0x040002EC RID: 748
	public Vector3 namePosOffset;

	// Token: 0x040002ED RID: 749
	public Vector3 numberPosOffset;

	// Token: 0x040002EE RID: 750
	public Vector3 editionPosOffset;

	// Token: 0x040002EF RID: 751
	public Vector3 famePosOffset;

	// Token: 0x040002F0 RID: 752
	public Vector3 fameScaleOffset;

	// Token: 0x040002F1 RID: 753
	public Vector3 monsterImagePosOffset;

	// Token: 0x040002F2 RID: 754
	public Vector3 monsterImageScaleOffset;

	// Token: 0x040002F3 RID: 755
	public Vector3 artworkImagePosOffset;

	// Token: 0x040002F4 RID: 756
	public Vector3 stat1PosOffset;

	// Token: 0x040002F5 RID: 757
	public Vector3 stat1ScaleOffset;

	// Token: 0x040002F6 RID: 758
	public Vector3 fullArtMonsterImagePosOffset;

	// Token: 0x040002F7 RID: 759
	public Vector3 fullArtMonsterImageScaleOffset;

	// Token: 0x040002F8 RID: 760
	public Vector3 fullArtArtworkImagePosOffset;

	// Token: 0x040002F9 RID: 761
	public Vector3 fullArtNamePosOffset;

	// Token: 0x040002FA RID: 762
	public Vector3 fullArtFamePosOffset;

	// Token: 0x040002FB RID: 763
	public Vector3 fullArtFameScaleOffset;

	// Token: 0x040002FC RID: 764
	public Vector3 fullArtBGMaskScaleOffset;
}
