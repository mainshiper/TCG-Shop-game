﻿using System;
using UnityEngine;

// Token: 0x02000003 RID: 3
public class PlayCard : MonoBehaviour
{
	// Token: 0x06000004 RID: 4 RVA: 0x0000212B File Offset: 0x0000032B
	public void Init()
	{
		base.gameObject.SetActive(false);
	}

	// Token: 0x06000005 RID: 5 RVA: 0x00002139 File Offset: 0x00000339
	public void ParentCardGrpToObj(Transform inputTransform)
	{
		this.m_CardGrp.transform.position = inputTransform.position;
		this.m_CardGrp.transform.rotation = inputTransform.rotation;
		this.m_CardGrp.transform.parent = inputTransform;
	}

	// Token: 0x06000006 RID: 6 RVA: 0x00002178 File Offset: 0x00000378
	public void SetDeckToPosition(Transform inputTransform)
	{
		this.m_Deck.transform.position = inputTransform.position;
		this.m_Deck.transform.rotation = inputTransform.rotation;
	}

	// Token: 0x06000007 RID: 7 RVA: 0x000021A6 File Offset: 0x000003A6
	public void EndPlay()
	{
		base.gameObject.SetActive(false);
		this.m_CardGrp.transform.parent = this.m_ParentRoot.transform;
	}

	// Token: 0x04000004 RID: 4
	public GameObject m_Deck;

	// Token: 0x04000005 RID: 5
	public GameObject m_CardGrp;

	// Token: 0x04000006 RID: 6
	public GameObject m_ParentRoot;
}
