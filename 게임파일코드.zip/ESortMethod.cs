﻿using System;

// Token: 0x020000F3 RID: 243
public enum ESortMethod
{
	// Token: 0x04000D7D RID: 3453
	None,
	// Token: 0x04000D7E RID: 3454
	HP_Ascending,
	// Token: 0x04000D7F RID: 3455
	HP_Descending,
	// Token: 0x04000D80 RID: 3456
	Atk_Ascending,
	// Token: 0x04000D81 RID: 3457
	Atk_Descending,
	// Token: 0x04000D82 RID: 3458
	Energy_Ascending,
	// Token: 0x04000D83 RID: 3459
	Energy_Descending,
	// Token: 0x04000D84 RID: 3460
	Level_Ascending,
	// Token: 0x04000D85 RID: 3461
	Level_Descending,
	// Token: 0x04000D86 RID: 3462
	Index_Ascending,
	// Token: 0x04000D87 RID: 3463
	Index_Descending,
	// Token: 0x04000D88 RID: 3464
	Stars_Ascending,
	// Token: 0x04000D89 RID: 3465
	Stars_Descending
}
