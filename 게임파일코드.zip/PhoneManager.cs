﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x0200003E RID: 62
public class PhoneManager : CSingleton<PhoneManager>
{
	// Token: 0x06000308 RID: 776 RVA: 0x0001CA63 File Offset: 0x0001AC63
	private void Awake()
	{
	}

	// Token: 0x06000309 RID: 777 RVA: 0x0001CA68 File Offset: 0x0001AC68
	private void Update()
	{
		if (this.m_IsPhoneMode)
		{
			this.m_Timer = Mathf.Clamp(this.m_Timer + Time.deltaTime * this.m_LerpSpeed, 0f, 1f);
		}
		else
		{
			this.m_Timer = Mathf.Clamp(this.m_Timer - Time.deltaTime * this.m_LerpSpeed, 0f, 1f);
		}
		this.m_PhoneGrp.transform.position = Vector3.Lerp(this.m_StartPos.position, this.m_EndPos.position, this.m_Timer);
	}

	// Token: 0x0600030A RID: 778 RVA: 0x0001CB00 File Offset: 0x0001AD00
	public static void EnterPhoneMode()
	{
		SoundManager.PlayAudio("SFX_Throw", 0.1f, 1f);
		CSingleton<InteractionPlayerController>.Instance.OnEnterPhoneScreenMode();
		CSingleton<PhoneManager>.Instance.m_IsPhoneMode = true;
		CSingleton<PhoneManager>.Instance.m_UI_PhoneScreen.OpenScreen();
		UnityAnalytic.OpenPhone();
	}

	// Token: 0x0600030B RID: 779 RVA: 0x0001CB40 File Offset: 0x0001AD40
	public static void ExitPhoneMode()
	{
		if (PhoneManager.CanClosePhone())
		{
			SoundManager.PlayAudio("SFX_Throw", 0.1f, 0.8f);
			CSingleton<InteractionPlayerController>.Instance.OnExitPhoneScreenMode();
			CSingleton<PhoneManager>.Instance.m_IsPhoneMode = false;
		}
		CSingleton<PhoneManager>.Instance.m_UI_PhoneScreen.OnPressBack();
	}

	// Token: 0x0600030C RID: 780 RVA: 0x0001CB8C File Offset: 0x0001AD8C
	public static void SetCanClosePhone(bool canClose)
	{
		if (canClose)
		{
			InteractionPlayerController.RemoveToolTip(EGameAction.ClosePhone);
			InteractionPlayerController.AddToolTip(EGameAction.ClosePhone, false, false);
		}
		else
		{
			InteractionPlayerController.RemoveToolTip(EGameAction.ClosePhone);
		}
		CSingleton<PhoneManager>.Instance.m_CanClosePhone = canClose;
	}

	// Token: 0x0600030D RID: 781 RVA: 0x0001CBB5 File Offset: 0x0001ADB5
	public static bool CanClosePhone()
	{
		return CSingleton<PhoneManager>.Instance.m_CanClosePhone && !CSingleton<PhoneManager>.Instance.m_IsOpeningPhone;
	}

	// Token: 0x0600030E RID: 782 RVA: 0x0001CBD2 File Offset: 0x0001ADD2
	public IEnumerator DelayOpenManageEventScreen()
	{
		this.m_IsOpeningPhone = true;
		PhoneManager.EnterPhoneMode();
		yield return new WaitForSeconds(0.1f);
		this.m_UI_PhoneScreen.OnPressManageEventBtn();
		this.m_IsOpeningPhone = false;
		yield break;
	}

	// Token: 0x0600030F RID: 783 RVA: 0x0001CBE1 File Offset: 0x0001ADE1
	public void SetBillNotificationVisible(bool isVisible)
	{
		this.m_UI_PhoneScreen.SetBillNotificationVisible(isVisible);
	}

	// Token: 0x06000310 RID: 784 RVA: 0x0001CBF0 File Offset: 0x0001ADF0
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.AddListener<CEventPlayer_FinishHideLoadingScreen>(new CEventManager.EventDelegate<CEventPlayer_FinishHideLoadingScreen>(this.OnFinishHideLoadingScreen));
			CEventManager.AddListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.AddListener<CEventPlayer_OnDayEnded>(new CEventManager.EventDelegate<CEventPlayer_OnDayEnded>(this.OnDayEnded));
		}
	}

	// Token: 0x06000311 RID: 785 RVA: 0x0001CC54 File Offset: 0x0001AE54
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.RemoveListener<CEventPlayer_FinishHideLoadingScreen>(new CEventManager.EventDelegate<CEventPlayer_FinishHideLoadingScreen>(this.OnFinishHideLoadingScreen));
			CEventManager.RemoveListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.RemoveListener<CEventPlayer_OnDayEnded>(new CEventManager.EventDelegate<CEventPlayer_OnDayEnded>(this.OnDayEnded));
		}
	}

	// Token: 0x06000312 RID: 786 RVA: 0x0001CCB5 File Offset: 0x0001AEB5
	protected virtual void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.m_RentBillScreen.OnGameFinishLoaded();
	}

	// Token: 0x06000313 RID: 787 RVA: 0x0001CCC2 File Offset: 0x0001AEC2
	protected virtual void OnFinishHideLoadingScreen(CEventPlayer_FinishHideLoadingScreen evt)
	{
	}

	// Token: 0x06000314 RID: 788 RVA: 0x0001CCC4 File Offset: 0x0001AEC4
	protected void OnDayStarted(CEventPlayer_OnDayStarted evt)
	{
		if (CPlayerData.m_CurrentDay > 0)
		{
			this.m_RentBillScreen.EvaluateNewDayBill();
		}
	}

	// Token: 0x06000315 RID: 789 RVA: 0x0001CCD9 File Offset: 0x0001AED9
	protected void OnDayEnded(CEventPlayer_OnDayEnded evt)
	{
	}

	// Token: 0x040003B9 RID: 953
	public static PhoneManager m_Instance;

	// Token: 0x040003BA RID: 954
	public Transform m_PhoneGrp;

	// Token: 0x040003BB RID: 955
	public Transform m_StartPos;

	// Token: 0x040003BC RID: 956
	public Transform m_EndPos;

	// Token: 0x040003BD RID: 957
	public UI_PhoneScreen m_UI_PhoneScreen;

	// Token: 0x040003BE RID: 958
	public RestockItemScreen m_RestockItemScreen;

	// Token: 0x040003BF RID: 959
	public RestockItemBoardGameScreen m_RestockItemBoardGameScreen;

	// Token: 0x040003C0 RID: 960
	public FurnitureShopUIScreen m_FurnitureShopUIScreen;

	// Token: 0x040003C1 RID: 961
	public ExpansionShopUIScreen m_ExpandShopUIScreen;

	// Token: 0x040003C2 RID: 962
	public SetGameEventScreen m_SetGameEventUIScreen;

	// Token: 0x040003C3 RID: 963
	public CheckPriceScreen m_CheckPriceScreen;

	// Token: 0x040003C4 RID: 964
	public HireWorkerScreen m_HireWorkerScreen;

	// Token: 0x040003C5 RID: 965
	public RentBillScreen m_RentBillScreen;

	// Token: 0x040003C6 RID: 966
	private bool m_IsPhoneMode;

	// Token: 0x040003C7 RID: 967
	private bool m_IsOpeningPhone;

	// Token: 0x040003C8 RID: 968
	private bool m_CanClosePhone = true;

	// Token: 0x040003C9 RID: 969
	private float m_Timer;

	// Token: 0x040003CA RID: 970
	private float m_LerpSpeed = 3f;
}
