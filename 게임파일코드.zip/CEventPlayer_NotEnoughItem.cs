﻿using System;

// Token: 0x020000B7 RID: 183
public class CEventPlayer_NotEnoughItem : CEvent
{
	// Token: 0x17000019 RID: 25
	// (get) Token: 0x0600071C RID: 1820 RVA: 0x000393EB File Offset: 0x000375EB
	// (set) Token: 0x0600071D RID: 1821 RVA: 0x000393F3 File Offset: 0x000375F3
	public EItemType m_ItemType { get; private set; }

	// Token: 0x0600071E RID: 1822 RVA: 0x000393FC File Offset: 0x000375FC
	public CEventPlayer_NotEnoughItem(EItemType itemType)
	{
		this.m_ItemType = itemType;
	}
}
