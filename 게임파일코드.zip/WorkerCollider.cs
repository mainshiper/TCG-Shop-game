﻿using System;
using UnityEngine;

// Token: 0x02000092 RID: 146
public class WorkerCollider : MonoBehaviour
{
	// Token: 0x060005CD RID: 1485 RVA: 0x000316E8 File Offset: 0x0002F8E8
	public void OnRaycasted()
	{
		this.m_Worker.OnRaycasted();
	}

	// Token: 0x060005CE RID: 1486 RVA: 0x000316F5 File Offset: 0x0002F8F5
	public void OnRaycastEnded()
	{
		this.m_Worker.OnRaycastEnded();
	}

	// Token: 0x060005CF RID: 1487 RVA: 0x00031702 File Offset: 0x0002F902
	public void OnMousePress()
	{
		this.m_Worker.OnMousePress();
	}

	// Token: 0x04000794 RID: 1940
	public Worker m_Worker;
}
