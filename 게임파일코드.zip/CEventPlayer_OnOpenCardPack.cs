﻿using System;

// Token: 0x020000D1 RID: 209
public class CEventPlayer_OnOpenCardPack : CEvent
{
	// Token: 0x1700002C RID: 44
	// (get) Token: 0x0600075C RID: 1884 RVA: 0x00039683 File Offset: 0x00037883
	// (set) Token: 0x0600075D RID: 1885 RVA: 0x0003968B File Offset: 0x0003788B
	public int m_PackIndex { get; private set; }

	// Token: 0x1700002D RID: 45
	// (get) Token: 0x0600075E RID: 1886 RVA: 0x00039694 File Offset: 0x00037894
	// (set) Token: 0x0600075F RID: 1887 RVA: 0x0003969C File Offset: 0x0003789C
	public int m_Amount { get; private set; }

	// Token: 0x06000760 RID: 1888 RVA: 0x000396A5 File Offset: 0x000378A5
	public CEventPlayer_OnOpenCardPack(int packIndex, int amount)
	{
		this.m_PackIndex = packIndex;
		this.m_Amount = amount;
	}
}
