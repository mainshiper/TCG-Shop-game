﻿using System;

// Token: 0x02000100 RID: 256
public enum ESpecialNPCType
{
	// Token: 0x04000EB8 RID: 3768
	None = -1,
	// Token: 0x04000EB9 RID: 3769
	LoanItem,
	// Token: 0x04000EBA RID: 3770
	CustomerTradeCard
}
