﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000113 RID: 275
public class InputTooltipUI : MonoBehaviour
{
	// Token: 0x0600081B RID: 2075 RVA: 0x0003D23F File Offset: 0x0003B43F
	public void SetActive(bool isActive)
	{
		this.m_IsActive = isActive;
		base.gameObject.SetActive(isActive);
	}

	// Token: 0x0600081C RID: 2076 RVA: 0x0003D254 File Offset: 0x0003B454
	public void SetGamepadInputTooltip(EGameAction gameAction, EGamepadControlBtn gamepadControlBtn, string actionName, bool isHold)
	{
		this.m_CurrentGameAction = gameAction;
		this.m_ActionText.text = actionName;
		this.m_GamepadControlBtn = gamepadControlBtn;
		this.m_IsHold = isHold;
		this.m_KeycodeText.text = "";
		if (CSingleton<InputManager>.Instance.m_IsPSController)
		{
			this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_PSCtrlBtnSpriteList[(int)this.m_GamepadControlBtn];
			return;
		}
		this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_XBoxCtrlBtnSpriteList[(int)this.m_GamepadControlBtn];
	}

	// Token: 0x0600081D RID: 2077 RVA: 0x0003D2F0 File Offset: 0x0003B4F0
	public void SetInputTooltip(EGameAction gameAction, KeyCode keycode, string actionName, bool isHold)
	{
		this.m_CurrentGameAction = gameAction;
		this.m_KeycodeText.text = keycode.ToString();
		this.m_ActionText.text = actionName;
		this.m_KeyCode = keycode;
		this.m_ActionName = actionName;
		this.m_IsHold = isHold;
		if (keycode == KeyCode.Mouse0)
		{
			this.m_KeycodeText.text = "";
			if (isHold)
			{
				this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_LeftMouseHoldImage;
				return;
			}
			this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_LeftMouseClickImage;
			return;
		}
		else if (keycode == KeyCode.Mouse1)
		{
			this.m_KeycodeText.text = "";
			if (isHold)
			{
				this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_RightMouseHoldImage;
				return;
			}
			this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_RightMouseClickImage;
			return;
		}
		else
		{
			if (keycode == KeyCode.Mouse2)
			{
				this.m_ActionText.text = this.m_ActionText.text;
				this.m_KeycodeText.text = "";
				this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_MiddleMouseScrollImage;
				return;
			}
			if (keycode == KeyCode.Return)
			{
				this.m_KeycodeText.text = "";
				this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_EnterImage;
				return;
			}
			if (keycode == KeyCode.Space)
			{
				this.m_KeycodeText.text = "";
				this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_SpacebarImage;
				return;
			}
			if (keycode == KeyCode.Tab)
			{
				this.m_KeycodeText.text = "";
				this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_TabImage;
				return;
			}
			if (keycode == KeyCode.LeftShift || keycode == KeyCode.RightShift)
			{
				this.m_KeycodeText.text = "";
				this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_ShiftImage;
				return;
			}
			if (keycode == KeyCode.Escape)
			{
				this.m_KeycodeText.text = "Esc";
			}
			else if (keycode == KeyCode.Backspace)
			{
				this.m_KeycodeText.text = "BSpace";
			}
			this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_KeyboardBtnImage;
			return;
		}
	}

	// Token: 0x04000F65 RID: 3941
	public Image m_KeyImage;

	// Token: 0x04000F66 RID: 3942
	public TextMeshProUGUI m_KeycodeText;

	// Token: 0x04000F67 RID: 3943
	public TextMeshProUGUI m_ActionText;

	// Token: 0x04000F68 RID: 3944
	public bool m_IsActive;

	// Token: 0x04000F69 RID: 3945
	public Transform m_Transform;

	// Token: 0x04000F6A RID: 3946
	public EGameAction m_CurrentGameAction;

	// Token: 0x04000F6B RID: 3947
	private bool m_IsHold;

	// Token: 0x04000F6C RID: 3948
	private KeyCode m_KeyCode;

	// Token: 0x04000F6D RID: 3949
	private EGamepadControlBtn m_GamepadControlBtn = EGamepadControlBtn.Start;

	// Token: 0x04000F6E RID: 3950
	private string m_ActionName = "";
}
