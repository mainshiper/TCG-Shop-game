﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200011D RID: 285
public class CRaycastTouch : MonoBehaviour
{
	// Token: 0x0600085E RID: 2142 RVA: 0x0003F620 File Offset: 0x0003D820
	private void Update()
	{
		if (this.m_MouseDown && Input.GetMouseButtonUp(0))
		{
			this.m_MouseDownTime = 0f;
			this.m_MouseDown = false;
			this.m_FirstRayCast = false;
			Vector3 vector = Input.mousePosition - this.m_MouseStartPos;
			CEventManager.QueueEvent(new CEventPlayer_TouchReleased(new Vector3(vector.x / (float)Screen.width, vector.y / (float)Screen.height, 0f)));
		}
		if (this.m_MouseDown)
		{
			if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
			{
				foreach (Touch touch in Input.touches)
				{
					if (touch.fingerId == 0 && (touch.phase == 1 || touch.phase == null))
					{
						this.EvaluateRaycast(touch.position);
						this.m_MouseCurrentPos = touch.position;
					}
				}
				return;
			}
			this.EvaluateRaycast(Input.mousePosition);
			this.m_MouseCurrentPos = Input.mousePosition;
		}
	}

	// Token: 0x0600085F RID: 2143 RVA: 0x0003F724 File Offset: 0x0003D924
	private Vector3 CalculateMouseSpeed()
	{
		Vector3 result = Vector3.zero;
		if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
		{
			foreach (Touch touch in Input.touches)
			{
				if (touch.fingerId == 0)
				{
					Vector3 b = new Vector3(touch.position.x, touch.position.y, 0f);
					result = this.m_MouseCurrentPos - b;
				}
			}
		}
		else
		{
			result = this.m_MouseCurrentPos - Input.mousePosition;
		}
		return result;
	}

	// Token: 0x06000860 RID: 2144 RVA: 0x0003F7B4 File Offset: 0x0003D9B4
	private void EvaluateRaycast(Vector2 InputPosition)
	{
		if (!this.m_FirstRayCast)
		{
			this.m_FirstRayCast = true;
			this.ray = Camera.main.ScreenPointToRay(InputPosition);
			if (Physics.Raycast(this.ray, ref this.hit))
			{
				if (this.hit.transform.root.tag == "Prop")
				{
					this.m_ObjectRootHit = this.hit.transform.root;
					this.TouchedProp(this.m_ObjectRootHit);
				}
				else if (this.hit.transform.tag == "CatFollow")
				{
					this.m_ObjectRootHit = this.hit.transform;
					this.TouchedProp(this.m_ObjectRootHit);
				}
				else if (this.hit.transform.tag == "Coin")
				{
					this.TouchedProp(this.hit.transform);
				}
			}
		}
		RaycastHit raycastHit;
		if (Physics.Raycast(Camera.main.ScreenPointToRay(InputPosition), ref raycastHit) && raycastHit.transform.tag == "Coin")
		{
			this.TouchedProp(raycastHit.transform);
		}
	}

	// Token: 0x06000861 RID: 2145 RVA: 0x0003F8EA File Offset: 0x0003DAEA
	private void TouchedProp(Transform objectHitRoot)
	{
		objectHitRoot.SendMessage("RaycastHit");
	}

	// Token: 0x06000862 RID: 2146 RVA: 0x0003F8F8 File Offset: 0x0003DAF8
	private bool IsMouseMove()
	{
		if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
		{
			Vector3 vector = default(Vector3);
			foreach (Touch touch in Input.touches)
			{
				if (touch.fingerId == 0 && touch.phase == 1)
				{
					vector = touch.position - this.m_LastMouseCoordinate;
					this.m_LastMouseCoordinate = touch.position;
				}
				else if (touch.fingerId == 1 && touch.phase == 1)
				{
					vector = touch.position - this.m_LastMouseCoordinate;
					this.m_LastMouseCoordinate = touch.position;
				}
			}
			if (vector.x < 0f || vector.x > 0f)
			{
				return true;
			}
		}
		else
		{
			Vector3 vector2 = Input.mousePosition - this.m_LastMouseCoordinate;
			this.m_LastMouseCoordinate = Input.mousePosition;
			if (vector2.x < 0f || vector2.x > 0f)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000863 RID: 2147 RVA: 0x0003FA18 File Offset: 0x0003DC18
	public void TouchScreenButton()
	{
		if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
		{
			if (Input.touchCount == 1)
			{
				this.m_MouseDown = true;
				this.m_ObjectRootHit = null;
				CEventManager.QueueEvent(new CEventPlayer_TouchScreen());
				this.m_MouseStartPos = Input.mousePosition;
				return;
			}
		}
		else
		{
			this.m_MouseDown = true;
			this.m_ObjectRootHit = null;
			CEventManager.QueueEvent(new CEventPlayer_TouchScreen());
			this.m_MouseStartPos = Input.mousePosition;
		}
	}

	// Token: 0x04001031 RID: 4145
	private RaycastHit hit;

	// Token: 0x04001032 RID: 4146
	private Ray ray;

	// Token: 0x04001033 RID: 4147
	private bool m_MouseDown;

	// Token: 0x04001034 RID: 4148
	private bool m_FirstRayCast;

	// Token: 0x04001035 RID: 4149
	private Vector3 m_MouseStartPos;

	// Token: 0x04001036 RID: 4150
	private Vector3 m_MouseCurrentPos;

	// Token: 0x04001037 RID: 4151
	private Vector3 m_LastMouseCoordinate = Vector3.zero;

	// Token: 0x04001038 RID: 4152
	private Transform m_ObjectRootHit;

	// Token: 0x04001039 RID: 4153
	private float m_MouseDownTime;

	// Token: 0x0400103A RID: 4154
	public Text m_Text;
}
