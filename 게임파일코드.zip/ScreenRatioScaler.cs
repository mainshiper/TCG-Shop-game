﻿using System;
using UnityEngine;

// Token: 0x02000109 RID: 265
public class ScreenRatioScaler : MonoBehaviour
{
	// Token: 0x060007C7 RID: 1991 RVA: 0x0003ADD3 File Offset: 0x00038FD3
	private void Awake()
	{
		this.Init();
	}

	// Token: 0x060007C8 RID: 1992 RVA: 0x0003ADDC File Offset: 0x00038FDC
	private void Init()
	{
		if (!this.m_HasInit)
		{
			this.m_HasInit = true;
			this.m_OriginalScale = this.m_Transform.localScale.x;
		}
		this.m_IsSteamDeckResolution = ((Screen.width < 1281 && Screen.height < 901) || CSingleton<InputManager>.Instance.m_IsSteamDeck);
	}

	// Token: 0x060007C9 RID: 1993 RVA: 0x0003AE3C File Offset: 0x0003903C
	private void Start()
	{
		this.Init();
		if (this.m_InitOnStart)
		{
			if (this.m_SteamDeckBigScaling)
			{
				if (this.m_IsSteamDeckResolution)
				{
					this.m_Transform.localScale = Vector3.one * this.m_SteamDeckScale;
				}
				return;
			}
			float num = (float)Screen.width / (float)Screen.height;
			if (num < 1.61f)
			{
				float d = Mathf.Lerp(this.m_MinScale, this.m_MaxScale, num / 1.6f);
				if (this.m_UseMaxScaleOnly)
				{
					d = this.m_MaxScale;
				}
				this.m_Transform.localScale = Vector3.one * d;
			}
		}
	}

	// Token: 0x060007CA RID: 1994 RVA: 0x0003AEDC File Offset: 0x000390DC
	private void OnEnable()
	{
		this.Init();
		if (this.m_SteamDeckBigScaling)
		{
			if (this.m_IsSteamDeckResolution)
			{
				this.m_Transform.localScale = Vector3.one * this.m_SteamDeckScale;
			}
			return;
		}
		float num = (float)Screen.width / (float)Screen.height;
		if (num < 1.61f)
		{
			float d = Mathf.Lerp(this.m_MinScale, this.m_MaxScale, num / 1.6f);
			if (this.m_UseMaxScaleOnly)
			{
				d = this.m_MaxScale;
			}
			this.m_Transform.localScale = Vector3.one * d;
			return;
		}
		this.m_Transform.localScale = Vector3.one * this.m_OriginalScale;
	}

	// Token: 0x04000F10 RID: 3856
	public Transform m_Transform;

	// Token: 0x04000F11 RID: 3857
	public float m_MinScale = 0.3f;

	// Token: 0x04000F12 RID: 3858
	public float m_MaxScale = 0.925f;

	// Token: 0x04000F13 RID: 3859
	public bool m_InitOnStart;

	// Token: 0x04000F14 RID: 3860
	public bool m_UseMaxScaleOnly = true;

	// Token: 0x04000F15 RID: 3861
	public bool m_SteamDeckBigScaling;

	// Token: 0x04000F16 RID: 3862
	private bool m_IsSteamDeckResolution;

	// Token: 0x04000F17 RID: 3863
	public float m_SteamDeckScale = 1.2f;

	// Token: 0x04000F18 RID: 3864
	private bool m_HasInit;

	// Token: 0x04000F19 RID: 3865
	private float m_OriginalScale = 1f;
}
