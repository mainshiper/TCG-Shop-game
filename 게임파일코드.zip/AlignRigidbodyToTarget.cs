﻿using System;
using UnityEngine;

// Token: 0x0200014C RID: 332
public class AlignRigidbodyToTarget : MonoBehaviour
{
	// Token: 0x06000965 RID: 2405 RVA: 0x00044F23 File Offset: 0x00043123
	private void Start()
	{
		this.tr = base.transform;
		this.r = base.GetComponent<Rigidbody>();
		if (this.target == null)
		{
			Debug.LogWarning("No target has been assigned.", this);
			base.enabled = false;
		}
	}

	// Token: 0x06000966 RID: 2406 RVA: 0x00044F60 File Offset: 0x00043160
	private void FixedUpdate()
	{
		Vector3 forward = this.tr.forward;
		Vector3 normalized = (this.tr.position - this.target.position).normalized;
		Quaternion quaternion = Quaternion.LookRotation(Quaternion.FromToRotation(this.tr.up, normalized) * forward, normalized);
		this.r.MoveRotation(quaternion);
	}

	// Token: 0x040011AC RID: 4524
	public Transform target;

	// Token: 0x040011AD RID: 4525
	private Transform tr;

	// Token: 0x040011AE RID: 4526
	private Rigidbody r;
}
