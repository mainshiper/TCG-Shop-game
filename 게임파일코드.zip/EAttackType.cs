﻿using System;

// Token: 0x020000F0 RID: 240
public enum EAttackType
{
	// Token: 0x04000D6B RID: 3435
	None,
	// Token: 0x04000D6C RID: 3436
	Special,
	// Token: 0x04000D6D RID: 3437
	Magic,
	// Token: 0x04000D6E RID: 3438
	Skill
}
