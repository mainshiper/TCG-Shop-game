﻿using System;

// Token: 0x020000F7 RID: 247
public enum ETagTeamMembership
{
	// Token: 0x04000DA5 RID: 3493
	None,
	// Token: 0x04000DA6 RID: 3494
	Creator,
	// Token: 0x04000DA7 RID: 3495
	Joiner,
	// Token: 0x04000DA8 RID: 3496
	PendingCreator,
	// Token: 0x04000DA9 RID: 3497
	PendingJoiner
}
