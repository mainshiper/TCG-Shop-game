﻿using System;

// Token: 0x020000E4 RID: 228
public enum ETutorialTaskCondition
{
	// Token: 0x04000ACD RID: 2765
	None,
	// Token: 0x04000ACE RID: 2766
	RestockItem,
	// Token: 0x04000ACF RID: 2767
	PickupBox,
	// Token: 0x04000AD0 RID: 2768
	PutItemOnShelf,
	// Token: 0x04000AD1 RID: 2769
	SetItemPrice,
	// Token: 0x04000AD2 RID: 2770
	OpenShop,
	// Token: 0x04000AD3 RID: 2771
	CheckoutCustomer,
	// Token: 0x04000AD4 RID: 2772
	ShopLevel,
	// Token: 0x04000AD5 RID: 2773
	OpenPack,
	// Token: 0x04000AD6 RID: 2774
	BuyPlayTable,
	// Token: 0x04000AD7 RID: 2775
	CustomerPlay,
	// Token: 0x04000AD8 RID: 2776
	BuyCardShelf,
	// Token: 0x04000AD9 RID: 2777
	PutCardOnShelf,
	// Token: 0x04000ADA RID: 2778
	SellCard,
	// Token: 0x04000ADB RID: 2779
	UnlockBasicCardBox,
	// Token: 0x04000ADC RID: 2780
	InteractCashierCounter
}
