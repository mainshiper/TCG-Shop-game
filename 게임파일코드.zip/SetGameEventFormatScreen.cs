﻿using System;
using I2.Loc;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200007F RID: 127
public class SetGameEventFormatScreen : UIScreenBase
{
	// Token: 0x06000500 RID: 1280 RVA: 0x0002B6D7 File Offset: 0x000298D7
	protected override void OnOpenScreen()
	{
		base.OnOpenScreen();
		this.m_CurrentFormatIndex = (int)CPlayerData.m_GameEventFormat;
		if (CPlayerData.m_PendingGameEventFormat != EGameEventFormat.None)
		{
			this.m_CurrentFormatIndex = (int)CPlayerData.m_PendingGameEventFormat;
		}
		this.EvaluateText((EGameEventFormat)this.m_CurrentFormatIndex);
	}

	// Token: 0x06000501 RID: 1281 RVA: 0x0002B709 File Offset: 0x00029909
	protected override void OnCloseScreen()
	{
		base.OnCloseScreen();
	}

	// Token: 0x06000502 RID: 1282 RVA: 0x0002B711 File Offset: 0x00029911
	public void OnPressConfirmBtn()
	{
		CPlayerData.m_PendingGameEventFormat = (EGameEventFormat)this.m_CurrentFormatIndex;
		SoundManager.GenericConfirm(1f, 1f);
		base.CloseScreen();
	}

	// Token: 0x06000503 RID: 1283 RVA: 0x0002B733 File Offset: 0x00029933
	public void OnPressCancelBtn()
	{
		SoundManager.GenericCancel(1f, 1f);
		base.CloseScreen();
	}

	// Token: 0x06000504 RID: 1284 RVA: 0x0002B74A File Offset: 0x0002994A
	public void OnPressNextEventSelect()
	{
		if (this.m_CurrentFormatIndex < 11)
		{
			SoundManager.GenericLightTap(1f, 1f);
			this.m_CurrentFormatIndex++;
			this.EvaluateText((EGameEventFormat)this.m_CurrentFormatIndex);
		}
	}

	// Token: 0x06000505 RID: 1285 RVA: 0x0002B77F File Offset: 0x0002997F
	public void OnPressPreviousEventSelect()
	{
		if (this.m_CurrentFormatIndex > 0)
		{
			SoundManager.GenericLightTap(1f, 1f);
			this.m_CurrentFormatIndex--;
			this.EvaluateText((EGameEventFormat)this.m_CurrentFormatIndex);
		}
	}

	// Token: 0x06000506 RID: 1286 RVA: 0x0002B7B4 File Offset: 0x000299B4
	private void EvaluateText(EGameEventFormat gameEventFormat)
	{
		GameEventData gameEventData = InventoryBase.GetGameEventData(gameEventFormat);
		this.m_IsFormatUnlocked = false;
		int customerPlayed = CPlayerData.m_GameReportDataCollectPermanent.customerPlayed;
		int unlockPlayCountRequired = gameEventData.unlockPlayCountRequired;
		if (customerPlayed >= unlockPlayCountRequired)
		{
			this.m_IsFormatUnlocked = true;
			this.m_LockedGrp.SetActive(false);
			this.m_ConfirmButton.interactable = true;
		}
		else
		{
			this.m_PlayCountRequired.text = customerPlayed.ToString() + "/" + unlockPlayCountRequired.ToString();
			this.m_LockedGrp.SetActive(true);
			this.m_ConfirmButton.interactable = false;
		}
		this.m_FormatText.text = gameEventData.GetName();
		this.m_CostText.text = string.Concat(new string[]
		{
			LocalizationManager.GetTranslation(this.m_CostPrefix, true, 0, true, false, null, null, true),
			" : ",
			GameInstance.GetPriceString((float)gameEventData.hostEventCost, false, true, false, "F2"),
			"/",
			LocalizationManager.GetTranslation(this.m_CostSuffix, true, 0, true, false, null, null, true)
		});
		this.m_FeeText.text = LocalizationManager.GetTranslation(this.m_FeePrefix, true, 0, true, false, null, null, true) + " : " + GameInstance.GetPriceString(PriceChangeManager.GetGameEventPrice(gameEventFormat, true), false, true, false, "F2") + LocalizationManager.GetTranslation(this.m_FeeSuffix, true, 0, true, false, null, null, true);
		this.m_PositiveEffectText.text = "(+) " + InventoryBase.GetPriceChangeTypeText(gameEventData.positivePriceChangeType, true);
		this.m_NegativeEffectText.text = "(-) " + InventoryBase.GetPriceChangeTypeText(gameEventData.negativePriceChangeType, false);
		this.m_NextButton.interactable = (this.m_CurrentFormatIndex < 11);
		this.m_PreviousButton.interactable = (this.m_CurrentFormatIndex > 0);
	}

	// Token: 0x04000695 RID: 1685
	public GameObject m_LockedGrp;

	// Token: 0x04000696 RID: 1686
	public Button m_ConfirmButton;

	// Token: 0x04000697 RID: 1687
	public Button m_PreviousButton;

	// Token: 0x04000698 RID: 1688
	public Button m_NextButton;

	// Token: 0x04000699 RID: 1689
	public TextMeshProUGUI m_PlayCountRequired;

	// Token: 0x0400069A RID: 1690
	public TextMeshProUGUI m_FeeText;

	// Token: 0x0400069B RID: 1691
	public TextMeshProUGUI m_FormatText;

	// Token: 0x0400069C RID: 1692
	public TextMeshProUGUI m_CostText;

	// Token: 0x0400069D RID: 1693
	public TextMeshProUGUI m_PositiveEffectText;

	// Token: 0x0400069E RID: 1694
	public TextMeshProUGUI m_NegativeEffectText;

	// Token: 0x0400069F RID: 1695
	private string m_FeePrefix = "Market Fee";

	// Token: 0x040006A0 RID: 1696
	private string m_FormatPrefix = "Format";

	// Token: 0x040006A1 RID: 1697
	private string m_CostPrefix = "Cost";

	// Token: 0x040006A2 RID: 1698
	private string m_FeeSuffix = "hr";

	// Token: 0x040006A3 RID: 1699
	private string m_CostSuffix = "day";

	// Token: 0x040006A4 RID: 1700
	private int m_CurrentFormatIndex;

	// Token: 0x040006A5 RID: 1701
	private bool m_IsFormatUnlocked;
}
