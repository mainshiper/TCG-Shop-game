﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000059 RID: 89
public class CardRaritySelectScreen : CSingleton<CardRaritySelectScreen>
{
	// Token: 0x06000402 RID: 1026 RVA: 0x00023F90 File Offset: 0x00022190
	public static void OpenScreen(ERarity initCardRarity)
	{
		CSingleton<CardRaritySelectScreen>.Instance.m_CurrentIndex = (int)(initCardRarity + 1);
		for (int i = 0; i < CSingleton<CardRaritySelectScreen>.Instance.m_BtnHighlightList.Count; i++)
		{
			CSingleton<CardRaritySelectScreen>.Instance.m_BtnHighlightList[i].SetActive(false);
		}
		CSingleton<CardRaritySelectScreen>.Instance.m_BtnHighlightList[CSingleton<CardRaritySelectScreen>.Instance.m_CurrentIndex].SetActive(true);
		SoundManager.GenericMenuOpen(1f, 1f);
		CSingleton<CardRaritySelectScreen>.Instance.m_ScreenGrp.SetActive(true);
		ControllerScreenUIExtManager.OnOpenScreen(CSingleton<CardRaritySelectScreen>.Instance.m_ControllerScreenUIExtension);
	}

	// Token: 0x06000403 RID: 1027 RVA: 0x00024027 File Offset: 0x00022227
	private void CloseScreen()
	{
		this.m_ScreenGrp.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<CardRaritySelectScreen>.Instance.m_ControllerScreenUIExtension);
	}

	// Token: 0x06000404 RID: 1028 RVA: 0x00024044 File Offset: 0x00022244
	public void OnPressButton(int index)
	{
		this.m_CurrentIndex = index + 1;
		CEventManager.QueueEvent(new CEventPlayer_OnCardRaritySelectScreenUpdated(index));
		this.CloseScreen();
		SoundManager.GenericConfirm(1f, 1f);
	}

	// Token: 0x06000405 RID: 1029 RVA: 0x0002406F File Offset: 0x0002226F
	public void OnPressBackButton()
	{
		CEventManager.QueueEvent(new CEventPlayer_OnCardRaritySelectScreenUpdated(this.m_CurrentIndex - 1));
		this.CloseScreen();
		SoundManager.GenericMenuClose(1f, 1f);
	}

	// Token: 0x040004D5 RID: 1237
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x040004D6 RID: 1238
	public GameObject m_ScreenGrp;

	// Token: 0x040004D7 RID: 1239
	public List<GameObject> m_BtnHighlightList;

	// Token: 0x040004D8 RID: 1240
	private int m_CurrentIndex;
}
