﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000138 RID: 312
public class SetRandomCard : MonoBehaviour
{
	// Token: 0x060008FD RID: 2301 RVA: 0x00042A69 File Offset: 0x00040C69
	private void Start()
	{
		this.EvaluateCard();
	}

	// Token: 0x060008FE RID: 2302 RVA: 0x00042A71 File Offset: 0x00040C71
	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.B))
		{
			this.EvaluateCard();
		}
	}

	// Token: 0x060008FF RID: 2303 RVA: 0x00042A84 File Offset: 0x00040C84
	private void EvaluateCard()
	{
		List<EMonsterType> shownMonsterList = InventoryBase.GetShownMonsterList(ECardExpansionType.Tetramon);
		for (int i = 0; i < this.m_CardList.Count; i++)
		{
			CardData cardData = new CardData();
			ECardBorderType borderType = ECardBorderType.Base;
			cardData.monsterType = shownMonsterList[Random.Range(0, shownMonsterList.Count)];
			cardData.borderType = borderType;
			cardData.expansionType = ECardExpansionType.Tetramon;
			cardData.isNew = false;
			this.m_CardList[i].m_CardUI.SetCardUI(cardData);
		}
	}

	// Token: 0x0400112A RID: 4394
	public List<Card3dUIGroup> m_CardList;
}
