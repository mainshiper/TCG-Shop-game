﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000074 RID: 116
public class RentBillScreen : UIScreenBase
{
	// Token: 0x060004B7 RID: 1207 RVA: 0x00029566 File Offset: 0x00027766
	public void OnGameFinishLoaded()
	{
		this.m_RentBillUI.Init(this, EBillType.Rent);
		this.m_ElectricBillUI.Init(this, EBillType.Electric);
		this.m_SalaryBillUI.Init(this, EBillType.Employee);
		this.EvaluateBillNotification();
	}

	// Token: 0x060004B8 RID: 1208 RVA: 0x00029598 File Offset: 0x00027798
	private void EvaluateBillNotification()
	{
		bool bill = CPlayerData.GetBill(EBillType.Rent) != null;
		BillData bill2 = CPlayerData.GetBill(EBillType.Electric);
		BillData bill3 = CPlayerData.GetBill(EBillType.Employee);
		if (bill && this.m_DueDayMax - CPlayerData.GetBill(EBillType.Rent).billDayPassed < 3)
		{
			CSingleton<PhoneManager>.Instance.SetBillNotificationVisible(true);
			return;
		}
		if (bill2 != null && this.m_DueDayMax - CPlayerData.GetBill(EBillType.Electric).billDayPassed < 3)
		{
			CSingleton<PhoneManager>.Instance.SetBillNotificationVisible(true);
			return;
		}
		if (bill3 != null && this.m_DueDayMax - CPlayerData.GetBill(EBillType.Employee).billDayPassed < 3)
		{
			CSingleton<PhoneManager>.Instance.SetBillNotificationVisible(true);
			return;
		}
		CSingleton<PhoneManager>.Instance.SetBillNotificationVisible(false);
	}

	// Token: 0x060004B9 RID: 1209 RVA: 0x00029630 File Offset: 0x00027830
	public void EvaluateNewDayBill()
	{
		bool bill = CPlayerData.GetBill(EBillType.Rent) != null;
		BillData bill2 = CPlayerData.GetBill(EBillType.Electric);
		BillData bill3 = CPlayerData.GetBill(EBillType.Employee);
		bool flag = false;
		if (bill && this.m_DueDayMax - CPlayerData.GetBill(EBillType.Rent).billDayPassed < -5)
		{
			this.OnPressPayRentBill(true);
			flag = true;
		}
		if (bill2 != null && this.m_DueDayMax - CPlayerData.GetBill(EBillType.Electric).billDayPassed < -5)
		{
			this.OnPressPayElectricBill(true);
			flag = true;
		}
		if (bill3 != null && this.m_DueDayMax - CPlayerData.GetBill(EBillType.Employee).billDayPassed < -5)
		{
			this.OnPressPaySalaryBill(true);
			flag = true;
		}
		if (flag)
		{
			SoundManager.PlayAudio("SFX_CustomerBuy", 0.6f, 1f);
		}
		float shopLightOnTime = LightManager.GetShopLightOnTime();
		int cashierCounterCount = ShelfManager.GetCashierCounterCount();
		int unlockRoomCount = CPlayerData.m_UnlockRoomCount;
		int num = CPlayerData.m_UnlockWarehouseRoomCount;
		bool isWarehouseRoomUnlocked = CPlayerData.m_IsWarehouseRoomUnlocked;
		float num2 = (float)(100 + unlockRoomCount * 20);
		num2 = 50f;
		for (int i = 0; i < unlockRoomCount; i++)
		{
			if (i < 4)
			{
				num2 += 20f;
			}
			else if (i >= 4 && i < 8)
			{
				num2 += 30f;
			}
			else if (i >= 8 && i < 12)
			{
				num2 += 40f;
			}
			else if (i >= 12 && i < 16)
			{
				num2 += 50f;
			}
			else
			{
				num2 += 60f;
			}
		}
		if (isWarehouseRoomUnlocked)
		{
			num2 += (float)(150 + num * 50);
		}
		float num3 = 1f;
		float num4 = 4f;
		if (isWarehouseRoomUnlocked)
		{
			num += 2;
		}
		float num5 = shopLightOnTime * (float)(unlockRoomCount + num) * (num3 / 60f) / 4f;
		float amountToPayChange = (float)cashierCounterCount * num4 + shopLightOnTime * (num3 / 60f) + num5;
		float totalSalaryCost = CSingleton<WorkerManager>.Instance.GetTotalSalaryCost();
		CPlayerData.UpdateBill(EBillType.Rent, 1, num2);
		CPlayerData.UpdateBill(EBillType.Electric, 1, amountToPayChange);
		CPlayerData.UpdateBill(EBillType.Employee, 1, totalSalaryCost);
		LightManager.ResetShopLightOnTime();
		this.EvaluateBillNotification();
	}

	// Token: 0x060004BA RID: 1210 RVA: 0x00029802 File Offset: 0x00027A02
	protected override void OnOpenScreen()
	{
		base.OnOpenScreen();
		this.EvaluateUI();
	}

	// Token: 0x060004BB RID: 1211 RVA: 0x00029810 File Offset: 0x00027A10
	private void EvaluateUI()
	{
		this.m_RentBillUI.EvaluateUI();
		this.m_ElectricBillUI.EvaluateUI();
		this.m_SalaryBillUI.EvaluateUI();
		BillData bill = CPlayerData.GetBill(EBillType.Rent);
		BillData bill2 = CPlayerData.GetBill(EBillType.Electric);
		BillData bill3 = CPlayerData.GetBill(EBillType.Employee);
		this.m_TotalAmountToPay = 0f;
		float num = 0f;
		float num2 = 0f;
		float num3 = 0f;
		if (bill != null && bill.amountToPay > 0f)
		{
			num = bill.amountToPay;
		}
		if (bill2 != null && bill2.amountToPay > 0f)
		{
			num2 = bill2.amountToPay;
		}
		if (bill3 != null && bill3.amountToPay > 0f)
		{
			num3 = bill3.amountToPay;
		}
		this.m_TotalAmountToPay = num + num2 + num3;
		if (this.m_TotalAmountToPay > 0f)
		{
			this.m_PayAllLockBtn.SetActive(false);
		}
		else
		{
			this.m_PayAllLockBtn.SetActive(true);
		}
		this.m_TotalAmountDueText.text = GameInstance.GetPriceString(this.m_TotalAmountToPay, false, true, false, "F2");
	}

	// Token: 0x060004BC RID: 1212 RVA: 0x0002990B File Offset: 0x00027B0B
	protected override void OnCloseScreen()
	{
		base.OnCloseScreen();
	}

	// Token: 0x060004BD RID: 1213 RVA: 0x00029914 File Offset: 0x00027B14
	public void OnPressPayRentBill(bool forcePay = false)
	{
		BillData bill = CPlayerData.GetBill(EBillType.Rent);
		if (bill != null && bill.amountToPay > 0f)
		{
			if (CPlayerData.m_CoinAmount >= bill.amountToPay || forcePay)
			{
				if (!forcePay)
				{
					SoundManager.PlayAudio("SFX_CustomerBuy", 0.6f, 1f);
				}
				CEventManager.QueueEvent(new CEventPlayer_ReduceCoin(bill.amountToPay, false));
				CPlayerData.m_GameReportDataCollect.rentCost = CPlayerData.m_GameReportDataCollect.rentCost - bill.amountToPay;
				CPlayerData.m_GameReportDataCollectPermanent.rentCost = CPlayerData.m_GameReportDataCollectPermanent.rentCost - bill.amountToPay;
				CPlayerData.SetBill(EBillType.Rent, 0, 0f);
				this.EvaluateUI();
				this.EvaluateBillNotification();
				return;
			}
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.Money);
			SoundManager.GenericCancel(1f, 1f);
		}
	}

	// Token: 0x060004BE RID: 1214 RVA: 0x000299D0 File Offset: 0x00027BD0
	public void OnPressPayElectricBill(bool forcePay = false)
	{
		BillData bill = CPlayerData.GetBill(EBillType.Electric);
		if (bill != null && bill.amountToPay > 0f)
		{
			if (CPlayerData.m_CoinAmount >= bill.amountToPay || forcePay)
			{
				if (!forcePay)
				{
					SoundManager.PlayAudio("SFX_CustomerBuy", 0.6f, 1f);
				}
				CEventManager.QueueEvent(new CEventPlayer_ReduceCoin(bill.amountToPay, false));
				CPlayerData.m_GameReportDataCollect.billCost = CPlayerData.m_GameReportDataCollect.billCost - bill.amountToPay;
				CPlayerData.m_GameReportDataCollectPermanent.billCost = CPlayerData.m_GameReportDataCollectPermanent.billCost - bill.amountToPay;
				CPlayerData.SetBill(EBillType.Electric, 0, 0f);
				this.EvaluateUI();
				this.EvaluateBillNotification();
				return;
			}
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.Money);
			SoundManager.GenericCancel(1f, 1f);
		}
	}

	// Token: 0x060004BF RID: 1215 RVA: 0x00029A8C File Offset: 0x00027C8C
	public void OnPressPaySalaryBill(bool forcePay = false)
	{
		BillData bill = CPlayerData.GetBill(EBillType.Employee);
		if (bill != null && bill.amountToPay > 0f)
		{
			if (CPlayerData.m_CoinAmount >= bill.amountToPay || forcePay)
			{
				if (!forcePay)
				{
					SoundManager.PlayAudio("SFX_CustomerBuy", 0.6f, 1f);
				}
				CEventManager.QueueEvent(new CEventPlayer_ReduceCoin(bill.amountToPay, false));
				CPlayerData.m_GameReportDataCollect.employeeCost = CPlayerData.m_GameReportDataCollect.employeeCost - bill.amountToPay;
				CPlayerData.m_GameReportDataCollectPermanent.employeeCost = CPlayerData.m_GameReportDataCollectPermanent.employeeCost - bill.amountToPay;
				CPlayerData.SetBill(EBillType.Employee, 0, 0f);
				this.EvaluateUI();
				this.EvaluateBillNotification();
				return;
			}
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.Money);
			SoundManager.GenericCancel(1f, 1f);
		}
	}

	// Token: 0x060004C0 RID: 1216 RVA: 0x00029B48 File Offset: 0x00027D48
	public void OnPressPayAllBill()
	{
		BillData bill = CPlayerData.GetBill(EBillType.Rent);
		BillData bill2 = CPlayerData.GetBill(EBillType.Electric);
		BillData bill3 = CPlayerData.GetBill(EBillType.Employee);
		float num = 0f;
		float num2 = 0f;
		float num3 = 0f;
		if (bill != null && bill.amountToPay > 0f)
		{
			num = bill.amountToPay;
		}
		if (bill2 != null && bill2.amountToPay > 0f)
		{
			num2 = bill2.amountToPay;
		}
		if (bill3 != null && bill3.amountToPay > 0f)
		{
			num3 = bill3.amountToPay;
		}
		float num4 = num + num2 + num3;
		if (num4 > 0f)
		{
			if (CPlayerData.m_CoinAmount >= num4)
			{
				SoundManager.PlayAudio("SFX_CustomerBuy", 0.6f, 1f);
				CEventManager.QueueEvent(new CEventPlayer_ReduceCoin(num4, false));
				CPlayerData.m_GameReportDataCollect.rentCost = CPlayerData.m_GameReportDataCollect.rentCost - num;
				CPlayerData.m_GameReportDataCollectPermanent.rentCost = CPlayerData.m_GameReportDataCollectPermanent.rentCost - num;
				CPlayerData.m_GameReportDataCollect.billCost = CPlayerData.m_GameReportDataCollect.billCost - num2;
				CPlayerData.m_GameReportDataCollectPermanent.billCost = CPlayerData.m_GameReportDataCollectPermanent.billCost - num2;
				CPlayerData.m_GameReportDataCollect.employeeCost = CPlayerData.m_GameReportDataCollect.employeeCost - num3;
				CPlayerData.m_GameReportDataCollectPermanent.employeeCost = CPlayerData.m_GameReportDataCollectPermanent.employeeCost - num3;
				CPlayerData.SetBill(EBillType.Rent, 0, 0f);
				CPlayerData.SetBill(EBillType.Electric, 0, 0f);
				CPlayerData.SetBill(EBillType.Employee, 0, 0f);
				this.EvaluateUI();
				this.EvaluateBillNotification();
				return;
			}
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.Money);
			SoundManager.GenericCancel(1f, 1f);
		}
	}

	// Token: 0x060004C1 RID: 1217 RVA: 0x00029CB2 File Offset: 0x00027EB2
	public int GetDueDayMax()
	{
		return this.m_DueDayMax;
	}

	// Token: 0x0400062B RID: 1579
	public RentBillPanelUI m_RentBillUI;

	// Token: 0x0400062C RID: 1580
	public RentBillPanelUI m_ElectricBillUI;

	// Token: 0x0400062D RID: 1581
	public RentBillPanelUI m_SalaryBillUI;

	// Token: 0x0400062E RID: 1582
	public TextMeshProUGUI m_TotalAmountDueText;

	// Token: 0x0400062F RID: 1583
	public GameObject m_PayAllLockBtn;

	// Token: 0x04000630 RID: 1584
	public Color m_LateDayColor;

	// Token: 0x04000631 RID: 1585
	public Color m_WarningDayColor;

	// Token: 0x04000632 RID: 1586
	public Color m_NormalDayColor;

	// Token: 0x04000633 RID: 1587
	private int m_DueDayMax = 8;

	// Token: 0x04000634 RID: 1588
	private float m_TotalAmountToPay;
}
