﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000133 RID: 307
[CreateAssetMenu(fileName = "Data", menuName = "Inventory/List", order = 9)]
public class ShelfData_ScriptableObject : ScriptableObject
{
	// Token: 0x04001101 RID: 4353
	public List<ObjectData> m_ObjectDataList;

	// Token: 0x04001102 RID: 4354
	public List<FurniturePurchaseData> m_FurniturePurchaseDataList;
}
