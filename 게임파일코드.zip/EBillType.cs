﻿using System;

// Token: 0x02000073 RID: 115
public enum EBillType
{
	// Token: 0x04000627 RID: 1575
	None,
	// Token: 0x04000628 RID: 1576
	Rent,
	// Token: 0x04000629 RID: 1577
	Electric,
	// Token: 0x0400062A RID: 1578
	Employee
}
