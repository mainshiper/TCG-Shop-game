﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000110 RID: 272
public class ControllerSelectorUIGrp : MonoBehaviour
{
	// Token: 0x06000802 RID: 2050 RVA: 0x0003C704 File Offset: 0x0003A904
	private void Start()
	{
		this.m_TopUIGrp.SetActive(false);
	}

	// Token: 0x06000803 RID: 2051 RVA: 0x0003C714 File Offset: 0x0003A914
	public void SetActive(bool isActive)
	{
		if (Time.timeScale <= 0f)
		{
			this.m_PopupAnim.enabled = false;
			this.m_TopUIGrp.transform.localScale = Vector3.one;
		}
		else
		{
			this.m_PopupAnim.enabled = true;
		}
		this.m_TopUIGrp.SetActive(isActive);
	}

	// Token: 0x06000804 RID: 2052 RVA: 0x0003C768 File Offset: 0x0003A968
	public void SetSpriteGrpScale(float scale)
	{
		if (Time.timeScale <= 0f)
		{
			this.m_PopupAnim.enabled = false;
			this.m_TopUIGrp.transform.localScale = Vector3.one;
		}
		else
		{
			this.m_PopupAnim.enabled = true;
		}
		for (int i = 0; i < this.m_SpriteGrp.Count; i++)
		{
			this.m_SpriteGrp[i].localScale = Vector3.one * scale;
		}
	}

	// Token: 0x04000F51 RID: 3921
	public RectTransform m_Rect;

	// Token: 0x04000F52 RID: 3922
	public GameObject m_TopUIGrp;

	// Token: 0x04000F53 RID: 3923
	public List<Transform> m_SpriteGrp;

	// Token: 0x04000F54 RID: 3924
	public Animation m_PopupAnim;
}
