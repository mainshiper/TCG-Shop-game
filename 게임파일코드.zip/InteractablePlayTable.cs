﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000026 RID: 38
public class InteractablePlayTable : InteractableObject
{
	// Token: 0x060001ED RID: 493 RVA: 0x00014760 File Offset: 0x00012960
	public bool IsLookingForPlayer(bool findTableWithPlayerWaiting)
	{
		return (!findTableWithPlayerWaiting && this.m_CurrentPlayerCount == 0 && this.HasSeatBooking() && this.HasEmptySeatBooking()) || (this.m_CurrentPlayerCount > 0 && this.m_CurrentPlayerCount < this.m_MaxSeatCount && this.HasEmptySeatBooking());
	}

	// Token: 0x060001EE RID: 494 RVA: 0x000147AC File Offset: 0x000129AC
	protected override void Awake()
	{
		base.Awake();
		ShelfManager.InitPlayTable(this);
		for (int i = 0; i < this.m_MaxSeatCount; i++)
		{
			this.m_IsSeatBooked.Add(false);
			this.m_IsSeatOccupied.Add(false);
			this.m_IsQueueOccupied.Add(false);
			this.m_IsCustomerSmelly.Add(false);
			this.m_IsStandLocValid.Add(true);
			this.m_IsStandLocBValid.Add(true);
			this.m_OccupiedCustomer.Add(null);
			this.m_PlayTableFee.Add(0f);
		}
		for (int j = 0; j < this.m_OccupiedCustomer.Count; j++)
		{
			this.m_TableGameItemSetList[j].gameObject.SetActive(false);
		}
	}

	// Token: 0x060001EF RID: 495 RVA: 0x00014867 File Offset: 0x00012A67
	public override void StartMoveObject()
	{
		if (this.m_CurrentPlayerCount > 0)
		{
			this.StopTableGame();
			return;
		}
		base.StartMoveObject();
	}

	// Token: 0x060001F0 RID: 496 RVA: 0x0001487F File Offset: 0x00012A7F
	protected override void OnPlacedMovedObject()
	{
		base.OnPlacedMovedObject();
		if (this.m_ObjectType == EObjectType.PlayTable)
		{
			TutorialManager.AddTaskValue(ETutorialTaskCondition.BuyPlayTable, 1f);
		}
		this.EvaluateValidStandLoc();
	}

	// Token: 0x060001F1 RID: 497 RVA: 0x000148A4 File Offset: 0x00012AA4
	private void EvaluateValidStandLoc()
	{
		for (int i = 0; i < this.m_StandLocList.Count; i++)
		{
			int mask = LayerMask.GetMask(new string[]
			{
				"PlayTableStandLocBlockedArea",
				"Glass"
			});
			Collider[] array = Physics.OverlapBox(this.m_StandLocList[i].position + Vector3.up, Vector3.one * 0.1f, this.m_StandLocList[i].rotation, mask);
			this.m_IsStandLocValid[i] = (array.Length == 0);
		}
		for (int j = 0; j < this.m_StandLocBList.Count; j++)
		{
			int mask2 = LayerMask.GetMask(new string[]
			{
				"PlayTableStandLocBlockedArea",
				"Glass"
			});
			Collider[] array2 = Physics.OverlapBox(this.m_StandLocBList[j].position + Vector3.up, Vector3.one * 0.1f, Quaternion.identity, mask2);
			this.m_IsStandLocBValid[j] = (array2.Length == 0);
		}
	}

	// Token: 0x060001F2 RID: 498 RVA: 0x000149B6 File Offset: 0x00012BB6
	protected override void Update()
	{
		base.Update();
		if (this.m_HasStartPlay)
		{
			this.m_CurrentPlayTime += Time.deltaTime;
			if (this.m_CurrentPlayTime >= this.m_CurrentPlayTimeMax)
			{
				this.StopTableGame();
			}
		}
	}

	// Token: 0x060001F3 RID: 499 RVA: 0x000149EC File Offset: 0x00012BEC
	private void StopTableGame()
	{
		if (!this.m_HasStartPlay)
		{
			this.m_CurrentPlayTime = 0f;
		}
		for (int i = 0; i < this.m_OccupiedCustomer.Count; i++)
		{
			if (this.m_OccupiedCustomer[i])
			{
				this.m_OccupiedCustomer[i].PlayTableGameEnded(this.m_CurrentPlayTime, this.m_PlayTableFee[i]);
			}
		}
		for (int j = 0; j < this.m_OccupiedCustomer.Count; j++)
		{
			this.m_TableGameItemSetList[j].gameObject.SetActive(false);
		}
		this.m_HasStartPlay = false;
		this.m_CurrentPlayTime = 0f;
		this.m_CurrentPlayerCount = 0;
		for (int k = 0; k < this.m_IsSeatOccupied.Count; k++)
		{
			this.m_IsSeatOccupied[k] = false;
			this.m_IsSeatBooked[k] = false;
			this.m_IsCustomerSmelly[k] = false;
			this.m_IsQueueOccupied[k] = false;
			this.m_OccupiedCustomer[k] = null;
			this.m_PlayTableFee[k] = 0f;
		}
		this.m_EmptySeatIndex.Clear();
		this.m_OccupiedSeatIndex.Clear();
	}

	// Token: 0x060001F4 RID: 500 RVA: 0x00014B1C File Offset: 0x00012D1C
	public void LoadData(PlayTableSaveData playTableSaveData)
	{
		this.m_HasStartPlay = playTableSaveData.hasStartPlay;
		this.m_IsSeatOccupied = playTableSaveData.isSeatOccupied;
		this.m_CurrentPlayerCount = playTableSaveData.currentPlayerCount;
		this.m_CurrentPlayTime = playTableSaveData.currentPlayTime;
		this.m_CurrentPlayTimeMax = playTableSaveData.currentPlayTimeMax;
		if (playTableSaveData.isCustomerSmelly != null)
		{
			this.m_IsCustomerSmelly = playTableSaveData.isCustomerSmelly;
		}
		if (playTableSaveData.playTableFee == null || playTableSaveData.playTableFee.Count < this.m_MaxSeatCount)
		{
			playTableSaveData.playTableFee = new List<float>();
			playTableSaveData.playTableFee.Clear();
			for (int i = 0; i < this.m_MaxSeatCount; i++)
			{
				playTableSaveData.playTableFee.Add(0f);
			}
		}
		this.m_PlayTableFee = playTableSaveData.playTableFee;
		int num = 0;
		for (int j = 0; j < this.m_IsSeatOccupied.Count; j++)
		{
			if (this.m_IsSeatOccupied[j])
			{
				Customer newCustomer = CSingleton<CustomerManager>.Instance.GetNewCustomer();
				newCustomer.InstantSnapToPlayTable(this, j, this.m_HasStartPlay);
				this.m_OccupiedCustomer[j] = newCustomer;
				if (this.m_IsCustomerSmelly[j])
				{
					newCustomer.SetSmelly();
				}
				num++;
			}
		}
		if (this.m_HasStartPlay)
		{
			for (int k = 0; k < this.m_OccupiedCustomer.Count; k++)
			{
				this.m_TableGameItemSetList[k].gameObject.SetActive(true);
			}
		}
		else if (num >= this.m_MaxSeatCount)
		{
			this.m_CurrentPlayerCount = 0;
			for (int l = 0; l < this.m_MaxSeatCount; l++)
			{
				this.CustomerHasReached(this.m_OccupiedCustomer[l], l);
			}
		}
		this.EvaluateValidStandLoc();
	}

	// Token: 0x060001F5 RID: 501 RVA: 0x00014CB7 File Offset: 0x00012EB7
	public Transform GetStandLoc(int index, bool canReturnNull = false)
	{
		if (this.m_IsStandLocValid[index])
		{
			return this.m_StandLocList[index];
		}
		if (canReturnNull)
		{
			return null;
		}
		return this.GetStandLocB(index, true);
	}

	// Token: 0x060001F6 RID: 502 RVA: 0x00014CE1 File Offset: 0x00012EE1
	public Transform GetStandLocB(int index, bool canReturnNull = false)
	{
		if (this.m_IsStandLocBValid[index])
		{
			return this.m_StandLocBList[index];
		}
		if (canReturnNull)
		{
			return null;
		}
		return this.GetStandLoc(index, true);
	}

	// Token: 0x060001F7 RID: 503 RVA: 0x00014D0B File Offset: 0x00012F0B
	public Transform GetSitLoc(int index)
	{
		return this.m_SitLocList[index];
	}

	// Token: 0x060001F8 RID: 504 RVA: 0x00014D19 File Offset: 0x00012F19
	public void CustomerBookSeatIndex(int bookedSeatIndex)
	{
	}

	// Token: 0x060001F9 RID: 505 RVA: 0x00014D1B File Offset: 0x00012F1B
	public void CustomerUnbookSeatIndex(int bookedSeatIndex)
	{
		this.m_IsSeatBooked[bookedSeatIndex] = false;
	}

	// Token: 0x060001FA RID: 506 RVA: 0x00014D2A File Offset: 0x00012F2A
	public void CustomerBookQueueIndex(int bookedSeatIndex)
	{
		this.m_IsQueueOccupied[bookedSeatIndex] = true;
	}

	// Token: 0x060001FB RID: 507 RVA: 0x00014D39 File Offset: 0x00012F39
	public void CustomerUnbookQueueIndex(int bookedSeatIndex)
	{
		this.m_IsQueueOccupied[bookedSeatIndex] = false;
	}

	// Token: 0x060001FC RID: 508 RVA: 0x00014D48 File Offset: 0x00012F48
	public void CustomerHasReached(Customer customer, int seatIndex)
	{
		this.m_OccupiedCustomer[seatIndex] = customer;
		this.m_IsSeatBooked[seatIndex] = false;
		this.m_IsSeatOccupied[seatIndex] = true;
		this.m_PlayTableFee[seatIndex] = customer.GetCurrentPlayTableFee();
		this.m_IsCustomerSmelly[seatIndex] = customer.IsSmelly();
		this.m_CurrentPlayerCount++;
		if (this.m_CurrentPlayerCount >= this.m_MaxSeatCount)
		{
			this.m_HasStartPlay = true;
			this.m_CurrentPlayTime = 0f;
			this.m_CurrentPlayTimeMax = (float)Random.Range(15, 180);
			for (int i = 0; i < this.m_OccupiedCustomer.Count; i++)
			{
				this.m_OccupiedCustomer[i].PlayTableGameStarted();
			}
			for (int j = 0; j < this.m_OccupiedCustomer.Count; j++)
			{
				this.m_TableGameItemSetList[j].gameObject.SetActive(true);
			}
		}
	}

	// Token: 0x060001FD RID: 509 RVA: 0x00014E38 File Offset: 0x00013038
	public bool HasSeatBooking()
	{
		for (int i = 0; i < this.m_IsSeatBooked.Count; i++)
		{
			if (this.m_IsSeatBooked[i])
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060001FE RID: 510 RVA: 0x00014E6C File Offset: 0x0001306C
	public bool HasEmptySeatBooking()
	{
		for (int i = 0; i < this.m_IsSeatBooked.Count; i++)
		{
			if (!this.m_IsSeatBooked[i])
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060001FF RID: 511 RVA: 0x00014EA0 File Offset: 0x000130A0
	public bool HasEmptyQueue()
	{
		for (int i = 0; i < this.m_IsQueueOccupied.Count; i++)
		{
			if (!this.m_IsQueueOccupied[i])
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000200 RID: 512 RVA: 0x00014ED4 File Offset: 0x000130D4
	public bool IsSeatEmpty(int index)
	{
		return !this.m_IsSeatOccupied[index];
	}

	// Token: 0x06000201 RID: 513 RVA: 0x00014EE5 File Offset: 0x000130E5
	public bool IsQueueEmpty(int index)
	{
		return !this.m_IsQueueOccupied[index];
	}

	// Token: 0x06000202 RID: 514 RVA: 0x00014EF8 File Offset: 0x000130F8
	public int GetEmptySeatBookingIndex()
	{
		this.m_EmptySeatIndex.Clear();
		this.m_OccupiedSeatIndex.Clear();
		for (int i = 0; i < this.m_IsSeatBooked.Count; i++)
		{
			if (!this.m_IsSeatBooked[i])
			{
				this.m_EmptySeatIndex.Add(i);
			}
			else
			{
				this.m_OccupiedSeatIndex.Add(i);
			}
		}
		if (this.m_EmptySeatIndex.Count <= 0)
		{
			return -1;
		}
		return this.m_EmptySeatIndex[Random.Range(0, this.m_EmptySeatIndex.Count)];
	}

	// Token: 0x06000203 RID: 515 RVA: 0x00014F88 File Offset: 0x00013188
	public int GetEmptySeatIndex()
	{
		if (this.m_CurrentPlayerCount >= this.m_MaxSeatCount)
		{
			return -1;
		}
		this.m_EmptySeatIndex.Clear();
		this.m_OccupiedSeatIndex.Clear();
		for (int i = 0; i < this.m_IsSeatOccupied.Count; i++)
		{
			if (!this.m_IsSeatOccupied[i])
			{
				this.m_EmptySeatIndex.Add(i);
			}
			else
			{
				this.m_OccupiedSeatIndex.Add(i);
			}
		}
		if (this.m_EmptySeatIndex.Count <= 0)
		{
			return -1;
		}
		return this.m_EmptySeatIndex[Random.Range(0, this.m_EmptySeatIndex.Count)];
	}

	// Token: 0x06000204 RID: 516 RVA: 0x00015025 File Offset: 0x00013225
	public override void OnDestroyed()
	{
		ShelfManager.RemovePlayTable(this);
		base.OnDestroyed();
	}

	// Token: 0x06000205 RID: 517 RVA: 0x00015033 File Offset: 0x00013233
	public void SetIndex(int index)
	{
		this.m_Index = index;
	}

	// Token: 0x06000206 RID: 518 RVA: 0x0001503C File Offset: 0x0001323C
	public int GetIndex()
	{
		return this.m_Index;
	}

	// Token: 0x06000207 RID: 519 RVA: 0x00015044 File Offset: 0x00013244
	public bool GetHasStartPlay()
	{
		return this.m_HasStartPlay;
	}

	// Token: 0x06000208 RID: 520 RVA: 0x0001504C File Offset: 0x0001324C
	public List<bool> GetIsSeatOccupied()
	{
		return this.m_IsSeatOccupied;
	}

	// Token: 0x06000209 RID: 521 RVA: 0x00015054 File Offset: 0x00013254
	public List<bool> GetIsCustomerSmelly()
	{
		return this.m_IsCustomerSmelly;
	}

	// Token: 0x0600020A RID: 522 RVA: 0x0001505C File Offset: 0x0001325C
	public List<float> GetPlayTableFee()
	{
		return this.m_PlayTableFee;
	}

	// Token: 0x0600020B RID: 523 RVA: 0x00015064 File Offset: 0x00013264
	public int GetCurrentPlayerCount()
	{
		return this.m_CurrentPlayerCount;
	}

	// Token: 0x0600020C RID: 524 RVA: 0x0001506C File Offset: 0x0001326C
	public float GetCurrentPlayTime()
	{
		return this.m_CurrentPlayTime;
	}

	// Token: 0x0600020D RID: 525 RVA: 0x00015074 File Offset: 0x00013274
	public float GetCurrentPlayTimeMax()
	{
		return this.m_CurrentPlayTimeMax;
	}

	// Token: 0x0600020E RID: 526 RVA: 0x0001507C File Offset: 0x0001327C
	public void OnPressGoNextDay()
	{
		this.StopTableGame();
	}

	// Token: 0x0600020F RID: 527 RVA: 0x00015084 File Offset: 0x00013284
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.AddListener<CEventPlayer_OnDayEnded>(new CEventManager.EventDelegate<CEventPlayer_OnDayEnded>(this.OnDayEnded));
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x06000210 RID: 528 RVA: 0x000150D4 File Offset: 0x000132D4
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.RemoveListener<CEventPlayer_OnDayEnded>(new CEventManager.EventDelegate<CEventPlayer_OnDayEnded>(this.OnDayEnded));
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x06000211 RID: 529 RVA: 0x00015124 File Offset: 0x00013324
	protected void OnDayStarted(CEventPlayer_OnDayStarted evt)
	{
		for (int i = 0; i < this.m_OccupiedCustomer.Count; i++)
		{
			if (this.m_OccupiedCustomer[i])
			{
				this.m_OccupiedCustomer[i].DeactivateCustomer();
			}
			this.m_OccupiedCustomer[i] = null;
		}
		this.StopTableGame();
	}

	// Token: 0x06000212 RID: 530 RVA: 0x0001517E File Offset: 0x0001337E
	protected void OnDayEnded(CEventPlayer_OnDayEnded evt)
	{
		this.m_CurrentPlayTimeMax -= Random.Range(0f, this.m_CurrentPlayTimeMax - this.m_CurrentPlayTime);
	}

	// Token: 0x06000213 RID: 531 RVA: 0x000151A4 File Offset: 0x000133A4
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.EvaluateValidStandLoc();
	}

	// Token: 0x04000252 RID: 594
	public List<Transform> m_StandLocList;

	// Token: 0x04000253 RID: 595
	public List<Transform> m_StandLocBList;

	// Token: 0x04000254 RID: 596
	public List<Transform> m_SitLocList;

	// Token: 0x04000255 RID: 597
	public List<TableGameItemSet> m_TableGameItemSetList;

	// Token: 0x04000256 RID: 598
	public int m_MaxSeatCount = 2;

	// Token: 0x04000257 RID: 599
	public bool m_HasStartPlay;

	// Token: 0x04000258 RID: 600
	public List<bool> m_IsSeatBooked = new List<bool>();

	// Token: 0x04000259 RID: 601
	public List<bool> m_IsSeatOccupied = new List<bool>();

	// Token: 0x0400025A RID: 602
	public List<bool> m_IsQueueOccupied = new List<bool>();

	// Token: 0x0400025B RID: 603
	public List<bool> m_IsCustomerSmelly = new List<bool>();

	// Token: 0x0400025C RID: 604
	public List<bool> m_IsStandLocValid = new List<bool>();

	// Token: 0x0400025D RID: 605
	public List<bool> m_IsStandLocBValid = new List<bool>();

	// Token: 0x0400025E RID: 606
	private List<int> m_EmptySeatIndex = new List<int>();

	// Token: 0x0400025F RID: 607
	private List<int> m_OccupiedSeatIndex = new List<int>();

	// Token: 0x04000260 RID: 608
	public List<float> m_PlayTableFee = new List<float>();

	// Token: 0x04000261 RID: 609
	private List<Customer> m_OccupiedCustomer = new List<Customer>();

	// Token: 0x04000262 RID: 610
	private int m_Index;

	// Token: 0x04000263 RID: 611
	public int m_CurrentPlayerCount;

	// Token: 0x04000264 RID: 612
	public float m_CurrentPlayTime;

	// Token: 0x04000265 RID: 613
	public float m_CurrentPlayTimeMax;
}
