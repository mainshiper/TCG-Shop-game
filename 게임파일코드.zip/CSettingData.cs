﻿using System;
using System.Collections.Generic;

// Token: 0x020000A6 RID: 166
[Serializable]
public class CSettingData
{
	// Token: 0x060006B1 RID: 1713 RVA: 0x00037F07 File Offset: 0x00036107
	public CSettingData()
	{
		if (CSettingData.instance == null)
		{
			CSettingData.instance = this;
		}
	}

	// Token: 0x060006B2 RID: 1714 RVA: 0x00037F1C File Offset: 0x0003611C
	public void PropagateLoadSettingData(CSettingData settingData)
	{
		if (settingData.m_KeybindBaseKeyList != null && settingData.m_KeybindBaseKeyList.Count > 0)
		{
			InputManager.m_KeybindBaseKeyList = settingData.m_KeybindBaseKeyList;
			InputManager.m_KeybindBaseJoystickCtrlList = settingData.m_KeybindBaseJoystickCtrlList;
		}
	}

	// Token: 0x060006B3 RID: 1715 RVA: 0x00037F4C File Offset: 0x0003614C
	public void SetLoadData<T>(ref T data, T loadData)
	{
		if (loadData != null)
		{
			T t = data;
			data = loadData;
		}
	}

	// Token: 0x060006B4 RID: 1716 RVA: 0x00037F76 File Offset: 0x00036176
	public void SaveSettingData()
	{
		InputManager.OnKeybindSettingSaved();
		this.SetLoadData<List<KeybindBaseKey>>(ref this.m_KeybindBaseKeyList, InputManager.m_KeybindBaseKeyList);
		this.SetLoadData<List<KeybindBaseGamepadControl>>(ref this.m_KeybindBaseJoystickCtrlList, InputManager.m_KeybindBaseJoystickCtrlList);
		CSaveLoad.SaveSetting();
	}

	// Token: 0x040008EA RID: 2282
	public static CSettingData instance;

	// Token: 0x040008EB RID: 2283
	private List<KeybindBaseKey> m_KeybindBaseKeyList;

	// Token: 0x040008EC RID: 2284
	private List<KeybindBaseGamepadControl> m_KeybindBaseJoystickCtrlList;
}
