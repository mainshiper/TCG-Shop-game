﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x020000AA RID: 170
public class CGameManager : CSingleton<CGameManager>
{
	// Token: 0x17000006 RID: 6
	// (get) Token: 0x060006CF RID: 1743 RVA: 0x00038B28 File Offset: 0x00036D28
	// (set) Token: 0x060006D0 RID: 1744 RVA: 0x00038B2F File Offset: 0x00036D2F
	public static Transform Player
	{
		get
		{
			return CGameManager.m_Player;
		}
		set
		{
			CGameManager.m_Player = value;
		}
	}

	// Token: 0x17000007 RID: 7
	// (get) Token: 0x060006D1 RID: 1745 RVA: 0x00038B37 File Offset: 0x00036D37
	// (set) Token: 0x060006D2 RID: 1746 RVA: 0x00038B3E File Offset: 0x00036D3E
	public static float TotalGameSceneTime
	{
		get
		{
			return CGameManager.m_TotalGameSceneTime;
		}
		set
		{
			CGameManager.m_TotalGameSceneTime = value;
		}
	}

	// Token: 0x17000008 RID: 8
	// (get) Token: 0x060006D3 RID: 1747 RVA: 0x00038B46 File Offset: 0x00036D46
	public static double TimePassed
	{
		get
		{
			return CGameManager.m_TimePassed;
		}
	}

	// Token: 0x17000009 RID: 9
	// (get) Token: 0x060006D4 RID: 1748 RVA: 0x00038B4D File Offset: 0x00036D4D
	// (set) Token: 0x060006D5 RID: 1749 RVA: 0x00038B54 File Offset: 0x00036D54
	public static double TotalTimePassed
	{
		get
		{
			return CGameManager.m_TotalTimePassed;
		}
		set
		{
			CGameManager.m_TotalTimePassed = value;
		}
	}

	// Token: 0x060006D6 RID: 1750 RVA: 0x00038B5C File Offset: 0x00036D5C
	private void Start()
	{
		this.m_LockItemLabel = true;
		this.Init();
	}

	// Token: 0x060006D7 RID: 1751 RVA: 0x00038B6C File Offset: 0x00036D6C
	private void Awake()
	{
		if (CGameManager.m_Instance == null)
		{
			CGameManager.m_Instance = this;
		}
		else if (CGameManager.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
		this.m_GameData = CGameData.instance;
		if (PlayerPrefs.HasKey("ResetGame") && PlayerPrefs.GetInt("ResetGame") == 1)
		{
			CSaveLoad.Delete();
			PlayerPrefs.SetInt("ResetGame", 0);
		}
		this.m_LastPauseDateTime = DateTime.UtcNow;
	}

	// Token: 0x060006D8 RID: 1752 RVA: 0x00038BEC File Offset: 0x00036DEC
	private void OnLevelFinishedLoading(Scene scene, LoadSceneMode mode)
	{
		LoadingScreen.CloseScreen();
		if (scene.name == "Title")
		{
			this.m_IsGameLevel = false;
			SoundManager.BlendToMusic("BGM_Silence", 1f, true);
			CSingleton<LoadingScreen>.Instance.FinishLoading();
		}
		else
		{
			this.m_IsGameLevel = true;
		}
		InputManager.OnLevelFinishedLoading();
		if (CGameManager.m_InitLoaded || scene.name == "Title")
		{
			return;
		}
		if (PlayerPrefs.HasKey("ResetGame") && PlayerPrefs.GetInt("ResetGame") == 1)
		{
			CSaveLoad.Delete();
			PlayerPrefs.SetInt("ResetGame", 0);
		}
		if (this.m_LoadGameIndex != -1 && this.m_IsGameLevel)
		{
			this.m_LoadGameIndex = -1;
			base.StartCoroutine(this.LoadDelay());
			return;
		}
		if (this.m_IsGameLevel)
		{
			CSingleton<ShelfManager>.Instance.m_FinishLoadingObjectData = true;
			GameInstance.m_SaveFileNotFound = true;
			CPlayerData.CreateDefaultData(false);
			CGameManager.m_InitLoaded = true;
			CEventManager.QueueEvent(new CEventPlayer_GameDataFinishLoaded());
			CSingleton<LoadingScreen>.Instance.FinishLoading();
			GameInstance.m_FinishedSavefileLoading = true;
		}
	}

	// Token: 0x060006D9 RID: 1753 RVA: 0x00038CEC File Offset: 0x00036EEC
	private void Update()
	{
		bool developerModeEnabled = this.m_DeveloperModeEnabled;
		CGameManager.m_TotalGameSceneTime += Time.deltaTime;
		CGameManager.m_TotalTimePassed += (double)Time.deltaTime;
		CGameManager.m_TutorialManagerTimer += Time.deltaTime;
		CGameManager.m_TutorialSubGrpTimer += Time.deltaTime;
		CGameManager.m_ForceSyncCloudResetTimer += Time.deltaTime;
		this.m_SecondTimer += Time.deltaTime;
		if (this.m_SecondTimer >= 1f)
		{
			this.m_SecondTimer -= 1f;
		}
		this.m_MinuteTimer += Time.deltaTime;
		if (this.m_MinuteTimer >= 60f)
		{
			this.m_MinuteTimer = 0f;
		}
		if (this.m_EnableScreenshotTaking && (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.V)))
		{
			ScreenCapture.CaptureScreenshot(Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "/Screenshots/" + DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss") + ".png", this.m_ScreenshotScaling);
		}
		if (CGameManager.m_HasSavedGame)
		{
			CGameManager.m_HasSavedGameTimer += Time.deltaTime;
			if (CGameManager.m_HasSavedGameTimer > 5f)
			{
				CGameManager.m_HasSavedGameTimer = 0f;
				CGameManager.m_HasSavedGame = false;
			}
		}
		if (CGameManager.m_HasSavedBackupGame)
		{
			CGameManager.m_HasSavedBackupGameTimer += Time.deltaTime;
			if (CGameManager.m_HasSavedBackupGameTimer > 5f)
			{
				CGameManager.m_HasSavedBackupGameTimer = 0f;
				CGameManager.m_HasSavedBackupGame = false;
			}
		}
		if (!this.m_CanSaveGame)
		{
			this.m_CanSaveGameTimer += Time.deltaTime;
			if (this.m_CanSaveGameTimer >= 300f)
			{
				this.m_CanSaveGame = true;
				this.m_CanSaveGameTimer = 0f;
			}
		}
	}

	// Token: 0x060006DA RID: 1754 RVA: 0x00038E97 File Offset: 0x00037097
	private void FixedUpdate()
	{
	}

	// Token: 0x060006DB RID: 1755 RVA: 0x00038E99 File Offset: 0x00037099
	private IEnumerator LoadDelay()
	{
		yield return new WaitForSeconds(0.0001f);
		if (!CGameManager.m_InitLoaded)
		{
			this.LoadData();
		}
		yield return new WaitForSeconds(0.1f);
		CGameManager.m_InitLoaded = true;
		if (PlayerPrefs.HasKey("HasFinishedTutorial"))
		{
			if ((!CPlayerData.m_HasFinishedTutorial || PlayerPrefs.GetInt("HasFinishedTutorial") != 1) && (CPlayerData.m_HasFinishedTutorial || PlayerPrefs.GetInt("HasFinishedTutorial") != 0))
			{
				CPlayerData.m_CanCloudLoad = true;
			}
		}
		else if (CPlayerData.m_HasFinishedTutorial)
		{
			PlayerPrefs.SetInt("HasFinishedTutorial", 1);
		}
		yield break;
	}

	// Token: 0x060006DC RID: 1756 RVA: 0x00038EA8 File Offset: 0x000370A8
	private void Init()
	{
		CGameManager.m_TotalGameSceneTime = 0f;
	}

	// Token: 0x060006DD RID: 1757 RVA: 0x00038EB4 File Offset: 0x000370B4
	private void LoadData()
	{
		Debug.Log("LoadData m_CurrentSaveLoadSlotSelectedIndex " + this.m_CurrentSaveLoadSlotSelectedIndex.ToString());
		if (CSaveLoad.Load(this.m_CurrentSaveLoadSlotSelectedIndex))
		{
			CGameData.instance.PropagateLoadData(CSaveLoad.m_SavedGame);
			return;
		}
		this.LoadBackupData(this.m_CurrentSaveLoadSlotSelectedIndex);
	}

	// Token: 0x060006DE RID: 1758 RVA: 0x00038F04 File Offset: 0x00037104
	private IEnumerator changeFramerate()
	{
		yield return new WaitForSeconds(1f);
		Application.targetFrameRate = 30;
		Application.runInBackground = false;
		yield break;
	}

	// Token: 0x060006DF RID: 1759 RVA: 0x00038F0C File Offset: 0x0003710C
	private new void OnApplicationQuit()
	{
		CGameManager.m_HasSavedGame = false;
		GameInstance.m_CurrentSceneIndex = 0;
		this.SaveGameData(0);
	}

	// Token: 0x060006E0 RID: 1760 RVA: 0x00038F21 File Offset: 0x00037121
	private void OnApplicationPause(bool pauseStatus)
	{
		if (pauseStatus)
		{
			CGameManager.m_HasSavedGame = false;
			this.SaveGameData(0);
			this.m_LastPauseDateTime = DateTime.UtcNow;
			return;
		}
		DateTime.UtcNow - this.m_LastPauseDateTime;
		this.m_LastPauseDateTime = DateTime.UtcNow;
	}

	// Token: 0x060006E1 RID: 1761 RVA: 0x00038F5B File Offset: 0x0003715B
	public void ResetLastPauseTime()
	{
		this.m_LastPauseDateTime = DateTime.UtcNow;
	}

	// Token: 0x060006E2 RID: 1762 RVA: 0x00038F68 File Offset: 0x00037168
	public double DateTimeToUnixTimestamp(DateTime dateTime)
	{
		return (dateTime - new DateTime(1970, 1, 1)).TotalSeconds;
	}

	// Token: 0x060006E3 RID: 1763 RVA: 0x00038F90 File Offset: 0x00037190
	public void SaveGameData(int saveSlotIndex)
	{
		if (!this.m_IsGameLevel)
		{
			Debug.Log("Skip save at title screen");
			return;
		}
		if (GameInstance.m_HasLoadingError)
		{
			Debug.Log("Cant save due to loading error");
			return;
		}
		if (CPlayerData.m_InteractableObjectSaveDataList.Count <= 0)
		{
			Debug.Log("Cant save, no shelf data");
			return;
		}
		if (GameInstance.m_FinishedSavefileLoading)
		{
			CPlayerData.m_LastLocalExitTime = DateTime.UtcNow;
			this.m_IsManualSaveLoad = true;
			this.m_CurrentSaveLoadSlotSelectedIndex = saveSlotIndex;
			CGameData.instance.SaveGameData(saveSlotIndex);
			CGameManager.m_HasSavedGame = true;
			CGameManager.m_HasSavedGameTimer = 0f;
			if (saveSlotIndex == 0)
			{
				CEventManager.QueueEvent(new CEventPlayer_OnSaveStatusUpdated(false, true));
			}
		}
	}

	// Token: 0x060006E4 RID: 1764 RVA: 0x00039024 File Offset: 0x00037224
	public void LoadBackupData(int slotIndex)
	{
		if (CSaveLoad.LoadBackup(slotIndex))
		{
			Debug.Log("Load backup save data slotIndex " + slotIndex.ToString());
			CGameData.instance.PropagateLoadData(CSaveLoad.m_SavedGame);
			return;
		}
		Debug.Log("No save found, start new data");
		GameInstance.m_HasLoadingError = false;
		GameInstance.m_SaveFileNotFound = true;
		CPlayerData.CreateDefaultData(false);
		CGameManager.m_InitLoaded = true;
		CSingleton<ShelfManager>.Instance.m_FinishLoadingObjectData = true;
		CEventManager.QueueEvent(new CEventPlayer_GameDataFinishLoaded());
		CSingleton<LoadingScreen>.Instance.FinishLoading();
		GameInstance.m_FinishedSavefileLoading = true;
	}

	// Token: 0x060006E5 RID: 1765 RVA: 0x000390A6 File Offset: 0x000372A6
	public static bool CanChangeScene()
	{
		return CGameManager.m_TotalGameSceneTime > 0.5f;
	}

	// Token: 0x060006E6 RID: 1766 RVA: 0x000390B7 File Offset: 0x000372B7
	public static void RestartGame()
	{
		GameInstance.m_CurrentSceneIndex = 0;
		CEventManager.QueueEvent(new CEventPlayer_ChangeScene(ELevelName.Start));
	}

	// Token: 0x060006E7 RID: 1767 RVA: 0x000390CA File Offset: 0x000372CA
	private void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_ChangeScene>(new CEventManager.EventDelegate<CEventPlayer_ChangeScene>(this.CPlayer_OnChangeScene));
			SceneManager.sceneLoaded += this.OnLevelFinishedLoading;
		}
	}

	// Token: 0x060006E8 RID: 1768 RVA: 0x000390FC File Offset: 0x000372FC
	private void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_ChangeScene>(new CEventManager.EventDelegate<CEventPlayer_ChangeScene>(this.CPlayer_OnChangeScene));
			SceneManager.sceneLoaded -= this.OnLevelFinishedLoading;
		}
	}

	// Token: 0x060006E9 RID: 1769 RVA: 0x0003912E File Offset: 0x0003732E
	private void CPlayer_OnChangeScene(CEventPlayer_ChangeScene evt)
	{
	}

	// Token: 0x060006EA RID: 1770 RVA: 0x00039130 File Offset: 0x00037330
	public static void SaveGameToCloud()
	{
		if (CSingleton<CGameManager>.Instance.m_ForceNoCloudSaveLoad)
		{
			return;
		}
		CGameData.instance.IsCloudVersionNewerThanLocal();
	}

	// Token: 0x060006EB RID: 1771 RVA: 0x0003914A File Offset: 0x0003734A
	public static int GetSaveLoadSlotSelectedIndex()
	{
		if (CSingleton<CGameManager>.Instance.m_IsManualSaveLoad)
		{
			CSingleton<CGameManager>.Instance.m_IsManualSaveLoad = false;
			return CSingleton<CGameManager>.Instance.m_CurrentSaveLoadSlotSelectedIndex;
		}
		return 0;
	}

	// Token: 0x060006EC RID: 1772 RVA: 0x0003916F File Offset: 0x0003736F
	public static void LoadGameFromCloud()
	{
		bool forceNoCloudSaveLoad = CSingleton<CGameManager>.Instance.m_ForceNoCloudSaveLoad;
	}

	// Token: 0x060006ED RID: 1773 RVA: 0x0003917C File Offset: 0x0003737C
	private IEnumerator DelayLoadScene(string sceneName)
	{
		yield return new WaitForSeconds(1f);
		SceneManager.LoadScene(sceneName);
		yield break;
	}

	// Token: 0x060006EE RID: 1774 RVA: 0x0003918B File Offset: 0x0003738B
	public void LoadMainLevelAsync(string sceneName, int loadGameIndex = -1)
	{
		Debug.Log(sceneName);
		this.m_LoadGameIndex = loadGameIndex;
		base.StartCoroutine(this.LoadLobbySceneAsync(sceneName));
	}

	// Token: 0x060006EF RID: 1775 RVA: 0x000391A8 File Offset: 0x000373A8
	private IEnumerator DelayLoadLobbyScene(string sceneName)
	{
		if (sceneName == "Title")
		{
			CGameManager.m_InitLoaded = false;
		}
		Debug.Log("DelayLoadLobbyScene");
		LoadingScreen.OpenScreen();
		yield return new WaitForSeconds(2f);
		SceneManager.LoadScene(sceneName);
		yield break;
	}

	// Token: 0x060006F0 RID: 1776 RVA: 0x000391B7 File Offset: 0x000373B7
	private IEnumerator LoadLobbySceneAsync(string sceneName)
	{
		if (sceneName == "Title")
		{
			CGameManager.m_InitLoaded = false;
		}
		LoadingScreen.OpenScreen();
		yield return new WaitForSeconds(2f);
		AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(sceneName);
		while (!asyncLoad.isDone)
		{
			string str = ((int)(100f * asyncLoad.progress / 0.9f)).ToString() + "%";
			LoadingScreen.SetPercentDone((int)(100f * asyncLoad.progress / 0.9f));
			Debug.Log("percentDone " + str);
			yield return null;
		}
		yield break;
	}

	// Token: 0x04000907 RID: 2311
	public static CGameManager m_Instance;

	// Token: 0x04000908 RID: 2312
	public Text_ScriptableObject m_TextSO;

	// Token: 0x04000909 RID: 2313
	public bool m_IsGameLevel;

	// Token: 0x0400090A RID: 2314
	public bool m_NoSave;

	// Token: 0x0400090B RID: 2315
	public bool m_IsPrologue;

	// Token: 0x0400090C RID: 2316
	public bool m_IsLightweightDev;

	// Token: 0x0400090D RID: 2317
	public bool m_DeveloperModeEnabled;

	// Token: 0x0400090E RID: 2318
	public bool m_ForceNoCloudSaveLoad;

	// Token: 0x0400090F RID: 2319
	public bool m_ForceCollectionPackFull;

	// Token: 0x04000910 RID: 2320
	public bool m_EnableScreenshotTaking;

	// Token: 0x04000911 RID: 2321
	public bool m_IsManualSaveLoad;

	// Token: 0x04000912 RID: 2322
	public int m_CurrentSaveLoadSlotSelectedIndex;

	// Token: 0x04000913 RID: 2323
	public int m_ScreenshotScaling = 2;

	// Token: 0x04000914 RID: 2324
	public int m_TimeScale = 1;

	// Token: 0x04000915 RID: 2325
	public int m_LoadGameIndex = -1;

	// Token: 0x04000916 RID: 2326
	public int m_KeyboardTypeIndex;

	// Token: 0x04000917 RID: 2327
	public int m_QualitySettingIndex;

	// Token: 0x04000918 RID: 2328
	public int m_CenterDotColorIndex;

	// Token: 0x04000919 RID: 2329
	public int m_CenterDotSpriteTypeIndex;

	// Token: 0x0400091A RID: 2330
	public EMoneyCurrencyType m_CurrencyType;

	// Token: 0x0400091B RID: 2331
	public float m_MouseSensitivity = 0.5f;

	// Token: 0x0400091C RID: 2332
	public float m_MouseSensitivityLerp = 0.5f;

	// Token: 0x0400091D RID: 2333
	public float m_CameraFOVSlider = 0.5f;

	// Token: 0x0400091E RID: 2334
	public float m_CenterDotSizeSlider = 0.3f;

	// Token: 0x0400091F RID: 2335
	public float m_OpenPackSpeedSlider;

	// Token: 0x04000920 RID: 2336
	public bool m_EnableTooltip = true;

	// Token: 0x04000921 RID: 2337
	public bool m_InvertedMouse;

	// Token: 0x04000922 RID: 2338
	public bool m_CashierLockMovement;

	// Token: 0x04000923 RID: 2339
	public bool m_LockItemLabel;

	// Token: 0x04000924 RID: 2340
	public bool m_CanConfineMouseCursor;

	// Token: 0x04000925 RID: 2341
	public bool m_CenterDotHasOutline;

	// Token: 0x04000926 RID: 2342
	public bool m_OpenPackShowNewCard;

	// Token: 0x04000927 RID: 2343
	public bool m_OpenPacAutoNextCard;

	// Token: 0x04000928 RID: 2344
	public bool m_DisableController;

	// Token: 0x04000929 RID: 2345
	public bool m_IsTurnVSyncOff;

	// Token: 0x0400092A RID: 2346
	public bool m_CanRunDebugString;

	// Token: 0x0400092B RID: 2347
	public bool m_CanRunDebugString2;

	// Token: 0x0400092C RID: 2348
	private static bool m_InitLoaded;

	// Token: 0x0400092D RID: 2349
	private CGameData m_GameData;

	// Token: 0x0400092E RID: 2350
	private static Transform m_Player;

	// Token: 0x0400092F RID: 2351
	private static float m_TotalGameSceneTime;

	// Token: 0x04000930 RID: 2352
	public static float m_TutorialManagerTimer;

	// Token: 0x04000931 RID: 2353
	public static float m_TutorialSubGrpTimer;

	// Token: 0x04000932 RID: 2354
	private static double m_TimePassed;

	// Token: 0x04000933 RID: 2355
	public static double m_LastTimePassed;

	// Token: 0x04000934 RID: 2356
	private static double m_TotalTimePassed;

	// Token: 0x04000935 RID: 2357
	public static float m_ForceSyncCloudResetTimer;

	// Token: 0x04000936 RID: 2358
	public static DateTime m_LoginTime;

	// Token: 0x04000937 RID: 2359
	private static bool m_HasSavedGame;

	// Token: 0x04000938 RID: 2360
	private static float m_HasSavedGameTimer;

	// Token: 0x04000939 RID: 2361
	private static bool m_HasSavedBackupGame;

	// Token: 0x0400093A RID: 2362
	private static float m_HasSavedBackupGameTimer;

	// Token: 0x0400093B RID: 2363
	private bool m_IsOpenCloseGameScreen;

	// Token: 0x0400093C RID: 2364
	private float m_CanSaveGameTimer;

	// Token: 0x0400093D RID: 2365
	private bool m_CanSaveGame;

	// Token: 0x0400093E RID: 2366
	private int m_LastScreenIndex;

	// Token: 0x0400093F RID: 2367
	private DateTime m_LastPauseDateTime;

	// Token: 0x04000940 RID: 2368
	private float m_SecondTimer;

	// Token: 0x04000941 RID: 2369
	private float m_MinuteTimer;

	// Token: 0x04000942 RID: 2370
	private float m_CloudSaveDirtyTimer;
}
