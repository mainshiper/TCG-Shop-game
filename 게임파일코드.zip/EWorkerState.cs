﻿using System;

// Token: 0x0200008F RID: 143
public enum EWorkerState
{
	// Token: 0x0400073B RID: 1851
	None = -1,
	// Token: 0x0400073C RID: 1852
	Idle,
	// Token: 0x0400073D RID: 1853
	WalkingToCounter,
	// Token: 0x0400073E RID: 1854
	ManningCounter,
	// Token: 0x0400073F RID: 1855
	WalkingToRestOutside,
	// Token: 0x04000740 RID: 1856
	RestOutside,
	// Token: 0x04000741 RID: 1857
	SearchingForBox,
	// Token: 0x04000742 RID: 1858
	FindingShelfToRestock,
	// Token: 0x04000743 RID: 1859
	WalkToShelf,
	// Token: 0x04000744 RID: 1860
	RestockingShelf,
	// Token: 0x04000745 RID: 1861
	TrashingBox,
	// Token: 0x04000746 RID: 1862
	ReadyToTrashBox,
	// Token: 0x04000747 RID: 1863
	FindingWarehouseShelf,
	// Token: 0x04000748 RID: 1864
	WalkToWarehouseShelf,
	// Token: 0x04000749 RID: 1865
	StoreBoxOnWarehouseShelf,
	// Token: 0x0400074A RID: 1866
	SearchingForBoxToStore,
	// Token: 0x0400074B RID: 1867
	TakingItemFromShelf,
	// Token: 0x0400074C RID: 1868
	ExitingShop,
	// Token: 0x0400074D RID: 1869
	ShopNotOpen
}
