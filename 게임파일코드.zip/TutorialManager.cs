﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000055 RID: 85
public class TutorialManager : CSingleton<TutorialManager>
{
	// Token: 0x060003E6 RID: 998 RVA: 0x00023458 File Offset: 0x00021658
	private void Awake()
	{
		for (int i = 0; i < CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList.Count; i++)
		{
			CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList[i].CloseScreen();
		}
	}

	// Token: 0x060003E7 RID: 999 RVA: 0x00023494 File Offset: 0x00021694
	private void Update()
	{
		if (this.m_FinishedTutorial)
		{
			return;
		}
		this.m_TempShowTutorialIndex = CPlayerData.m_TutorialIndex;
		this.m_TutorialDataList = CPlayerData.m_TutorialDataList;
		if (this.m_IsShowingCanvasGrpAlpha)
		{
			this.m_CanvasGrpAlphaLerpTimer += Time.deltaTime * 2f;
			this.m_CanvasGrp.alpha = Mathf.Lerp(0f, 1f, this.m_CanvasGrpAlphaLerpTimer);
			if (this.m_CanvasGrpAlphaLerpTimer >= 1f)
			{
				this.m_IsShowingCanvasGrpAlpha = false;
				this.m_CanvasGrpAlphaLerpTimer = 1f;
				return;
			}
		}
		else if (this.m_IsHidingCanvasGrpAlpha)
		{
			this.m_CanvasGrpAlphaLerpTimer -= Time.deltaTime * 2f;
			this.m_CanvasGrp.alpha = Mathf.Lerp(0f, 1f, this.m_CanvasGrpAlphaLerpTimer);
			if (this.m_CanvasGrpAlphaLerpTimer <= 0f)
			{
				this.m_IsShowingCanvasGrpAlpha = false;
				this.m_CanvasGrpAlphaLerpTimer = 0f;
			}
		}
	}

	// Token: 0x060003E8 RID: 1000 RVA: 0x00023580 File Offset: 0x00021780
	public static void AddTaskValue(ETutorialTaskCondition tutorialTaskCondition, float valueAdd)
	{
		if (CSingleton<TutorialManager>.Instance.m_FinishedTutorial)
		{
			return;
		}
		bool flag = false;
		for (int i = 0; i < CPlayerData.m_TutorialDataList.Count; i++)
		{
			if (CPlayerData.m_TutorialDataList[i].tutorialTaskCondition == tutorialTaskCondition)
			{
				flag = true;
				CPlayerData.m_TutorialDataList[i].value += valueAdd;
			}
		}
		if (!flag)
		{
			TutorialData tutorialData = new TutorialData();
			tutorialData.tutorialTaskCondition = tutorialTaskCondition;
			tutorialData.value = valueAdd;
			CPlayerData.m_TutorialDataList.Add(tutorialData);
		}
		for (int j = 0; j < CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList.Count; j++)
		{
			CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList[j].AddTaskValue(valueAdd, tutorialTaskCondition);
		}
		CSingleton<TutorialManager>.Instance.EvaluateTaskVisibility();
	}

	// Token: 0x060003E9 RID: 1001 RVA: 0x0002363C File Offset: 0x0002183C
	public void EvaluateTaskVisibility()
	{
		bool flag = false;
		for (int i = 0; i < CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList.Count; i++)
		{
			if (CPlayerData.m_TutorialIndex == 0 || flag || CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList[i].IsTaskFinish())
			{
				CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList[i].CloseScreen();
			}
			else
			{
				flag = true;
				CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList[i].OpenScreen();
				CPlayerData.m_TutorialIndex = i + 1;
			}
		}
		if (!flag)
		{
			this.m_FinishedTutorial = true;
		}
	}

	// Token: 0x060003EA RID: 1002 RVA: 0x000236C8 File Offset: 0x000218C8
	public static void SetGameUIVisible(bool isVisible)
	{
		if (isVisible)
		{
			if (CSingleton<TutorialManager>.Instance.m_CanvasGrp.alpha != 1f)
			{
				CSingleton<TutorialManager>.Instance.m_IsShowingCanvasGrpAlpha = true;
				CSingleton<TutorialManager>.Instance.m_IsHidingCanvasGrpAlpha = false;
				return;
			}
		}
		else if (CSingleton<TutorialManager>.Instance.m_CanvasGrp.alpha != 0f)
		{
			CSingleton<TutorialManager>.Instance.m_IsShowingCanvasGrpAlpha = false;
			CSingleton<TutorialManager>.Instance.m_IsHidingCanvasGrpAlpha = true;
		}
	}

	// Token: 0x060003EB RID: 1003 RVA: 0x00023731 File Offset: 0x00021931
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x060003EC RID: 1004 RVA: 0x00023752 File Offset: 0x00021952
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x060003ED RID: 1005 RVA: 0x00023774 File Offset: 0x00021974
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		if (CPlayerData.m_TutorialIndex == 0)
		{
			this.m_TutorialTargetIndicator.gameObject.SetActive(true);
			this.m_ShopRenamer.SetIsTutorial();
			return;
		}
		if (CPlayerData.GetIsItemLicenseUnlocked(2) || CPlayerData.GetIsItemLicenseUnlocked(3))
		{
			bool flag = false;
			for (int i = 0; i < CPlayerData.m_TutorialDataList.Count; i++)
			{
				if (CPlayerData.m_TutorialDataList[i].tutorialTaskCondition == ETutorialTaskCondition.UnlockBasicCardBox)
				{
					flag = true;
					CPlayerData.m_TutorialDataList[i].value = 1f;
					break;
				}
			}
			if (!flag)
			{
				TutorialData tutorialData = new TutorialData();
				tutorialData.tutorialTaskCondition = ETutorialTaskCondition.UnlockBasicCardBox;
				tutorialData.value = 1f;
				CPlayerData.m_TutorialDataList.Add(tutorialData);
			}
		}
		this.m_TutorialTargetIndicator.gameObject.SetActive(false);
		for (int j = 0; j < CPlayerData.m_TutorialDataList.Count; j++)
		{
			for (int k = 0; k < CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList.Count; k++)
			{
				CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList[k].AddTaskValue(CPlayerData.m_TutorialDataList[j].value, CPlayerData.m_TutorialDataList[j].tutorialTaskCondition);
			}
		}
		this.EvaluateTaskVisibility();
	}

	// Token: 0x040004AE RID: 1198
	public ShopRenamer m_ShopRenamer;

	// Token: 0x040004AF RID: 1199
	public GameObject m_TutorialTargetIndicator;

	// Token: 0x040004B0 RID: 1200
	public List<TutorialSubGroup> m_TutorialSubGroupList;

	// Token: 0x040004B1 RID: 1201
	public int m_TempShowTutorialIndex;

	// Token: 0x040004B2 RID: 1202
	public List<TutorialData> m_TutorialDataList = new List<TutorialData>();

	// Token: 0x040004B3 RID: 1203
	public CanvasGroup m_CanvasGrp;

	// Token: 0x040004B4 RID: 1204
	private bool m_IsShowingCanvasGrpAlpha;

	// Token: 0x040004B5 RID: 1205
	private bool m_IsHidingCanvasGrpAlpha;

	// Token: 0x040004B6 RID: 1206
	private bool m_FinishedTutorial;

	// Token: 0x040004B7 RID: 1207
	private float m_CanvasGrpAlphaLerpTimer;
}
