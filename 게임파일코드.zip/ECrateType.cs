﻿using System;

// Token: 0x020000F4 RID: 244
public enum ECrateType
{
	// Token: 0x04000D8B RID: 3467
	None,
	// Token: 0x04000D8C RID: 3468
	Training,
	// Token: 0x04000D8D RID: 3469
	Normal,
	// Token: 0x04000D8E RID: 3470
	Super,
	// Token: 0x04000D8F RID: 3471
	SuperL,
	// Token: 0x04000D90 RID: 3472
	Mega,
	// Token: 0x04000D91 RID: 3473
	Legendary,
	// Token: 0x04000D92 RID: 3474
	Ultra,
	// Token: 0x04000D93 RID: 3475
	DailyKO
}
