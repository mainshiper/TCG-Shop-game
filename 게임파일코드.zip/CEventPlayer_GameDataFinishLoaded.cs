﻿using System;

// Token: 0x020000BC RID: 188
public class CEventPlayer_GameDataFinishLoaded : CEvent
{
}
