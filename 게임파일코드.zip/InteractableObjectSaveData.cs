﻿using System;

// Token: 0x02000048 RID: 72
[Serializable]
public class InteractableObjectSaveData
{
	// Token: 0x04000436 RID: 1078
	public Vector3Serializer pos;

	// Token: 0x04000437 RID: 1079
	public QuaternionSerializer rot;

	// Token: 0x04000438 RID: 1080
	public bool isBoxed;

	// Token: 0x04000439 RID: 1081
	public Vector3Serializer boxedPackagePos;

	// Token: 0x0400043A RID: 1082
	public QuaternionSerializer boxedPackageRot;

	// Token: 0x0400043B RID: 1083
	public EObjectType objectType;
}
