﻿using System;
using System.Collections.Generic;

// Token: 0x02000013 RID: 19
[Serializable]
public class CustomerProfile
{
	// Token: 0x04000143 RID: 323
	public string name;

	// Token: 0x04000144 RID: 324
	public ECustomerType type;

	// Token: 0x04000145 RID: 325
	public float appearRate;

	// Token: 0x04000146 RID: 326
	public int maxMoneyRangeMin;

	// Token: 0x04000147 RID: 327
	public int maxMoneyRangeMax;

	// Token: 0x04000148 RID: 328
	public int maxMoney;

	// Token: 0x04000149 RID: 329
	public int itemWantRandomPercentMin;

	// Token: 0x0400014A RID: 330
	public int itemWantRandomPercentMax;

	// Token: 0x0400014B RID: 331
	public int maxItemCountRangeMin;

	// Token: 0x0400014C RID: 332
	public int maxItemCountRangeMax;

	// Token: 0x0400014D RID: 333
	public List<EItemType> ignoreItemList;

	// Token: 0x0400014E RID: 334
	public float buyCardPercentChance;
}
