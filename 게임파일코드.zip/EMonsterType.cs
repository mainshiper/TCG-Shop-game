﻿using System;

// Token: 0x020000EC RID: 236
public enum EMonsterType
{
	// Token: 0x04000BF8 RID: 3064
	EarlyPlayer = -1,
	// Token: 0x04000BF9 RID: 3065
	None,
	// Token: 0x04000BFA RID: 3066
	PiggyA,
	// Token: 0x04000BFB RID: 3067
	PiggyB,
	// Token: 0x04000BFC RID: 3068
	PiggyC,
	// Token: 0x04000BFD RID: 3069
	PiggyD,
	// Token: 0x04000BFE RID: 3070
	FoxA,
	// Token: 0x04000BFF RID: 3071
	FoxB,
	// Token: 0x04000C00 RID: 3072
	FoxC,
	// Token: 0x04000C01 RID: 3073
	FoxD,
	// Token: 0x04000C02 RID: 3074
	GolemA,
	// Token: 0x04000C03 RID: 3075
	GolemB,
	// Token: 0x04000C04 RID: 3076
	GolemC,
	// Token: 0x04000C05 RID: 3077
	GolemD,
	// Token: 0x04000C06 RID: 3078
	TreeA,
	// Token: 0x04000C07 RID: 3079
	TreeB,
	// Token: 0x04000C08 RID: 3080
	TreeC,
	// Token: 0x04000C09 RID: 3081
	TreeD,
	// Token: 0x04000C0A RID: 3082
	StarfishA,
	// Token: 0x04000C0B RID: 3083
	StarfishB,
	// Token: 0x04000C0C RID: 3084
	StarfishC,
	// Token: 0x04000C0D RID: 3085
	StarfishD,
	// Token: 0x04000C0E RID: 3086
	ShellyA,
	// Token: 0x04000C0F RID: 3087
	ShellyB,
	// Token: 0x04000C10 RID: 3088
	ShellyC,
	// Token: 0x04000C11 RID: 3089
	ShellyD,
	// Token: 0x04000C12 RID: 3090
	BugA,
	// Token: 0x04000C13 RID: 3091
	BugB,
	// Token: 0x04000C14 RID: 3092
	BugC,
	// Token: 0x04000C15 RID: 3093
	BugD,
	// Token: 0x04000C16 RID: 3094
	BatA,
	// Token: 0x04000C17 RID: 3095
	BatB,
	// Token: 0x04000C18 RID: 3096
	BatC,
	// Token: 0x04000C19 RID: 3097
	BatD,
	// Token: 0x04000C1A RID: 3098
	Skull,
	// Token: 0x04000C1B RID: 3099
	Beetle,
	// Token: 0x04000C1C RID: 3100
	Bear,
	// Token: 0x04000C1D RID: 3101
	Jellyfish,
	// Token: 0x04000C1E RID: 3102
	Wisp,
	// Token: 0x04000C1F RID: 3103
	MummyMan,
	// Token: 0x04000C20 RID: 3104
	FlowerA,
	// Token: 0x04000C21 RID: 3105
	FlowerB,
	// Token: 0x04000C22 RID: 3106
	FlowerC,
	// Token: 0x04000C23 RID: 3107
	FlowerD,
	// Token: 0x04000C24 RID: 3108
	WeirdBirdA,
	// Token: 0x04000C25 RID: 3109
	FireSpirit,
	// Token: 0x04000C26 RID: 3110
	Angez,
	// Token: 0x04000C27 RID: 3111
	Mosquito,
	// Token: 0x04000C28 RID: 3112
	HydraA,
	// Token: 0x04000C29 RID: 3113
	HydraB,
	// Token: 0x04000C2A RID: 3114
	HydraC,
	// Token: 0x04000C2B RID: 3115
	HydraD,
	// Token: 0x04000C2C RID: 3116
	DragonFire,
	// Token: 0x04000C2D RID: 3117
	DragonEarth,
	// Token: 0x04000C2E RID: 3118
	DragonWater,
	// Token: 0x04000C2F RID: 3119
	DragonThunder,
	// Token: 0x04000C30 RID: 3120
	Turtle,
	// Token: 0x04000C31 RID: 3121
	FireWolfA,
	// Token: 0x04000C32 RID: 3122
	FireWolfB,
	// Token: 0x04000C33 RID: 3123
	FireWolfC,
	// Token: 0x04000C34 RID: 3124
	FireWolfD,
	// Token: 0x04000C35 RID: 3125
	FishA,
	// Token: 0x04000C36 RID: 3126
	FishB,
	// Token: 0x04000C37 RID: 3127
	FishC,
	// Token: 0x04000C38 RID: 3128
	FishD,
	// Token: 0x04000C39 RID: 3129
	HalloweenA,
	// Token: 0x04000C3A RID: 3130
	HalloweenB,
	// Token: 0x04000C3B RID: 3131
	HalloweenC,
	// Token: 0x04000C3C RID: 3132
	HalloweenD,
	// Token: 0x04000C3D RID: 3133
	TronA,
	// Token: 0x04000C3E RID: 3134
	TronB,
	// Token: 0x04000C3F RID: 3135
	TronC,
	// Token: 0x04000C40 RID: 3136
	TronD,
	// Token: 0x04000C41 RID: 3137
	LobsterA,
	// Token: 0x04000C42 RID: 3138
	LobsterB,
	// Token: 0x04000C43 RID: 3139
	LobsterC,
	// Token: 0x04000C44 RID: 3140
	LobsterD,
	// Token: 0x04000C45 RID: 3141
	FireBirdA,
	// Token: 0x04000C46 RID: 3142
	FireBirdB,
	// Token: 0x04000C47 RID: 3143
	FireBirdC,
	// Token: 0x04000C48 RID: 3144
	SerpentA,
	// Token: 0x04000C49 RID: 3145
	SerpentB,
	// Token: 0x04000C4A RID: 3146
	SerpentC,
	// Token: 0x04000C4B RID: 3147
	CloudA,
	// Token: 0x04000C4C RID: 3148
	CloudB,
	// Token: 0x04000C4D RID: 3149
	CloudC,
	// Token: 0x04000C4E RID: 3150
	EmeraldA,
	// Token: 0x04000C4F RID: 3151
	EmeraldB,
	// Token: 0x04000C50 RID: 3152
	EmeraldC,
	// Token: 0x04000C51 RID: 3153
	Crystalmon,
	// Token: 0x04000C52 RID: 3154
	ElecDragon,
	// Token: 0x04000C53 RID: 3155
	CrabA,
	// Token: 0x04000C54 RID: 3156
	CrabB,
	// Token: 0x04000C55 RID: 3157
	FireUmbrellaDragon,
	// Token: 0x04000C56 RID: 3158
	Lanternmon,
	// Token: 0x04000C57 RID: 3159
	SeedBugA,
	// Token: 0x04000C58 RID: 3160
	SeedBugB,
	// Token: 0x04000C59 RID: 3161
	SeedBugC,
	// Token: 0x04000C5A RID: 3162
	NinjaBirdA,
	// Token: 0x04000C5B RID: 3163
	NinjaBirdB,
	// Token: 0x04000C5C RID: 3164
	NinjaBirdC,
	// Token: 0x04000C5D RID: 3165
	NinjaBirdD,
	// Token: 0x04000C5E RID: 3166
	NinjaCrowC,
	// Token: 0x04000C5F RID: 3167
	NinjaCrowD,
	// Token: 0x04000C60 RID: 3168
	MuffinTreeA,
	// Token: 0x04000C61 RID: 3169
	MuffinTreeB,
	// Token: 0x04000C62 RID: 3170
	MuffinTreeC,
	// Token: 0x04000C63 RID: 3171
	SharkFishA,
	// Token: 0x04000C64 RID: 3172
	SharkFishB,
	// Token: 0x04000C65 RID: 3173
	SharkFishC,
	// Token: 0x04000C66 RID: 3174
	FireGeckoA,
	// Token: 0x04000C67 RID: 3175
	FireGeckoB,
	// Token: 0x04000C68 RID: 3176
	EarthDino,
	// Token: 0x04000C69 RID: 3177
	SlimeA,
	// Token: 0x04000C6A RID: 3178
	SlimeB,
	// Token: 0x04000C6B RID: 3179
	SlimeC,
	// Token: 0x04000C6C RID: 3180
	SlimeD,
	// Token: 0x04000C6D RID: 3181
	SeahorseA,
	// Token: 0x04000C6E RID: 3182
	SeahorseB,
	// Token: 0x04000C6F RID: 3183
	SeahorseC,
	// Token: 0x04000C70 RID: 3184
	SeahorseD,
	// Token: 0x04000C71 RID: 3185
	FireChickenA,
	// Token: 0x04000C72 RID: 3186
	FireChickenB,
	// Token: 0x04000C73 RID: 3187
	MAX,
	// Token: 0x04000C74 RID: 3188
	START_MEGABOT = -1000,
	// Token: 0x04000C75 RID: 3189
	Alpha = 1000,
	// Token: 0x04000C76 RID: 3190
	Beta,
	// Token: 0x04000C77 RID: 3191
	Gamma,
	// Token: 0x04000C78 RID: 3192
	Ronin,
	// Token: 0x04000C79 RID: 3193
	Bumblebee,
	// Token: 0x04000C7A RID: 3194
	Orca,
	// Token: 0x04000C7B RID: 3195
	Garuda,
	// Token: 0x04000C7C RID: 3196
	Viper,
	// Token: 0x04000C7D RID: 3197
	Blitz,
	// Token: 0x04000C7E RID: 3198
	Cylops,
	// Token: 0x04000C7F RID: 3199
	Kabuto,
	// Token: 0x04000C80 RID: 3200
	Minotaur,
	// Token: 0x04000C81 RID: 3201
	Spectre,
	// Token: 0x04000C82 RID: 3202
	Wolf,
	// Token: 0x04000C83 RID: 3203
	Bolt,
	// Token: 0x04000C84 RID: 3204
	Hawk,
	// Token: 0x04000C85 RID: 3205
	Cyber,
	// Token: 0x04000C86 RID: 3206
	Space,
	// Token: 0x04000C87 RID: 3207
	Hangar,
	// Token: 0x04000C88 RID: 3208
	Arena,
	// Token: 0x04000C89 RID: 3209
	UndergroundDark,
	// Token: 0x04000C8A RID: 3210
	UndergroundLight,
	// Token: 0x04000C8B RID: 3211
	RoninBoss,
	// Token: 0x04000C8C RID: 3212
	OrcaBoss,
	// Token: 0x04000C8D RID: 3213
	GarudaBoss,
	// Token: 0x04000C8E RID: 3214
	ViperBoss,
	// Token: 0x04000C8F RID: 3215
	Max,
	// Token: 0x04000C90 RID: 3216
	Shockwave,
	// Token: 0x04000C91 RID: 3217
	Tremor,
	// Token: 0x04000C92 RID: 3218
	Rhino,
	// Token: 0x04000C93 RID: 3219
	RoninArt,
	// Token: 0x04000C94 RID: 3220
	GarudaArt,
	// Token: 0x04000C95 RID: 3221
	MaxArt,
	// Token: 0x04000C96 RID: 3222
	MinotaurArt,
	// Token: 0x04000C97 RID: 3223
	WolfArt,
	// Token: 0x04000C98 RID: 3224
	SkullArt,
	// Token: 0x04000C99 RID: 3225
	OrcaAlt,
	// Token: 0x04000C9A RID: 3226
	GarudaAlt,
	// Token: 0x04000C9B RID: 3227
	ViperAlt,
	// Token: 0x04000C9C RID: 3228
	KabutoAlt,
	// Token: 0x04000C9D RID: 3229
	Neon,
	// Token: 0x04000C9E RID: 3230
	Pulse,
	// Token: 0x04000C9F RID: 3231
	Raptor,
	// Token: 0x04000CA0 RID: 3232
	AncientHammer,
	// Token: 0x04000CA1 RID: 3233
	ArcMissile,
	// Token: 0x04000CA2 RID: 3234
	Axe,
	// Token: 0x04000CA3 RID: 3235
	BarrageMissle,
	// Token: 0x04000CA4 RID: 3236
	BarrelHammer,
	// Token: 0x04000CA5 RID: 3237
	BattleChip,
	// Token: 0x04000CA6 RID: 3238
	BoxingGlove,
	// Token: 0x04000CA7 RID: 3239
	ChainGun,
	// Token: 0x04000CA8 RID: 3240
	ChillMissile,
	// Token: 0x04000CA9 RID: 3241
	ColdShoulder,
	// Token: 0x04000CAA RID: 3242
	CrescentClaw,
	// Token: 0x04000CAB RID: 3243
	CrescentMachete,
	// Token: 0x04000CAC RID: 3244
	CrimsonWheel,
	// Token: 0x04000CAD RID: 3245
	CryoBlaster,
	// Token: 0x04000CAE RID: 3246
	Drill,
	// Token: 0x04000CAF RID: 3247
	DualMissile,
	// Token: 0x04000CB0 RID: 3248
	ElecBroadsword,
	// Token: 0x04000CB1 RID: 3249
	ElectricChainsaw,
	// Token: 0x04000CB2 RID: 3250
	ElectricSpike,
	// Token: 0x04000CB3 RID: 3251
	EnergyShield,
	// Token: 0x04000CB4 RID: 3252
	FanBlade,
	// Token: 0x04000CB5 RID: 3253
	FeatherBlade,
	// Token: 0x04000CB6 RID: 3254
	FireAxe,
	// Token: 0x04000CB7 RID: 3255
	FireBroadsword,
	// Token: 0x04000CB8 RID: 3256
	FireKatana,
	// Token: 0x04000CB9 RID: 3257
	FireRocket,
	// Token: 0x04000CBA RID: 3258
	FireShield,
	// Token: 0x04000CBB RID: 3259
	FireTwinAxe,
	// Token: 0x04000CBC RID: 3260
	Flamethrower,
	// Token: 0x04000CBD RID: 3261
	FreezeBomb,
	// Token: 0x04000CBE RID: 3262
	GigaBlade,
	// Token: 0x04000CBF RID: 3263
	GigaCannon,
	// Token: 0x04000CC0 RID: 3264
	GreatCleaver,
	// Token: 0x04000CC1 RID: 3265
	HeatKnife,
	// Token: 0x04000CC2 RID: 3266
	HeatMissile,
	// Token: 0x04000CC3 RID: 3267
	IceBroadsword,
	// Token: 0x04000CC4 RID: 3268
	IceMortar,
	// Token: 0x04000CC5 RID: 3269
	IcePike,
	// Token: 0x04000CC6 RID: 3270
	IceSpinner,
	// Token: 0x04000CC7 RID: 3271
	IceTwinSpear,
	// Token: 0x04000CC8 RID: 3272
	InfernoBoost,
	// Token: 0x04000CC9 RID: 3273
	IronBall,
	// Token: 0x04000CCA RID: 3274
	JetBurner,
	// Token: 0x04000CCB RID: 3275
	Katana,
	// Token: 0x04000CCC RID: 3276
	KnightShield,
	// Token: 0x04000CCD RID: 3277
	KnightSword,
	// Token: 0x04000CCE RID: 3278
	LightSaber,
	// Token: 0x04000CCF RID: 3279
	LionShield,
	// Token: 0x04000CD0 RID: 3280
	MagneticCoil,
	// Token: 0x04000CD1 RID: 3281
	MaulerMace,
	// Token: 0x04000CD2 RID: 3282
	MegavoltBeam,
	// Token: 0x04000CD3 RID: 3283
	MiniMissile,
	// Token: 0x04000CD4 RID: 3284
	MissileCannon,
	// Token: 0x04000CD5 RID: 3285
	MoonlightBlade,
	// Token: 0x04000CD6 RID: 3286
	MorningStar,
	// Token: 0x04000CD7 RID: 3287
	Mortar,
	// Token: 0x04000CD8 RID: 3288
	PulseCannon,
	// Token: 0x04000CD9 RID: 3289
	RailCannon,
	// Token: 0x04000CDA RID: 3290
	Ravager,
	// Token: 0x04000CDB RID: 3291
	RocketMissile,
	// Token: 0x04000CDC RID: 3292
	RollerSpike,
	// Token: 0x04000CDD RID: 3293
	ShurikenBlade,
	// Token: 0x04000CDE RID: 3294
	SonicBlaster,
	// Token: 0x04000CDF RID: 3295
	SpikeBall,
	// Token: 0x04000CE0 RID: 3296
	SpikedWarhammer,
	// Token: 0x04000CE1 RID: 3297
	Sword,
	// Token: 0x04000CE2 RID: 3298
	ThorHammer,
	// Token: 0x04000CE3 RID: 3299
	Thunderblade,
	// Token: 0x04000CE4 RID: 3300
	ThunderTwinBlade,
	// Token: 0x04000CE5 RID: 3301
	WingBooster,
	// Token: 0x04000CE6 RID: 3302
	MAX_MEGABOT,
	// Token: 0x04000CE7 RID: 3303
	START_FANTASYRPG = -2000,
	// Token: 0x04000CE8 RID: 3304
	Archer = 2000,
	// Token: 0x04000CE9 RID: 3305
	ArmoredSlime,
	// Token: 0x04000CEA RID: 3306
	AxeWarrior,
	// Token: 0x04000CEB RID: 3307
	Basilisk,
	// Token: 0x04000CEC RID: 3308
	Blacksmith,
	// Token: 0x04000CED RID: 3309
	CatMage,
	// Token: 0x04000CEE RID: 3310
	CatPirate1,
	// Token: 0x04000CEF RID: 3311
	CatThief,
	// Token: 0x04000CF0 RID: 3312
	Cook,
	// Token: 0x04000CF1 RID: 3313
	DarkKnight,
	// Token: 0x04000CF2 RID: 3314
	Dragon,
	// Token: 0x04000CF3 RID: 3315
	DragonKnight,
	// Token: 0x04000CF4 RID: 3316
	EldritchCreature,
	// Token: 0x04000CF5 RID: 3317
	Farmer,
	// Token: 0x04000CF6 RID: 3318
	Fencer,
	// Token: 0x04000CF7 RID: 3319
	Florist,
	// Token: 0x04000CF8 RID: 3320
	GoblinMage,
	// Token: 0x04000CF9 RID: 3321
	GoblinThief,
	// Token: 0x04000CFA RID: 3322
	GoblinWarrior,
	// Token: 0x04000CFB RID: 3323
	Golem,
	// Token: 0x04000CFC RID: 3324
	Grandma,
	// Token: 0x04000CFD RID: 3325
	Harpy1,
	// Token: 0x04000CFE RID: 3326
	Harpy2,
	// Token: 0x04000CFF RID: 3327
	InkKnight,
	// Token: 0x04000D00 RID: 3328
	Jester1,
	// Token: 0x04000D01 RID: 3329
	Jester2,
	// Token: 0x04000D02 RID: 3330
	King,
	// Token: 0x04000D03 RID: 3331
	Knight,
	// Token: 0x04000D04 RID: 3332
	Lamia,
	// Token: 0x04000D05 RID: 3333
	Mage,
	// Token: 0x04000D06 RID: 3334
	Mimic1,
	// Token: 0x04000D07 RID: 3335
	Mimic2,
	// Token: 0x04000D08 RID: 3336
	MushroomMonster,
	// Token: 0x04000D09 RID: 3337
	Noble1,
	// Token: 0x04000D0A RID: 3338
	Noble2,
	// Token: 0x04000D0B RID: 3339
	Peasant1,
	// Token: 0x04000D0C RID: 3340
	Peasant2,
	// Token: 0x04000D0D RID: 3341
	Phoenix,
	// Token: 0x04000D0E RID: 3342
	Queen,
	// Token: 0x04000D0F RID: 3343
	Reaper,
	// Token: 0x04000D10 RID: 3344
	Schoolboy1,
	// Token: 0x04000D11 RID: 3345
	SchoolBoy2,
	// Token: 0x04000D12 RID: 3346
	Slime,
	// Token: 0x04000D13 RID: 3347
	Snake,
	// Token: 0x04000D14 RID: 3348
	Traveller,
	// Token: 0x04000D15 RID: 3349
	TreeMonster,
	// Token: 0x04000D16 RID: 3350
	Vampire,
	// Token: 0x04000D17 RID: 3351
	Witch,
	// Token: 0x04000D18 RID: 3352
	Wizard,
	// Token: 0x04000D19 RID: 3353
	WolfFantasy,
	// Token: 0x04000D1A RID: 3354
	MAX_FANTASYRPG,
	// Token: 0x04000D1B RID: 3355
	START_CATJOB = -3000,
	// Token: 0x04000D1C RID: 3356
	EX0Teacher = 3000,
	// Token: 0x04000D1D RID: 3357
	EX0Detective,
	// Token: 0x04000D1E RID: 3358
	EX0Woodworker,
	// Token: 0x04000D1F RID: 3359
	EX0Plumber,
	// Token: 0x04000D20 RID: 3360
	EX0Electrician,
	// Token: 0x04000D21 RID: 3361
	EX0Soldier,
	// Token: 0x04000D22 RID: 3362
	EX0General,
	// Token: 0x04000D23 RID: 3363
	EX0Police,
	// Token: 0x04000D24 RID: 3364
	EX0Fireman,
	// Token: 0x04000D25 RID: 3365
	EX0Farmer,
	// Token: 0x04000D26 RID: 3366
	EX0Architect,
	// Token: 0x04000D27 RID: 3367
	EX0Construction,
	// Token: 0x04000D28 RID: 3368
	EX0Bodybuilder,
	// Token: 0x04000D29 RID: 3369
	EX0Archer,
	// Token: 0x04000D2A RID: 3370
	EX0Explorer,
	// Token: 0x04000D2B RID: 3371
	EX0Hiker,
	// Token: 0x04000D2C RID: 3372
	EX0Programmer,
	// Token: 0x04000D2D RID: 3373
	EX0Librarian,
	// Token: 0x04000D2E RID: 3374
	EX0Laundry,
	// Token: 0x04000D2F RID: 3375
	EX0Racer,
	// Token: 0x04000D30 RID: 3376
	EX0Florist,
	// Token: 0x04000D31 RID: 3377
	EX0Geologist,
	// Token: 0x04000D32 RID: 3378
	EX0Gamer,
	// Token: 0x04000D33 RID: 3379
	EX0Maid,
	// Token: 0x04000D34 RID: 3380
	EX0Barber,
	// Token: 0x04000D35 RID: 3381
	EX0Bartender,
	// Token: 0x04000D36 RID: 3382
	EX0Bouncer,
	// Token: 0x04000D37 RID: 3383
	EX0Composer,
	// Token: 0x04000D38 RID: 3384
	EX0Director,
	// Token: 0x04000D39 RID: 3385
	EX0Investor,
	// Token: 0x04000D3A RID: 3386
	EX0Singer,
	// Token: 0x04000D3B RID: 3387
	EX0Musician,
	// Token: 0x04000D3C RID: 3388
	EX0Artist,
	// Token: 0x04000D3D RID: 3389
	EX0Photographer,
	// Token: 0x04000D3E RID: 3390
	EX0Lawyer,
	// Token: 0x04000D3F RID: 3391
	EX0Janitor,
	// Token: 0x04000D40 RID: 3392
	EX0Psychic,
	// Token: 0x04000D41 RID: 3393
	EX0Astronaut,
	// Token: 0x04000D42 RID: 3394
	EX0Scout,
	// Token: 0x04000D43 RID: 3395
	EX0Pirate,
	// Token: 0x04000D44 RID: 3396
	MAX_CATJOB
}
