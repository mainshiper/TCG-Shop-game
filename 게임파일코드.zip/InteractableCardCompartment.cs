﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000019 RID: 25
public class InteractableCardCompartment : MonoBehaviour
{
	// Token: 0x0600012E RID: 302 RVA: 0x0000FFA4 File Offset: 0x0000E1A4
	public void InitCardShelf(CardShelf cardShelf)
	{
		this.m_CardShelf = cardShelf;
		if (this.m_ItemNotForSale)
		{
			for (int i = 0; i < this.m_InteractablePriceTagList.Count; i++)
			{
				this.m_InteractablePriceTagList[i].gameObject.SetActive(false);
			}
		}
	}

	// Token: 0x0600012F RID: 303 RVA: 0x0000FFF0 File Offset: 0x0000E1F0
	public void OnMouseButtonUp()
	{
		if (InteractionPlayerController.GetCurrentHoldCard() && !InteractionPlayerController.GetCurrentHoldCard().IsDisplayedOnShelf())
		{
			if (this.m_StoredCardList.Count > 0)
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.GenericNoSlot);
				return;
			}
			this.SetCardOnShelf(InteractionPlayerController.GetCurrentHoldCard());
			InteractionPlayerController.RemoveCurrentCard();
			TutorialManager.AddTaskValue(ETutorialTaskCondition.PutCardOnShelf, 1f);
		}
	}

	// Token: 0x06000130 RID: 304 RVA: 0x00010048 File Offset: 0x0000E248
	public void OnRightMouseButtonUp()
	{
		if (this.m_StoredCardList.Count > 0 && this.m_StoredCardList[0].IsDisplayedOnShelf())
		{
			if (InteractionPlayerController.HasEnoughSlotToHoldCard())
			{
				InteractionPlayerController.AddHoldCard(this.m_StoredCardList[0]);
				CSingleton<InteractionPlayerController>.Instance.EnterHoldCardMode();
				this.RemoveCardFromShelf(null, null);
				TutorialManager.AddTaskValue(ETutorialTaskCondition.PutCardOnShelf, -1f);
				return;
			}
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.HandFull);
		}
	}

	// Token: 0x06000131 RID: 305 RVA: 0x000100B4 File Offset: 0x0000E2B4
	public void SetCardOnShelf(InteractableCard3d card)
	{
		card.SetIsDisplayedOnShelf(true);
		this.SetPriceTagCardData(card.m_Card3dUI.m_CardUI.GetCardData());
		this.SetPriceTagItemPriceText(card.m_Card3dUI.m_CardUI.GetCardData());
		card.SetTargetRotation(Quaternion.identity);
		card.LerpToTransform(this.m_PutCardLocation, this.m_StoredItemListGrp);
		this.m_StoredCardList.Add(card);
		this.SetPriceTagVisibility(true);
	}

	// Token: 0x06000132 RID: 306 RVA: 0x00010124 File Offset: 0x0000E324
	public void RemoveCardFromShelf(Transform targetpos, Transform targetParent)
	{
		if (this.m_StoredCardList.Count > 0)
		{
			this.m_StoredCardList[0].SetIsDisplayedOnShelf(false);
			this.m_StoredCardList[0].SetTargetRotation(Quaternion.identity);
			if (targetpos != null)
			{
				this.m_StoredCardList[0].LerpToTransform(targetpos, targetParent);
			}
			this.m_StoredCardList.RemoveAt(0);
			this.SetPriceTagCardData(null);
			this.SetPriceTagVisibility(false);
		}
	}

	// Token: 0x06000133 RID: 307 RVA: 0x000101A0 File Offset: 0x0000E3A0
	public void SetPriceTagVisibility(bool isVisible)
	{
		if (this.m_ItemNotForSale)
		{
			return;
		}
		for (int i = 0; i < this.m_InteractablePriceTagList.Count; i++)
		{
			this.m_InteractablePriceTagList[i].SetVisibility(isVisible);
		}
	}

	// Token: 0x06000134 RID: 308 RVA: 0x000101E0 File Offset: 0x0000E3E0
	public void SetPriceTagCardData(CardData cardData)
	{
		if (this.m_ItemNotForSale)
		{
			return;
		}
		for (int i = 0; i < this.m_InteractablePriceTagList.Count; i++)
		{
			this.m_InteractablePriceTagList[i].SetCardData(cardData);
		}
	}

	// Token: 0x06000135 RID: 309 RVA: 0x00010220 File Offset: 0x0000E420
	public void SetPriceTagItemPriceText(CardData cardData)
	{
		if (this.m_ItemNotForSale)
		{
			return;
		}
		this.m_CurrentPrice = CPlayerData.GetCardPrice(cardData);
		for (int i = 0; i < this.m_InteractablePriceTagList.Count; i++)
		{
			this.m_InteractablePriceTagList[i].SetPriceText(this.m_CurrentPrice);
		}
	}

	// Token: 0x06000136 RID: 310 RVA: 0x00010270 File Offset: 0x0000E470
	public void RefreshPriceTagItemPriceText()
	{
		if (this.m_ItemNotForSale)
		{
			return;
		}
		for (int i = 0; i < this.m_InteractablePriceTagList.Count; i++)
		{
			this.m_InteractablePriceTagList[i].RefreshPriceText();
		}
	}

	// Token: 0x06000137 RID: 311 RVA: 0x000102B0 File Offset: 0x0000E4B0
	public void SetCardVisibility(bool isVisible)
	{
		for (int i = 0; i < this.m_StoredCardList.Count; i++)
		{
			if (this.m_StoredCardList[i])
			{
				this.m_StoredCardList[i].m_Card3dUI.SetVisibility(isVisible);
			}
		}
	}

	// Token: 0x06000138 RID: 312 RVA: 0x00010300 File Offset: 0x0000E500
	public void DisableAllCard()
	{
		for (int i = 0; i < this.m_StoredCardList.Count; i++)
		{
			if (this.m_StoredCardList[i])
			{
				this.m_StoredCardList[i].OnDestroyed();
			}
		}
	}

	// Token: 0x040001A1 RID: 417
	public bool m_ItemNotForSale;

	// Token: 0x040001A2 RID: 418
	public Transform m_CustomerStandLoc;

	// Token: 0x040001A3 RID: 419
	public Transform m_StoredItemListGrp;

	// Token: 0x040001A4 RID: 420
	public Transform m_PutCardLocation;

	// Token: 0x040001A5 RID: 421
	public List<InteractableCardPriceTag> m_InteractablePriceTagList;

	// Token: 0x040001A6 RID: 422
	public List<InteractableCard3d> m_StoredCardList = new List<InteractableCard3d>();

	// Token: 0x040001A7 RID: 423
	private int m_Index;

	// Token: 0x040001A8 RID: 424
	private CardShelf m_CardShelf;

	// Token: 0x040001A9 RID: 425
	private ShelfCompartment m_ShelfCompartment;

	// Token: 0x040001AA RID: 426
	private float m_CurrentPrice;
}
