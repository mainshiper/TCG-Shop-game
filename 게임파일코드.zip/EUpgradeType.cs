﻿using System;

// Token: 0x020000E5 RID: 229
public enum EUpgradeType
{
	// Token: 0x04000ADE RID: 2782
	None = -1,
	// Token: 0x04000ADF RID: 2783
	BasicCardPackSupply,
	// Token: 0x04000AE0 RID: 2784
	BasicCardBoxSupply,
	// Token: 0x04000AE1 RID: 2785
	RareCardPackSupply,
	// Token: 0x04000AE2 RID: 2786
	RareCardBoxSupply,
	// Token: 0x04000AE3 RID: 2787
	EpicCardPackSupply,
	// Token: 0x04000AE4 RID: 2788
	EpicCardBoxSupply,
	// Token: 0x04000AE5 RID: 2789
	LegendaryCardPackSupply,
	// Token: 0x04000AE6 RID: 2790
	LegendaryCardBoxSupply,
	// Token: 0x04000AE7 RID: 2791
	BasicCardPackCollectionUsingGoldMax,
	// Token: 0x04000AE8 RID: 2792
	BasicCardPackCollectionUsingGemMax,
	// Token: 0x04000AE9 RID: 2793
	RareCardPackCollectionUsingGoldMax,
	// Token: 0x04000AEA RID: 2794
	RareCardPackCollectionUsingGemMax,
	// Token: 0x04000AEB RID: 2795
	EpicCardPackCollectionUsingGoldMax,
	// Token: 0x04000AEC RID: 2796
	EpicCardPackCollectionUsingGemMax,
	// Token: 0x04000AED RID: 2797
	LegendaryCardPackCollectionUsingGoldMax,
	// Token: 0x04000AEE RID: 2798
	LegendaryCardPackCollectionUsingGemMax,
	// Token: 0x04000AEF RID: 2799
	CommonPackEarningUp,
	// Token: 0x04000AF0 RID: 2800
	RarePackEarningUp,
	// Token: 0x04000AF1 RID: 2801
	EpicPackEarningUp,
	// Token: 0x04000AF2 RID: 2802
	LegendPackEarningUp,
	// Token: 0x04000AF3 RID: 2803
	CommonBoxEarningUp,
	// Token: 0x04000AF4 RID: 2804
	RareBoxEarningUp,
	// Token: 0x04000AF5 RID: 2805
	EpicBoxEarningUp,
	// Token: 0x04000AF6 RID: 2806
	LegendBoxEarningUp,
	// Token: 0x04000AF7 RID: 2807
	TapPowerLevel,
	// Token: 0x04000AF8 RID: 2808
	CustomerSpendingPower,
	// Token: 0x04000AF9 RID: 2809
	CustomerBuyMoreItem,
	// Token: 0x04000AFA RID: 2810
	CustomerSpawnTime,
	// Token: 0x04000AFB RID: 2811
	CustomerCollectorSpawnRate,
	// Token: 0x04000AFC RID: 2812
	CustomerSuperCollectorSpawnRate,
	// Token: 0x04000AFD RID: 2813
	CustomerUltimateCollectorSpawnRate,
	// Token: 0x04000AFE RID: 2814
	CustomerLegendCollectorSpawnRate,
	// Token: 0x04000AFF RID: 2815
	DestinyExtraGold,
	// Token: 0x04000B00 RID: 2816
	DestinyExtraGem,
	// Token: 0x04000B01 RID: 2817
	DestinyExtraFame,
	// Token: 0x04000B02 RID: 2818
	DestinyCheaperShelfUpgrade,
	// Token: 0x04000B03 RID: 2819
	DestinyDoubleCustomerChance,
	// Token: 0x04000B04 RID: 2820
	DestinyReduceRestockTime,
	// Token: 0x04000B05 RID: 2821
	DestinyCustomerSpending,
	// Token: 0x04000B06 RID: 2822
	DestinyFoilChance,
	// Token: 0x04000B07 RID: 2823
	DestinyCustomerCountMax,
	// Token: 0x04000B08 RID: 2824
	MAX
}
