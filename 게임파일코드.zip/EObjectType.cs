﻿using System;

// Token: 0x020000E6 RID: 230
public enum EObjectType
{
	// Token: 0x04000B0A RID: 2826
	None = -1,
	// Token: 0x04000B0B RID: 2827
	CashCounter,
	// Token: 0x04000B0C RID: 2828
	Trashbin,
	// Token: 0x04000B0D RID: 2829
	PersonalStash,
	// Token: 0x04000B0E RID: 2830
	PackageBoxBig,
	// Token: 0x04000B0F RID: 2831
	PackageBoxSmall,
	// Token: 0x04000B10 RID: 2832
	PackageBoxShelf,
	// Token: 0x04000B11 RID: 2833
	Shelf,
	// Token: 0x04000B12 RID: 2834
	ShelfSmall,
	// Token: 0x04000B13 RID: 2835
	WarehouseShelf,
	// Token: 0x04000B14 RID: 2836
	Card3d,
	// Token: 0x04000B15 RID: 2837
	CardShelf,
	// Token: 0x04000B16 RID: 2838
	PlayTable,
	// Token: 0x04000B17 RID: 2839
	ShelfSmallB,
	// Token: 0x04000B18 RID: 2840
	PersonalShelfA,
	// Token: 0x04000B19 RID: 2841
	PersonalShelfB,
	// Token: 0x04000B1A RID: 2842
	PersonalShelfC,
	// Token: 0x04000B1B RID: 2843
	FancyShelfA,
	// Token: 0x04000B1C RID: 2844
	FancyShelfB,
	// Token: 0x04000B1D RID: 2845
	HugeShelfA,
	// Token: 0x04000B1E RID: 2846
	HugeShelfB,
	// Token: 0x04000B1F RID: 2847
	CabinetA,
	// Token: 0x04000B20 RID: 2848
	LongShelfA,
	// Token: 0x04000B21 RID: 2849
	RusticShelfA,
	// Token: 0x04000B22 RID: 2850
	VintageCardTable,
	// Token: 0x04000B23 RID: 2851
	DisplayCardTableA,
	// Token: 0x04000B24 RID: 2852
	DisplayCardShelfA,
	// Token: 0x04000B25 RID: 2853
	DisplayCardShelfB,
	// Token: 0x04000B26 RID: 2854
	WarehouseShelfA,
	// Token: 0x04000B27 RID: 2855
	WarehouseShelfB,
	// Token: 0x04000B28 RID: 2856
	WarehouseShelfC,
	// Token: 0x04000B29 RID: 2857
	Workbench,
	// Token: 0x04000B2A RID: 2858
	AutoCleanser1,
	// Token: 0x04000B2B RID: 2859
	AutoCleanser2,
	// Token: 0x04000B2C RID: 2860
	AutoCleanser3,
	// Token: 0x04000B2D RID: 2861
	MAX
}
