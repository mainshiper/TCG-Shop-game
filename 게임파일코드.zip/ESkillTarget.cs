﻿using System;

// Token: 0x020000F1 RID: 241
public enum ESkillTarget
{
	// Token: 0x04000D70 RID: 3440
	None,
	// Token: 0x04000D71 RID: 3441
	Single,
	// Token: 0x04000D72 RID: 3442
	AllActive,
	// Token: 0x04000D73 RID: 3443
	All,
	// Token: 0x04000D74 RID: 3444
	Team
}
