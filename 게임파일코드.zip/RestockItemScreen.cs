﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x0200007B RID: 123
public class RestockItemScreen : GenericSliderScreen
{
	// Token: 0x060004E0 RID: 1248 RVA: 0x0002A973 File Offset: 0x00028B73
	protected override void Awake()
	{
		base.Awake();
		this.m_CartNotification.SetActive(false);
	}

	// Token: 0x060004E1 RID: 1249 RVA: 0x0002A987 File Offset: 0x00028B87
	protected override void Init()
	{
		this.m_TotalCostText.text = GameInstance.GetPriceString(this.m_TotalCost, false, true, false, "F2");
		this.m_PageIndex = -1;
		this.EvaluateRestockItemPanelUI(0);
		base.Init();
	}

	// Token: 0x060004E2 RID: 1250 RVA: 0x0002A9BC File Offset: 0x00028BBC
	protected virtual void EvaluateRestockItemPanelUI(int pageIndex)
	{
		if (this.m_PageIndex == pageIndex)
		{
			return;
		}
		this.m_PageIndex = pageIndex;
		for (int i = 0; i < this.m_PageButtonHighlightList.Count; i++)
		{
			this.m_PageButtonHighlightList[i].SetActive(false);
		}
		this.m_PageButtonHighlightList[this.m_PageIndex].SetActive(true);
		List<EItemType> list = new List<EItemType>();
		if (pageIndex == 0)
		{
			list = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownItemType;
		}
		else if (pageIndex == 1)
		{
			list = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownAccessoryItemType;
		}
		else if (pageIndex == 2)
		{
			list = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownFigurineItemType;
		}
		else if (pageIndex == 3)
		{
			list = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownAllItemType;
		}
		for (int j = 0; j < this.m_RestockItemPanelUIList.Count; j++)
		{
			this.m_RestockItemPanelUIList[j].SetActive(false);
		}
		this.m_CurrentRestockDataIndexList.Clear();
		for (int k = 0; k < list.Count; k++)
		{
			for (int l = 0; l < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList.Count; l++)
			{
				if (list[k] == CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList[l].itemType)
				{
					this.m_CurrentRestockDataIndexList.Add(l);
				}
			}
		}
		int num = 0;
		while (num < this.m_CurrentRestockDataIndexList.Count && num < this.m_RestockItemPanelUIList.Count)
		{
			this.m_RestockItemPanelUIList[num].Init(this, this.m_CurrentRestockDataIndexList[num]);
			this.m_RestockItemPanelUIList[num].SetActive(true);
			this.m_ScrollEndPosParent = this.m_RestockItemPanelUIList[num].gameObject;
			num++;
		}
	}

	// Token: 0x060004E3 RID: 1251 RVA: 0x0002AB80 File Offset: 0x00028D80
	protected override void OnOpenScreen()
	{
		this.Init();
		base.OnOpenScreen();
	}

	// Token: 0x060004E4 RID: 1252 RVA: 0x0002AB8E File Offset: 0x00028D8E
	public void OnPressChangePageButton(int index)
	{
		this.EvaluateRestockItemPanelUI(index);
		base.StartCoroutine(base.EvaluateActiveRestockUIScroller());
		this.m_PosX = 0f;
		this.m_LerpPosX = 0f;
	}

	// Token: 0x060004E5 RID: 1253 RVA: 0x0002ABBC File Offset: 0x00028DBC
	public void EvaluateCartCheckout(float totalCost)
	{
		CEventManager.QueueEvent(new CEventPlayer_ReduceCoin(totalCost, false));
		CPlayerData.m_GameReportDataCollect.supplyCost = CPlayerData.m_GameReportDataCollect.supplyCost - totalCost;
		CPlayerData.m_GameReportDataCollectPermanent.supplyCost = CPlayerData.m_GameReportDataCollectPermanent.supplyCost - totalCost;
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		foreach (KeyValuePair<int, int> keyValuePair in this.m_CartItemList)
		{
			list.Add(keyValuePair.Key);
			list2.Add(keyValuePair.Value);
		}
		CSingleton<CGameManager>.Instance.m_CanRunDebugString = true;
		CPlayerData.m_DebugString = "indexList.Count" + list.Count.ToString();
		int num = 0;
		for (int i = 0; i < list.Count; i++)
		{
			RestockManager.SpawnPackageBoxItemMultipleFrame(InventoryBase.GetRestockData(list[i]), list2[i]);
			num += list2[i];
		}
		this.m_CartItemList.Clear();
		this.m_RestockItemCheckoutScreen.UpdateData(this, this.m_CartItemList, false);
		base.StartCoroutine(this.DelaySaveShelfData());
		CEventManager.QueueEvent(new CEventPlayer_AddShopExp(num * 5, false));
		TutorialManager.AddTaskValue(ETutorialTaskCondition.RestockItem, (float)num);
		SoundManager.PlayAudio("SFX_CustomerBuy", 0.6f, 1f);
	}

	// Token: 0x060004E6 RID: 1254 RVA: 0x0002AD14 File Offset: 0x00028F14
	private IEnumerator DelaySaveShelfData()
	{
		yield return new WaitForSeconds(1f);
		CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
		yield break;
	}

	// Token: 0x060004E7 RID: 1255 RVA: 0x0002AD1C File Offset: 0x00028F1C
	private void SpawnPackageItemBox(EItemType itemType, bool isBigBox, int boxCount)
	{
		for (int i = 0; i < boxCount; i++)
		{
			if (isBigBox)
			{
				RestockManager.SpawnPackageBoxItem(itemType, 64, true);
			}
			else
			{
				RestockManager.SpawnPackageBoxItem(itemType, 32, false);
			}
		}
	}

	// Token: 0x060004E8 RID: 1256 RVA: 0x0002AD4E File Offset: 0x00028F4E
	public void OnPressAddToCartButton(int index)
	{
		this.m_RestockItemAddToCartScreen.UpdateData(this, index);
		base.OpenChildScreen(this.m_RestockItemAddToCartScreen);
	}

	// Token: 0x060004E9 RID: 1257 RVA: 0x0002AD69 File Offset: 0x00028F69
	public bool HasEnoughCartSlot()
	{
		return this.m_CartItemList.Count < this.m_RestockItemCheckoutScreen.m_RestockCheckoutItemBarUIList.Count;
	}

	// Token: 0x060004EA RID: 1258 RVA: 0x0002AD8C File Offset: 0x00028F8C
	public void AddToCartForCheckout(int index, int boxCount)
	{
		if (this.m_CartItemList.ContainsKey(index))
		{
			Dictionary<int, int> cartItemList = this.m_CartItemList;
			cartItemList[index] += boxCount;
		}
		else
		{
			this.m_CartItemList.Add(index, boxCount);
		}
		this.m_RestockItemCheckoutScreen.UpdateData(this, this.m_CartItemList, false);
	}

	// Token: 0x060004EB RID: 1259 RVA: 0x0002ADE4 File Offset: 0x00028FE4
	public void RemoveFromCartForCheckout(int index, int boxCount)
	{
		bool hasItemRemoved = false;
		if (this.m_CartItemList.ContainsKey(index))
		{
			Dictionary<int, int> cartItemList = this.m_CartItemList;
			cartItemList[index] -= boxCount;
			if (this.m_CartItemList[index] <= 0)
			{
				hasItemRemoved = true;
				this.m_CartItemList.Remove(index);
			}
		}
		this.m_RestockItemCheckoutScreen.UpdateData(this, this.m_CartItemList, hasItemRemoved);
	}

	// Token: 0x060004EC RID: 1260 RVA: 0x0002AE4B File Offset: 0x0002904B
	public int GetBoxCountInCart(int index)
	{
		if (this.m_CartItemList.ContainsKey(index))
		{
			return this.m_CartItemList[index];
		}
		return 0;
	}

	// Token: 0x060004ED RID: 1261 RVA: 0x0002AE69 File Offset: 0x00029069
	public void OnPressCheckoutButton()
	{
		this.m_RestockItemCheckoutScreen.UpdateData(this, this.m_CartItemList, false);
		base.OpenChildScreen(this.m_RestockItemCheckoutScreen);
	}

	// Token: 0x060004EE RID: 1262 RVA: 0x0002AE8C File Offset: 0x0002908C
	public void UpdateCartTotalCost(float cost, int count)
	{
		this.m_TotalCost = cost;
		this.m_TotalCostText.text = GameInstance.GetPriceString(this.m_TotalCost, false, true, false, "F2");
		this.m_TotalCartItemCountText.text = count.ToString();
		if (count > 0)
		{
			this.m_CartNotification.SetActive(true);
			return;
		}
		this.m_CartNotification.SetActive(false);
	}

	// Token: 0x060004EF RID: 1263 RVA: 0x0002AEF0 File Offset: 0x000290F0
	public RestockItemPanelUI GetRestockItemPanelUI(int index)
	{
		for (int i = 0; i < this.m_RestockItemPanelUIList.Count; i++)
		{
			if (this.m_RestockItemPanelUIList[i].GetIndex() == (float)index)
			{
				return this.m_RestockItemPanelUIList[i];
			}
		}
		return this.m_RestockItemPanelUIList[0];
	}

	// Token: 0x0400066D RID: 1645
	public List<RestockItemPanelUI> m_RestockItemPanelUIList;

	// Token: 0x0400066E RID: 1646
	public List<GameObject> m_PageButtonHighlightList;

	// Token: 0x0400066F RID: 1647
	public RestockItemAddToCartScreen m_RestockItemAddToCartScreen;

	// Token: 0x04000670 RID: 1648
	public RestockItemCheckoutScreen m_RestockItemCheckoutScreen;

	// Token: 0x04000671 RID: 1649
	public TextMeshProUGUI m_TotalCostText;

	// Token: 0x04000672 RID: 1650
	public TextMeshProUGUI m_TotalCartItemCountText;

	// Token: 0x04000673 RID: 1651
	public GameObject m_CartNotification;

	// Token: 0x04000674 RID: 1652
	protected int m_PageIndex = -1;

	// Token: 0x04000675 RID: 1653
	protected float m_TotalCost;

	// Token: 0x04000676 RID: 1654
	protected Dictionary<int, int> m_CartItemList = new Dictionary<int, int>();

	// Token: 0x04000677 RID: 1655
	protected List<int> m_CurrentRestockDataIndexList = new List<int>();
}
