﻿using System;

// Token: 0x020000D3 RID: 211
public enum PoolObjectType
{
	// Token: 0x0400096A RID: 2410
	none,
	// Token: 0x0400096B RID: 2411
	slashHitFX,
	// Token: 0x0400096C RID: 2412
	explosionFX
}
