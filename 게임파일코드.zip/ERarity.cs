﻿using System;

// Token: 0x020000F5 RID: 245
public enum ERarity
{
	// Token: 0x04000D95 RID: 3477
	None = -1,
	// Token: 0x04000D96 RID: 3478
	Common,
	// Token: 0x04000D97 RID: 3479
	Rare,
	// Token: 0x04000D98 RID: 3480
	Epic,
	// Token: 0x04000D99 RID: 3481
	Legendary,
	// Token: 0x04000D9A RID: 3482
	SuperLegend
}
