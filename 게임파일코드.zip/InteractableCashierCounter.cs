﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200001C RID: 28
public class InteractableCashierCounter : InteractableObject
{
	// Token: 0x06000143 RID: 323 RVA: 0x000103F0 File Offset: 0x0000E5F0
	protected override void Awake()
	{
		base.Awake();
		ShelfManager.InitCashierCounter(this);
		this.SetPlsaticBagVisibility(false);
		if (!this.m_UICashCounterScreen)
		{
			this.m_UICashCounterScreen = WorldCanvasUIManager.SpawnCashCounterScreenUI(this.m_CounterScreenFollowLoc);
			this.m_UICashCounterScreen.gameObject.SetActive(true);
			this.m_UICashCounterScreen.Init(this);
		}
		if (!this.m_UICreditCardScreen)
		{
			this.m_UICreditCardScreen = WorldCanvasUIManager.SpawnCreditCardScreenUI(this.m_CreditCardScreenFollowLoc);
			this.m_UICreditCardScreen.SetCashierCounter(this);
			this.m_UICreditCardScreen.gameObject.SetActive(true);
		}
	}

	// Token: 0x06000144 RID: 324 RVA: 0x00010488 File Offset: 0x0000E688
	protected override void Update()
	{
		base.Update();
		if (this.m_IsMannedByNPC && this.m_CurrentWorker && !this.m_CurrentWorker.m_IsPausingAction)
		{
			if (this.m_CashierCounterState == ECashierCounterState.ScanningItem)
			{
				this.m_NPCTimer += Time.deltaTime * this.m_NPCScanItemSpeed;
				if (this.m_NPCTimer > this.m_CurrentWorker.m_ScanItemTime)
				{
					bool flag = false;
					if (this.m_CurrentCustomer.GetItemInBagList().Count > 0)
					{
						for (int i = 0; i < this.m_CurrentCustomer.GetItemInBagList().Count; i++)
						{
							if (this.m_CurrentCustomer.GetItemInBagList()[i].m_InteractableScanItem.IsNotScanned())
							{
								this.m_CurrentCustomer.GetItemInBagList()[i].m_InteractableScanItem.OnMouseButtonUp();
								flag = true;
								break;
							}
						}
					}
					if (!flag && this.m_CurrentCustomer.GetCardInBagList().Count > 0)
					{
						for (int j = 0; j < this.m_CurrentCustomer.GetCardInBagList().Count; j++)
						{
							if (this.m_CurrentCustomer.GetCardInBagList()[j].IsNotScanned())
							{
								this.m_CurrentCustomer.GetCardInBagList()[j].OnMouseButtonUp();
								break;
							}
						}
					}
					this.m_NPCTimer = 0f;
					this.PlayWorkerActionAnim();
				}
			}
			else if (this.m_CashierCounterState == ECashierCounterState.TakingCash)
			{
				this.m_NPCTimer += Time.deltaTime;
				if (this.m_NPCTimer > this.m_CurrentWorker.m_GiveChangeTime)
				{
					this.m_CurrentCustomer.m_CustomerCash.OnMouseButtonUp();
					this.m_NPCTimer = 0f;
					this.PlayWorkerActionAnim();
				}
			}
			else if (this.m_CashierCounterState == ECashierCounterState.GivingChange)
			{
				this.m_NPCTimer += Time.deltaTime;
				if (this.m_IsUsingCard)
				{
					if (this.m_NPCTimer > this.m_CurrentWorker.m_GiveChangeTime)
					{
						this.EvaluateCreditCard(this.m_TotalScannedItemCost);
						this.m_NPCTimer = 0f;
						this.PlayWorkerActionAnim();
						this.m_CurrentWorker.CounterNextCustomer(this.m_CustomerQueueCount);
					}
				}
				else if (this.m_NPCTimer > this.m_CurrentWorker.m_GiveChangeTime)
				{
					if (!this.m_IsChangeReady)
					{
						this.NPCEvaluateMoneyChange();
						this.CheckChangeReady();
					}
					else
					{
						this.OnPressSpaceBar();
						this.m_CurrentWorker.CounterNextCustomer(this.m_CustomerQueueCount);
					}
					this.m_NPCTimer = 0f;
					this.PlayWorkerActionAnim();
				}
			}
		}
		if (this.m_IsMannedByPlayer && !CSingleton<CGameManager>.Instance.m_CashierLockMovement)
		{
			if (this.m_IsStartGivingChange && this.m_IsUsingCard)
			{
				return;
			}
			if (InputManager.GetKeyDownAction(EGameAction.MoveForward) || InputManager.GetKeyDownAction(EGameAction.MoveForwardAlt))
			{
				this.OnPressEsc();
				return;
			}
			if (InputManager.GetKeyDownAction(EGameAction.MoveBackward) || InputManager.GetKeyDownAction(EGameAction.MoveBackwardAlt))
			{
				this.OnPressEsc();
				return;
			}
			if (InputManager.GetKeyDownAction(EGameAction.MoveLeft) || InputManager.GetKeyDownAction(EGameAction.MoveLeftAlt))
			{
				this.OnPressEsc();
				return;
			}
			if (InputManager.GetKeyDownAction(EGameAction.MoveRight) || InputManager.GetKeyDownAction(EGameAction.MoveRightAlt))
			{
				this.OnPressEsc();
				return;
			}
			if (InputManager.GetLeftAnalogDown(0, true) || InputManager.GetLeftAnalogDown(0, false))
			{
				this.OnPressEsc();
				return;
			}
			if (InputManager.GetLeftAnalogDown(1, true) || InputManager.GetLeftAnalogDown(1, false))
			{
				this.OnPressEsc();
			}
		}
	}

	// Token: 0x06000145 RID: 325 RVA: 0x000107BC File Offset: 0x0000E9BC
	private void NPCEvaluateMoneyChange()
	{
		float num = GameInstance.GetConvertedCurrencyPrice(this.m_CustomerPaidAmount) - GameInstance.GetConvertedCurrencyPrice(this.m_TotalScannedItemCost) - GameInstance.GetConvertedCurrencyPrice(this.m_CurrentMoneyChangeValue);
		num /= GameInstance.GetCurrencyConversionRate();
		if (this.NPCEvaluateMoneyChangeAction(num, this.m_InteractableCounterMoneyChangeList[4].m_Value, false))
		{
			return;
		}
		if (this.NPCEvaluateMoneyChangeAction(num, this.m_InteractableCounterMoneyChangeList[3].m_Value, false))
		{
			return;
		}
		if (this.NPCEvaluateMoneyChangeAction(num, this.m_InteractableCounterMoneyChangeList[2].m_Value, false))
		{
			return;
		}
		if (this.NPCEvaluateMoneyChangeAction(num, this.m_InteractableCounterMoneyChangeList[1].m_Value, false))
		{
			return;
		}
		if (this.NPCEvaluateMoneyChangeAction(num, this.m_InteractableCounterMoneyChangeList[0].m_Value, false))
		{
			return;
		}
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.Yen)
		{
			if (this.NPCEvaluateMoneyChangeAction(num, this.m_InteractableCounterMoneyChangeList[5].m_Value, false))
			{
				return;
			}
			if (this.NPCEvaluateMoneyChangeAction(num, this.m_InteractableCounterMoneyChangeList[6].m_Value, false))
			{
				return;
			}
			if (this.NPCEvaluateMoneyChangeAction(num, this.m_InteractableCounterMoneyChangeList[7].m_Value, false))
			{
				return;
			}
			if (this.NPCEvaluateMoneyChangeAction(num, this.m_InteractableCounterMoneyChangeList[8].m_Value, false))
			{
				return;
			}
			if (this.NPCEvaluateMoneyChangeAction(num, this.m_InteractableCounterMoneyChangeList[9].m_Value, false))
			{
				return;
			}
			this.NPCEvaluateMoneyChangeAction(this.m_InteractableCounterMoneyChangeList[9].m_Value, this.m_InteractableCounterMoneyChangeList[9].m_Value, true);
		}
		else
		{
			if (this.NPCEvaluateMoneyChangeAction(num, this.m_InteractableCounterMoneyChangeList[9].m_Value, false))
			{
				return;
			}
			if (this.NPCEvaluateMoneyChangeAction(num, this.m_InteractableCounterMoneyChangeList[8].m_Value, false))
			{
				return;
			}
			if (this.NPCEvaluateMoneyChangeAction(num, this.m_InteractableCounterMoneyChangeList[7].m_Value, false))
			{
				return;
			}
			if (this.NPCEvaluateMoneyChangeAction(num, this.m_InteractableCounterMoneyChangeList[6].m_Value, false))
			{
				return;
			}
			if (this.NPCEvaluateMoneyChangeAction(num, this.m_InteractableCounterMoneyChangeList[5].m_Value, false))
			{
				return;
			}
			this.NPCEvaluateMoneyChangeAction(this.m_InteractableCounterMoneyChangeList[5].m_Value, this.m_InteractableCounterMoneyChangeList[5].m_Value, true);
		}
		this.NPCEvaluateMoneyChangeAction(0.01f, 0.01f, true);
	}

	// Token: 0x06000146 RID: 326 RVA: 0x00010A18 File Offset: 0x0000EC18
	private bool NPCEvaluateMoneyChangeAction(float changeRequired, float amount, bool forceGive = false)
	{
		changeRequired = (float)Mathf.RoundToInt(changeRequired * GameInstance.GetCurrencyRoundDivideAmount()) / GameInstance.GetCurrencyRoundDivideAmount();
		int num = Mathf.FloorToInt(changeRequired / amount);
		if (forceGive)
		{
			num = 1;
		}
		if (num > 0)
		{
			for (int i = 0; i < this.m_InteractableCounterMoneyChangeList.Count; i++)
			{
				if (this.m_InteractableCounterMoneyChangeList[i].m_Value == amount)
				{
					this.m_InteractableCounterMoneyChangeList[i].OnMouseButtonUp();
					return true;
				}
			}
		}
		return false;
	}

	// Token: 0x06000147 RID: 327 RVA: 0x00010A8C File Offset: 0x0000EC8C
	public override void OnMouseButtonUp()
	{
		CSingleton<InteractionPlayerController>.Instance.OnEnterCashCounterMode(this);
		this.OnRaycastEnded();
		InteractionPlayerController.SetPlayerPos(this.m_LockPlayerPos.position);
		this.m_IsMannedByPlayer = true;
		this.StopCurrentWorker();
		this.m_IsMannedByNPC = false;
		this.m_NavMeshCutWhenManned.SetActive(true);
		this.EvaluateTooltip();
		TutorialManager.AddTaskValue(ETutorialTaskCondition.InteractCashierCounter, 1f);
		if (this.m_IsUsingCard && this.m_IsStartGivingChange)
		{
			this.StartGivingChange();
		}
	}

	// Token: 0x06000148 RID: 328 RVA: 0x00010B02 File Offset: 0x0000ED02
	public override void OnPressEsc()
	{
		CSingleton<InteractionPlayerController>.Instance.OnExitCashCounterMode();
		this.m_IsMannedByPlayer = false;
		this.m_NavMeshCutWhenManned.SetActive(false);
	}

	// Token: 0x06000149 RID: 329 RVA: 0x00010B24 File Offset: 0x0000ED24
	public override void OnPressSpaceBar()
	{
		if (this.m_IsChangeReady)
		{
			this.m_IsChangeReady = false;
			float num = GameInstance.GetConvertedCurrencyPrice(this.m_CustomerPaidAmount) - GameInstance.GetConvertedCurrencyPrice(this.m_CurrentMoneyChangeValue);
			num /= GameInstance.GetCurrencyConversionRate();
			if (num > 0f)
			{
				CEventManager.QueueEvent(new CEventPlayer_AddCoin(num, false));
			}
			else if (num < 0f)
			{
				CEventManager.QueueEvent(new CEventPlayer_ReduceCoin(Mathf.Abs(num), false));
				CPlayerData.m_GameReportDataCollect.supplyCost = CPlayerData.m_GameReportDataCollect.supplyCost - num;
				CPlayerData.m_GameReportDataCollectPermanent.supplyCost = CPlayerData.m_GameReportDataCollectPermanent.supplyCost - num;
			}
			this.m_CurrentMoneyChangeValue = 0f;
			this.m_TotalScannedItemCost = 0f;
			this.m_CurrentCustomer.CounterGiveChangeCompleted();
			if (this.m_IsUsingCard)
			{
				if (this.m_IsMannedByPlayer)
				{
					CSingleton<InteractionPlayerController>.Instance.ExitUIMode();
					this.m_CreditCardMachineModel.transform.position = this.m_CreditCardMachineOriginalPos;
					this.m_CreditCardMachineModel.transform.rotation = this.m_CreditCardMachineOriginalRot;
					this.m_CreditCardModel.SetActive(false);
				}
				this.m_UICreditCardScreen.ResetCounter();
				this.m_UICashCounterScreen.ResetCounter();
			}
			else
			{
				this.m_OpenCloseDrawerAnim.Play("CashRegisterCloseDrawer");
				this.m_UICashCounterScreen.ResetCounter();
				if (this.m_IsMannedByPlayer)
				{
					SoundManager.PlayAudio("SFX_CheckoutRegisterOpen", 0.6f, 1f);
				}
			}
			for (int i = 0; i < this.m_InteractableCounterMoneyChangeList.Count; i++)
			{
				this.m_InteractableCounterMoneyChangeList[i].ResetAmountGiven();
			}
			if (this.m_IsMannedByPlayer)
			{
				SoundManager.PlayAudio("SFX_CheckoutDone", 0.6f, 1f);
				TutorialManager.AddTaskValue(ETutorialTaskCondition.CheckoutCustomer, 1f);
				InteractionPlayerController.RestoreHiddenToolTip();
				CPlayerData.m_GameReportDataCollect.manualCheckoutCount = CPlayerData.m_GameReportDataCollect.manualCheckoutCount + 1;
				CPlayerData.m_GameReportDataCollectPermanent.manualCheckoutCount = CPlayerData.m_GameReportDataCollectPermanent.manualCheckoutCount + 1;
				AchievementManager.OnCustomerFinishCheckout(CPlayerData.m_GameReportDataCollectPermanent.manualCheckoutCount);
			}
			if (this.m_IsMannedByNPC && this.m_CurrentWorker.m_WorkerTask != EWorkerTask.ManCounter)
			{
				this.StopCurrentWorker();
			}
			this.m_IsStartGivingChange = false;
			return;
		}
		if (this.m_IsMannedByPlayer && this.m_IsStartGivingChange)
		{
			if (this.m_IsUsingCard)
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.WrongCounterCardAmount);
				return;
			}
			if (this.m_TooMuchChangeGiven)
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.TooMuchCounterChangeAmount);
				return;
			}
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.WrongCounterChangeAmount);
		}
	}

	// Token: 0x0600014A RID: 330 RVA: 0x00010D50 File Offset: 0x0000EF50
	public void EvaluateCreditCard(float value)
	{
		if (value == 0f && this.m_IsMannedByPlayer && this.m_IsStartGivingChange)
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.WrongCounterCardAmount);
		}
		if (value >= this.m_TotalScannedItemCost - 0.005f && value <= this.m_TotalScannedItemCost + 0.005f)
		{
			this.m_IsChangeReady = true;
			this.m_CustomerPaidAmount = value;
			this.m_CurrentMoneyChangeValue = 0f;
		}
		else
		{
			this.m_IsChangeReady = false;
		}
		this.OnPressSpaceBar();
	}

	// Token: 0x0600014B RID: 331 RVA: 0x00010DC2 File Offset: 0x0000EFC2
	public override void StartMoveObject()
	{
		if (this.m_ValidQueuePosList.Count > 0)
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.CannotMoveCounterCustomerInQueue);
			return;
		}
		base.StartMoveObject();
	}

	// Token: 0x0600014C RID: 332 RVA: 0x00010DE0 File Offset: 0x0000EFE0
	protected override void OnStartMoveObject()
	{
		base.OnStartMoveObject();
		this.m_UICashCounterScreen.gameObject.SetActive(true);
		this.m_UICreditCardScreen.gameObject.SetActive(true);
		this.StopCurrentWorker();
	}

	// Token: 0x0600014D RID: 333 RVA: 0x00010E10 File Offset: 0x0000F010
	protected override void OnPlacedMovedObject()
	{
		base.OnPlacedMovedObject();
	}

	// Token: 0x0600014E RID: 334 RVA: 0x00010E18 File Offset: 0x0000F018
	public override void BoxUpObject(bool holdBox)
	{
		base.BoxUpObject(holdBox);
		this.m_UICashCounterScreen.gameObject.SetActive(false);
		this.m_UICreditCardScreen.gameObject.SetActive(false);
	}

	// Token: 0x0600014F RID: 335 RVA: 0x00010E44 File Offset: 0x0000F044
	public void AddScannedItemCostTotal(float value, EItemType itemType)
	{
		this.m_TotalScannedItemCost = GameInstance.GetConvertedCurrencyPrice(this.m_TotalScannedItemCost) + GameInstance.GetConvertedCurrencyPrice(value);
		this.m_TotalScannedItemCost /= GameInstance.GetCurrencyConversionRate();
		this.m_TotalScannedItemCost = (float)Mathf.RoundToInt(this.m_TotalScannedItemCost * GameInstance.GetCurrencyRoundDivideAmount()) / GameInstance.GetCurrencyRoundDivideAmount();
		this.m_UICashCounterScreen.OnItemScanned(value, itemType, this.m_TotalScannedItemCost);
		if (this.m_IsMannedByPlayer)
		{
			SoundManager.PlayAudio("SFX_CheckoutScan", 0.25f, 1f);
		}
	}

	// Token: 0x06000150 RID: 336 RVA: 0x00010EC8 File Offset: 0x0000F0C8
	public void AddScannedCardCostTotal(float value, CardData cardData)
	{
		this.m_TotalScannedItemCost = GameInstance.GetConvertedCurrencyPrice(this.m_TotalScannedItemCost) + GameInstance.GetConvertedCurrencyPrice(value);
		this.m_TotalScannedItemCost /= GameInstance.GetCurrencyConversionRate();
		this.m_TotalScannedItemCost = (float)Mathf.RoundToInt(this.m_TotalScannedItemCost * GameInstance.GetCurrencyRoundDivideAmount()) / GameInstance.GetCurrencyRoundDivideAmount();
		this.m_UICashCounterScreen.OnCardScanned(value, cardData, this.m_TotalScannedItemCost);
		if (this.m_IsMannedByPlayer)
		{
			SoundManager.PlayAudio("SFX_CheckoutScan", 0.25f, 1f);
		}
	}

	// Token: 0x06000151 RID: 337 RVA: 0x00010F4C File Offset: 0x0000F14C
	public void SetCustomerPaidAmount(bool isUseCard, float customerPaidAmount)
	{
		this.m_IsUsingCard = isUseCard;
		this.m_CustomerPaidAmount = customerPaidAmount;
	}

	// Token: 0x06000152 RID: 338 RVA: 0x00010F5C File Offset: 0x0000F15C
	public void StartGivingChange()
	{
		this.m_IsStartGivingChange = true;
		if (this.m_IsUsingCard)
		{
			if (this.m_IsMannedByPlayer)
			{
				CSingleton<InteractionPlayerController>.Instance.EnterUIMode();
				CSingleton<InteractionPlayerController>.Instance.ForceLookAt(this.m_CreditCardPlayerLookRot, 3f);
				this.m_CreditCardMachineOriginalPos = this.m_CreditCardMachineModel.transform.position;
				this.m_CreditCardMachineOriginalRot = this.m_CreditCardMachineModel.transform.rotation;
				this.m_CreditCardMachineModel.transform.position = this.m_CreditCardMachineTargetPos.position;
				this.m_CreditCardMachineModel.transform.rotation = this.m_CreditCardMachineTargetPos.rotation;
				this.m_CreditCardModel.SetActive(true);
			}
			this.m_UICreditCardScreen.EnableCreditCardMode(this.m_IsMannedByPlayer);
			this.m_UICashCounterScreen.ShowScaledUpTotalCost();
			return;
		}
		this.m_ChangeMoneyAddedCount = 0;
		this.m_ChangeCoinAddedCount = 0;
		this.m_UICashCounterScreen.OnStartGivingChange();
		this.m_OpenCloseDrawerAnim.Play("CashRegisterOpenDrawer");
		this.CheckChangeReady();
		if (this.m_IsMannedByPlayer)
		{
			SoundManager.PlayAudio("SFX_CheckoutRegisterOpen", 0.6f, 1f);
		}
		if (this.m_CurrentCurrencyType != CSingleton<CGameManager>.Instance.m_CurrencyType)
		{
			this.m_CurrentCurrencyType = CSingleton<CGameManager>.Instance.m_CurrencyType;
			for (int i = 0; i < this.m_InteractableCounterMoneyChangeList.Count; i++)
			{
				this.m_InteractableCounterMoneyChangeList[i].UpdateCurrency();
			}
		}
	}

	// Token: 0x06000153 RID: 339 RVA: 0x000110C5 File Offset: 0x0000F2C5
	public bool CanGiveChange(float value)
	{
		return (GameInstance.GetConvertedCurrencyPrice(this.m_CurrentMoneyChangeValue) + GameInstance.GetConvertedCurrencyPrice(value)) / GameInstance.GetCurrencyConversionRate() <= this.m_CustomerPaidAmount;
	}

	// Token: 0x06000154 RID: 340 RVA: 0x000110EC File Offset: 0x0000F2EC
	public void OnGiveChange(float value, bool isTakingBack)
	{
		if (isTakingBack)
		{
			if (value >= 1f)
			{
				this.m_ChangeMoneyAddedCount--;
			}
			else
			{
				this.m_ChangeCoinAddedCount--;
			}
			this.m_CurrentMoneyChangeValue = GameInstance.GetConvertedCurrencyPrice(this.m_CurrentMoneyChangeValue) - GameInstance.GetConvertedCurrencyPrice(value);
			this.m_CurrentMoneyChangeValue /= GameInstance.GetCurrencyConversionRate();
		}
		else
		{
			if (value >= 1f)
			{
				this.m_ChangeMoneyAddedCount++;
			}
			else
			{
				this.m_ChangeCoinAddedCount++;
			}
			this.m_CurrentMoneyChangeValue = GameInstance.GetConvertedCurrencyPrice(this.m_CurrentMoneyChangeValue) + GameInstance.GetConvertedCurrencyPrice(value);
			this.m_CurrentMoneyChangeValue /= GameInstance.GetCurrencyConversionRate();
		}
		this.m_CurrentMoneyChangeValue = Mathf.Round(this.m_CurrentMoneyChangeValue * GameInstance.GetCurrencyRoundDivideAmount()) / GameInstance.GetCurrencyRoundDivideAmount();
		this.CheckChangeReady();
		if (this.m_IsMannedByPlayer)
		{
			SoundManager.PlayAudio("SFX_WhipSoft", 0.4f, 1f);
		}
	}

	// Token: 0x06000155 RID: 341 RVA: 0x000111E0 File Offset: 0x0000F3E0
	public Vector3 GetChangeMoneyPosYOffset(bool isCoin, int count)
	{
		if (isCoin)
		{
			if (this.m_ChangeCoinAddedCount >= 150)
			{
				return Vector3.up * 0.005f;
			}
			return Vector3.up * (0.005f * (float)Mathf.Clamp(count, 0, 150));
		}
		else
		{
			if (this.m_ChangeMoneyAddedCount >= 150)
			{
				return Vector3.up * 0.001f;
			}
			return Vector3.up * (0.001f * (float)Mathf.Clamp(count, 0, 150));
		}
	}

	// Token: 0x06000156 RID: 342 RVA: 0x00011268 File Offset: 0x0000F468
	private void CheckChangeReady()
	{
		float num = GameInstance.GetConvertedCurrencyPrice(this.m_CustomerPaidAmount) - GameInstance.GetConvertedCurrencyPrice(this.m_TotalScannedItemCost) - GameInstance.GetConvertedCurrencyPrice(0.001f);
		num /= GameInstance.GetCurrencyConversionRate();
		num = Mathf.Round(num * GameInstance.GetCurrencyRoundDivideAmount()) / GameInstance.GetCurrencyRoundDivideAmount();
		if (this.m_CurrentMoneyChangeValue >= num && this.m_TotalScannedItemCost > 0f)
		{
			if (Mathf.Round((GameInstance.GetConvertedCurrencyPrice(this.m_CustomerPaidAmount) - GameInstance.GetConvertedCurrencyPrice(this.m_TotalScannedItemCost) - GameInstance.GetConvertedCurrencyPrice(this.m_CurrentMoneyChangeValue) - GameInstance.GetConvertedCurrencyPrice(0.001f)) / GameInstance.GetCurrencyConversionRate() * GameInstance.GetCurrencyRoundDivideAmount()) / GameInstance.GetCurrencyRoundDivideAmount() < -2f)
			{
				this.m_IsChangeReady = false;
				this.m_TooMuchChangeGiven = true;
			}
			else
			{
				this.m_IsChangeReady = true;
				this.m_TooMuchChangeGiven = false;
			}
		}
		else
		{
			this.m_IsChangeReady = false;
			this.m_TooMuchChangeGiven = false;
		}
		this.m_UICashCounterScreen.UpdateMoneyChangeAmount(this.m_IsChangeReady, this.m_CustomerPaidAmount, this.m_TotalScannedItemCost, this.m_CurrentMoneyChangeValue);
	}

	// Token: 0x06000157 RID: 343 RVA: 0x00011368 File Offset: 0x0000F568
	public Transform GetQueuePosition()
	{
		if (this.m_CustomerQueueCount == 0)
		{
			for (int i = 0; i < this.m_QueueTransformList.Count; i++)
			{
				if (!this.m_QueueTransformList[i].gameObject.activeSelf && !this.m_ValidQueuePosList.Contains(this.m_QueueTransformList[i].transform))
				{
					this.m_QueueTransformList[i].transform.position = this.m_QueueStartPos.position;
					this.m_QueueTransformList[i].transform.rotation = this.m_QueueStartPos.rotation;
					this.m_QueueTransformList[i].gameObject.SetActive(true);
					this.m_ValidQueuePosList.Add(this.m_QueueTransformList[i].transform);
					this.m_CustomerQueueCount++;
					return this.m_QueueTransformList[i].transform;
				}
			}
		}
		else
		{
			Transform transform = this.m_ValidQueuePosList[this.m_ValidQueuePosList.Count - 1];
			int mask = LayerMask.GetMask(new string[]
			{
				"ShopModel",
				"Glass",
				"Customer",
				"QueueBlocker"
			});
			Vector3 vector = transform.position - transform.forward;
			Collider[] array = Physics.OverlapBox(vector + Vector3.up, Vector3.one * 0.25f, transform.rotation, mask);
			Collider[] array2 = Physics.OverlapBox(transform.position - transform.forward * 0.5f + Vector3.up, Vector3.one * 0.25f, transform.rotation, mask);
			Vector3 vector2 = transform.position + transform.right;
			Collider[] array3 = Physics.OverlapBox(vector2 + Vector3.up, Vector3.one * 0.25f, transform.rotation, mask);
			Collider[] array4 = Physics.OverlapBox(transform.position + transform.right * 0.5f + Vector3.up, Vector3.one * 0.25f, transform.rotation, mask);
			Vector3 vector3 = transform.position - transform.right;
			Collider[] array5 = Physics.OverlapBox(vector3 + Vector3.up, Vector3.one * 0.25f, transform.rotation, mask);
			Collider[] array6 = Physics.OverlapBox(transform.position - transform.right * 0.5f + Vector3.up, Vector3.one * 0.25f, transform.rotation, mask);
			List<int> list = new List<int>();
			if (array.Length == 0 && array2.Length == 0)
			{
				list.Add(0);
			}
			if (array3.Length == 0 && array4.Length == 0)
			{
				list.Add(1);
			}
			if (array5.Length == 0 && array6.Length == 0)
			{
				list.Add(2);
			}
			if (list.Count == 0)
			{
				return null;
			}
			int num = list[Random.Range(0, list.Count)];
			for (int j = 0; j < this.m_QueueTransformList.Count; j++)
			{
				if (!this.m_QueueTransformList[j].gameObject.activeSelf && !this.m_ValidQueuePosList.Contains(this.m_QueueTransformList[j].transform))
				{
					if (num == 0)
					{
						this.m_QueueTransformList[j].transform.position = vector;
					}
					else if (num == 1)
					{
						this.m_QueueTransformList[j].transform.position = vector2;
					}
					else if (num == 2)
					{
						this.m_QueueTransformList[j].transform.position = vector3;
					}
					this.m_QueueTransformList[j].transform.LookAt(transform.transform, Vector3.up);
					this.m_QueueTransformList[j].gameObject.SetActive(true);
					this.m_ValidQueuePosList.Add(this.m_QueueTransformList[j].transform);
					this.m_CustomerQueueCount++;
					return this.m_QueueTransformList[j].transform;
				}
			}
		}
		return null;
	}

	// Token: 0x06000158 RID: 344 RVA: 0x000117BC File Offset: 0x0000F9BC
	public void RemoveCurrentCustomerFromQueue()
	{
		if (this.m_CustomerQueueCount > 0)
		{
			if (this.m_ValidQueuePosList.Count > 1)
			{
				int num = this.m_ValidQueuePosList.Count - 1;
				while (num >= 0 && num != 0)
				{
					this.m_ValidQueuePosList[num].transform.position = this.m_ValidQueuePosList[num - 1].transform.position;
					this.m_ValidQueuePosList[num].transform.rotation = this.m_ValidQueuePosList[num - 1].transform.rotation;
					num--;
				}
			}
			this.m_ValidQueuePosList[0].gameObject.SetActive(false);
			this.m_ValidQueuePosList.RemoveAt(0);
			this.m_CustomerQueueCount--;
			for (int i = 0; i < this.m_CustomerListInQueue.Count; i++)
			{
				this.m_CustomerListInQueue[i].OnCashierCounterQueueMoved(i);
			}
		}
	}

	// Token: 0x06000159 RID: 345 RVA: 0x000118B3 File Offset: 0x0000FAB3
	public Worker GetCurrentWorker()
	{
		return this.m_CurrentWorker;
	}

	// Token: 0x0600015A RID: 346 RVA: 0x000118BB File Offset: 0x0000FABB
	public void SetCurrentWorker(Worker worker)
	{
		this.m_CurrentWorker = worker;
		if (worker == null)
		{
			this.m_IsMannedByNPC = false;
			this.m_NavMeshCutWhenManned.SetActive(false);
		}
	}

	// Token: 0x0600015B RID: 347 RVA: 0x000118E0 File Offset: 0x0000FAE0
	public void NPCStartManCounter(Worker worker)
	{
		this.m_IsMannedByNPC = true;
		this.m_NavMeshCutWhenManned.SetActive(true);
	}

	// Token: 0x0600015C RID: 348 RVA: 0x000118F5 File Offset: 0x0000FAF5
	public void PlayWorkerActionAnim()
	{
		if (this.m_CurrentWorker)
		{
			this.m_CurrentWorker.PlayWorkerActionAnim();
		}
	}

	// Token: 0x0600015D RID: 349 RVA: 0x0001190F File Offset: 0x0000FB0F
	public void StopCurrentWorker()
	{
		if (this.m_CurrentWorker)
		{
			this.m_IsMannedByNPC = false;
			this.m_CurrentWorker.StopManningCounter();
			this.m_CurrentWorker = null;
			this.m_NavMeshCutWhenManned.SetActive(false);
		}
	}

	// Token: 0x0600015E RID: 350 RVA: 0x00011943 File Offset: 0x0000FB43
	public void AddCustomerToQueue(Customer customer)
	{
		this.m_CustomerListInQueue.Add(customer);
	}

	// Token: 0x0600015F RID: 351 RVA: 0x00011951 File Offset: 0x0000FB51
	public void RemoveCustomerFromQueue(Customer customer)
	{
		this.m_CustomerListInQueue.Remove(customer);
	}

	// Token: 0x06000160 RID: 352 RVA: 0x00011960 File Offset: 0x0000FB60
	public void UpdateCurrentCustomer(Customer customer)
	{
		this.m_CurrentCustomer = customer;
		this.m_TotalScannedItemCost = 0f;
		this.m_CurrentMoneyChangeValue = 0f;
	}

	// Token: 0x06000161 RID: 353 RVA: 0x0001197F File Offset: 0x0000FB7F
	public void UpdateCashierCounterState(ECashierCounterState state)
	{
		this.m_CashierCounterState = state;
		this.EvaluateTooltip();
	}

	// Token: 0x06000162 RID: 354 RVA: 0x00011990 File Offset: 0x0000FB90
	private void EvaluateTooltip()
	{
		if (this.m_IsMannedByPlayer)
		{
			if (this.m_CashierCounterState == ECashierCounterState.TakingCash)
			{
				InteractionPlayerController.TempHideToolTip();
				InteractionPlayerController.AddToolTip(EGameAction.InteractLeft, false, false);
				return;
			}
			if (this.m_CashierCounterState == ECashierCounterState.GivingChange)
			{
				InteractionPlayerController.TempHideToolTip();
				if (this.m_IsUsingCard)
				{
					InteractionPlayerController.AddToolTip(EGameAction.InteractLeft, false, false);
					InteractionPlayerController.AddToolTip(EGameAction.DoneCounter, false, false);
					return;
				}
				InteractionPlayerController.AddToolTip(EGameAction.AddChange, true, false);
				InteractionPlayerController.AddToolTip(EGameAction.RemoveChange, true, false);
				InteractionPlayerController.AddToolTip(EGameAction.DoneCounter, false, false);
				return;
			}
			else
			{
				InteractionPlayerController.RestoreHiddenToolTip();
			}
		}
	}

	// Token: 0x06000163 RID: 355 RVA: 0x00011A07 File Offset: 0x0000FC07
	public bool IsCustomerAtPayingPosition(Vector3 customerTargetPos)
	{
		return customerTargetPos == this.m_QueueStartPos.position;
	}

	// Token: 0x06000164 RID: 356 RVA: 0x00011A1F File Offset: 0x0000FC1F
	public bool IsCustomerNextInLine(Customer customer)
	{
		return this.m_CustomerListInQueue.Count > 0 && this.m_CustomerListInQueue[0] == customer;
	}

	// Token: 0x06000165 RID: 357 RVA: 0x00011A46 File Offset: 0x0000FC46
	public int GetCurrentQueingCustomerCount()
	{
		return this.m_ValidQueuePosList.Count;
	}

	// Token: 0x06000166 RID: 358 RVA: 0x00011A53 File Offset: 0x0000FC53
	public bool IsMannedByNPC()
	{
		return this.m_IsMannedByNPC;
	}

	// Token: 0x06000167 RID: 359 RVA: 0x00011A5B File Offset: 0x0000FC5B
	public bool IsMannedByPlayer()
	{
		return this.m_IsMannedByPlayer;
	}

	// Token: 0x06000168 RID: 360 RVA: 0x00011A63 File Offset: 0x0000FC63
	public void SetPlsaticBagVisibility(bool isShow)
	{
		this.m_ScanItemPlasticBag.SetActive(isShow);
	}

	// Token: 0x06000169 RID: 361 RVA: 0x00011A71 File Offset: 0x0000FC71
	public override void OnDestroyed()
	{
		ShelfManager.RemoveCashierCounter(this);
		Object.Destroy(this.m_UICashCounterScreen.gameObject);
		Object.Destroy(this.m_UICreditCardScreen.gameObject);
		this.m_UICashCounterScreen = null;
		this.m_UICreditCardScreen = null;
		base.OnDestroyed();
	}

	// Token: 0x0600016A RID: 362 RVA: 0x00011AAD File Offset: 0x0000FCAD
	public bool IsGivingChange()
	{
		return this.m_CashierCounterState == ECashierCounterState.GivingChange;
	}

	// Token: 0x0600016B RID: 363 RVA: 0x00011AB8 File Offset: 0x0000FCB8
	private void ForceResetCounter()
	{
		for (int i = 0; i < this.m_QueueTransformList.Count; i++)
		{
			this.m_QueueTransformList[i].SetActive(false);
		}
		if (this.m_IsStartGivingChange)
		{
			this.m_OpenCloseDrawerAnim.Play("CashRegisterCloseDrawer");
			for (int j = 0; j < this.m_InteractableCounterMoneyChangeList.Count; j++)
			{
				this.m_InteractableCounterMoneyChangeList[j].ResetAmountGiven();
			}
		}
		this.m_CustomerListInQueue.Clear();
		this.UpdateCashierCounterState(ECashierCounterState.Idle);
		this.m_UICashCounterScreen.ResetCounter();
		this.UpdateCurrentCustomer(null);
		this.m_CurrentWorker = null;
		this.SetPlsaticBagVisibility(false);
		this.m_NPCTimer = 0f;
		this.m_TotalScannedItemCost = 0f;
		this.m_CurrentMoneyChangeValue = 0f;
		this.m_CustomerPaidAmount = 0f;
		this.m_IsChangeReady = false;
		this.m_IsUsingCard = false;
		this.m_IsMannedByPlayer = false;
		this.m_IsMannedByNPC = false;
		this.m_IsStartGivingChange = false;
		this.m_ValidQueuePosList.Clear();
		this.m_CustomerQueueCount = 0;
		this.m_NavMeshCutWhenManned.SetActive(false);
	}

	// Token: 0x0600016C RID: 364 RVA: 0x00011BCC File Offset: 0x0000FDCC
	public int GetCustomerInQueueCount()
	{
		return this.m_CustomerQueueCount;
	}

	// Token: 0x0600016D RID: 365 RVA: 0x00011BD4 File Offset: 0x0000FDD4
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.AddListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x0600016E RID: 366 RVA: 0x00011C06 File Offset: 0x0000FE06
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.RemoveListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x0600016F RID: 367 RVA: 0x00011C38 File Offset: 0x0000FE38
	protected void OnDayStarted(CEventPlayer_OnDayStarted evt)
	{
		this.ForceResetCounter();
	}

	// Token: 0x06000170 RID: 368 RVA: 0x00011C40 File Offset: 0x0000FE40
	protected void OnMoneyCurrencyUpdated(CEventPlayer_OnMoneyCurrencyUpdated evt)
	{
		if (!this.m_IsUsingCard)
		{
			this.m_ChangeMoneyAddedCount = 0;
			this.m_CurrentMoneyChangeValue = 0f;
			this.CheckChangeReady();
		}
	}

	// Token: 0x040001B2 RID: 434
	public Transform m_LockPlayerPos;

	// Token: 0x040001B3 RID: 435
	public Transform m_QueueStartPos;

	// Token: 0x040001B4 RID: 436
	public Transform m_CustomerPlaceItemPos;

	// Token: 0x040001B5 RID: 437
	public Transform m_ScannedItemLerpPos;

	// Token: 0x040001B6 RID: 438
	public Transform m_PlaceMoneyLocation;

	// Token: 0x040001B7 RID: 439
	public Transform m_PlaceCoinLocation;

	// Token: 0x040001B8 RID: 440
	public Transform m_CounterScreenFollowLoc;

	// Token: 0x040001B9 RID: 441
	public Transform m_CreditCardScreenFollowLoc;

	// Token: 0x040001BA RID: 442
	public Transform m_CreditCardMachineModel;

	// Token: 0x040001BB RID: 443
	public Transform m_CreditCardMachineTargetPos;

	// Token: 0x040001BC RID: 444
	public Transform m_CreditCardPlayerLookRot;

	// Token: 0x040001BD RID: 445
	private Vector3 m_CreditCardMachineOriginalPos;

	// Token: 0x040001BE RID: 446
	private Quaternion m_CreditCardMachineOriginalRot;

	// Token: 0x040001BF RID: 447
	public GameObject m_CreditCardModel;

	// Token: 0x040001C0 RID: 448
	public GameObject m_ScanItemPlasticBag;

	// Token: 0x040001C1 RID: 449
	public GameObject m_NavMeshCutWhenManned;

	// Token: 0x040001C2 RID: 450
	public Animation m_OpenCloseDrawerAnim;

	// Token: 0x040001C3 RID: 451
	public List<GameObject> m_QueueTransformList;

	// Token: 0x040001C4 RID: 452
	public List<InteractableCounterMoneyChange> m_InteractableCounterMoneyChangeList;

	// Token: 0x040001C5 RID: 453
	public bool m_IsMannedByNPC;

	// Token: 0x040001C6 RID: 454
	private bool m_IsMannedByPlayer;

	// Token: 0x040001C7 RID: 455
	private bool m_IsStartGivingChange;

	// Token: 0x040001C8 RID: 456
	public int m_CustomerQueueCount;

	// Token: 0x040001C9 RID: 457
	public List<Transform> m_ValidQueuePosList = new List<Transform>();

	// Token: 0x040001CA RID: 458
	private Worker m_CurrentWorker;

	// Token: 0x040001CB RID: 459
	public Customer m_CurrentCustomer;

	// Token: 0x040001CC RID: 460
	public List<Customer> m_CustomerListInQueue = new List<Customer>();

	// Token: 0x040001CD RID: 461
	private UI_CashCounterScreen m_UICashCounterScreen;

	// Token: 0x040001CE RID: 462
	private UI_CreditCardScreen m_UICreditCardScreen;

	// Token: 0x040001CF RID: 463
	public ECashierCounterState m_CashierCounterState;

	// Token: 0x040001D0 RID: 464
	private int m_ChangeMoneyAddedCount;

	// Token: 0x040001D1 RID: 465
	private int m_ChangeCoinAddedCount;

	// Token: 0x040001D2 RID: 466
	private float m_NPCTimer;

	// Token: 0x040001D3 RID: 467
	private float m_NPCScanItemSpeed = 1.5f;

	// Token: 0x040001D4 RID: 468
	private float m_TotalScannedItemCost;

	// Token: 0x040001D5 RID: 469
	private float m_CustomerPaidAmount;

	// Token: 0x040001D6 RID: 470
	private float m_CurrentMoneyChangeValue;

	// Token: 0x040001D7 RID: 471
	private bool m_IsChangeReady;

	// Token: 0x040001D8 RID: 472
	private bool m_TooMuchChangeGiven;

	// Token: 0x040001D9 RID: 473
	private bool m_IsUsingCard;

	// Token: 0x040001DA RID: 474
	private EMoneyCurrencyType m_CurrentCurrencyType = EMoneyCurrencyType.None;
}
