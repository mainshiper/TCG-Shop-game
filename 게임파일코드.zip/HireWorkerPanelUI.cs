﻿using System;
using I2.Loc;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200006B RID: 107
public class HireWorkerPanelUI : UIElementBase
{
	// Token: 0x0600049C RID: 1180 RVA: 0x000281C8 File Offset: 0x000263C8
	public void Init(HireWorkerScreen hireWorkerScreen, int index)
	{
		this.m_HireWorkerScreen = hireWorkerScreen;
		this.m_Index = index;
		WorkerData workerData = WorkerManager.GetWorkerData(index);
		this.m_IconImage.sprite = workerData.icon;
		this.m_NameText.text = workerData.GetName();
		this.m_RestockSpeedText.text = workerData.GetRestockSpeedText();
		this.m_CheckoutSpeedText.text = workerData.GetCheckoutSpeedText();
		this.m_SalaryCostText.text = workerData.GetSalaryCostText();
		this.m_Description.text = workerData.GetDescription();
		this.m_TotalHireFee = workerData.hiringCost;
		this.m_LevelRequired = workerData.shopLevelRequired;
		this.m_HireFeeText.text = GameInstance.GetPriceString(this.m_TotalHireFee, false, true, false, "F2");
		if (this.m_LevelRequirementString == "")
		{
			this.m_LevelRequirementString = this.m_LevelRequirementText.text;
		}
		if (CPlayerData.m_ShopLevel + 1 >= this.m_LevelRequired)
		{
			this.m_LevelRequirementText.gameObject.SetActive(false);
			this.m_HireFeeText.gameObject.SetActive(true);
			this.m_LockPurchaseBtn.gameObject.SetActive(false);
		}
		else
		{
			this.m_LevelRequirementText.text = LocalizationManager.GetTranslation(this.m_LevelRequirementString, true, 0, true, false, null, null, true).Replace("XXX", this.m_LevelRequired.ToString());
			this.m_LevelRequirementText.gameObject.SetActive(true);
			this.m_HireFeeText.gameObject.SetActive(false);
			this.m_LockPurchaseBtn.gameObject.SetActive(true);
		}
		this.EvaluateHired();
		if (CSingleton<CGameManager>.Instance.m_IsPrologue && !workerData.prologueShow)
		{
			this.m_PrologueUIGrp.SetActive(true);
			this.m_LockPurchaseBtn.gameObject.SetActive(true);
			return;
		}
		this.m_PrologueUIGrp.SetActive(false);
	}

	// Token: 0x0600049D RID: 1181 RVA: 0x00028398 File Offset: 0x00026598
	private void EvaluateHired()
	{
		this.m_IsHired = CPlayerData.GetIsWorkerHired(this.m_Index);
		if (this.m_IsHired)
		{
			this.m_HiredText.SetActive(true);
			this.m_PurchaseBtn.SetActive(false);
			this.m_HireFeeText.gameObject.SetActive(false);
			return;
		}
		this.m_HiredText.SetActive(false);
		this.m_PurchaseBtn.SetActive(true);
	}

	// Token: 0x0600049E RID: 1182 RVA: 0x00028400 File Offset: 0x00026600
	public void OnPressHireButton()
	{
		if (this.m_IsHired)
		{
			return;
		}
		if (CPlayerData.m_ShopLevel + 1 < this.m_LevelRequired)
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.ShopLevelNotEnough);
			return;
		}
		if (CPlayerData.m_CoinAmount >= this.m_TotalHireFee)
		{
			CEventManager.QueueEvent(new CEventPlayer_ReduceCoin(this.m_TotalHireFee, false));
			CPlayerData.SetIsWorkerHired(this.m_Index, true);
			CSingleton<WorkerManager>.Instance.ActivateWorker(this.m_Index, true);
			CPlayerData.m_GameReportDataCollect.employeeCost = CPlayerData.m_GameReportDataCollect.employeeCost - this.m_TotalHireFee;
			CPlayerData.m_GameReportDataCollectPermanent.employeeCost = CPlayerData.m_GameReportDataCollectPermanent.employeeCost - this.m_TotalHireFee;
			int num = 0;
			for (int i = 0; i < CPlayerData.m_IsWorkerHired.Count; i++)
			{
				if (CPlayerData.m_IsWorkerHired[i])
				{
					num++;
				}
			}
			AchievementManager.OnStaffHired(num);
			SoundManager.PlayAudio("SFX_CustomerBuy", 0.6f, 1f);
			this.EvaluateHired();
			return;
		}
		NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.Money);
	}

	// Token: 0x040005BB RID: 1467
	public Image m_IconImage;

	// Token: 0x040005BC RID: 1468
	public TextMeshProUGUI m_NameText;

	// Token: 0x040005BD RID: 1469
	public TextMeshProUGUI m_RestockSpeedText;

	// Token: 0x040005BE RID: 1470
	public TextMeshProUGUI m_CheckoutSpeedText;

	// Token: 0x040005BF RID: 1471
	public TextMeshProUGUI m_SalaryCostText;

	// Token: 0x040005C0 RID: 1472
	public TextMeshProUGUI m_HireFeeText;

	// Token: 0x040005C1 RID: 1473
	public TextMeshProUGUI m_LevelRequirementText;

	// Token: 0x040005C2 RID: 1474
	public TextMeshProUGUI m_Description;

	// Token: 0x040005C3 RID: 1475
	private string m_LevelRequirementString = "";

	// Token: 0x040005C4 RID: 1476
	public GameObject m_HiredText;

	// Token: 0x040005C5 RID: 1477
	public GameObject m_PurchaseBtn;

	// Token: 0x040005C6 RID: 1478
	public GameObject m_LockPurchaseBtn;

	// Token: 0x040005C7 RID: 1479
	public GameObject m_PrologueUIGrp;

	// Token: 0x040005C8 RID: 1480
	private HireWorkerScreen m_HireWorkerScreen;

	// Token: 0x040005C9 RID: 1481
	private bool m_IsHired;

	// Token: 0x040005CA RID: 1482
	private int m_Index;

	// Token: 0x040005CB RID: 1483
	private int m_LevelRequired;

	// Token: 0x040005CC RID: 1484
	private float m_TotalHireFee;
}
