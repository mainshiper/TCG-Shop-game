﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000061 RID: 97
public class EndDayReportTextUI : MonoBehaviour
{
	// Token: 0x06000444 RID: 1092 RVA: 0x000255BC File Offset: 0x000237BC
	public void SetNumber(float start, float end, float lerpTime, Color positiveColor, Color negativeColor, Color neutralColor)
	{
		this.m_IsLerpEnded = false;
		this.m_LerpTimer = 0f;
		this.m_LerpTime = lerpTime;
		if (this.m_LerpTime <= 0f)
		{
			this.m_LerpTime = 0.01f;
		}
		this.m_LerpStart = start;
		this.m_LerpTarget = end;
		if (this.m_LerpStart == this.m_LerpTarget)
		{
			this.m_LerpTime /= 2f;
		}
		base.gameObject.SetActive(false);
		if (end > 0f)
		{
			this.m_Text.color = positiveColor;
			return;
		}
		if (end < 0f)
		{
			this.m_Text.color = negativeColor;
			return;
		}
		this.m_Text.color = neutralColor;
	}

	// Token: 0x06000445 RID: 1093 RVA: 0x00025670 File Offset: 0x00023870
	public void UpdateLerp()
	{
		if (this.m_IsLerpEnded)
		{
			return;
		}
		if (this.m_LerpTimer == 0f)
		{
			base.gameObject.SetActive(true);
			if (this.m_LerpStart != this.m_LerpTarget)
			{
				SoundManager.SetEnableSound_CoinIncrease(true);
			}
		}
		this.m_LerpTimer += Time.deltaTime / this.m_LerpTime;
		this.m_LerpNumber = Mathf.Lerp(this.m_LerpStart, this.m_LerpTarget, this.m_LerpTimer);
		if (this.m_IsTime)
		{
			this.m_Text.text = GameInstance.GetTimeString((float)Mathf.FloorToInt(this.m_LerpNumber), false, true, true, false, false, true);
		}
		else if (this.m_IsInt)
		{
			if (this.m_IsShowPlusSymbol && this.m_LerpNumber > 0f)
			{
				this.m_Text.text = "+" + Mathf.FloorToInt(this.m_LerpNumber).ToString();
			}
			else
			{
				this.m_Text.text = Mathf.FloorToInt(this.m_LerpNumber).ToString();
			}
		}
		else if (this.m_IsPrice)
		{
			if (this.m_IsShowPlusSymbol && this.m_LerpNumber > 0f)
			{
				this.m_Text.text = "+" + GameInstance.GetPriceString(this.m_LerpNumber, false, true, false, "F2");
			}
			else
			{
				this.m_Text.text = GameInstance.GetPriceString(this.m_LerpNumber, false, true, false, "F2");
			}
		}
		else if (this.m_IsShowPlusSymbol && this.m_LerpNumber > 0f)
		{
			this.m_Text.text = "+" + this.m_LerpNumber.ToString("F2");
		}
		else
		{
			this.m_Text.text = this.m_LerpNumber.ToString("F2");
		}
		if (this.m_LerpTimer >= 1f)
		{
			this.m_IsLerpEnded = true;
			SoundManager.SetEnableSound_CoinIncrease(false);
		}
	}

	// Token: 0x06000446 RID: 1094 RVA: 0x0002585D File Offset: 0x00023A5D
	public void EndLerpInstantly()
	{
		base.gameObject.SetActive(true);
		this.m_LerpTimer = 1f;
		this.UpdateLerp();
	}

	// Token: 0x06000447 RID: 1095 RVA: 0x0002587C File Offset: 0x00023A7C
	public bool IsLerpEnded()
	{
		return this.m_IsLerpEnded;
	}

	// Token: 0x04000516 RID: 1302
	public TextMeshProUGUI m_Text;

	// Token: 0x04000517 RID: 1303
	public bool m_IsInt;

	// Token: 0x04000518 RID: 1304
	public bool m_IsPrice;

	// Token: 0x04000519 RID: 1305
	public bool m_IsTime;

	// Token: 0x0400051A RID: 1306
	public bool m_IsShowPlusSymbol;

	// Token: 0x0400051B RID: 1307
	private bool m_IsLerpEnded;

	// Token: 0x0400051C RID: 1308
	private float m_LerpNumber;

	// Token: 0x0400051D RID: 1309
	private float m_LerpStart;

	// Token: 0x0400051E RID: 1310
	private float m_LerpTarget;

	// Token: 0x0400051F RID: 1311
	private float m_LerpTimer;

	// Token: 0x04000520 RID: 1312
	private float m_LerpTime;
}
