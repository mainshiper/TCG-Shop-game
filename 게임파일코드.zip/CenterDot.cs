﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200005A RID: 90
public class CenterDot : CSingleton<CenterDot>
{
	// Token: 0x06000407 RID: 1031 RVA: 0x000240A0 File Offset: 0x000222A0
	private void Start()
	{
		this.EvaluateDot();
	}

	// Token: 0x06000408 RID: 1032 RVA: 0x000240A8 File Offset: 0x000222A8
	public static void SetVisibility(bool isVisible)
	{
		CSingleton<CenterDot>.Instance.m_DotImage.enabled = isVisible;
	}

	// Token: 0x06000409 RID: 1033 RVA: 0x000240BC File Offset: 0x000222BC
	private void EvaluateDot()
	{
		if (CSingleton<CGameManager>.Instance.m_CenterDotHasOutline)
		{
			this.m_DotImage.sprite = this.m_OutlineSpriteList[CSingleton<CGameManager>.Instance.m_CenterDotSpriteTypeIndex];
		}
		else
		{
			this.m_DotImage.sprite = this.m_SpriteList[CSingleton<CGameManager>.Instance.m_CenterDotSpriteTypeIndex];
		}
		this.m_DotImage.color = this.m_ColorList[CSingleton<CGameManager>.Instance.m_CenterDotColorIndex];
		this.m_DotImage.transform.localScale = Vector3.one * Mathf.Clamp(CSingleton<CGameManager>.Instance.m_CenterDotSizeSlider, 0.05f, 1f);
	}

	// Token: 0x0600040A RID: 1034 RVA: 0x0002416A File Offset: 0x0002236A
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.AddListener<CEventPlayer_OnSettingUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnSettingUpdated>(this.OnSettingUpdated));
		}
	}

	// Token: 0x0600040B RID: 1035 RVA: 0x0002419C File Offset: 0x0002239C
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.RemoveListener<CEventPlayer_OnSettingUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnSettingUpdated>(this.OnSettingUpdated));
		}
	}

	// Token: 0x0600040C RID: 1036 RVA: 0x000241CE File Offset: 0x000223CE
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.EvaluateDot();
	}

	// Token: 0x0600040D RID: 1037 RVA: 0x000241D6 File Offset: 0x000223D6
	protected void OnSettingUpdated(CEventPlayer_OnSettingUpdated evt)
	{
		this.EvaluateDot();
	}

	// Token: 0x040004D9 RID: 1241
	public Image m_DotImage;

	// Token: 0x040004DA RID: 1242
	public List<Color> m_ColorList;

	// Token: 0x040004DB RID: 1243
	public List<Sprite> m_SpriteList;

	// Token: 0x040004DC RID: 1244
	public List<Sprite> m_OutlineSpriteList;
}
