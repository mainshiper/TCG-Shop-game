﻿using System;

// Token: 0x020000F2 RID: 242
public enum EDamageType
{
	// Token: 0x04000D76 RID: 3446
	None,
	// Token: 0x04000D77 RID: 3447
	Damage,
	// Token: 0x04000D78 RID: 3448
	Buff,
	// Token: 0x04000D79 RID: 3449
	Heal,
	// Token: 0x04000D7A RID: 3450
	Charge,
	// Token: 0x04000D7B RID: 3451
	Barrier
}
