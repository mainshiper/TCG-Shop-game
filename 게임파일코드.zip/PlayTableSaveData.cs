﻿using System;
using System.Collections.Generic;

// Token: 0x0200004D RID: 77
[Serializable]
public class PlayTableSaveData
{
	// Token: 0x04000453 RID: 1107
	public Vector3Serializer pos;

	// Token: 0x04000454 RID: 1108
	public QuaternionSerializer rot;

	// Token: 0x04000455 RID: 1109
	public bool isBoxed;

	// Token: 0x04000456 RID: 1110
	public Vector3Serializer boxedPackagePos;

	// Token: 0x04000457 RID: 1111
	public QuaternionSerializer boxedPackageRot;

	// Token: 0x04000458 RID: 1112
	public EObjectType objectType;

	// Token: 0x04000459 RID: 1113
	public bool hasStartPlay;

	// Token: 0x0400045A RID: 1114
	public List<bool> isSeatOccupied;

	// Token: 0x0400045B RID: 1115
	public List<bool> isCustomerSmelly;

	// Token: 0x0400045C RID: 1116
	public int currentPlayerCount;

	// Token: 0x0400045D RID: 1117
	public float currentPlayTime;

	// Token: 0x0400045E RID: 1118
	public float currentPlayTimeMax;

	// Token: 0x0400045F RID: 1119
	public List<float> playTableFee;
}
