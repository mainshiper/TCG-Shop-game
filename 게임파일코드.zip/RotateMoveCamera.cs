﻿using System;
using UnityEngine;

// Token: 0x0200013B RID: 315
public class RotateMoveCamera : MonoBehaviour
{
	// Token: 0x06000909 RID: 2313 RVA: 0x00042DD4 File Offset: 0x00040FD4
	private void Update()
	{
		float axis = Input.GetAxis("Mouse X");
		float axis2 = Input.GetAxis("Mouse Y");
		if (axis != this.MouseX || axis2 != this.MouseY)
		{
			this.rotationX += axis * this.sensX * Time.deltaTime;
			this.rotationY += axis2 * this.sensY * Time.deltaTime;
			this.rotationY = Mathf.Clamp(this.rotationY, this.minY, this.maxY);
			this.MouseX = axis;
			this.MouseY = axis2;
			this.Camera.transform.localEulerAngles = new Vector3(-this.rotationY, this.rotationX, 0f);
		}
		if (Input.GetKey(KeyCode.W))
		{
			base.transform.Translate(new Vector3(0f, 0f, 0.01f));
		}
		else if (Input.GetKey(KeyCode.S))
		{
			base.transform.Translate(new Vector3(0f, 0f, -0.01f));
		}
		if (Input.GetKey(KeyCode.D))
		{
			base.transform.Translate(new Vector3(0.01f, 0f, 0f));
			return;
		}
		if (Input.GetKey(KeyCode.A))
		{
			base.transform.Translate(new Vector3(-0.01f, 0f, 0f));
		}
	}

	// Token: 0x0400112F RID: 4399
	public GameObject Camera;

	// Token: 0x04001130 RID: 4400
	public float minX = -360f;

	// Token: 0x04001131 RID: 4401
	public float maxX = 360f;

	// Token: 0x04001132 RID: 4402
	public float minY = -45f;

	// Token: 0x04001133 RID: 4403
	public float maxY = 45f;

	// Token: 0x04001134 RID: 4404
	public float sensX = 100f;

	// Token: 0x04001135 RID: 4405
	public float sensY = 100f;

	// Token: 0x04001136 RID: 4406
	private float rotationY;

	// Token: 0x04001137 RID: 4407
	private float rotationX;

	// Token: 0x04001138 RID: 4408
	private float MouseX;

	// Token: 0x04001139 RID: 4409
	private float MouseY;
}
