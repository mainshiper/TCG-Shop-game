﻿using System;

// Token: 0x02000020 RID: 32
public class InteractableLightSwitch : InteractableObject
{
	// Token: 0x06000184 RID: 388 RVA: 0x000126E4 File Offset: 0x000108E4
	public override void OnMouseButtonUp()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.6f, 0.5f);
		CSingleton<LightManager>.Instance.ToggleShopLight();
	}
}
