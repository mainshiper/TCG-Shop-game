﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000089 RID: 137
public class UI_CheckoutItemBar : MonoBehaviour
{
	// Token: 0x06000563 RID: 1379 RVA: 0x0002DB88 File Offset: 0x0002BD88
	public void SetItemName(string name, float value)
	{
		this.m_NameText.text = name;
		this.m_UnitPrice = value;
		this.m_TotalPrice = value;
		this.m_UnitText.text = 1.ToString();
		this.m_PriceText.text = GameInstance.GetPriceString(this.m_UnitPrice, false, true, false, "F2");
		this.m_TotalText.text = this.m_PriceText.text;
	}

	// Token: 0x06000564 RID: 1380 RVA: 0x0002DBF8 File Offset: 0x0002BDF8
	public void AddScannedItem(int itemCount)
	{
		this.m_UnitText.text = itemCount.ToString();
		this.m_TotalPrice = this.m_UnitPrice * (float)itemCount;
		this.m_TotalText.text = GameInstance.GetPriceString(this.m_TotalPrice, false, true, false, "F2");
	}

	// Token: 0x06000565 RID: 1381 RVA: 0x0002DC44 File Offset: 0x0002BE44
	protected virtual void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x06000566 RID: 1382 RVA: 0x0002DC65 File Offset: 0x0002BE65
	protected virtual void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x06000567 RID: 1383 RVA: 0x0002DC86 File Offset: 0x0002BE86
	protected void OnMoneyCurrencyUpdated(CEventPlayer_OnMoneyCurrencyUpdated evt)
	{
		this.m_PriceText.text = GameInstance.GetPriceString(this.m_UnitPrice, false, true, false, "F2");
		this.m_TotalText.text = GameInstance.GetPriceString(this.m_TotalPrice, false, true, false, "F2");
	}

	// Token: 0x04000717 RID: 1815
	public TextMeshProUGUI m_NameText;

	// Token: 0x04000718 RID: 1816
	public TextMeshProUGUI m_PriceText;

	// Token: 0x04000719 RID: 1817
	public TextMeshProUGUI m_UnitText;

	// Token: 0x0400071A RID: 1818
	public TextMeshProUGUI m_TotalText;

	// Token: 0x0400071B RID: 1819
	private float m_UnitPrice;

	// Token: 0x0400071C RID: 1820
	private float m_TotalPrice;
}
