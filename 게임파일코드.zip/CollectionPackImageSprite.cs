﻿using System;
using UnityEngine;

// Token: 0x02000030 RID: 48
[Serializable]
public struct CollectionPackImageSprite
{
	// Token: 0x040002FD RID: 765
	public ECollectionPackType colelctionPackType;

	// Token: 0x040002FE RID: 766
	public Sprite fullSprite;

	// Token: 0x040002FF RID: 767
	public Sprite topSprite;

	// Token: 0x04000300 RID: 768
	public Sprite bottomSprite;
}
