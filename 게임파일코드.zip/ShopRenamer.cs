﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000053 RID: 83
public class ShopRenamer : MonoBehaviour
{
	// Token: 0x060003D8 RID: 984 RVA: 0x00023008 File Offset: 0x00021208
	public void SetIsTutorial()
	{
		this.m_IsTutorial = true;
		this.m_ShopName.text = "";
		CPlayerData.PlayerName = "My Card Shop";
		GameUIScreen.SetGameUIVisible(false);
		InteractionPlayerController.AddToolTip(EGameAction.MoveForward, false, false);
		InteractionPlayerController.AddToolTip(EGameAction.MoveLeft, false, false);
		InteractionPlayerController.AddToolTip(EGameAction.MoveBackward, false, false);
		InteractionPlayerController.AddToolTip(EGameAction.MoveRight, false, false);
		InteractionPlayerController.AddToolTip(EGameAction.Jump, false, false);
		InteractionPlayerController.AddToolTip(EGameAction.Sprint, false, false);
	}

	// Token: 0x060003D9 RID: 985 RVA: 0x00023074 File Offset: 0x00021274
	private void OnTriggerEnter(Collider other)
	{
		if (this.m_IsInArea || !this.m_IsTutorial)
		{
			return;
		}
		this.m_IsInArea = true;
		CSingleton<InteractionPlayerController>.Instance.EnterUIMode();
		CSingleton<InteractionPlayerController>.Instance.ForceLookAt(this.m_FollowTarget, 3f);
		InteractionPlayerController.SetPlayerPos(this.m_FollowTarget.position);
		CSingleton<InteractionPlayerController>.Instance.EnterLockMoveMode();
		GameUIScreen.SetGameUIVisible(false);
		this.m_IntroScreen.SetActive(true);
		CSingleton<TutorialManager>.Instance.m_TutorialTargetIndicator.SetActive(false);
		InteractionPlayerController.RemoveToolTip(EGameAction.MoveForward);
		InteractionPlayerController.RemoveToolTip(EGameAction.MoveLeft);
		InteractionPlayerController.RemoveToolTip(EGameAction.MoveBackward);
		InteractionPlayerController.RemoveToolTip(EGameAction.MoveRight);
		InteractionPlayerController.RemoveToolTip(EGameAction.Jump);
		InteractionPlayerController.RemoveToolTip(EGameAction.Sprint);
		ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension_IntroScreen);
	}

	// Token: 0x060003DA RID: 986 RVA: 0x0002312C File Offset: 0x0002132C
	public void OnPressGoNextButton()
	{
		this.m_IntroScreen.SetActive(false);
		this.m_NameScreen.SetActive(true);
		this.m_SetName.text = CPlayerData.PlayerName;
		this.m_SetNameInputDisplay.text = CPlayerData.PlayerName;
		this.m_ShopName.text = CPlayerData.PlayerName;
		this.m_SetNameInputDisplay.gameObject.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension_IntroScreen);
		ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension_NameScreen);
	}

	// Token: 0x060003DB RID: 987 RVA: 0x000231A8 File Offset: 0x000213A8
	public void OnPressRenameButton()
	{
		GameUIScreen.SetGameUIVisible(false);
		this.m_SetName.text = CPlayerData.PlayerName;
		this.m_SetNameInputDisplay.text = CPlayerData.PlayerName;
		this.m_ShopName.text = CPlayerData.PlayerName;
		this.m_NameScreen.SetActive(true);
		this.m_ConfirmNameScreen.SetActive(false);
		this.m_SetNameInputDisplay.gameObject.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension_ConfirmNameScreen);
		ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension_NameScreen);
	}

	// Token: 0x060003DC RID: 988 RVA: 0x0002322A File Offset: 0x0002142A
	public void OnPressSetNameButton()
	{
		if (string.IsNullOrWhiteSpace(CPlayerData.PlayerName))
		{
			return;
		}
		this.m_NameScreen.SetActive(false);
		this.m_ConfirmNameScreen.SetActive(true);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension_NameScreen);
		ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension_ConfirmNameScreen);
	}

	// Token: 0x060003DD RID: 989 RVA: 0x00023268 File Offset: 0x00021468
	public void OnInputChanged(string text)
	{
		this.m_SetNameInputDisplay.text = text;
		this.m_ShopName.text = text;
		this.m_SetNameInputDisplay.gameObject.SetActive(true);
		this.m_SetName.gameObject.SetActive(false);
		CPlayerData.PlayerName = text;
	}

	// Token: 0x060003DE RID: 990 RVA: 0x000232B5 File Offset: 0x000214B5
	public void OnInputTextSelected(string text)
	{
		this.m_SetNameInputDisplay.gameObject.SetActive(true);
		this.m_SetNameInput.text = text;
		this.m_SetName.gameObject.SetActive(false);
	}

	// Token: 0x060003DF RID: 991 RVA: 0x000232E8 File Offset: 0x000214E8
	public void OnInputTextUpdated(string text)
	{
		this.m_SetNameInput.text = text;
		this.m_SetNameInputDisplay.text = text;
		this.m_SetName.text = text;
		this.m_ShopName.text = text;
		this.m_SetNameInputDisplay.gameObject.SetActive(false);
		this.m_SetName.gameObject.SetActive(true);
		CPlayerData.PlayerName = text;
	}

	// Token: 0x060003E0 RID: 992 RVA: 0x00023350 File Offset: 0x00021550
	public void OnPressConfirmShopName()
	{
		this.m_IntroScreen.SetActive(false);
		this.m_NameScreen.SetActive(false);
		this.m_ConfirmNameScreen.SetActive(false);
		base.gameObject.SetActive(false);
		CSingleton<InteractionPlayerController>.Instance.ExitUIMode();
		CSingleton<InteractionPlayerController>.Instance.ExitLockMoveMode();
		GameUIScreen.SetGameUIVisible(true);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension_ConfirmNameScreen);
		if (this.m_IsTutorial)
		{
			this.m_IsTutorial = false;
			CPlayerData.m_TutorialIndex = 1;
			CSingleton<TutorialManager>.Instance.EvaluateTaskVisibility();
			CSingleton<TutorialManager>.Instance.m_TutorialTargetIndicator.SetActive(false);
		}
	}

	// Token: 0x060003E1 RID: 993 RVA: 0x000233E1 File Offset: 0x000215E1
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x060003E2 RID: 994 RVA: 0x00023402 File Offset: 0x00021602
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x060003E3 RID: 995 RVA: 0x00023423 File Offset: 0x00021623
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		if (CPlayerData.m_TutorialIndex != 0)
		{
			this.m_ShopName.text = CPlayerData.PlayerName;
			base.gameObject.SetActive(false);
		}
	}

	// Token: 0x0400049F RID: 1183
	public ControllerScreenUIExtension m_ControllerScreenUIExtension_IntroScreen;

	// Token: 0x040004A0 RID: 1184
	public ControllerScreenUIExtension m_ControllerScreenUIExtension_NameScreen;

	// Token: 0x040004A1 RID: 1185
	public ControllerScreenUIExtension m_ControllerScreenUIExtension_ConfirmNameScreen;

	// Token: 0x040004A2 RID: 1186
	public Transform m_FollowTarget;

	// Token: 0x040004A3 RID: 1187
	public GameObject m_IntroScreen;

	// Token: 0x040004A4 RID: 1188
	public GameObject m_NameScreen;

	// Token: 0x040004A5 RID: 1189
	public GameObject m_ConfirmNameScreen;

	// Token: 0x040004A6 RID: 1190
	public TMP_InputField m_SetNameInput;

	// Token: 0x040004A7 RID: 1191
	public TextMeshProUGUI m_SetNameInputDisplay;

	// Token: 0x040004A8 RID: 1192
	public TextMeshProUGUI m_SetName;

	// Token: 0x040004A9 RID: 1193
	public TextMeshProUGUI m_ShopName;

	// Token: 0x040004AA RID: 1194
	private bool m_IsInArea;

	// Token: 0x040004AB RID: 1195
	private bool m_IsTutorial;
}
