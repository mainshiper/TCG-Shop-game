﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000017 RID: 23
public class InteractableAutoCleanser : InteractableObject
{
	// Token: 0x06000100 RID: 256 RVA: 0x0000F4F3 File Offset: 0x0000D6F3
	protected override void Awake()
	{
		base.Awake();
		ShelfManager.InitAutoCleanser(this);
	}

	// Token: 0x06000101 RID: 257 RVA: 0x0000F501 File Offset: 0x0000D701
	public int GetCurrentSlotAvailable()
	{
		return this.m_PosList.Count - this.m_ItemAmount;
	}

	// Token: 0x06000102 RID: 258 RVA: 0x0000F518 File Offset: 0x0000D718
	public override void OnMouseButtonUp()
	{
		base.OnMouseButtonUp();
		this.m_IsTurnedOn = !this.m_IsTurnedOn;
		if (!this.m_IsTurnedOn)
		{
			this.m_IsSprayOnCooldown = true;
			this.m_Timer = 0f;
		}
		else if (this.m_IsTurnedOn && this.m_IsNeedRefill)
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.AutoCleanserRefill);
		}
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.6f, 0.5f);
		if (this.m_IsTurnedOn)
		{
			InteractionPlayerController.AddToolTip(EGameAction.TurnOff, false, false);
			InteractionPlayerController.RemoveToolTip(EGameAction.TurnOn);
			return;
		}
		InteractionPlayerController.AddToolTip(EGameAction.TurnOn, false, false);
		InteractionPlayerController.RemoveToolTip(EGameAction.TurnOff);
	}

	// Token: 0x06000103 RID: 259 RVA: 0x0000F5AA File Offset: 0x0000D7AA
	public override void OnRightMouseButtonUp()
	{
		base.OnRightMouseButtonUp();
	}

	// Token: 0x06000104 RID: 260 RVA: 0x0000F5B4 File Offset: 0x0000D7B4
	protected override void Update()
	{
		base.Update();
		if (this.m_IsBoxedUp)
		{
			return;
		}
		if (!this.m_IsTurnedOn || this.m_IsNeedRefill)
		{
			return;
		}
		if (this.m_DispenseMethod == 1)
		{
			if (!this.m_IsSprayOnCooldown)
			{
				for (int i = 0; i < CSingleton<CustomerManager>.Instance.GetSmellyCustomerList().Count; i++)
				{
					if (CSingleton<CustomerManager>.Instance.GetSmellyCustomerList()[i].IsInsideShop() && (base.transform.position - CSingleton<CustomerManager>.Instance.GetSmellyCustomerList()[i].transform.position).magnitude <= this.m_CleanserRange)
					{
						this.m_Timer = 0f;
						this.m_IsSprayOnCooldown = true;
						this.Spray();
					}
				}
				return;
			}
			this.m_Timer += Time.deltaTime;
			if (this.m_Timer >= this.m_CooldownTime)
			{
				this.m_Timer = this.m_CooldownTime;
				this.m_IsSprayOnCooldown = false;
				return;
			}
		}
		else if (this.m_DispenseMethod == 0)
		{
			this.m_Timer += Time.deltaTime;
			if (this.m_CooldownTime > 0f && this.m_Timer >= this.m_CooldownTime)
			{
				this.m_Timer = 0f;
				this.Spray();
			}
		}
	}

	// Token: 0x06000105 RID: 261 RVA: 0x0000F6F6 File Offset: 0x0000D8F6
	public override void OnRaycasted()
	{
		base.OnRaycasted();
		this.m_IsRaycasted = true;
		AutoCleanserStatusUI.SetTargetCleanser(this, this.m_UIPosYOffset);
	}

	// Token: 0x06000106 RID: 262 RVA: 0x0000F711 File Offset: 0x0000D911
	public override void OnRaycastEnded()
	{
		base.OnRaycastEnded();
		this.m_IsRaycasted = false;
		AutoCleanserStatusUI.SetTargetCleanser(null, 0f);
	}

	// Token: 0x06000107 RID: 263 RVA: 0x0000F72C File Offset: 0x0000D92C
	private bool HasEnoughSprayMeter(bool depleteItemContent)
	{
		if (this.m_ItemAmount <= 0)
		{
			return false;
		}
		int num = -1;
		float num2 = 1000f;
		for (int i = 0; i < this.m_StoredItemList.Count; i++)
		{
			if (this.m_StoredItemList[i].GetContentFill() > 0f && this.m_StoredItemList[i].GetContentFill() < num2)
			{
				num = i;
				num2 = this.m_StoredItemList[i].GetContentFill();
			}
		}
		if (num != -1)
		{
			if (depleteItemContent)
			{
				this.m_StoredItemList[num].DepleteContent(this.m_ItemContentDepleteAmountPerSpray);
				if (this.m_StoredItemList[num].GetContentFill() <= 0f)
				{
					this.m_StoredItemList[num].DisableItem();
					this.RemoveItem(this.m_StoredItemList[num]);
				}
			}
			return true;
		}
		return false;
	}

	// Token: 0x06000108 RID: 264 RVA: 0x0000F800 File Offset: 0x0000DA00
	private void Spray()
	{
		if (this.m_IsNeedRefill)
		{
			return;
		}
		if (this.HasEnoughSprayMeter(true))
		{
			this.m_DeodorantSprayVFX.Play();
			for (int i = 0; i < CSingleton<CustomerManager>.Instance.GetCustomerList().Count; i++)
			{
				CSingleton<CustomerManager>.Instance.GetCustomerList()[i].DeodorantSprayCheck(base.transform.position, this.m_CleanserRange, this.m_Potency);
			}
			return;
		}
		this.m_IsNeedRefill = true;
		this.m_IsSprayOnCooldown = true;
		this.m_Timer = 0f;
		Debug.Log("Ran out of spray content, need refill");
	}

	// Token: 0x06000109 RID: 265 RVA: 0x0000F894 File Offset: 0x0000DA94
	public void DispenseItemFromBox(InteractablePackagingBox_Item itemBox, bool isPlayer)
	{
		if (itemBox)
		{
			if (itemBox.m_ItemCompartment.GetItemType() == EItemType.Deodorant)
			{
				if (itemBox.m_ItemCompartment.GetItemCount() > 0)
				{
					if (this.HasEnoughSlot())
					{
						Item firstItem = itemBox.m_ItemCompartment.GetFirstItem();
						this.AddItem(firstItem, true);
						itemBox.m_ItemCompartment.RemoveItem(firstItem);
						if (isPlayer)
						{
							SoundManager.GenericPop(1f, 1f);
							return;
						}
					}
					else if (isPlayer)
					{
						NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.AutoCleanserNoSlot);
						return;
					}
				}
				else if (isPlayer)
				{
					NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.BoxNoItem);
					return;
				}
			}
			else if (isPlayer)
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.AutoCleanserOnlyAllowCleanser);
			}
		}
	}

	// Token: 0x0600010A RID: 266 RVA: 0x0000F920 File Offset: 0x0000DB20
	public void AddItem(Item item, bool addToFront)
	{
		if (item.GetContentFill() > 0f)
		{
			this.m_IsNeedRefill = false;
		}
		this.m_ItemAmount++;
		if (this.m_IsRaycasted)
		{
			CSingleton<AutoCleanserStatusUI>.Instance.UpdateItemSlotAmountFilled(this.m_ItemAmount);
		}
		if (addToFront)
		{
			this.m_StoredItemList.Insert(0, item);
		}
		else
		{
			this.m_StoredItemList.Add(item);
		}
		item.LerpToTransform(this.m_PosList[this.m_ItemAmount - 1], this.m_PosList[this.m_ItemAmount - 1], false);
	}

	// Token: 0x0600010B RID: 267 RVA: 0x0000F9B4 File Offset: 0x0000DBB4
	public void RemoveItem(Item item)
	{
		this.m_ItemAmount--;
		this.m_StoredItemList.Remove(item);
		if (!this.HasEnoughSprayMeter(false))
		{
			this.m_IsNeedRefill = true;
			this.m_IsSprayOnCooldown = true;
			this.m_Timer = 0f;
		}
		if (this.m_IsRaycasted)
		{
			CSingleton<AutoCleanserStatusUI>.Instance.UpdateItemSlotAmountFilled(this.m_ItemAmount);
		}
		for (int i = 0; i < this.m_StoredItemList.Count; i++)
		{
			this.m_StoredItemList[i].transform.position = this.m_PosList[i].position;
		}
	}

	// Token: 0x0600010C RID: 268 RVA: 0x0000FA54 File Offset: 0x0000DC54
	public Item TakeItemToHand(bool getLastItem = true)
	{
		if (this.m_ItemAmount <= 0)
		{
			return null;
		}
		Item item = this.GetLastItem();
		if (!getLastItem)
		{
			item = this.GetFirstItem();
		}
		this.m_ItemAmount--;
		this.m_StoredItemList.Remove(item);
		if (this.m_IsRaycasted)
		{
			CSingleton<AutoCleanserStatusUI>.Instance.UpdateItemSlotAmountFilled(this.m_ItemAmount);
		}
		if (!this.HasEnoughSprayMeter(false))
		{
			this.m_IsNeedRefill = true;
			this.m_IsSprayOnCooldown = true;
			this.m_Timer = 0f;
		}
		return item;
	}

	// Token: 0x0600010D RID: 269 RVA: 0x0000FAD3 File Offset: 0x0000DCD3
	protected override void OnStartMoveObject()
	{
		base.OnStartMoveObject();
		AutoCleanserStatusUI.SetTargetCleanser(this, this.m_UIPosYOffset);
	}

	// Token: 0x0600010E RID: 270 RVA: 0x0000FAE7 File Offset: 0x0000DCE7
	protected override void OnPlacedMovedObject()
	{
		base.OnPlacedMovedObject();
		AutoCleanserStatusUI.SetTargetCleanser(null, 0f);
	}

	// Token: 0x0600010F RID: 271 RVA: 0x0000FAFA File Offset: 0x0000DCFA
	public override void OnDestroyed()
	{
		ShelfManager.RemoveAutoCleanser(this);
		base.OnDestroyed();
	}

	// Token: 0x06000110 RID: 272 RVA: 0x0000FB08 File Offset: 0x0000DD08
	public int GetItemCount()
	{
		return this.m_ItemAmount;
	}

	// Token: 0x06000111 RID: 273 RVA: 0x0000FB10 File Offset: 0x0000DD10
	public bool HasEnoughSlot()
	{
		return this.m_ItemAmount < this.m_PosList.Count;
	}

	// Token: 0x06000112 RID: 274 RVA: 0x0000FB28 File Offset: 0x0000DD28
	public Transform GetEmptySlotTransform()
	{
		return this.m_PosList[this.m_ItemAmount];
	}

	// Token: 0x06000113 RID: 275 RVA: 0x0000FB3B File Offset: 0x0000DD3B
	public Transform GetLastEmptySlotTransform()
	{
		return this.m_PosList[this.m_PosList.Count - this.m_ItemAmount - 1];
	}

	// Token: 0x06000114 RID: 276 RVA: 0x0000FB5C File Offset: 0x0000DD5C
	public Item GetFirstItem()
	{
		return this.m_StoredItemList[0];
	}

	// Token: 0x06000115 RID: 277 RVA: 0x0000FB6A File Offset: 0x0000DD6A
	public Item GetLastItem()
	{
		if (this.m_StoredItemList.Count <= 0)
		{
			return null;
		}
		return this.m_StoredItemList[this.m_ItemAmount - 1];
	}

	// Token: 0x06000116 RID: 278 RVA: 0x0000FB8F File Offset: 0x0000DD8F
	public float GetTimer()
	{
		return this.m_Timer;
	}

	// Token: 0x06000117 RID: 279 RVA: 0x0000FB97 File Offset: 0x0000DD97
	public bool IsTurnedOn()
	{
		return this.m_IsTurnedOn;
	}

	// Token: 0x06000118 RID: 280 RVA: 0x0000FB9F File Offset: 0x0000DD9F
	public bool IsNeedRefill()
	{
		return this.m_IsNeedRefill;
	}

	// Token: 0x06000119 RID: 281 RVA: 0x0000FBA7 File Offset: 0x0000DDA7
	public List<Item> GetStoredItemList()
	{
		return this.m_StoredItemList;
	}

	// Token: 0x0600011A RID: 282 RVA: 0x0000FBB0 File Offset: 0x0000DDB0
	public void LoadData(AutoCleanserSaveData saveData)
	{
		this.m_IsNeedRefill = saveData.isNeedRefill;
		this.m_IsTurnedOn = saveData.isTurnedOn;
		this.m_IsSprayOnCooldown = true;
		this.m_Timer = 0f;
		for (int i = 0; i < saveData.itemAmount; i++)
		{
			ItemMeshData itemMeshData = InventoryBase.GetItemMeshData(EItemType.Deodorant);
			Item item = ItemSpawnManager.GetItem(this.m_PosList[i]);
			item.SetMesh(itemMeshData.mesh, itemMeshData.material, EItemType.Deodorant, itemMeshData.meshSecondary, itemMeshData.materialSecondary);
			item.transform.localPosition = Vector3.zero;
			item.transform.localRotation = Quaternion.identity;
			item.SetContentFill(saveData.contentFillList[i]);
			item.gameObject.SetActive(true);
			this.AddItem(item, true);
		}
		this.m_ItemAmount = saveData.itemAmount;
		for (int j = 0; j < this.m_StoredItemList.Count; j++)
		{
			if (this.m_StoredItemList[j].GetContentFill() <= 0f)
			{
				this.m_StoredItemList[j].DisableItem();
				this.RemoveItem(this.m_StoredItemList[j]);
			}
		}
	}

	// Token: 0x04000187 RID: 391
	public List<Transform> m_PosList;

	// Token: 0x04000188 RID: 392
	public ParticleSystem m_DeodorantSprayVFX;

	// Token: 0x04000189 RID: 393
	public int m_Potency = 5;

	// Token: 0x0400018A RID: 394
	public int m_DispenseMethod;

	// Token: 0x0400018B RID: 395
	public float m_ItemContentDepleteAmountPerSpray = 0.05f;

	// Token: 0x0400018C RID: 396
	public float m_CleanserRange = 2.5f;

	// Token: 0x0400018D RID: 397
	public float m_CooldownTime = 3f;

	// Token: 0x0400018E RID: 398
	public float m_UIPosYOffset = 1f;

	// Token: 0x0400018F RID: 399
	private bool m_IsTurnedOn;

	// Token: 0x04000190 RID: 400
	private bool m_IsSprayOnCooldown = true;

	// Token: 0x04000191 RID: 401
	private bool m_IsNeedRefill = true;

	// Token: 0x04000192 RID: 402
	private int m_ItemAmount;

	// Token: 0x04000193 RID: 403
	private float m_Timer;

	// Token: 0x04000194 RID: 404
	public List<Item> m_StoredItemList;
}
