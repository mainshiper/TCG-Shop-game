﻿using System;

// Token: 0x020000C5 RID: 197
public class CEventPlayer_OnCardRaritySelectScreenUpdated : CEvent
{
	// Token: 0x17000021 RID: 33
	// (get) Token: 0x0600073A RID: 1850 RVA: 0x0003951B File Offset: 0x0003771B
	// (set) Token: 0x0600073B RID: 1851 RVA: 0x00039523 File Offset: 0x00037723
	public int m_CardRarityIndex { get; private set; }

	// Token: 0x0600073C RID: 1852 RVA: 0x0003952C File Offset: 0x0003772C
	public CEventPlayer_OnCardRaritySelectScreenUpdated(int cardRarityIndex)
	{
		this.m_CardRarityIndex = cardRarityIndex;
	}
}
