﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200010B RID: 267
public class ControllerButton : MonoBehaviour
{
	// Token: 0x060007E2 RID: 2018 RVA: 0x0003B38C File Offset: 0x0003958C
	private void Awake()
	{
		if (this.m_ButtonHighlight)
		{
			this.m_ButtonHighlight.SetActive(false);
		}
		for (int i = 0; i < this.m_OverlayButtonHighlight.Count; i++)
		{
			this.m_OverlayButtonHighlight[i].SetActive(false);
		}
	}

	// Token: 0x060007E3 RID: 2019 RVA: 0x0003B3DC File Offset: 0x000395DC
	public void OnSelectionActive()
	{
		if (!CSingleton<ControllerScreenUIExtManager>.Instance.m_IsControllerActive)
		{
			return;
		}
		if (!this.m_ButtonHighlight && this.m_OverlayButtonHighlight.Count == 0)
		{
			ControllerScreenUIExtManager.SetControllerSelectorUI(this, this.m_RectTransformOffsetMultiplier, this.m_BtnHighlightSpriteScale);
			return;
		}
		for (int i = 0; i < this.m_OverlayButtonHighlight.Count; i++)
		{
			if (this.m_OverlayButtonHighlight[i].activeInHierarchy)
			{
				return;
			}
		}
		this.m_ButtonHighlight.SetActive(true);
	}

	// Token: 0x060007E4 RID: 2020 RVA: 0x0003B45C File Offset: 0x0003965C
	public void OnSelectionDeactivate()
	{
		if (!this.m_ButtonHighlight && this.m_OverlayButtonHighlight.Count == 0)
		{
			ControllerScreenUIExtManager.SetControllerSelectorUI(null, 1f, 1f);
			return;
		}
		for (int i = 0; i < this.m_OverlayButtonHighlight.Count; i++)
		{
			if (this.m_OverlayButtonHighlight[i].activeInHierarchy)
			{
				this.m_OverlayButtonHighlight[i].SetActive(false);
				return;
			}
		}
		this.m_ButtonHighlight.SetActive(false);
	}

	// Token: 0x060007E5 RID: 2021 RVA: 0x0003B4DC File Offset: 0x000396DC
	public void OnPressConfirm()
	{
		if (this.m_GamepadSettingLinker)
		{
			this.m_GamepadSettingLinker.OnPressConfirm();
			return;
		}
		for (int i = 0; i < this.m_OverlayButton.Count; i++)
		{
			if (this.m_OverlayButton[i].gameObject.activeInHierarchy)
			{
				this.m_OverlayButton[i].onClick.Invoke();
				return;
			}
		}
		if (!this.m_EnableVirtualKeyboard)
		{
			this.m_Button.onClick.Invoke();
			return;
		}
		if (this.m_InitVirtualKeyboardWithInputString)
		{
			ControllerScreenUIExtManager.StartVirtualKeyboard(this.m_VirtualKeyboardInputText.text, this.m_VirtualKeyboardInputText);
			return;
		}
		ControllerScreenUIExtManager.StartVirtualKeyboard("", this.m_VirtualKeyboardInputText);
	}

	// Token: 0x060007E6 RID: 2022 RVA: 0x0003B590 File Offset: 0x00039790
	public bool OnPressCancel()
	{
		if (this.m_GamepadSettingLinker && InputManager.IsSliderActive())
		{
			this.m_GamepadSettingLinker.OnPressCancel();
			return true;
		}
		return false;
	}

	// Token: 0x060007E7 RID: 2023 RVA: 0x0003B5C0 File Offset: 0x000397C0
	public bool IsActive()
	{
		if (this.m_GamepadSettingLinker)
		{
			return base.gameObject.activeInHierarchy;
		}
		for (int i = 0; i < this.m_OverlayButton.Count; i++)
		{
			if (this.m_OverlayButton[i].gameObject.activeInHierarchy)
			{
				return true;
			}
		}
		if (this.m_EnableVirtualKeyboard)
		{
			return base.gameObject.activeInHierarchy;
		}
		return this.m_Button.gameObject.activeInHierarchy;
	}

	// Token: 0x04000F1D RID: 3869
	public bool m_CanScrollerSlide = true;

	// Token: 0x04000F1E RID: 3870
	public Button m_Button;

	// Token: 0x04000F1F RID: 3871
	public ControllerSelectorUIGrp m_ButtonHighlight;

	// Token: 0x04000F20 RID: 3872
	public float m_RectTransformOffsetMultiplier = 1f;

	// Token: 0x04000F21 RID: 3873
	public float m_BtnHighlightSpriteScale = 1f;

	// Token: 0x04000F22 RID: 3874
	public List<Button> m_OverlayButton;

	// Token: 0x04000F23 RID: 3875
	public List<GameObject> m_OverlayButtonHighlight;

	// Token: 0x04000F24 RID: 3876
	public bool m_EnableVirtualKeyboard;

	// Token: 0x04000F25 RID: 3877
	public bool m_InitVirtualKeyboardWithInputString;

	// Token: 0x04000F26 RID: 3878
	public TMP_InputField m_VirtualKeyboardInputText;

	// Token: 0x04000F27 RID: 3879
	public GamepadSettingLinker m_GamepadSettingLinker;
}
