﻿using System;

// Token: 0x0200013D RID: 317
public enum ButtonTypes
{
	// Token: 0x04001145 RID: 4421
	NotDefined,
	// Token: 0x04001146 RID: 4422
	Previous,
	// Token: 0x04001147 RID: 4423
	Next
}
