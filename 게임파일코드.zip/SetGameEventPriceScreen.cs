﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000080 RID: 128
public class SetGameEventPriceScreen : UIScreenBase
{
	// Token: 0x06000508 RID: 1288 RVA: 0x0002B9B0 File Offset: 0x00029BB0
	protected override void OnOpenScreen()
	{
		EGameEventFormat egameEventFormat = CPlayerData.m_GameEventFormat;
		if (CPlayerData.m_PendingGameEventFormat != EGameEventFormat.None)
		{
			egameEventFormat = CPlayerData.m_PendingGameEventFormat;
		}
		if (egameEventFormat == EGameEventFormat.None)
		{
			Debug.LogError("Event type cannot be none");
			return;
		}
		this.m_GameEventFormat = egameEventFormat;
		this.m_PriceSet = PriceChangeManager.GetGameEventPrice(this.m_GameEventFormat, false);
		this.m_MarketPrice = PriceChangeManager.GetGameEventMarketPrice(this.m_GameEventFormat);
		this.m_SetPrice.text = GameInstance.GetPriceString(this.m_PriceSet, false, true, false, "F2");
		this.m_SetPriceInputDisplay.text = GameInstance.GetPriceString(this.m_PriceSet, false, true, false, "F2");
		this.m_MarketPriceText.text = GameInstance.GetPriceString(this.m_MarketPrice, false, true, false, "F2");
		this.m_SetPriceInputDisplay.gameObject.SetActive(false);
		base.OnOpenScreen();
	}

	// Token: 0x06000509 RID: 1289 RVA: 0x0002BA7B File Offset: 0x00029C7B
	protected override void OnCloseScreen()
	{
		base.OnCloseScreen();
	}

	// Token: 0x0600050A RID: 1290 RVA: 0x0002BA83 File Offset: 0x00029C83
	public void OnPressConfirm()
	{
		PriceChangeManager.SetGameEventPrice(this.m_GameEventFormat, this.m_PriceSet);
		base.CloseScreen();
		SoundManager.GenericConfirm(1f, 1f);
	}

	// Token: 0x0600050B RID: 1291 RVA: 0x0002BAAC File Offset: 0x00029CAC
	public void OnInputChanged(string text)
	{
		float num = GameInstance.GetInvariantCultureDecimal(text) / GameInstance.GetCurrencyConversionRate();
		num = (float)Mathf.RoundToInt(num * GameInstance.GetCurrencyRoundDivideAmount()) / GameInstance.GetCurrencyRoundDivideAmount();
		this.m_SetPriceInputDisplay.text = GameInstance.GetPriceString(num, false, true, false, "F2");
		this.m_SetPriceInputDisplay.gameObject.SetActive(true);
		this.m_SetPrice.gameObject.SetActive(false);
	}

	// Token: 0x0600050C RID: 1292 RVA: 0x0002BB18 File Offset: 0x00029D18
	public void OnInputTextSelected(string text)
	{
		this.m_SetPriceInputDisplay.gameObject.SetActive(true);
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.Yen)
		{
			this.m_SetPriceInput.text = GameInstance.GetPriceString(this.m_PriceSet, false, false, false, "F0");
		}
		else
		{
			this.m_SetPriceInput.text = GameInstance.GetPriceString(this.m_PriceSet, false, false, false, "F2");
		}
		this.m_SetPrice.gameObject.SetActive(false);
	}

	// Token: 0x0600050D RID: 1293 RVA: 0x0002BB94 File Offset: 0x00029D94
	public void OnInputTextUpdated(string text)
	{
		float num = GameInstance.GetInvariantCultureDecimal(text) / GameInstance.GetCurrencyConversionRate();
		this.m_PriceSet = (float)Mathf.RoundToInt(num * GameInstance.GetCurrencyRoundDivideAmount()) / GameInstance.GetCurrencyRoundDivideAmount();
		if (this.m_PriceSet < 0f)
		{
			this.m_PriceSet = 0f;
		}
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.Yen)
		{
			this.m_SetPriceInput.text = GameInstance.GetPriceString(this.m_PriceSet, false, false, false, "F0");
		}
		else
		{
			this.m_SetPriceInput.text = GameInstance.GetPriceString(this.m_PriceSet, false, false, false, "F2");
		}
		this.m_SetPriceInputDisplay.text = GameInstance.GetPriceString(this.m_PriceSet, false, true, false, "F2");
		this.m_SetPrice.text = GameInstance.GetPriceString(this.m_PriceSet, false, true, false, "F2");
		this.m_SetPriceInputDisplay.gameObject.SetActive(false);
		this.m_SetPrice.gameObject.SetActive(true);
	}

	// Token: 0x040006A6 RID: 1702
	public TextMeshProUGUI m_MarketPriceText;

	// Token: 0x040006A7 RID: 1703
	public TMP_InputField m_SetPriceInput;

	// Token: 0x040006A8 RID: 1704
	public TextMeshProUGUI m_SetPriceInputDisplay;

	// Token: 0x040006A9 RID: 1705
	public TextMeshProUGUI m_SetPrice;

	// Token: 0x040006AA RID: 1706
	private float m_PriceSet;

	// Token: 0x040006AB RID: 1707
	private float m_MarketPrice;

	// Token: 0x040006AC RID: 1708
	private EGameEventFormat m_GameEventFormat;
}
