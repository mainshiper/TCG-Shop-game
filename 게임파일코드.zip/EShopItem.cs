﻿using System;

// Token: 0x020000FC RID: 252
public enum EShopItem
{
	// Token: 0x04000E3A RID: 3642
	None = -1,
	// Token: 0x04000E3B RID: 3643
	Gem1,
	// Token: 0x04000E3C RID: 3644
	Gem2,
	// Token: 0x04000E3D RID: 3645
	Gem3,
	// Token: 0x04000E3E RID: 3646
	Gem4,
	// Token: 0x04000E3F RID: 3647
	Gem5,
	// Token: 0x04000E40 RID: 3648
	Gem6,
	// Token: 0x04000E41 RID: 3649
	Gold1,
	// Token: 0x04000E42 RID: 3650
	Gold2,
	// Token: 0x04000E43 RID: 3651
	Gold3,
	// Token: 0x04000E44 RID: 3652
	RemoveAd,
	// Token: 0x04000E45 RID: 3653
	Earning1,
	// Token: 0x04000E46 RID: 3654
	Earning2,
	// Token: 0x04000E47 RID: 3655
	Earning3,
	// Token: 0x04000E48 RID: 3656
	OfflineTime1,
	// Token: 0x04000E49 RID: 3657
	OfflineTime2,
	// Token: 0x04000E4A RID: 3658
	OfflineTime3,
	// Token: 0x04000E4B RID: 3659
	SpecialPack1,
	// Token: 0x04000E4C RID: 3660
	SpecialPack2,
	// Token: 0x04000E4D RID: 3661
	SpecialPack3,
	// Token: 0x04000E4E RID: 3662
	ChestBundle1,
	// Token: 0x04000E4F RID: 3663
	ChestBundle2,
	// Token: 0x04000E50 RID: 3664
	ChestBundle3,
	// Token: 0x04000E51 RID: 3665
	ChestBundle4,
	// Token: 0x04000E52 RID: 3666
	ChestBundle5,
	// Token: 0x04000E53 RID: 3667
	AutoRestock,
	// Token: 0x04000E54 RID: 3668
	AutoPlaceItem,
	// Token: 0x04000E55 RID: 3669
	UnlimitedEnergy,
	// Token: 0x04000E56 RID: 3670
	FoilBasicPack,
	// Token: 0x04000E57 RID: 3671
	FoilRarePack,
	// Token: 0x04000E58 RID: 3672
	FoilEpicPack,
	// Token: 0x04000E59 RID: 3673
	FoilLegendPack,
	// Token: 0x04000E5A RID: 3674
	UltimateShopkeeperPack,
	// Token: 0x04000E5B RID: 3675
	PowerupEXPack,
	// Token: 0x04000E5C RID: 3676
	StarterPack,
	// Token: 0x04000E5D RID: 3677
	ProPack,
	// Token: 0x04000E5E RID: 3678
	UltimateShopkeeperPackFull,
	// Token: 0x04000E5F RID: 3679
	PowerupEXPackFull,
	// Token: 0x04000E60 RID: 3680
	StarterPackFull,
	// Token: 0x04000E61 RID: 3681
	ProPackFull,
	// Token: 0x04000E62 RID: 3682
	AutoManager,
	// Token: 0x04000E63 RID: 3683
	SubDollarUltimateShopkeeperPack,
	// Token: 0x04000E64 RID: 3684
	SubDollarGemPack,
	// Token: 0x04000E65 RID: 3685
	MassiveGemPack,
	// Token: 0x04000E66 RID: 3686
	SpecialSeasonBundle1,
	// Token: 0x04000E67 RID: 3687
	SpecialSeasonBundle2,
	// Token: 0x04000E68 RID: 3688
	SpecialConsumableBundle1,
	// Token: 0x04000E69 RID: 3689
	SpecialConsumableBundle2,
	// Token: 0x04000E6A RID: 3690
	StorePointUpgrade1,
	// Token: 0x04000E6B RID: 3691
	StorePointUpgrade2,
	// Token: 0x04000E6C RID: 3692
	StorePointUpgrade3,
	// Token: 0x04000E6D RID: 3693
	BeginnerBundle1,
	// Token: 0x04000E6E RID: 3694
	BeginnerBundle2,
	// Token: 0x04000E6F RID: 3695
	BuilderBundle1,
	// Token: 0x04000E70 RID: 3696
	BuilderBundle2,
	// Token: 0x04000E71 RID: 3697
	BuilderBundle3
}
