﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000038 RID: 56
public class ItemSpawnManager : CSingleton<ItemSpawnManager>
{
	// Token: 0x060002D7 RID: 727 RVA: 0x0001AF40 File Offset: 0x00019140
	private void Start()
	{
		for (int i = 0; i < this.m_ItemParentGrp.childCount; i++)
		{
			this.m_ItemList.Add(this.m_ItemParentGrp.GetChild(i).gameObject.GetComponent<Item>());
		}
	}

	// Token: 0x060002D8 RID: 728 RVA: 0x0001AF84 File Offset: 0x00019184
	public static Item GetItem(Transform parent)
	{
		Item item = null;
		for (int i = 0; i < CSingleton<ItemSpawnManager>.Instance.m_ItemList.Count; i++)
		{
			if (CSingleton<ItemSpawnManager>.Instance.m_ItemList[i] && !CSingleton<ItemSpawnManager>.Instance.m_ItemList[i].gameObject.activeSelf && CSingleton<ItemSpawnManager>.Instance.m_ItemList[i].transform.parent == CSingleton<ItemSpawnManager>.Instance.m_ItemParentGrp)
			{
				item = CSingleton<ItemSpawnManager>.Instance.m_ItemList[i];
				break;
			}
		}
		if (!item)
		{
			item = CSingleton<ItemSpawnManager>.Instance.AddItemPrefab();
		}
		item.transform.parent = parent;
		return item;
	}

	// Token: 0x060002D9 RID: 729 RVA: 0x0001B044 File Offset: 0x00019244
	public static void DisableItem(Item item)
	{
		item.transform.parent = CSingleton<ItemSpawnManager>.Instance.m_ItemParentGrp;
		item.transform.localPosition = Vector3.zero;
		item.transform.localRotation = Quaternion.identity;
		item.transform.localScale = Vector3.one;
		item.gameObject.SetActive(false);
		item.m_Mesh.enabled = true;
	}

	// Token: 0x060002DA RID: 730 RVA: 0x0001B0B0 File Offset: 0x000192B0
	private Item AddItemPrefab()
	{
		Item item = Object.Instantiate<Item>(this.m_ItemPrefab, new Vector3(0f, 0f, 0f), Quaternion.identity, this.m_ItemParentGrp);
		item.name = "ItemGrp" + this.m_SpawnedItemCount.ToString();
		item.gameObject.SetActive(false);
		this.m_ItemList.Add(item);
		this.m_SpawnedItemCount++;
		return item;
	}

	// Token: 0x0400034B RID: 843
	public static ItemSpawnManager m_Instance;

	// Token: 0x0400034C RID: 844
	public Item m_ItemPrefab;

	// Token: 0x0400034D RID: 845
	public Transform m_ItemParentGrp;

	// Token: 0x0400034E RID: 846
	private int m_SpawnedItemCount;

	// Token: 0x0400034F RID: 847
	private List<Item> m_ItemList = new List<Item>();
}
