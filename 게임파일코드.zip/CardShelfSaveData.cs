﻿using System;
using System.Collections.Generic;

// Token: 0x0200004C RID: 76
[Serializable]
public class CardShelfSaveData
{
	// Token: 0x0400044C RID: 1100
	public Vector3Serializer pos;

	// Token: 0x0400044D RID: 1101
	public QuaternionSerializer rot;

	// Token: 0x0400044E RID: 1102
	public bool isBoxed;

	// Token: 0x0400044F RID: 1103
	public Vector3Serializer boxedPackagePos;

	// Token: 0x04000450 RID: 1104
	public QuaternionSerializer boxedPackageRot;

	// Token: 0x04000451 RID: 1105
	public EObjectType objectType;

	// Token: 0x04000452 RID: 1106
	public List<CardData> cardDataList;
}
