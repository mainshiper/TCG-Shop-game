﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000D4 RID: 212
public class PoolingManager : CSingleton<PoolingManager>
{
	// Token: 0x06000766 RID: 1894 RVA: 0x000396F3 File Offset: 0x000378F3
	protected PoolingManager()
	{
	}

	// Token: 0x06000767 RID: 1895 RVA: 0x00039704 File Offset: 0x00037904
	private void Start()
	{
		PoolingManager.m_SlashHitFXList = new List<GameObject>();
		PoolingManager.m_ExplosionFXList = new List<GameObject>();
		this.m_SlashHitFXPrefab = this.m_PoolFXScriptableObject.m_SlashHitFXPrefab;
		this.m_ExplosionFXPrefab = this.m_PoolFXScriptableObject.m_ExplosionFXPrefab;
		PoolingManager.m_DefaultPos = new Vector3(9999f, 9999f, 0f);
		base.StartCoroutine(this.SpawnInitialPool());
	}

	// Token: 0x06000768 RID: 1896 RVA: 0x0003976D File Offset: 0x0003796D
	private void ParentObjectToGroup(GameObject poolObject)
	{
		poolObject.transform.SetParent(this.m_PoolingObjectGroup.transform);
	}

	// Token: 0x06000769 RID: 1897 RVA: 0x00039785 File Offset: 0x00037985
	private IEnumerator SpawnInitialPool()
	{
		float waitTime = 0.02f;
		this.m_PoolingObjectGroup = new GameObject("PoolingObject_Grp");
		Object.DontDestroyOnLoad(this.m_PoolingObjectGroup);
		yield return new WaitForSeconds(waitTime);
		for (int i = 0; i < this.m_SlashHitFXInitCount; i++)
		{
			this.objectInst = Object.Instantiate<GameObject>(this.m_SlashHitFXPrefab, PoolingManager.m_DefaultPos, base.transform.rotation);
			this.objectInst.SetActive(false);
			this.ParentObjectToGroup(this.objectInst);
			PoolingManager.m_SlashHitFXList.Add(this.objectInst);
		}
		yield return new WaitForSeconds(waitTime);
		for (int j = 0; j < this.m_ExplosionFXInitCount; j++)
		{
			this.objectInst = Object.Instantiate<GameObject>(this.m_ExplosionFXPrefab, PoolingManager.m_DefaultPos, base.transform.rotation);
			this.objectInst.SetActive(false);
			this.ParentObjectToGroup(this.objectInst);
			PoolingManager.m_ExplosionFXList.Add(this.objectInst);
		}
		yield break;
	}

	// Token: 0x0600076A RID: 1898 RVA: 0x00039794 File Offset: 0x00037994
	public static GameObject ActivateObject(PoolObjectType objectType, Vector3 position, Quaternion rotation, Transform followTarget = null)
	{
		List<GameObject> list = new List<GameObject>();
		List<FollowObject> list2 = new List<FollowObject>();
		if (objectType != PoolObjectType.slashHitFX)
		{
			if (objectType == PoolObjectType.explosionFX)
			{
				list = PoolingManager.m_ExplosionFXList;
			}
		}
		else
		{
			list = PoolingManager.m_SlashHitFXList;
		}
		for (int i = 0; i < list.Count; i++)
		{
			if (!list[i].activeSelf)
			{
				list[i].transform.position = position;
				list[i].transform.rotation = rotation;
				list[i].SetActive(true);
				if (followTarget)
				{
					list2[i].SetFollowTarget(followTarget);
				}
				return list[i];
			}
		}
		return null;
	}

	// Token: 0x0600076B RID: 1899 RVA: 0x00039833 File Offset: 0x00037A33
	public static void DeactivateObject(GameObject gameobject)
	{
		gameobject.transform.position = PoolingManager.m_DefaultPos;
		gameobject.SetActive(false);
	}

	// Token: 0x0400096D RID: 2413
	public PoolFX_ScriptableObject m_PoolFXScriptableObject;

	// Token: 0x0400096E RID: 2414
	private static Vector3 m_DefaultPos;

	// Token: 0x0400096F RID: 2415
	private GameObject m_PoolingObjectGroup;

	// Token: 0x04000970 RID: 2416
	private static List<GameObject> m_SlashHitFXList;

	// Token: 0x04000971 RID: 2417
	private static List<GameObject> m_ExplosionFXList;

	// Token: 0x04000972 RID: 2418
	private GameObject objectInst;

	// Token: 0x04000973 RID: 2419
	private int m_SlashHitFXInitCount;

	// Token: 0x04000974 RID: 2420
	private int m_ExplosionFXInitCount = 10;

	// Token: 0x04000975 RID: 2421
	private GameObject m_SlashHitFXPrefab;

	// Token: 0x04000976 RID: 2422
	private GameObject m_ExplosionFXPrefab;
}
