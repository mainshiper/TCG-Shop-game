﻿using System;
using System.Collections.Generic;

// Token: 0x02000078 RID: 120
public class RestockItemBoardGameScreen : RestockItemScreen
{
	// Token: 0x060004D5 RID: 1237 RVA: 0x0002A028 File Offset: 0x00028228
	protected override void EvaluateRestockItemPanelUI(int pageIndex)
	{
		if (this.m_PageIndex == pageIndex)
		{
			return;
		}
		this.m_PageIndex = pageIndex;
		for (int i = 0; i < this.m_PageButtonHighlightList.Count; i++)
		{
			this.m_PageButtonHighlightList[i].SetActive(false);
		}
		this.m_PageButtonHighlightList[this.m_PageIndex].SetActive(true);
		List<EItemType> list = new List<EItemType>();
		list = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownBoardGameItemType;
		for (int j = 0; j < this.m_RestockItemPanelUIList.Count; j++)
		{
			this.m_RestockItemPanelUIList[j].SetActive(false);
		}
		this.m_CurrentRestockDataIndexList.Clear();
		for (int k = 0; k < list.Count; k++)
		{
			for (int l = 0; l < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList.Count; l++)
			{
				if (list[k] == CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList[l].itemType)
				{
					this.m_CurrentRestockDataIndexList.Add(l);
				}
				else if (list[k] == EItemType.None)
				{
					this.m_CurrentRestockDataIndexList.Add(-1);
					break;
				}
			}
		}
		int num = 0;
		while (num < this.m_CurrentRestockDataIndexList.Count && num < this.m_RestockItemPanelUIList.Count)
		{
			this.m_RestockItemPanelUIList[num].Init(this, this.m_CurrentRestockDataIndexList[num]);
			this.m_RestockItemPanelUIList[num].SetActive(true);
			this.m_ScrollEndPosParent = this.m_RestockItemPanelUIList[num].gameObject;
			num++;
		}
	}
}
