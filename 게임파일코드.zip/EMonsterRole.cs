﻿using System;

// Token: 0x020000ED RID: 237
public enum EMonsterRole
{
	// Token: 0x04000D46 RID: 3398
	PhysicalAttacker,
	// Token: 0x04000D47 RID: 3399
	Defender,
	// Token: 0x04000D48 RID: 3400
	Support,
	// Token: 0x04000D49 RID: 3401
	Healer,
	// Token: 0x04000D4A RID: 3402
	MagicalAttacker,
	// Token: 0x04000D4B RID: 3403
	AllRounder,
	// Token: 0x04000D4C RID: 3404
	Disruptor
}
