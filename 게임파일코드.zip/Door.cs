﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200014E RID: 334
public class Door : MonoBehaviour
{
	// Token: 0x0600097D RID: 2429 RVA: 0x00045EBC File Offset: 0x000440BC
	private void Start()
	{
		this.defaulRot = base.transform.eulerAngles;
		this.openRot = new Vector3(this.defaulRot.x, this.defaulRot.y + this.DoorOpenAngle, this.defaulRot.z);
	}

	// Token: 0x0600097E RID: 2430 RVA: 0x00045F10 File Offset: 0x00044110
	private void Update()
	{
		if (this.open)
		{
			base.transform.eulerAngles = Vector3.Slerp(base.transform.eulerAngles, this.openRot, Time.deltaTime * this.smooth);
		}
		else
		{
			base.transform.eulerAngles = Vector3.Slerp(base.transform.eulerAngles, this.defaulRot, Time.deltaTime * this.smooth);
		}
		if (Input.GetKeyDown(KeyCode.E) && this.trig)
		{
			this.open = !this.open;
		}
		if (this.trig)
		{
			if (this.open)
			{
				this.txt.text = "Close E";
				return;
			}
			this.txt.text = "Open E";
		}
	}

	// Token: 0x0600097F RID: 2431 RVA: 0x00045FD4 File Offset: 0x000441D4
	private void OnTriggerEnter(Collider coll)
	{
		if (coll.tag == "Player")
		{
			if (!this.open)
			{
				this.txt.text = "Close E ";
			}
			else
			{
				this.txt.text = "Open E";
			}
			this.trig = true;
		}
	}

	// Token: 0x06000980 RID: 2432 RVA: 0x00046024 File Offset: 0x00044224
	private void OnTriggerExit(Collider coll)
	{
		if (coll.tag == "Player")
		{
			this.txt.text = " ";
			this.trig = false;
		}
	}

	// Token: 0x040011D7 RID: 4567
	private bool trig;

	// Token: 0x040011D8 RID: 4568
	private bool open;

	// Token: 0x040011D9 RID: 4569
	public float smooth = 2f;

	// Token: 0x040011DA RID: 4570
	public float DoorOpenAngle = 90f;

	// Token: 0x040011DB RID: 4571
	private Vector3 defaulRot;

	// Token: 0x040011DC RID: 4572
	private Vector3 openRot;

	// Token: 0x040011DD RID: 4573
	public Text txt;
}
