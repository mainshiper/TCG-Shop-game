﻿using System;
using System.Collections.Generic;
using I2.Loc;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000085 RID: 133
public class WorkbenchUIScreen : CSingleton<WorkbenchUIScreen>
{
	// Token: 0x0600053D RID: 1341 RVA: 0x0002CA3C File Offset: 0x0002AC3C
	private void Update()
	{
		if (this.m_IsWorkingOnTask)
		{
			this.m_TaskTimer += Time.deltaTime;
			this.m_TaskFinishCirlceFillBar.fillAmount = Mathf.Lerp(0f, 1f, this.m_TaskTimer / this.m_TaskTime);
			if (this.m_TaskTimer >= this.m_TaskTime)
			{
				this.m_TaskTimer = 0f;
				this.m_IsWorkingOnTask = false;
				this.OnTaskCompleted();
			}
		}
	}

	// Token: 0x0600053E RID: 1342 RVA: 0x0002CAB0 File Offset: 0x0002ACB0
	private void OnTaskCompleted()
	{
		this.m_CurrentInteractableWorkbench.OnTaskCompleted(this.m_CurrentCardExpansionType);
		this.m_SliderPriceLimit.interactable = true;
		this.m_SliderMinCard.interactable = true;
		this.m_TaskFinishCirlceGrp.SetActive(false);
		this.CloseScreen(false);
	}

	// Token: 0x0600053F RID: 1343 RVA: 0x0002CAF0 File Offset: 0x0002ACF0
	public static void OpenScreen(InteractableWorkbench interactableWorkbench)
	{
		if (CPlayerData.m_WorkbenchPriceLimit > 0f)
		{
			CSingleton<WorkbenchUIScreen>.Instance.m_MinimumCardLimit = CPlayerData.m_WorkbenchMinimumCardLimit;
			CSingleton<WorkbenchUIScreen>.Instance.m_PriceLimit = CPlayerData.m_WorkbenchPriceLimit;
			CSingleton<WorkbenchUIScreen>.Instance.m_RarityLimit = CPlayerData.m_WorkbenchRarityLimit;
			CSingleton<WorkbenchUIScreen>.Instance.m_CurrentCardExpansionType = CPlayerData.m_WorkbenchCardExpansionType;
		}
		CSingleton<WorkbenchUIScreen>.Instance.m_IgnoreSliderUpdateFunction = true;
		CSingleton<WorkbenchUIScreen>.Instance.m_SliderPriceLimit.value = CPlayerData.m_WorkbenchPriceLimit * 100f;
		CSingleton<WorkbenchUIScreen>.Instance.m_SliderMinCard.value = (float)CPlayerData.m_WorkbenchMinimumCardLimit / 10f * 10f;
		CSingleton<WorkbenchUIScreen>.Instance.m_PriceLimitMinText.text = GameInstance.GetPriceString(0.01f, false, true, false, "F2");
		CSingleton<WorkbenchUIScreen>.Instance.m_PriceLimitMaxText.text = GameInstance.GetPriceString(1f, false, true, false, "F2");
		CSingleton<WorkbenchUIScreen>.Instance.m_IgnoreSliderUpdateFunction = false;
		CSingleton<WorkbenchUIScreen>.Instance.m_MinimumCardLimit = CPlayerData.m_WorkbenchMinimumCardLimit;
		CSingleton<WorkbenchUIScreen>.Instance.m_CardExpansionText.text = InventoryBase.GetCardExpansionName(CSingleton<WorkbenchUIScreen>.Instance.m_CurrentCardExpansionType);
		if (CSingleton<WorkbenchUIScreen>.Instance.m_HasRarityLimit)
		{
			CSingleton<WorkbenchUIScreen>.Instance.m_RarityLimitText.text = LocalizationManager.GetTranslation(CSingleton<WorkbenchUIScreen>.Instance.m_RarityLimit.ToString(), true, 0, true, false, null, null, true);
		}
		else
		{
			CSingleton<WorkbenchUIScreen>.Instance.m_RarityLimitText.text = LocalizationManager.GetTranslation("Any Rarity", true, 0, true, false, null, null, true);
		}
		CSingleton<WorkbenchUIScreen>.Instance.m_PriceLimitText.text = GameInstance.GetPriceString(CSingleton<WorkbenchUIScreen>.Instance.m_PriceLimit, false, true, false, "F2");
		CSingleton<WorkbenchUIScreen>.Instance.m_MinimumCardText.text = CSingleton<WorkbenchUIScreen>.Instance.m_MinimumCardLimit.ToString();
		CSingleton<WorkbenchUIScreen>.Instance.m_TaskFinishCirlceGrp.SetActive(false);
		CSingleton<WorkbenchUIScreen>.Instance.m_CurrentInteractableWorkbench = interactableWorkbench;
		CSingleton<WorkbenchUIScreen>.Instance.m_ScreenGrp.SetActive(true);
		SoundManager.GenericMenuOpen(1f, 1f);
		ControllerScreenUIExtManager.OnOpenScreen(CSingleton<WorkbenchUIScreen>.Instance.m_ControllerScreenUIExtension);
		TutorialManager.SetGameUIVisible(false);
	}

	// Token: 0x06000540 RID: 1344 RVA: 0x0002CCF8 File Offset: 0x0002AEF8
	public void CloseScreen(bool playSound)
	{
		if (InputManager.IsSliderActive())
		{
			return;
		}
		if (this.m_IsWorkingOnTask)
		{
			return;
		}
		if (playSound)
		{
			SoundManager.GenericMenuClose(1f, 1f);
		}
		this.m_PriceLimitText.text = GameInstance.GetPriceString(this.m_PriceLimit, false, true, false, "F2");
		this.m_MinimumCardText.text = this.m_MinimumCardLimit.ToString();
		this.m_CardExpansionText.text = InventoryBase.GetCardExpansionName(this.m_CurrentCardExpansionType);
		if (this.m_HasRarityLimit)
		{
			this.m_RarityLimitText.text = LocalizationManager.GetTranslation(this.m_RarityLimit.ToString(), true, 0, true, false, null, null, true);
		}
		else
		{
			this.m_RarityLimitText.text = LocalizationManager.GetTranslation("Any Rarity", true, 0, true, false, null, null, true);
		}
		CSingleton<WorkbenchUIScreen>.Instance.m_CurrentInteractableWorkbench.OnPressEsc();
		this.m_ScreenGrp.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<WorkbenchUIScreen>.Instance.m_ControllerScreenUIExtension);
		TutorialManager.SetGameUIVisible(true);
	}

	// Token: 0x06000541 RID: 1345 RVA: 0x0002CDF0 File Offset: 0x0002AFF0
	public void OpenBundleCardScreen()
	{
		if (this.m_IsWorkingOnTask)
		{
			return;
		}
		bool flag = false;
		List<InteractableWorkbench> workbenchList = CSingleton<ShelfManager>.Instance.m_WorkbenchList;
		for (int i = 0; i < workbenchList.Count; i++)
		{
			if (workbenchList[i].HasEnoughSlot())
			{
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			EItemType bulkBoxItemType = this.m_CurrentInteractableWorkbench.GetBulkBoxItemType(this.m_CurrentCardExpansionType);
			if (ShelfManager.GetShelfListToRestockItem(bulkBoxItemType, false).Count > 0)
			{
				flag = true;
			}
			else if (RestockManager.GetItemPackagingBoxListWithSpaceForItem(bulkBoxItemType).Count > 0)
			{
				flag = true;
			}
		}
		SoundManager.GenericConfirm(1f, 1f);
		if (flag)
		{
			this.RunBundleCardBulkFunction();
			return;
		}
		NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.NoSpaceToStartBundle);
	}

	// Token: 0x06000542 RID: 1346 RVA: 0x0002CE8E File Offset: 0x0002B08E
	public void OnPressChangeCardExpannsionButton()
	{
		if (this.m_IsWorkingOnTask)
		{
			return;
		}
		SoundManager.GenericMenuOpen(1f, 1f);
		CardExpansionSelectScreen.OpenScreen(this.m_CurrentCardExpansionType);
		CEventManager.AddListener<CEventPlayer_OnCardExpansionSelectScreenUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnCardExpansionSelectScreenUpdated>(this.OnCardExpansionUpdated));
	}

	// Token: 0x06000543 RID: 1347 RVA: 0x0002CEC4 File Offset: 0x0002B0C4
	protected void OnCardExpansionUpdated(CEventPlayer_OnCardExpansionSelectScreenUpdated evt)
	{
		this.m_CurrentCardExpansionType = (ECardExpansionType)evt.m_CardExpansionTypeIndex;
		CPlayerData.m_WorkbenchCardExpansionType = this.m_CurrentCardExpansionType;
		this.m_CardExpansionText.text = InventoryBase.GetCardExpansionName(this.m_CurrentCardExpansionType);
		CEventManager.RemoveListener<CEventPlayer_OnCardExpansionSelectScreenUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnCardExpansionSelectScreenUpdated>(this.OnCardExpansionUpdated));
	}

	// Token: 0x06000544 RID: 1348 RVA: 0x0002CF04 File Offset: 0x0002B104
	public void OnPressChangeRarityButton()
	{
		if (this.m_IsWorkingOnTask)
		{
			return;
		}
		SoundManager.GenericMenuOpen(1f, 1f);
		CardRaritySelectScreen.OpenScreen(this.m_RarityLimit);
		CEventManager.AddListener<CEventPlayer_OnCardRaritySelectScreenUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnCardRaritySelectScreenUpdated>(this.OnRarityLimitUpdated));
	}

	// Token: 0x06000545 RID: 1349 RVA: 0x0002CF3C File Offset: 0x0002B13C
	public void OnRarityLimitUpdated(CEventPlayer_OnCardRaritySelectScreenUpdated evt)
	{
		if (evt.m_CardRarityIndex == -1)
		{
			this.m_HasRarityLimit = false;
		}
		else
		{
			this.m_HasRarityLimit = true;
			this.m_RarityLimit = (ERarity)evt.m_CardRarityIndex;
		}
		CPlayerData.m_WorkbenchRarityLimit = this.m_RarityLimit;
		if (this.m_HasRarityLimit)
		{
			this.m_RarityLimitText.text = LocalizationManager.GetTranslation(this.m_RarityLimit.ToString(), true, 0, true, false, null, null, true);
		}
		else
		{
			this.m_RarityLimitText.text = LocalizationManager.GetTranslation("Any Rarity", true, 0, true, false, null, null, true);
		}
		CEventManager.RemoveListener<CEventPlayer_OnCardRaritySelectScreenUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnCardRaritySelectScreenUpdated>(this.OnRarityLimitUpdated));
	}

	// Token: 0x06000546 RID: 1350 RVA: 0x0002CFD8 File Offset: 0x0002B1D8
	public void OnSliderValueChanged_PriceLimit()
	{
		if (this.m_IgnoreSliderUpdateFunction)
		{
			return;
		}
		this.m_PriceLimit = (float)Mathf.RoundToInt(this.m_SliderPriceLimit.value) / 100f;
		this.m_PriceLimitText.text = GameInstance.GetPriceString(this.m_PriceLimit, false, true, false, "F2");
		CPlayerData.m_WorkbenchPriceLimit = this.m_PriceLimit;
	}

	// Token: 0x06000547 RID: 1351 RVA: 0x0002D034 File Offset: 0x0002B234
	public void OnSliderValueChanged_MinimumCard()
	{
		if (this.m_IgnoreSliderUpdateFunction)
		{
			return;
		}
		this.m_MinimumCardLimit = Mathf.CeilToInt(this.m_SliderMinCard.value);
		this.m_MinimumCardText.text = this.m_MinimumCardLimit.ToString();
		CPlayerData.m_WorkbenchMinimumCardLimit = this.m_MinimumCardLimit;
	}

	// Token: 0x06000548 RID: 1352 RVA: 0x0002D084 File Offset: 0x0002B284
	private void RunBundleCardBulkFunction()
	{
		ECardExpansionType currentCardExpansionType = this.m_CurrentCardExpansionType;
		bool flag = false;
		int num = 0;
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		for (int i = 0; i < InventoryBase.GetShownMonsterList(currentCardExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(currentCardExpansionType, true); i++)
		{
			int num2 = i;
			EMonsterType monsterTypeFromCardSaveIndex = CPlayerData.GetMonsterTypeFromCardSaveIndex(num2, currentCardExpansionType);
			float cardMarketPrice = CPlayerData.GetCardMarketPrice(num2, currentCardExpansionType, flag);
			ERarity rarity = InventoryBase.GetMonsterData(monsterTypeFromCardSaveIndex).Rarity;
			int cardAmountByIndex = CPlayerData.GetCardAmountByIndex(num2, currentCardExpansionType, flag);
			if (cardMarketPrice < this.m_PriceLimit && (!this.m_HasRarityLimit || this.m_RarityLimit == rarity) && cardAmountByIndex > CPlayerData.m_WorkbenchMinimumCardLimit)
			{
				list.Add(num2);
				list2.Add(cardAmountByIndex - CPlayerData.m_WorkbenchMinimumCardLimit);
				num += cardAmountByIndex - CPlayerData.m_WorkbenchMinimumCardLimit;
			}
		}
		if (num < 100)
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.NotEnoughCardForBundle);
			return;
		}
		this.m_SliderPriceLimit.interactable = false;
		this.m_SliderMinCard.interactable = false;
		int j = 0;
		int num3 = 0;
		float num4 = 0f;
		List<CardData> list3 = new List<CardData>();
		while (j < 100)
		{
			for (int k = 0; k < list.Count; k++)
			{
				int num5 = Mathf.Clamp(Random.Range(1, list2[k] + 5), 1, 10);
				if (num5 > list2[k])
				{
					num5 = list2[k];
				}
				if (num5 > 100 - j)
				{
					num5 = 100 - j;
				}
				j += num5;
				List<int> list4 = list2;
				int index = k;
				list4[index] -= num5;
				if (list3.Count < 10)
				{
					list3.Add(CPlayerData.GetCardData(list[k], currentCardExpansionType, flag));
				}
				num4 += CPlayerData.GetCardMarketPrice(list[k], currentCardExpansionType, flag) * (float)num5;
				CPlayerData.ReduceCardUsingIndex(list[k], currentCardExpansionType, flag, num5);
				if (j >= 100)
				{
					break;
				}
			}
			num3++;
			if (num3 > 10000)
			{
				break;
			}
		}
		this.m_CurrentCardExpansionType = currentCardExpansionType;
		this.m_CurrentInteractableWorkbench.PlayBundlingCardBoxSequence(list3, currentCardExpansionType);
		this.m_IsWorkingOnTask = true;
		this.m_TaskFinishCirlceGrp.SetActive(true);
	}

	// Token: 0x040006D9 RID: 1753
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x040006DA RID: 1754
	public GameObject m_ScreenGrp;

	// Token: 0x040006DB RID: 1755
	public GameObject m_TaskFinishCirlceGrp;

	// Token: 0x040006DC RID: 1756
	public Image m_TaskFinishCirlceFillBar;

	// Token: 0x040006DD RID: 1757
	public Slider m_SliderPriceLimit;

	// Token: 0x040006DE RID: 1758
	public Slider m_SliderMinCard;

	// Token: 0x040006DF RID: 1759
	public TextMeshProUGUI m_PriceLimitText;

	// Token: 0x040006E0 RID: 1760
	public TextMeshProUGUI m_MinimumCardText;

	// Token: 0x040006E1 RID: 1761
	public TextMeshProUGUI m_CardExpansionText;

	// Token: 0x040006E2 RID: 1762
	public TextMeshProUGUI m_RarityLimitText;

	// Token: 0x040006E3 RID: 1763
	public TextMeshProUGUI m_PriceLimitMinText;

	// Token: 0x040006E4 RID: 1764
	public TextMeshProUGUI m_PriceLimitMaxText;

	// Token: 0x040006E5 RID: 1765
	private bool m_IsWorkingOnTask;

	// Token: 0x040006E6 RID: 1766
	private bool m_HasRarityLimit;

	// Token: 0x040006E7 RID: 1767
	private bool m_IgnoreSliderUpdateFunction;

	// Token: 0x040006E8 RID: 1768
	private int m_MinimumCardLimit = 4;

	// Token: 0x040006E9 RID: 1769
	private float m_TaskTime = 5f;

	// Token: 0x040006EA RID: 1770
	private float m_TaskTimer;

	// Token: 0x040006EB RID: 1771
	private float m_PriceLimit = 0.5f;

	// Token: 0x040006EC RID: 1772
	private ERarity m_RarityLimit = ERarity.None;

	// Token: 0x040006ED RID: 1773
	private ECardExpansionType m_CurrentCardExpansionType;

	// Token: 0x040006EE RID: 1774
	private InteractableWorkbench m_CurrentInteractableWorkbench;
}
