﻿using System;

// Token: 0x020000BE RID: 190
public class CEventPlayer_FinishHideLoadingScreen : CEvent
{
}
