﻿using System;

// Token: 0x020000DA RID: 218
public enum EItemType
{
	// Token: 0x040009C9 RID: 2505
	None = -1,
	// Token: 0x040009CA RID: 2506
	BasicCardPack,
	// Token: 0x040009CB RID: 2507
	BasicCardBox,
	// Token: 0x040009CC RID: 2508
	RareCardPack,
	// Token: 0x040009CD RID: 2509
	RareCardBox,
	// Token: 0x040009CE RID: 2510
	EpicCardPack,
	// Token: 0x040009CF RID: 2511
	EpicCardBox,
	// Token: 0x040009D0 RID: 2512
	LegendaryCardPack,
	// Token: 0x040009D1 RID: 2513
	LegendaryCardBox,
	// Token: 0x040009D2 RID: 2514
	DestinyBasicCardPack,
	// Token: 0x040009D3 RID: 2515
	DestinyBasicCardBox,
	// Token: 0x040009D4 RID: 2516
	DestinyRareCardPack,
	// Token: 0x040009D5 RID: 2517
	DestinyRareCardBox,
	// Token: 0x040009D6 RID: 2518
	DestinyEpicCardPack,
	// Token: 0x040009D7 RID: 2519
	DestinyEpicCardBox,
	// Token: 0x040009D8 RID: 2520
	DestinyLegendaryCardPack,
	// Token: 0x040009D9 RID: 2521
	DestinyLegendaryCardBox,
	// Token: 0x040009DA RID: 2522
	GhostPack,
	// Token: 0x040009DB RID: 2523
	MegabotPack,
	// Token: 0x040009DC RID: 2524
	FantasyRPGPack,
	// Token: 0x040009DD RID: 2525
	CatJobPack,
	// Token: 0x040009DE RID: 2526
	FoodieGOPack,
	// Token: 0x040009DF RID: 2527
	FoodieGOBWPack,
	// Token: 0x040009E0 RID: 2528
	FoodieGOJPPack,
	// Token: 0x040009E1 RID: 2529
	Deodorant,
	// Token: 0x040009E2 RID: 2530
	DeckBox1,
	// Token: 0x040009E3 RID: 2531
	DeckBox2,
	// Token: 0x040009E4 RID: 2532
	DeckBox3,
	// Token: 0x040009E5 RID: 2533
	DeckBox4,
	// Token: 0x040009E6 RID: 2534
	BinderBook,
	// Token: 0x040009E7 RID: 2535
	D20DiceBox,
	// Token: 0x040009E8 RID: 2536
	D20DiceBox2,
	// Token: 0x040009E9 RID: 2537
	D20DiceBox3,
	// Token: 0x040009EA RID: 2538
	D20DiceBox4,
	// Token: 0x040009EB RID: 2539
	Toy_PiggyA,
	// Token: 0x040009EC RID: 2540
	Toy_GolemA,
	// Token: 0x040009ED RID: 2541
	Toy_StarfishA,
	// Token: 0x040009EE RID: 2542
	Toy_BatA,
	// Token: 0x040009EF RID: 2543
	BulkBox_TetramonBase,
	// Token: 0x040009F0 RID: 2544
	BulkBox_TetramonDestiny,
	// Token: 0x040009F1 RID: 2545
	Toy_PiggyB,
	// Token: 0x040009F2 RID: 2546
	Toy_PiggyC,
	// Token: 0x040009F3 RID: 2547
	Toy_PiggyD,
	// Token: 0x040009F4 RID: 2548
	Toy_GolemB,
	// Token: 0x040009F5 RID: 2549
	Toy_GolemC,
	// Token: 0x040009F6 RID: 2550
	Toy_GolemD,
	// Token: 0x040009F7 RID: 2551
	Toy_StarfishB,
	// Token: 0x040009F8 RID: 2552
	Toy_StarfishC,
	// Token: 0x040009F9 RID: 2553
	Toy_StarfishD,
	// Token: 0x040009FA RID: 2554
	Toy_BatB,
	// Token: 0x040009FB RID: 2555
	Toy_BatC,
	// Token: 0x040009FC RID: 2556
	Toy_BatD,
	// Token: 0x040009FD RID: 2557
	Toy_Beetle,
	// Token: 0x040009FE RID: 2558
	Toy_FoxB,
	// Token: 0x040009FF RID: 2559
	Toy_ToonZ,
	// Token: 0x04000A00 RID: 2560
	BinderBookPremium,
	// Token: 0x04000A01 RID: 2561
	PreconDeck_Fire,
	// Token: 0x04000A02 RID: 2562
	PreconDeck_Earth,
	// Token: 0x04000A03 RID: 2563
	PreconDeck_Water,
	// Token: 0x04000A04 RID: 2564
	PreconDeck_Wind,
	// Token: 0x04000A05 RID: 2565
	PreconDeck_FireDestiny,
	// Token: 0x04000A06 RID: 2566
	PreconDeck_EarthDestiny,
	// Token: 0x04000A07 RID: 2567
	PreconDeck_WaterDestiny,
	// Token: 0x04000A08 RID: 2568
	PreconDeck_WindDestiny,
	// Token: 0x04000A09 RID: 2569
	CardSleeve_Clear,
	// Token: 0x04000A0A RID: 2570
	CardSleeve_Tetramon,
	// Token: 0x04000A0B RID: 2571
	CardSleeve_Fire,
	// Token: 0x04000A0C RID: 2572
	CardSleeve_Earth,
	// Token: 0x04000A0D RID: 2573
	CardSleeve_Water,
	// Token: 0x04000A0E RID: 2574
	CardSleeve_Wind,
	// Token: 0x04000A0F RID: 2575
	Playmat1,
	// Token: 0x04000A10 RID: 2576
	Playmat2,
	// Token: 0x04000A11 RID: 2577
	Playmat2b,
	// Token: 0x04000A12 RID: 2578
	Playmat3,
	// Token: 0x04000A13 RID: 2579
	Playmat4,
	// Token: 0x04000A14 RID: 2580
	Playmat5,
	// Token: 0x04000A15 RID: 2581
	Playmat6,
	// Token: 0x04000A16 RID: 2582
	Playmat7,
	// Token: 0x04000A17 RID: 2583
	Playmat8,
	// Token: 0x04000A18 RID: 2584
	Playmat9,
	// Token: 0x04000A19 RID: 2585
	Playmat10,
	// Token: 0x04000A1A RID: 2586
	Playmat11,
	// Token: 0x04000A1B RID: 2587
	Playmat12,
	// Token: 0x04000A1C RID: 2588
	Playmat13,
	// Token: 0x04000A1D RID: 2589
	Playmat14,
	// Token: 0x04000A1E RID: 2590
	Boardgame_Speedrobo_Necro,
	// Token: 0x04000A1F RID: 2591
	Boardgame_Speedrobo_Claim,
	// Token: 0x04000A20 RID: 2592
	Boardgame_Speedrobo_Mafia,
	// Token: 0x04000A21 RID: 2593
	Boardgame_Speedrobo_SystemGate1,
	// Token: 0x04000A22 RID: 2594
	Boardgame_Speedrobo_SystemGate2,
	// Token: 0x04000A23 RID: 2595
	Max
}
