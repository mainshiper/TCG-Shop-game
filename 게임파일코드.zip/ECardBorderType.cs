﻿using System;

// Token: 0x020000EA RID: 234
public enum ECardBorderType
{
	// Token: 0x04000B75 RID: 2933
	Base,
	// Token: 0x04000B76 RID: 2934
	FirstEdition,
	// Token: 0x04000B77 RID: 2935
	Silver,
	// Token: 0x04000B78 RID: 2936
	Gold,
	// Token: 0x04000B79 RID: 2937
	EX,
	// Token: 0x04000B7A RID: 2938
	FullArt
}
