﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x0200008C RID: 140
public class LockedRoomBlocker : MonoBehaviour
{
	// Token: 0x06000584 RID: 1412 RVA: 0x0002E419 File Offset: 0x0002C619
	private void Awake()
	{
		this.m_Wall.SetActive(!this.m_IsFrontRow);
		this.m_Building.SetActive(this.m_IsFrontRow);
	}

	// Token: 0x06000585 RID: 1413 RVA: 0x0002E440 File Offset: 0x0002C640
	public void HideBlocker()
	{
		this.m_Anim.Play();
	}

	// Token: 0x06000586 RID: 1414 RVA: 0x0002E44E File Offset: 0x0002C64E
	private IEnumerator DelayHide()
	{
		yield return new WaitForSeconds(1f);
		base.gameObject.SetActive(false);
		yield break;
	}

	// Token: 0x0400072A RID: 1834
	public bool m_IsFrontRow;

	// Token: 0x0400072B RID: 1835
	public GameObject m_Wall;

	// Token: 0x0400072C RID: 1836
	public GameObject m_Building;

	// Token: 0x0400072D RID: 1837
	public Animation m_Anim;
}
