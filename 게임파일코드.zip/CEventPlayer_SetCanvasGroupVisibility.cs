﻿using System;

// Token: 0x020000C6 RID: 198
public class CEventPlayer_SetCanvasGroupVisibility : CEvent
{
	// Token: 0x17000022 RID: 34
	// (get) Token: 0x0600073D RID: 1853 RVA: 0x0003953B File Offset: 0x0003773B
	// (set) Token: 0x0600073E RID: 1854 RVA: 0x00039543 File Offset: 0x00037743
	public bool m_IsVisible { get; private set; }

	// Token: 0x0600073F RID: 1855 RVA: 0x0003954C File Offset: 0x0003774C
	public CEventPlayer_SetCanvasGroupVisibility(bool isVisible)
	{
		this.m_IsVisible = isVisible;
	}
}
