﻿using System;
using UnityEngine;

// Token: 0x0200001D RID: 29
[Serializable]
public class CounterMoneyChangeCurrencyData
{
	// Token: 0x040001DB RID: 475
	public string name;

	// Token: 0x040001DC RID: 476
	public EMoneyCurrencyType currencyType;

	// Token: 0x040001DD RID: 477
	public bool isCoin;

	// Token: 0x040001DE RID: 478
	public float value;

	// Token: 0x040001DF RID: 479
	public Material changeMaterial;
}
