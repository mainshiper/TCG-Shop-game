﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000135 RID: 309
[CreateAssetMenu(fileName = "Data", menuName = "Inventory/List", order = 4)]
public class StockItemData_ScriptableObject : ScriptableObject
{
	// Token: 0x04001104 RID: 4356
	public List<EItemType> m_ShownAllItemType;

	// Token: 0x04001105 RID: 4357
	public List<EItemType> m_ShownItemType;

	// Token: 0x04001106 RID: 4358
	public List<EItemType> m_ShownAccessoryItemType;

	// Token: 0x04001107 RID: 4359
	public List<EItemType> m_ShownFigurineItemType;

	// Token: 0x04001108 RID: 4360
	public List<EItemType> m_ShownBoardGameItemType;

	// Token: 0x04001109 RID: 4361
	public List<ECollectionPackType> m_ShownCollectionPackType;

	// Token: 0x0400110A RID: 4362
	public List<ECardExpansionType> m_ShownCardExpansionType;

	// Token: 0x0400110B RID: 4363
	public List<ItemData> m_ItemDataList;

	// Token: 0x0400110C RID: 4364
	public List<ItemMeshData> m_ItemMeshDataList;

	// Token: 0x0400110D RID: 4365
	public List<RestockData> m_RestockDataList;

	// Token: 0x0400110E RID: 4366
	public List<GameEventData> m_GameEventDataList;

	// Token: 0x0400110F RID: 4367
	public List<CollectionPackImageSprite> m_CollectionPackImageSpriteList;

	// Token: 0x04001110 RID: 4368
	public float m_ShelfUnlockCostMultiplier;

	// Token: 0x04001111 RID: 4369
	public float m_ShelfUpgradeCostMultiplier;

	// Token: 0x04001112 RID: 4370
	public List<EQuestType> m_IdealQuestSequenceList;

	// Token: 0x04001113 RID: 4371
	public List<Sprite> m_AncientArtifactSpriteList;
}
