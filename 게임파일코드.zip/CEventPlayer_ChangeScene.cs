﻿using System;

// Token: 0x020000BB RID: 187
public class CEventPlayer_ChangeScene : CEvent
{
	// Token: 0x1700001F RID: 31
	// (get) Token: 0x0600072C RID: 1836 RVA: 0x0003949B File Offset: 0x0003769B
	// (set) Token: 0x0600072D RID: 1837 RVA: 0x000394A3 File Offset: 0x000376A3
	public ELevelName m_SceneName { get; private set; }

	// Token: 0x0600072E RID: 1838 RVA: 0x000394AC File Offset: 0x000376AC
	public CEventPlayer_ChangeScene(ELevelName SceneName)
	{
		this.m_SceneName = SceneName;
	}
}
