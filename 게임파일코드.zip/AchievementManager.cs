﻿using System;
using System.Collections.Generic;
using HeathenEngineering.SteamworksIntegration;
using UnityEngine;

// Token: 0x020000A0 RID: 160
public class AchievementManager : CSingleton<AchievementManager>
{
	// Token: 0x0600063C RID: 1596 RVA: 0x000335C0 File Offset: 0x000317C0
	private void Awake()
	{
		if (AchievementManager.m_Instance == null)
		{
			AchievementManager.m_Instance = this;
		}
		else if (AchievementManager.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
	}

	// Token: 0x0600063D RID: 1597 RVA: 0x000335F8 File Offset: 0x000317F8
	public static void OnItemLicenseUnlocked(EItemType itemType)
	{
		if (itemType == EItemType.BasicCardBox)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockBasicCardBox");
			return;
		}
		if (itemType == EItemType.RareCardPack)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockRareCardPack");
			return;
		}
		if (itemType == EItemType.EpicCardPack)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockEpicCardPack");
			return;
		}
		if (itemType == EItemType.LegendaryCardPack)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockLegendCardPack");
			return;
		}
		if (itemType == EItemType.DestinyBasicCardPack)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockDestinyBasicPack");
			return;
		}
		if (itemType == EItemType.DestinyRareCardPack)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockDestinyRarePack");
			return;
		}
		if (itemType == EItemType.DestinyEpicCardPack)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockDestinyEpicPack");
			return;
		}
		if (itemType == EItemType.DestinyLegendaryCardPack)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockDestinyLegendPack");
		}
	}

	// Token: 0x0600063E RID: 1598 RVA: 0x000336A7 File Offset: 0x000318A7
	public static void OnStaffHired(int count)
	{
		if (count >= 8)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_Worker3");
		}
		if (count >= 4)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_Worker2");
		}
		if (count >= 1)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_Worker1");
		}
	}

	// Token: 0x0600063F RID: 1599 RVA: 0x000336E4 File Offset: 0x000318E4
	public static void OnCardPackOpened(int count)
	{
		if (count >= 100)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_OpenPack1");
		}
		if (count >= 1000)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_OpenPack2");
		}
		if (count >= 10000)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_OpenPack3");
		}
	}

	// Token: 0x06000640 RID: 1600 RVA: 0x00033734 File Offset: 0x00031934
	public static void OnCustomerFinishPlay(int count)
	{
		if (count >= 100)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_CustomerPlay1");
		}
		if (count >= 1500)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_CustomerPlay2");
		}
		if (count >= 5000)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_CustomerPlay3");
		}
	}

	// Token: 0x06000641 RID: 1601 RVA: 0x00033783 File Offset: 0x00031983
	public static void OnCustomerFinishCheckout(int count)
	{
		if (count >= 1000)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_Checkout");
		}
	}

	// Token: 0x06000642 RID: 1602 RVA: 0x0003379C File Offset: 0x0003199C
	public static void OnSoldCardPrice(float priceAmount)
	{
		if (priceAmount >= 200f)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_SellCard1");
		}
		if (priceAmount >= 5000f)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_SellCard2");
		}
		if (priceAmount >= 10000f)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_SellCard3");
		}
	}

	// Token: 0x06000643 RID: 1603 RVA: 0x000337F0 File Offset: 0x000319F0
	public static void OnDailyProfitReached(float priceAmount)
	{
		if (priceAmount >= 30000f)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_Profit3");
		}
		if (priceAmount >= 10000f)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_Profit2");
		}
		if (priceAmount >= 1000f)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_Profit1");
		}
	}

	// Token: 0x06000644 RID: 1604 RVA: 0x00033842 File Offset: 0x00031A42
	public static void OnGetFullArtFoil(bool isGet)
	{
		if (isGet)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_FullArtFoil");
		}
	}

	// Token: 0x06000645 RID: 1605 RVA: 0x00033856 File Offset: 0x00031A56
	public static void OnGetFullArtGhostFoil(bool isGet)
	{
		if (isGet)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_GhostFoil");
		}
	}

	// Token: 0x06000646 RID: 1606 RVA: 0x0003386C File Offset: 0x00031A6C
	public static void OnCheckAlbumCardCount(int count)
	{
		if (count >= 100)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_CardCollector1");
		}
		if (count >= 500)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_CardCollector2");
		}
		if (count >= 1500)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_CardCollector3");
		}
		if (count >= 2500)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_CardCollector4");
		}
	}

	// Token: 0x06000647 RID: 1607 RVA: 0x000338D2 File Offset: 0x00031AD2
	public static void OnCleanSmellyCustomer(int count)
	{
		if (count >= 20)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_SmellyClean1");
		}
		if (count >= 200)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_SmellyClean2");
		}
	}

	// Token: 0x06000648 RID: 1608 RVA: 0x000338FF File Offset: 0x00031AFF
	public static void OnShopLotBUnlocked()
	{
		CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockShopLotB");
	}

	// Token: 0x06000649 RID: 1609 RVA: 0x00033910 File Offset: 0x00031B10
	public static void OnUnlockShopExpansion(int roomCount)
	{
		if (roomCount >= 4)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopExpansion1");
		}
		if (roomCount >= 10)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopExpansion2");
		}
		if (roomCount >= 20)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopExpansion3");
		}
	}

	// Token: 0x0600064A RID: 1610 RVA: 0x00033950 File Offset: 0x00031B50
	private void OnShopLevelUp(CEventPlayer_ShopLeveledUp evt)
	{
		if (evt.m_ShopLevel + 1 >= 5)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopLevel1");
		}
		if (evt.m_ShopLevel + 1 >= 20)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopLevel2");
		}
		if (evt.m_ShopLevel + 1 >= 50)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopLevel3");
		}
		if (evt.m_ShopLevel + 1 >= 100)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopLevel4");
		}
	}

	// Token: 0x0600064B RID: 1611 RVA: 0x000339C8 File Offset: 0x00031BC8
	public static void ShopLevelCheck(int level)
	{
		if (level + 1 >= 5)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopLevel1");
		}
		if (level + 1 >= 20)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopLevel2");
		}
		if (level + 1 >= 50)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopLevel3");
		}
		if (level + 1 >= 100)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopLevel4");
		}
	}

	// Token: 0x0600064C RID: 1612 RVA: 0x00033A2C File Offset: 0x00031C2C
	public void UnlockAchievement(string achievementID)
	{
		try
		{
			AchievementData achievementData = achievementID;
			if (!achievementData.IsAchieved)
			{
				achievementData.IsAchieved = true;
				achievementData.Store();
			}
		}
		catch
		{
		}
		int index = this.m_AchievementSringList.IndexOf(achievementID);
		CPlayerData.m_IsAchievementUnlocked[index] = true;
	}

	// Token: 0x0600064D RID: 1613 RVA: 0x00033A88 File Offset: 0x00031C88
	protected virtual void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_ShopLeveledUp>(new CEventManager.EventDelegate<CEventPlayer_ShopLeveledUp>(this.OnShopLevelUp));
			CEventManager.AddListener<CEventPlayer_FinishHideLoadingScreen>(new CEventManager.EventDelegate<CEventPlayer_FinishHideLoadingScreen>(this.OnFinishHideLoadingScreen));
		}
	}

	// Token: 0x0600064E RID: 1614 RVA: 0x00033ABA File Offset: 0x00031CBA
	protected virtual void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_ShopLeveledUp>(new CEventManager.EventDelegate<CEventPlayer_ShopLeveledUp>(this.OnShopLevelUp));
			CEventManager.RemoveListener<CEventPlayer_FinishHideLoadingScreen>(new CEventManager.EventDelegate<CEventPlayer_FinishHideLoadingScreen>(this.OnFinishHideLoadingScreen));
		}
	}

	// Token: 0x0600064F RID: 1615 RVA: 0x00033AEC File Offset: 0x00031CEC
	protected void OnFinishHideLoadingScreen(CEventPlayer_FinishHideLoadingScreen evt)
	{
		AchievementManager.ShopLevelCheck(CPlayerData.m_ShopLevel);
		for (int i = 0; i < CPlayerData.m_IsAchievementUnlocked.Count; i++)
		{
			if (CPlayerData.m_IsAchievementUnlocked[i])
			{
				this.UnlockAchievement(this.m_AchievementSringList[i]);
			}
		}
	}

	// Token: 0x0400080A RID: 2058
	public static AchievementManager m_Instance;

	// Token: 0x0400080B RID: 2059
	public List<string> m_AchievementSringList;
}
