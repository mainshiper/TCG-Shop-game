﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000045 RID: 69
public class RestockManager : CSingleton<RestockManager>
{
	// Token: 0x06000349 RID: 841 RVA: 0x0001E0BB File Offset: 0x0001C2BB
	private void Awake()
	{
	}

	// Token: 0x0600034A RID: 842 RVA: 0x0001E0C0 File Offset: 0x0001C2C0
	private void Update()
	{
		if (CSingleton<RestockManager>.Instance.m_SpawnBoxItemWaitingList.Count > 0)
		{
			this.m_SpawnBoxItemTimer += Time.deltaTime;
			if (this.m_SpawnBoxItemTimer >= this.m_SpawnBoxItemTime)
			{
				if (this.m_SpawnBoxItemWaitingList[0].isBigBox)
				{
					RestockManager.SpawnPackageBoxItem(this.m_SpawnBoxItemWaitingList[0].itemType, 64, this.m_SpawnBoxItemWaitingList[0].isBigBox);
				}
				else
				{
					RestockManager.SpawnPackageBoxItem(this.m_SpawnBoxItemWaitingList[0].itemType, 32, this.m_SpawnBoxItemWaitingList[0].isBigBox);
				}
				List<int> spawnBoxItemCountWaitingList = this.m_SpawnBoxItemCountWaitingList;
				spawnBoxItemCountWaitingList[0] = spawnBoxItemCountWaitingList[0] - 1;
				if (this.m_SpawnBoxItemCountWaitingList[0] <= 0)
				{
					this.m_SpawnBoxItemWaitingList.RemoveAt(0);
					this.m_SpawnBoxItemCountWaitingList.RemoveAt(0);
				}
				this.m_SpawnBoxItemTimer = 0f;
			}
		}
		this.m_OutofBoundCheckTimer += Time.deltaTime;
		if (this.m_OutofBoundCheckTimer > 5f)
		{
			this.m_OutofBoundCheckTimer = 0f;
			for (int i = 0; i < this.m_ItemPackagingBoxList.Count; i++)
			{
				if (this.m_ItemPackagingBoxList[i].transform.position.y > 8f || this.m_ItemPackagingBoxList[i].transform.position.y < -1f || this.m_ItemPackagingBoxList[i].transform.position.x < -4.35f || this.m_ItemPackagingBoxList[i].transform.position.x > 17.5f)
				{
					this.m_ItemPackagingBoxList[i].transform.position = CSingleton<RestockManager>.Instance.m_PackageBoxSpawnLocationList[Random.Range(0, CSingleton<RestockManager>.Instance.m_PackageBoxSpawnLocationList.Count)].position;
				}
				if (!CPlayerData.m_IsWarehouseRoomUnlocked && this.m_ItemPackagingBoxList[i].transform.position.x < 3.5f && this.m_ItemPackagingBoxList[i].transform.position.z > -6.6f && this.m_ItemPackagingBoxList[i].transform.position.z < 1f)
				{
					this.m_ItemPackagingBoxList[i].transform.position = CSingleton<RestockManager>.Instance.m_PackageBoxSpawnLocationList[Random.Range(0, CSingleton<RestockManager>.Instance.m_PackageBoxSpawnLocationList.Count)].position;
				}
			}
			for (int j = 0; j < this.m_ShelfPackagingBoxList.Count; j++)
			{
				if (this.m_ShelfPackagingBoxList[j].transform.position.y > 8f || this.m_ShelfPackagingBoxList[j].transform.position.y < -1f || this.m_ShelfPackagingBoxList[j].transform.position.x < -4.35f || this.m_ShelfPackagingBoxList[j].transform.position.x > 17.5f)
				{
					this.m_ShelfPackagingBoxList[j].transform.position = CSingleton<RestockManager>.Instance.m_PackageBoxSpawnLocationList[Random.Range(0, CSingleton<RestockManager>.Instance.m_PackageBoxSpawnLocationList.Count)].position;
				}
				if (!CPlayerData.m_IsWarehouseRoomUnlocked && this.m_ShelfPackagingBoxList[j].transform.position.x < 3.5f && this.m_ShelfPackagingBoxList[j].transform.position.z > -6.5f && this.m_ShelfPackagingBoxList[j].transform.position.z < 1f)
				{
					this.m_ShelfPackagingBoxList[j].transform.position = CSingleton<RestockManager>.Instance.m_PackageBoxSpawnLocationList[Random.Range(0, CSingleton<RestockManager>.Instance.m_PackageBoxSpawnLocationList.Count)].position;
				}
			}
		}
	}

	// Token: 0x0600034B RID: 843 RVA: 0x0001E510 File Offset: 0x0001C710
	private void Init()
	{
		for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ItemDataList.Count; i++)
		{
			if (CPlayerData.m_GeneratedCostPriceList[i] == 0f)
			{
				CPlayerData.m_GeneratedCostPriceList[i] = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ItemDataList[i].baseCost * Mathf.Clamp(Random.Range(0.9f, 1.3f), 1f, 1.3f);
				if (CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ItemDataList[i].boxFollowItemPrice != EItemType.None)
				{
					CPlayerData.m_GeneratedCostPriceList[i] = CPlayerData.GetItemCost(CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ItemDataList[i].boxFollowItemPrice) * 8f * Mathf.Clamp(Random.Range(0.9f, 1.2f), 1f, 1.15f);
				}
				float num = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ItemDataList[i].marketPriceMinPercent;
				float maxInclusive = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ItemDataList[i].marketPriceMaxPercent;
				if (num == 0f)
				{
					num = 1.5f;
					maxInclusive = 3f;
				}
				if (CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ItemDataList[i].boxFollowItemPrice != EItemType.None)
				{
					CPlayerData.m_GeneratedMarketPriceList[i] = CPlayerData.GetItemMarketPrice(CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ItemDataList[i].boxFollowItemPrice) * 8f * Random.Range(num, maxInclusive);
				}
				else
				{
					CPlayerData.m_GeneratedMarketPriceList[i] = CPlayerData.m_GeneratedCostPriceList[i] * Random.Range(num, maxInclusive);
				}
			}
		}
		if (!CPlayerData.m_IsItemPriceGenerated)
		{
			CPlayerData.UpdateItemPricePercentChange();
		}
		CPlayerData.m_IsItemPriceGenerated = true;
		this.GenerateCardMarketPrice(ECardExpansionType.Tetramon);
		this.GenerateCardMarketPrice(ECardExpansionType.Destiny);
		this.GenerateCardMarketPrice(ECardExpansionType.Ghost);
		this.GenerateCardMarketPrice(ECardExpansionType.FantasyRPG);
		this.GenerateCardMarketPrice(ECardExpansionType.Megabot);
		this.GenerateCardMarketPrice(ECardExpansionType.CatJob);
		if (!CPlayerData.m_IsCardPriceGenerated)
		{
			CPlayerData.UpdatePastCardPricePercentChange();
			CPlayerData.m_IsCardPriceGenerated = true;
		}
		this.m_GeneratedCostPriceList = CPlayerData.m_GeneratedCostPriceList;
		this.m_GeneratedMarketPriceList = CPlayerData.m_GeneratedMarketPriceList;
		this.m_ItemPricePercentChangeList = CPlayerData.m_ItemPricePercentChangeList;
		this.m_ItemPricePercentPastChangeList = CPlayerData.m_ItemPricePercentPastChangeList;
		this.m_GenCardMarketPriceList = CPlayerData.m_GenCardMarketPriceList;
	}

	// Token: 0x0600034C RID: 844 RVA: 0x0001E74C File Offset: 0x0001C94C
	private void GenerateCardMarketPrice(ECardExpansionType expansionType)
	{
		CardData cardData = new CardData();
		int num = InventoryBase.GetShownMonsterList(expansionType).Count * CPlayerData.GetCardAmountPerMonsterType(expansionType, true);
		if (expansionType == ECardExpansionType.Ghost)
		{
			num *= 2;
		}
		for (int i = 0; i < num; i++)
		{
			int num2 = i;
			bool isDestiny = false;
			if (expansionType == ECardExpansionType.Ghost && num2 >= InventoryBase.GetShownMonsterList(expansionType).Count * CPlayerData.GetCardAmountPerMonsterType(expansionType, true))
			{
				isDestiny = true;
				num2 -= InventoryBase.GetShownMonsterList(expansionType).Count * CPlayerData.GetCardAmountPerMonsterType(expansionType, true);
			}
			ECardBorderType ecardBorderType = (ECardBorderType)(i % CPlayerData.GetCardAmountPerMonsterType(expansionType, false));
			EMonsterType monsterTypeFromCardSaveIndex = CPlayerData.GetMonsterTypeFromCardSaveIndex(num2, expansionType);
			ERarity rarity = InventoryBase.GetMonsterData(monsterTypeFromCardSaveIndex).Rarity;
			bool flag = i % CPlayerData.GetCardAmountPerMonsterType(expansionType, true) >= CPlayerData.GetCardAmountPerMonsterType(expansionType, false);
			cardData.monsterType = monsterTypeFromCardSaveIndex;
			cardData.borderType = ecardBorderType;
			cardData.isFoil = flag;
			cardData.isDestiny = isDestiny;
			cardData.expansionType = expansionType;
			if (CPlayerData.GetCardMarketPrice(cardData) == 0f)
			{
				ecardBorderType = cardData.GetCardBorderType();
				float num3 = 0f;
				if (rarity == ERarity.Legendary)
				{
					num3 = 0.5f;
				}
				else if (rarity == ERarity.Epic)
				{
					num3 = 0.2f;
				}
				else if (rarity == ERarity.Rare)
				{
					num3 = 0.1f;
				}
				float num4;
				if (flag)
				{
					if (ecardBorderType == ECardBorderType.FullArt)
					{
						num4 = 1500f * Random.Range(0.65f + num3, 1.4f + num3);
					}
					else if (ecardBorderType == ECardBorderType.EX)
					{
						num4 = 500f * Random.Range(0.6f + num3, 1.3f + num3);
					}
					else if (ecardBorderType == ECardBorderType.Gold)
					{
						num4 = 100f * Random.Range(0.5f + num3, 1.2f + num3);
					}
					else if (ecardBorderType == ECardBorderType.Silver)
					{
						num4 = 30f * Random.Range(0.4f + num3, 1.2f + num3);
					}
					else if (ecardBorderType == ECardBorderType.FirstEdition)
					{
						num4 = 10f * Random.Range(0.3f + num3, 1.2f + num3);
					}
					else
					{
						num4 = 5f * Random.Range(0.2f + num3, 1.2f + num3);
					}
				}
				else if (ecardBorderType == ECardBorderType.FullArt)
				{
					num4 = 50f * Random.Range(0.6f + num3, 1.4f + num3);
				}
				else if (ecardBorderType == ECardBorderType.EX)
				{
					num4 = 15f * Random.Range(0.5f + num3, 1.3f + num3);
				}
				else if (ecardBorderType == ECardBorderType.Gold)
				{
					num4 = 5f * Random.Range(0.4f + num3, 1.2f + num3);
				}
				else if (ecardBorderType == ECardBorderType.Silver)
				{
					num4 = 2.5f * Random.Range(0.3f + num3, 1.2f + num3);
				}
				else if (ecardBorderType == ECardBorderType.FirstEdition)
				{
					num4 = 1f * Random.Range(0.2f + num3, 1.2f + num3);
				}
				else
				{
					num4 = 0.2f * Random.Range(0.1f + num3, 1.2f + num3);
				}
				if (rarity == ERarity.Legendary)
				{
					if (ecardBorderType >= ECardBorderType.Gold)
					{
						num4 *= Random.Range(1.5f, 2f);
					}
				}
				else if (rarity == ERarity.Epic)
				{
					if (ecardBorderType >= ECardBorderType.Gold)
					{
						num4 *= Random.Range(1.25f, 1.5f);
					}
				}
				else if (rarity == ERarity.Rare && ecardBorderType >= ECardBorderType.Gold)
				{
					num4 *= Random.Range(1f, 1.25f);
				}
				if (expansionType == ECardExpansionType.Destiny)
				{
					num4 *= Random.Range(1.2f, 1.5f);
				}
				else if (expansionType == ECardExpansionType.Ghost)
				{
					num4 *= Random.Range(2.8f, 3.2f);
				}
				if (rarity == ERarity.Legendary)
				{
					num4 += 0.5f * (float)(ecardBorderType + 1) * Random.Range(0.9f, 1.1f);
				}
				else if (rarity == ERarity.Epic)
				{
					num4 += 0.3f * (float)(ecardBorderType + 1) * Random.Range(0.7f, 1.3f);
				}
				else if (rarity == ERarity.Rare)
				{
					num4 += 0.1f * (float)(ecardBorderType + 1) * Random.Range(0.5f, 1.5f);
				}
				CPlayerData.SetCardGeneratedMarketPrice(num2, expansionType, isDestiny, num4);
			}
		}
	}

	// Token: 0x0600034D RID: 845 RVA: 0x0001EB44 File Offset: 0x0001CD44
	public static float GetItemCost(EItemType itemType)
	{
		return (float)Mathf.RoundToInt((CPlayerData.m_GeneratedCostPriceList[(int)itemType] + CPlayerData.m_GeneratedCostPriceList[(int)itemType] * (CPlayerData.m_ItemPricePercentChangeList[(int)itemType] / 100f)) * 100f) / 100f;
	}

	// Token: 0x0600034E RID: 846 RVA: 0x0001EB81 File Offset: 0x0001CD81
	public static float GetItemMarketPrice(EItemType itemType)
	{
		return (float)Mathf.RoundToInt((CPlayerData.m_GeneratedMarketPriceList[(int)itemType] + CPlayerData.m_GeneratedMarketPriceList[(int)itemType] * (CPlayerData.m_ItemPricePercentChangeList[(int)itemType] / 100f)) * 100f) / 100f;
	}

	// Token: 0x0600034F RID: 847 RVA: 0x0001EBBE File Offset: 0x0001CDBE
	public static float GetItemMarketPriceCustomPercent(EItemType itemType, float percent)
	{
		return (float)Mathf.RoundToInt((CPlayerData.m_GeneratedMarketPriceList[(int)itemType] + CPlayerData.m_GeneratedMarketPriceList[(int)itemType] * (percent / 100f)) * 100f) / 100f;
	}

	// Token: 0x06000350 RID: 848 RVA: 0x0001EBF1 File Offset: 0x0001CDF1
	public static void SpawnPackageBoxItemMultipleFrame(RestockData restockData, int count)
	{
		CSingleton<RestockManager>.Instance.m_SpawnBoxItemWaitingList.Add(restockData);
		CSingleton<RestockManager>.Instance.m_SpawnBoxItemCountWaitingList.Add(count);
	}

	// Token: 0x06000351 RID: 849 RVA: 0x0001EC14 File Offset: 0x0001CE14
	public static InteractablePackagingBox_Item SpawnPackageBoxItem(EItemType itemType, int amount, bool isBigBox)
	{
		Transform transform = CSingleton<RestockManager>.Instance.m_PackageBoxSpawnLocationList[Random.Range(0, CSingleton<RestockManager>.Instance.m_PackageBoxSpawnLocationList.Count)];
		Vector3 position = transform.position;
		Quaternion rotation = transform.rotation;
		if (isBigBox)
		{
			InteractablePackagingBox_Item interactablePackagingBox_Item = Object.Instantiate<InteractablePackagingBox_Item>(CSingleton<RestockManager>.Instance.m_PackageBoxPrefab, position, rotation, CSingleton<RestockManager>.Instance.m_PackageBoxParentGrp);
			interactablePackagingBox_Item.FillBoxWithItem(itemType, amount);
			interactablePackagingBox_Item.name = interactablePackagingBox_Item.m_ObjectType.ToString() + CSingleton<RestockManager>.Instance.m_SpawnedBoxCount.ToString();
			CSingleton<RestockManager>.Instance.m_SpawnedBoxCount = CSingleton<RestockManager>.Instance.m_SpawnedBoxCount + 1;
			return interactablePackagingBox_Item;
		}
		InteractablePackagingBox_Item interactablePackagingBox_Item2 = Object.Instantiate<InteractablePackagingBox_Item>(CSingleton<RestockManager>.Instance.m_PackageBoxSmallPrefab, position, rotation, CSingleton<RestockManager>.Instance.m_PackageBoxParentGrp);
		interactablePackagingBox_Item2.FillBoxWithItem(itemType, amount);
		interactablePackagingBox_Item2.name = interactablePackagingBox_Item2.m_ObjectType.ToString() + CSingleton<RestockManager>.Instance.m_SpawnedBoxCount.ToString();
		CSingleton<RestockManager>.Instance.m_SpawnedBoxCount = CSingleton<RestockManager>.Instance.m_SpawnedBoxCount + 1;
		return interactablePackagingBox_Item2;
	}

	// Token: 0x06000352 RID: 850 RVA: 0x0001ED20 File Offset: 0x0001CF20
	public static InteractablePackagingBox_Shelf SpawnPackageBoxShelf(InteractableObject obj, bool holdBox)
	{
		Vector3 position = obj.transform.position;
		Quaternion rotation = obj.transform.rotation;
		InteractablePackagingBox_Shelf interactablePackagingBox_Shelf = Object.Instantiate<InteractablePackagingBox_Shelf>(CSingleton<RestockManager>.Instance.m_PackageBoxShelfPrefab, position, rotation, CSingleton<RestockManager>.Instance.m_PackageBoxParentGrp);
		interactablePackagingBox_Shelf.ExecuteBoxUpObject(obj, holdBox);
		interactablePackagingBox_Shelf.name = interactablePackagingBox_Shelf.m_ObjectType.ToString() + CSingleton<RestockManager>.Instance.m_SpawnedBoxCount.ToString();
		CSingleton<RestockManager>.Instance.m_SpawnedBoxCount = CSingleton<RestockManager>.Instance.m_SpawnedBoxCount + 1;
		return interactablePackagingBox_Shelf;
	}

	// Token: 0x06000353 RID: 851 RVA: 0x0001EDA9 File Offset: 0x0001CFA9
	public static void InitItemPackageBox(InteractablePackagingBox_Item itemPackagingBox)
	{
		CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList.Add(itemPackagingBox);
	}

	// Token: 0x06000354 RID: 852 RVA: 0x0001EDBB File Offset: 0x0001CFBB
	public static void RemoveItemPackageBox(InteractablePackagingBox_Item itemPackagingBox)
	{
		CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList.Remove(itemPackagingBox);
	}

	// Token: 0x06000355 RID: 853 RVA: 0x0001EDCE File Offset: 0x0001CFCE
	public static List<InteractablePackagingBox_Item> GetItemPackagingBoxList()
	{
		return CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList;
	}

	// Token: 0x06000356 RID: 854 RVA: 0x0001EDDC File Offset: 0x0001CFDC
	public static InteractablePackagingBox_Item GetItemPackagingBoxWithItem()
	{
		for (int i = 0; i < CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList.Count; i++)
		{
			if (CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList[i].IsValidObject() && CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList[i].m_ItemCompartment.GetItemCount() > 0)
			{
				return CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList[i];
			}
		}
		return null;
	}

	// Token: 0x06000357 RID: 855 RVA: 0x0001EE4C File Offset: 0x0001D04C
	public static List<InteractablePackagingBox_Item> GetItemPackagingBoxListWithItem(bool includeStoredItem)
	{
		List<InteractablePackagingBox_Item> list = new List<InteractablePackagingBox_Item>();
		for (int i = 0; i < CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList.Count; i++)
		{
			if ((includeStoredItem || !CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList[i].m_IsStored) && CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList[i].IsValidObject() && CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList[i].m_ItemCompartment.GetItemCount() > 0)
			{
				list.Add(CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList[i]);
			}
		}
		return list;
	}

	// Token: 0x06000358 RID: 856 RVA: 0x0001EEE0 File Offset: 0x0001D0E0
	public static List<InteractablePackagingBox_Item> GetItemPackagingBoxListWithSpaceForItem(EItemType itemType)
	{
		List<InteractablePackagingBox_Item> list = new List<InteractablePackagingBox_Item>();
		for (int i = 0; i < CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList.Count; i++)
		{
			if (!CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList[i].m_IsStored && (CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList[i].GetItemType() == EItemType.None || CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList[i].m_ItemCompartment.GetItemCount() <= 0 || CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList[i].GetItemType() == itemType) && CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList[i].IsValidObject() && (CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList[i].GetItemType() == EItemType.None || CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList[i].m_ItemCompartment.HasEnoughSlot()))
			{
				list.Add(CSingleton<RestockManager>.Instance.m_ItemPackagingBoxList[i]);
			}
		}
		return list;
	}

	// Token: 0x06000359 RID: 857 RVA: 0x0001EFDC File Offset: 0x0001D1DC
	public static void InitShelfPackageBox(InteractablePackagingBox_Shelf shelfPackagingBox)
	{
		CSingleton<RestockManager>.Instance.m_ShelfPackagingBoxList.Add(shelfPackagingBox);
	}

	// Token: 0x0600035A RID: 858 RVA: 0x0001EFEE File Offset: 0x0001D1EE
	public static void RemoveShelfPackageBox(InteractablePackagingBox_Shelf shelfPackagingBox)
	{
		CSingleton<RestockManager>.Instance.m_ShelfPackagingBoxList.Remove(shelfPackagingBox);
	}

	// Token: 0x0600035B RID: 859 RVA: 0x0001F001 File Offset: 0x0001D201
	public static List<InteractablePackagingBox_Shelf> GetShelfPackagingBoxList()
	{
		return CSingleton<RestockManager>.Instance.m_ShelfPackagingBoxList;
	}

	// Token: 0x0600035C RID: 860 RVA: 0x0001F010 File Offset: 0x0001D210
	public static void DestroyAllObject()
	{
		CSingleton<RestockManager>.Instance.m_SpawnedBoxCount = 0;
		for (int i = RestockManager.GetItemPackagingBoxList().Count - 1; i >= 0; i--)
		{
			RestockManager.GetItemPackagingBoxList()[i].OnDestroyed();
		}
		for (int j = RestockManager.GetShelfPackagingBoxList().Count - 1; j >= 0; j--)
		{
			RestockManager.GetShelfPackagingBoxList()[j].OnDestroyed();
		}
	}

	// Token: 0x0600035D RID: 861 RVA: 0x0001F078 File Offset: 0x0001D278
	public static int GetMaxItemCountInBox(EItemType itemType, bool isBigBox)
	{
		ItemData itemData = InventoryBase.GetItemData(itemType);
		float num = 4f;
		float num2 = 8f;
		float num3 = 1f;
		if (isBigBox)
		{
			num3 = 2f;
		}
		int num4 = Mathf.RoundToInt(num / itemData.itemDimension.x);
		int num5 = Mathf.RoundToInt(num2 / itemData.itemDimension.y);
		int num6 = Mathf.RoundToInt(num3 / itemData.itemDimension.z);
		if (itemData.isTallItem)
		{
			num6 = Mathf.RoundToInt(num3 / (itemData.itemDimension.z * 2f));
		}
		return num4 * num5 * num6;
	}

	// Token: 0x0600035E RID: 862 RVA: 0x0001F105 File Offset: 0x0001D305
	public static Transform GetRandomPackageSpawnPos()
	{
		return CSingleton<RestockManager>.Instance.m_PackageBoxSpawnLocationList[Random.Range(0, CSingleton<RestockManager>.Instance.m_PackageBoxSpawnLocationList.Count)];
	}

	// Token: 0x0600035F RID: 863 RVA: 0x0001F12B File Offset: 0x0001D32B
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x06000360 RID: 864 RVA: 0x0001F14C File Offset: 0x0001D34C
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x06000361 RID: 865 RVA: 0x0001F16D File Offset: 0x0001D36D
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.Init();
	}

	// Token: 0x040003F5 RID: 1013
	public static RestockManager m_Instance;

	// Token: 0x040003F6 RID: 1014
	public InteractablePackagingBox_Item m_PackageBoxPrefab;

	// Token: 0x040003F7 RID: 1015
	public InteractablePackagingBox_Item m_PackageBoxSmallPrefab;

	// Token: 0x040003F8 RID: 1016
	public InteractablePackagingBox_Shelf m_PackageBoxShelfPrefab;

	// Token: 0x040003F9 RID: 1017
	public Transform m_PackageBoxSpawnLocation;

	// Token: 0x040003FA RID: 1018
	public List<Transform> m_PackageBoxSpawnLocationList;

	// Token: 0x040003FB RID: 1019
	public Transform m_PackageBoxParentGrp;

	// Token: 0x040003FC RID: 1020
	public List<InteractablePackagingBox_Item> m_ItemPackagingBoxList = new List<InteractablePackagingBox_Item>();

	// Token: 0x040003FD RID: 1021
	public List<InteractablePackagingBox_Shelf> m_ShelfPackagingBoxList = new List<InteractablePackagingBox_Shelf>();

	// Token: 0x040003FE RID: 1022
	public List<RestockData> m_SpawnBoxItemWaitingList = new List<RestockData>();

	// Token: 0x040003FF RID: 1023
	public List<int> m_SpawnBoxItemCountWaitingList = new List<int>();

	// Token: 0x04000400 RID: 1024
	private float m_SpawnBoxItemTimer;

	// Token: 0x04000401 RID: 1025
	private float m_SpawnBoxItemTime = 0.02f;

	// Token: 0x04000402 RID: 1026
	private float m_OutofBoundCheckTimer;

	// Token: 0x04000403 RID: 1027
	private int m_SpawnedBoxCount;

	// Token: 0x04000404 RID: 1028
	public List<float> m_GeneratedCostPriceList = new List<float>();

	// Token: 0x04000405 RID: 1029
	public List<float> m_GeneratedMarketPriceList = new List<float>();

	// Token: 0x04000406 RID: 1030
	public List<float> m_ItemPricePercentChangeList = new List<float>();

	// Token: 0x04000407 RID: 1031
	public List<FloatList> m_ItemPricePercentPastChangeList = new List<FloatList>();

	// Token: 0x04000408 RID: 1032
	public List<MarketPrice> m_GenCardMarketPriceList = new List<MarketPrice>();
}
