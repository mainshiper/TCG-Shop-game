﻿using System;
using System.Collections.Generic;
using I2.Loc;
using TMPro;
using UnityEngine;

// Token: 0x02000070 RID: 112
public class NotEnoughResourceTextPopup : CSingleton<NotEnoughResourceTextPopup>
{
	// Token: 0x060004AF RID: 1199 RVA: 0x0002915C File Offset: 0x0002735C
	private void Update()
	{
		if (this.m_CurrentNotEnoughResourceText != ENotEnoughResourceText.None)
		{
			this.m_ResetTimer += Time.deltaTime;
			if (this.m_ResetTimer > 2f)
			{
				this.m_ResetTimer = 0f;
				this.m_CurrentNotEnoughResourceText = ENotEnoughResourceText.None;
			}
		}
	}

	// Token: 0x060004B0 RID: 1200 RVA: 0x00029198 File Offset: 0x00027398
	public static void ShowText(ENotEnoughResourceText notEnoughResourceText)
	{
		if (CSingleton<NotEnoughResourceTextPopup>.Instance.m_CurrentNotEnoughResourceText != notEnoughResourceText)
		{
			CSingleton<NotEnoughResourceTextPopup>.Instance.m_ResetTimer = 0f;
			CSingleton<NotEnoughResourceTextPopup>.Instance.m_CurrentNotEnoughResourceText = notEnoughResourceText;
			string translation = LocalizationManager.GetTranslation(CSingleton<NotEnoughResourceTextPopup>.Instance.m_StringList[(int)notEnoughResourceText], true, 0, true, false, null, null, true);
			for (int i = 0; i < CSingleton<NotEnoughResourceTextPopup>.Instance.m_ShowTextGameObjectList.Count; i++)
			{
				if (!CSingleton<NotEnoughResourceTextPopup>.Instance.m_ShowTextGameObjectList[i].activeSelf)
				{
					CSingleton<NotEnoughResourceTextPopup>.Instance.m_ShowTextList[i].text = translation;
					CSingleton<NotEnoughResourceTextPopup>.Instance.m_ShowTextGameObjectList[i].gameObject.SetActive(true);
					return;
				}
			}
			return;
		}
	}

	// Token: 0x04000614 RID: 1556
	public List<string> m_StringList;

	// Token: 0x04000615 RID: 1557
	public List<GameObject> m_ShowTextGameObjectList;

	// Token: 0x04000616 RID: 1558
	public List<TextMeshProUGUI> m_ShowTextList;

	// Token: 0x04000617 RID: 1559
	private float m_ResetTimer;

	// Token: 0x04000618 RID: 1560
	private ENotEnoughResourceText m_CurrentNotEnoughResourceText = ENotEnoughResourceText.None;
}
