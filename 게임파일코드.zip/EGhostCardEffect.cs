﻿using System;

// Token: 0x02000102 RID: 258
public enum EGhostCardEffect
{
	// Token: 0x04000ED8 RID: 3800
	None,
	// Token: 0x04000ED9 RID: 3801
	MoreMoney,
	// Token: 0x04000EDA RID: 3802
	MoreFame,
	// Token: 0x04000EDB RID: 3803
	MoreDP,
	// Token: 0x04000EDC RID: 3804
	ReducePlayTableTime,
	// Token: 0x04000EDD RID: 3805
	CustomerDoubleChance,
	// Token: 0x04000EDE RID: 3806
	FoilChance,
	// Token: 0x04000EDF RID: 3807
	CustomerSpendingPower,
	// Token: 0x04000EE0 RID: 3808
	CollectorChance,
	// Token: 0x04000EE1 RID: 3809
	SuperCollectorChance,
	// Token: 0x04000EE2 RID: 3810
	UltimateCollectorChance,
	// Token: 0x04000EE3 RID: 3811
	LegendaryCollectorChance,
	// Token: 0x04000EE4 RID: 3812
	CommonPackOverCharge,
	// Token: 0x04000EE5 RID: 3813
	CommonBoxOverCharge,
	// Token: 0x04000EE6 RID: 3814
	RarePackOverCharge,
	// Token: 0x04000EE7 RID: 3815
	RareBoxOverCharge,
	// Token: 0x04000EE8 RID: 3816
	EpicPackOverCharge,
	// Token: 0x04000EE9 RID: 3817
	EpicBoxOverCharge,
	// Token: 0x04000EEA RID: 3818
	LegendaryPackOverCharge,
	// Token: 0x04000EEB RID: 3819
	LegendaryBoxOverCharge,
	// Token: 0x04000EEC RID: 3820
	MAX
}
