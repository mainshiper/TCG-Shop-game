﻿using System;
using UnityEngine;

// Token: 0x0200012B RID: 299
public class UpdateLineRendererPosition : MonoBehaviour
{
	// Token: 0x060008D0 RID: 2256 RVA: 0x00041BA9 File Offset: 0x0003FDA9
	private void Awake()
	{
		this.m_Line = base.GetComponent<LineRenderer>();
		this.rend = base.GetComponent<Renderer>();
	}

	// Token: 0x060008D1 RID: 2257 RVA: 0x00041BC3 File Offset: 0x0003FDC3
	private void OnEnable()
	{
		this.m_Line.SetPosition(0, Vector3.zero);
		this.m_Line.SetPosition(1, Vector3.zero);
	}

	// Token: 0x060008D2 RID: 2258 RVA: 0x00041BE8 File Offset: 0x0003FDE8
	private void Update()
	{
		this.m_Line.SetPosition(0, this.m_StartPosObject.transform.position);
		this.m_Line.SetPosition(1, this.m_MouseFollowObject.transform.position);
		this.rend.material.mainTextureScale = new Vector2((float)(Mathf.CeilToInt(Vector2.Distance(this.m_StartPosObject.transform.position, this.m_MouseFollowObject.transform.position) / 4f) * 2), 1f);
	}

	// Token: 0x040010C3 RID: 4291
	private LineRenderer m_Line;

	// Token: 0x040010C4 RID: 4292
	public GameObject m_StartPosObject;

	// Token: 0x040010C5 RID: 4293
	public GameObject m_MouseFollowObject;

	// Token: 0x040010C6 RID: 4294
	private Renderer rend;
}
