﻿using System;
using UnityEngine;

// Token: 0x020000A5 RID: 165
[Serializable]
public struct QuaternionSerializer
{
	// Token: 0x060006AF RID: 1711 RVA: 0x00037EB6 File Offset: 0x000360B6
	public void SetData(Quaternion q)
	{
		this.x = q.x;
		this.y = q.y;
		this.z = q.z;
		this.w = q.w;
	}

	// Token: 0x17000005 RID: 5
	// (get) Token: 0x060006B0 RID: 1712 RVA: 0x00037EE8 File Offset: 0x000360E8
	public Quaternion Data
	{
		get
		{
			return new Quaternion(this.x, this.y, this.z, this.w);
		}
	}

	// Token: 0x040008E6 RID: 2278
	public float x;

	// Token: 0x040008E7 RID: 2279
	public float y;

	// Token: 0x040008E8 RID: 2280
	public float z;

	// Token: 0x040008E9 RID: 2281
	public float w;
}
