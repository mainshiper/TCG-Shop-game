﻿using System;

// Token: 0x020000AC RID: 172
public class CEventPlayer_SetGamePaused : CEvent
{
	// Token: 0x1700000A RID: 10
	// (get) Token: 0x060006F3 RID: 1779 RVA: 0x0003922B File Offset: 0x0003742B
	// (set) Token: 0x060006F4 RID: 1780 RVA: 0x00039233 File Offset: 0x00037433
	public bool m_IsPaused { get; private set; }

	// Token: 0x060006F5 RID: 1781 RVA: 0x0003923C File Offset: 0x0003743C
	public CEventPlayer_SetGamePaused(bool isPaused)
	{
		this.m_IsPaused = isPaused;
	}
}
