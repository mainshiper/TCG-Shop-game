﻿using System;
using UnityEngine;

// Token: 0x02000141 RID: 321
public class ETFXProjectileScript : MonoBehaviour
{
	// Token: 0x06000924 RID: 2340 RVA: 0x000435A8 File Offset: 0x000417A8
	private void Start()
	{
		this.projectileParticle = Object.Instantiate<GameObject>(this.projectileParticle, base.transform.position, base.transform.rotation);
		this.projectileParticle.transform.parent = base.transform;
		if (this.muzzleParticle)
		{
			this.muzzleParticle = Object.Instantiate<GameObject>(this.muzzleParticle, base.transform.position, base.transform.rotation);
			Object.Destroy(this.muzzleParticle, 1.5f);
		}
	}

	// Token: 0x06000925 RID: 2341 RVA: 0x00043638 File Offset: 0x00041838
	private void OnCollisionEnter(Collision hit)
	{
		if (!this.hasCollided)
		{
			this.hasCollided = true;
			this.impactParticle = Object.Instantiate<GameObject>(this.impactParticle, base.transform.position, Quaternion.FromToRotation(Vector3.up, this.impactNormal));
			if (hit.gameObject.tag == "Destructible")
			{
				Object.Destroy(hit.gameObject);
			}
			foreach (GameObject gameObject in this.trailParticles)
			{
				GameObject gameObject2 = base.transform.Find(this.projectileParticle.name + "/" + gameObject.name).gameObject;
				gameObject2.transform.parent = null;
				Object.Destroy(gameObject2, 3f);
			}
			Object.Destroy(this.projectileParticle, 3f);
			Object.Destroy(this.impactParticle, 5f);
			Object.Destroy(base.gameObject);
			ParticleSystem[] componentsInChildren = base.GetComponentsInChildren<ParticleSystem>();
			for (int j = 1; j < componentsInChildren.Length; j++)
			{
				ParticleSystem particleSystem = componentsInChildren[j];
				if (particleSystem.gameObject.name.Contains("Trail"))
				{
					particleSystem.transform.SetParent(null);
					Object.Destroy(particleSystem.gameObject, 2f);
				}
			}
		}
	}

	// Token: 0x0400114F RID: 4431
	public GameObject impactParticle;

	// Token: 0x04001150 RID: 4432
	public GameObject projectileParticle;

	// Token: 0x04001151 RID: 4433
	public GameObject muzzleParticle;

	// Token: 0x04001152 RID: 4434
	public GameObject[] trailParticles;

	// Token: 0x04001153 RID: 4435
	[HideInInspector]
	public Vector3 impactNormal;

	// Token: 0x04001154 RID: 4436
	private bool hasCollided;
}
