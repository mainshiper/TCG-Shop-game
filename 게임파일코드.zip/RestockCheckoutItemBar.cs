﻿using System;
using TMPro;

// Token: 0x02000076 RID: 118
public class RestockCheckoutItemBar : UIElementBase
{
	// Token: 0x060004C5 RID: 1221 RVA: 0x00029CDE File Offset: 0x00027EDE
	public void Init(RestockItemScreen restockItemScreen)
	{
		this.m_RestockItemScreen = restockItemScreen;
	}

	// Token: 0x060004C6 RID: 1222 RVA: 0x00029CE8 File Offset: 0x00027EE8
	public void UpdateData(int index, int boxCount)
	{
		this.m_Index = index;
		this.m_BoxCount = boxCount;
		RestockData restockData = InventoryBase.GetRestockData(index);
		this.m_ItemType = restockData.itemType;
		ItemData itemData = InventoryBase.GetItemData(this.m_ItemType);
		int maxItemCountInBox = RestockManager.GetMaxItemCountInBox(this.m_ItemType, restockData.isBigBox);
		this.m_TotalItemUnitCount = this.m_BoxCount * maxItemCountInBox;
		this.m_UnitPrice = CPlayerData.GetItemCost(this.m_ItemType);
		this.m_TotalPrice = this.m_UnitPrice * (float)this.m_TotalItemUnitCount;
		this.m_ItemNameText.text = itemData.GetName() + " (" + maxItemCountInBox.ToString() + ")";
		this.m_AmountText.text = this.m_BoxCount.ToString();
		this.m_UnitPriceText.text = GameInstance.GetPriceString(this.m_UnitPrice, false, true, false, "F2");
		this.m_TotalPriceText.text = GameInstance.GetPriceString(this.m_TotalPrice, false, true, false, "F2");
	}

	// Token: 0x060004C7 RID: 1223 RVA: 0x00029DE0 File Offset: 0x00027FE0
	public float GetUnitPrice()
	{
		return this.m_UnitPrice;
	}

	// Token: 0x060004C8 RID: 1224 RVA: 0x00029DE8 File Offset: 0x00027FE8
	public float GetTotalPrice()
	{
		return this.m_TotalPrice;
	}

	// Token: 0x060004C9 RID: 1225 RVA: 0x00029DF0 File Offset: 0x00027FF0
	public int GetTotalUnit()
	{
		return this.m_TotalItemUnitCount;
	}

	// Token: 0x060004CA RID: 1226 RVA: 0x00029DF8 File Offset: 0x00027FF8
	public EItemType GetItemType()
	{
		return this.m_ItemType;
	}

	// Token: 0x060004CB RID: 1227 RVA: 0x00029E00 File Offset: 0x00028000
	public void OnPressAddItem()
	{
		this.m_RestockItemScreen.AddToCartForCheckout(this.m_Index, 1);
	}

	// Token: 0x060004CC RID: 1228 RVA: 0x00029E14 File Offset: 0x00028014
	public void OnPressRemoveItem()
	{
		this.m_RestockItemScreen.RemoveFromCartForCheckout(this.m_Index, 1);
	}

	// Token: 0x060004CD RID: 1229 RVA: 0x00029E28 File Offset: 0x00028028
	public void OnPressClearItem()
	{
		this.m_RestockItemScreen.RemoveFromCartForCheckout(this.m_Index, this.m_BoxCount);
	}

	// Token: 0x04000636 RID: 1590
	public TextMeshProUGUI m_ItemNameText;

	// Token: 0x04000637 RID: 1591
	public TextMeshProUGUI m_AmountText;

	// Token: 0x04000638 RID: 1592
	public TextMeshProUGUI m_UnitPriceText;

	// Token: 0x04000639 RID: 1593
	public TextMeshProUGUI m_TotalPriceText;

	// Token: 0x0400063A RID: 1594
	private int m_Index;

	// Token: 0x0400063B RID: 1595
	private int m_BoxCount;

	// Token: 0x0400063C RID: 1596
	private int m_TotalItemUnitCount;

	// Token: 0x0400063D RID: 1597
	private float m_UnitPrice;

	// Token: 0x0400063E RID: 1598
	private float m_TotalPrice;

	// Token: 0x0400063F RID: 1599
	private EItemType m_ItemType;

	// Token: 0x04000640 RID: 1600
	private RestockItemScreen m_RestockItemScreen;
}
