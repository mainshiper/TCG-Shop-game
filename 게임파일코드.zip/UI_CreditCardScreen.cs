﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x0200008A RID: 138
public class UI_CreditCardScreen : MonoBehaviour
{
	// Token: 0x06000569 RID: 1385 RVA: 0x0002DCCC File Offset: 0x0002BECC
	private void Awake()
	{
		this.ResetCounter();
	}

	// Token: 0x0600056A RID: 1386 RVA: 0x0002DCD4 File Offset: 0x0002BED4
	public void Update()
	{
		if (!this.m_IsCreditCardMode)
		{
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha1) || Input.GetKeyUp(KeyCode.Keypad1))
		{
			this.OnPressNumber(1);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha2) || Input.GetKeyUp(KeyCode.Keypad2))
		{
			this.OnPressNumber(2);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha3) || Input.GetKeyUp(KeyCode.Keypad3))
		{
			this.OnPressNumber(3);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha4) || Input.GetKeyUp(KeyCode.Keypad4))
		{
			this.OnPressNumber(4);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha5) || Input.GetKeyUp(KeyCode.Keypad5))
		{
			this.OnPressNumber(5);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha6) || Input.GetKeyUp(KeyCode.Keypad6))
		{
			this.OnPressNumber(6);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha7) || Input.GetKeyUp(KeyCode.Keypad7))
		{
			this.OnPressNumber(7);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha8) || Input.GetKeyUp(KeyCode.Keypad8))
		{
			this.OnPressNumber(8);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha9) || Input.GetKeyUp(KeyCode.Keypad9))
		{
			this.OnPressNumber(9);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha0) || Input.GetKeyUp(KeyCode.Keypad0))
		{
			this.OnPressNumber(0);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Period) || Input.GetKeyUp(KeyCode.KeypadPeriod) || Input.GetKeyUp(KeyCode.Comma))
		{
			this.OnPressDecimalBtn();
			return;
		}
		if (Input.GetKeyUp(KeyCode.Backspace))
		{
			this.OnPressBackBtn();
			return;
		}
		if (Input.GetKeyUp(KeyCode.KeypadEnter) || Input.GetKeyUp(KeyCode.Return) || InputManager.GetKeyUpAction(EGameAction.DoneCounter))
		{
			this.OnPressConfirmBtn();
		}
	}

	// Token: 0x0600056B RID: 1387 RVA: 0x0002DE68 File Offset: 0x0002C068
	public void OnPressNumber(int number)
	{
		if (!this.m_IsCreditCardMode)
		{
			return;
		}
		int num = 10000;
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.Yen)
		{
			num = 1000000;
		}
		if (!this.m_HasPressedDecimal && this.m_CurrentNumberValue > (float)num)
		{
			return;
		}
		if (!this.m_HasPressedDecimal)
		{
			this.m_CurrentNumberValue = this.m_CurrentNumberValue * 10f + (float)number;
		}
		else if (this.m_CurrentDecimalPoint == 0)
		{
			this.m_CurrentNumberValue += (float)number * 0.1f;
			this.m_CurrentDecimalPoint++;
		}
		else if (this.m_CurrentDecimalPoint == 1)
		{
			this.m_CurrentNumberValue += (float)number * 0.01f;
			this.m_CurrentDecimalPoint++;
		}
		this.m_TotalPriceText.text = GameInstance.GetPriceString(this.m_CurrentNumberValue / GameInstance.GetCurrencyConversionRate(), false, true, false, "F2");
		SoundManager.PlayAudio("SFX_CheckoutCardPress", 0.2f, 1f);
	}

	// Token: 0x0600056C RID: 1388 RVA: 0x0002DF5A File Offset: 0x0002C15A
	public void OnPressDecimalBtn()
	{
		if (!this.m_IsCreditCardMode)
		{
			return;
		}
		if (!GameInstance.GetCurrencyHasDecimal(CSingleton<CGameManager>.Instance.m_CurrencyType))
		{
			return;
		}
		if (!this.m_HasPressedDecimal)
		{
			this.m_HasPressedDecimal = true;
		}
		SoundManager.PlayAudio("SFX_CheckoutCardPress", 0.2f, 1f);
	}

	// Token: 0x0600056D RID: 1389 RVA: 0x0002DF9C File Offset: 0x0002C19C
	public void OnPressBackBtn()
	{
		if (!this.m_IsCreditCardMode)
		{
			return;
		}
		if (!this.m_HasPressedDecimal || this.m_CurrentDecimalPoint == 0)
		{
			this.m_HasPressedDecimal = false;
			this.m_CurrentNumberValue = (float)Mathf.FloorToInt(this.m_CurrentNumberValue / 10f);
		}
		else if (this.m_CurrentDecimalPoint == 0)
		{
			this.m_HasPressedDecimal = false;
			this.m_CurrentDecimalPoint = 0;
		}
		else if (this.m_CurrentDecimalPoint == 1)
		{
			this.m_CurrentNumberValue = (float)Mathf.FloorToInt(this.m_CurrentNumberValue);
			this.m_CurrentDecimalPoint--;
		}
		else if (this.m_CurrentDecimalPoint == 2)
		{
			this.m_CurrentNumberValue = (float)Mathf.FloorToInt(this.m_CurrentNumberValue * 10f) / 10f;
			this.m_CurrentDecimalPoint--;
		}
		this.m_TotalPriceText.text = GameInstance.GetPriceString(this.m_CurrentNumberValue / GameInstance.GetCurrencyConversionRate(), false, true, false, "F2");
		SoundManager.PlayAudio("SFX_CheckoutCardPress", 0.2f, 1f);
	}

	// Token: 0x0600056E RID: 1390 RVA: 0x0002E093 File Offset: 0x0002C293
	public void OnPressConfirmBtn()
	{
		if (!this.m_IsCreditCardMode)
		{
			return;
		}
		this.m_CashierCounter.EvaluateCreditCard(this.m_CurrentNumberValue / GameInstance.GetCurrencyConversionRate());
		SoundManager.PlayAudio("SFX_CheckoutCardPress", 0.2f, 1f);
	}

	// Token: 0x0600056F RID: 1391 RVA: 0x0002E0C9 File Offset: 0x0002C2C9
	public void SetCashierCounter(InteractableCashierCounter cashierCounter)
	{
		this.m_CashierCounter = cashierCounter;
	}

	// Token: 0x06000570 RID: 1392 RVA: 0x0002E0D2 File Offset: 0x0002C2D2
	public void EnableCreditCardMode(bool isPlayer)
	{
		this.m_IsCreditCardMode = isPlayer;
		if (isPlayer)
		{
			ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension);
			this.m_TotalPriceText.text = GameInstance.GetPriceString(this.m_CurrentNumberValue, false, true, false, "F2");
		}
	}

	// Token: 0x06000571 RID: 1393 RVA: 0x0002E108 File Offset: 0x0002C308
	public void ResetCounter()
	{
		if (this.m_IsCreditCardMode)
		{
			ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension);
		}
		this.m_IsCreditCardMode = false;
		this.m_HasPressedDecimal = false;
		this.m_CurrentDecimalPoint = 0;
		this.m_CurrentNumberValue = 0f;
		this.m_TotalPriceText.text = GameInstance.GetPriceString(this.m_CurrentNumberValue, false, true, false, "F2");
	}

	// Token: 0x0400071D RID: 1821
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x0400071E RID: 1822
	public FollowObject m_FollowObject;

	// Token: 0x0400071F RID: 1823
	public TextMeshProUGUI m_TotalPriceText;

	// Token: 0x04000720 RID: 1824
	private int m_CurrentDecimalPoint;

	// Token: 0x04000721 RID: 1825
	private float m_CurrentNumberValue;

	// Token: 0x04000722 RID: 1826
	private bool m_HasPressedDecimal;

	// Token: 0x04000723 RID: 1827
	private bool m_IsCreditCardMode;

	// Token: 0x04000724 RID: 1828
	private InteractableCashierCounter m_CashierCounter;
}
