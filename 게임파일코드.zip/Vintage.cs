﻿using System;
using UnityEngine;

// Token: 0x0200014F RID: 335
[ExecuteInEditMode]
public class Vintage : MonoBehaviour
{
	// Token: 0x17000036 RID: 54
	// (get) Token: 0x06000982 RID: 2434 RVA: 0x0004606D File Offset: 0x0004426D
	private Material material
	{
		get
		{
			if (this.curMaterial == null)
			{
				this.curMaterial = new Material(this.curShader);
				this.curMaterial.hideFlags = HideFlags.HideAndDontSave;
			}
			return this.curMaterial;
		}
	}

	// Token: 0x06000983 RID: 2435 RVA: 0x000460A1 File Offset: 0x000442A1
	private void Start()
	{
		if (!SystemInfo.supportsImageEffects)
		{
			base.enabled = false;
			return;
		}
		this.curShader = Shader.Find("Custom/Vintage");
	}

	// Token: 0x06000984 RID: 2436 RVA: 0x000460C4 File Offset: 0x000442C4
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
		if (this.curShader != null)
		{
			this.material.SetFloat("_YellowLevel", this.YellowLevel);
			this.material.SetFloat("_CyanLevel", this.CyanLevel);
			this.material.SetFloat("_MagentaLevel", this.MagentaLevel);
			this.material.SetColor("_Yellow", this.Yellow);
			this.material.SetColor("_Cyan", this.Cyan);
			this.material.SetColor("_Magenta", this.Magenta);
			Graphics.Blit(sourceTexture, destTexture, this.material);
			return;
		}
		Graphics.Blit(sourceTexture, destTexture);
	}

	// Token: 0x06000985 RID: 2437 RVA: 0x0004617B File Offset: 0x0004437B
	private void Update()
	{
	}

	// Token: 0x06000986 RID: 2438 RVA: 0x0004617D File Offset: 0x0004437D
	private void OnDisable()
	{
		if (this.curMaterial)
		{
			Object.DestroyImmediate(this.curMaterial);
		}
	}

	// Token: 0x040011DE RID: 4574
	private Shader curShader;

	// Token: 0x040011DF RID: 4575
	private Color Yellow = Color.yellow;

	// Token: 0x040011E0 RID: 4576
	private Color Cyan = Color.cyan;

	// Token: 0x040011E1 RID: 4577
	private Color Magenta = Color.magenta;

	// Token: 0x040011E2 RID: 4578
	public float YellowLevel = 0.01f;

	// Token: 0x040011E3 RID: 4579
	public float CyanLevel = 0.03f;

	// Token: 0x040011E4 RID: 4580
	public float MagentaLevel = 0.04f;

	// Token: 0x040011E5 RID: 4581
	private Material curMaterial;
}
