﻿using System;
using UnityEngine;

// Token: 0x02000018 RID: 24
public class InteractableCard3d : InteractableObject
{
	// Token: 0x0600011C RID: 284 RVA: 0x0000FD34 File Offset: 0x0000DF34
	protected override void Start()
	{
		base.Start();
	}

	// Token: 0x0600011D RID: 285 RVA: 0x0000FD3C File Offset: 0x0000DF3C
	public override void OnMouseButtonUp()
	{
		base.OnMouseButtonUp();
		if (this.m_CurrentCustomer)
		{
			this.OnCardScanned();
		}
	}

	// Token: 0x0600011E RID: 286 RVA: 0x0000FD57 File Offset: 0x0000DF57
	public void SetCardUIFollow(Card3dUIGroup card3dUI)
	{
		if (card3dUI)
		{
			this.m_IsCard3dUIFollow = true;
			this.m_Card3dUI = card3dUI;
			return;
		}
		this.m_IsCard3dUIFollow = false;
		this.m_Card3dUI = null;
	}

	// Token: 0x0600011F RID: 287 RVA: 0x0000FD7E File Offset: 0x0000DF7E
	public void SetTargetRotation(Quaternion targetRot)
	{
		this.m_IsLerpingCardRot = true;
		this.m_CardTargetLerpRot = targetRot;
	}

	// Token: 0x06000120 RID: 288 RVA: 0x0000FD8E File Offset: 0x0000DF8E
	public override void OnRaycasted()
	{
		if (this.m_IsLerpingToPos)
		{
			return;
		}
		base.OnRaycasted();
		if (this.m_CollectionBinderFlipAnimCtrl)
		{
			this.m_CollectionBinderFlipAnimCtrl.OnCardRaycasted(this);
		}
	}

	// Token: 0x06000121 RID: 289 RVA: 0x0000FDB8 File Offset: 0x0000DFB8
	public override void OnRaycastEnded()
	{
		if (this.m_IsLerpingToPos)
		{
			return;
		}
		base.OnRaycastEnded();
		if (this.m_CollectionBinderFlipAnimCtrl)
		{
			this.m_CollectionBinderFlipAnimCtrl.OnCardRaycastEnded();
		}
	}

	// Token: 0x06000122 RID: 290 RVA: 0x0000FDE1 File Offset: 0x0000DFE1
	public void SetEnableCollision(bool isEnable)
	{
		this.m_BoxCollider.enabled = isEnable;
	}

	// Token: 0x06000123 RID: 291 RVA: 0x0000FDF0 File Offset: 0x0000DFF0
	protected override void LateUpdate()
	{
		if (this.m_IsCard3dUIFollow)
		{
			this.m_Card3dUI.transform.position = base.transform.position;
			this.m_Card3dUI.transform.rotation = base.transform.rotation;
		}
		if (this.m_IsLerpingCardRot)
		{
			this.m_Card3dUI.m_ScaleGrp.localRotation = Quaternion.Lerp(this.m_Card3dUI.m_ScaleGrp.localRotation, this.m_CardTargetLerpRot, Time.deltaTime * 5f);
		}
		base.LateUpdate();
	}

	// Token: 0x06000124 RID: 292 RVA: 0x0000FE80 File Offset: 0x0000E080
	protected override void OnFinishLerp()
	{
		base.OnFinishLerp();
		if (this.m_IsHideAfterFinishLerp)
		{
			this.m_Card3dUI.gameObject.SetActive(false);
			base.gameObject.SetActive(false);
			if (this.m_CollectionBinderFlipAnimCtrl)
			{
				this.m_CollectionBinderFlipAnimCtrl.OnCardFinishLerpHide();
			}
		}
	}

	// Token: 0x06000125 RID: 293 RVA: 0x0000FED0 File Offset: 0x0000E0D0
	public override void OnDestroyed()
	{
		if (this.m_Card3dUI && this.m_IsCard3dUIFollow)
		{
			this.m_Card3dUI.DisableCard();
		}
		this.m_CurrentCustomer = null;
		base.OnDestroyed();
	}

	// Token: 0x06000126 RID: 294 RVA: 0x0000FF00 File Offset: 0x0000E100
	public void OnCardScanned()
	{
		this.m_Collider.enabled = false;
		this.m_Rigidbody.isKinematic = true;
		this.m_CurrentCustomer.OnCardScanned(this);
		this.m_CurrentCustomer = null;
		base.LerpToTransform(this.m_ScannedItemLerpPos, this.m_ScannedItemLerpPos);
		base.SetHideItemAfterFinishLerp();
	}

	// Token: 0x06000127 RID: 295 RVA: 0x0000FF50 File Offset: 0x0000E150
	public void RegisterScanCard(Customer customer, Transform scannedItemLerpPos)
	{
		this.m_CurrentCustomer = customer;
		this.m_ScannedItemLerpPos = scannedItemLerpPos;
	}

	// Token: 0x06000128 RID: 296 RVA: 0x0000FF60 File Offset: 0x0000E160
	public void SetCurrentPrice(float price)
	{
		this.m_CurrentPrice = price;
	}

	// Token: 0x06000129 RID: 297 RVA: 0x0000FF69 File Offset: 0x0000E169
	public float GetCurrentPrice()
	{
		return this.m_CurrentPrice;
	}

	// Token: 0x0600012A RID: 298 RVA: 0x0000FF71 File Offset: 0x0000E171
	public bool IsNotScanned()
	{
		return this.m_CurrentCustomer;
	}

	// Token: 0x0600012B RID: 299 RVA: 0x0000FF83 File Offset: 0x0000E183
	public bool IsDisplayedOnShelf()
	{
		return this.m_IsDisplayedOnShelf;
	}

	// Token: 0x0600012C RID: 300 RVA: 0x0000FF8B File Offset: 0x0000E18B
	public void SetIsDisplayedOnShelf(bool isDisplayedOnShelf)
	{
		this.m_CollectionBinderFlipAnimCtrl = null;
		this.m_IsDisplayedOnShelf = isDisplayedOnShelf;
	}

	// Token: 0x04000195 RID: 405
	public bool m_IsCardAlbumCard;

	// Token: 0x04000196 RID: 406
	public CollectionBinderFlipAnimCtrl m_CollectionBinderFlipAnimCtrl;

	// Token: 0x04000197 RID: 407
	public Card3dUIGroup m_Card3dUI;

	// Token: 0x04000198 RID: 408
	public BoxCollider m_Collider;

	// Token: 0x04000199 RID: 409
	public Rigidbody m_Rigidbody;

	// Token: 0x0400019A RID: 410
	public bool m_IsCard3dUIFollow;

	// Token: 0x0400019B RID: 411
	private bool m_IsLerpingCardRot;

	// Token: 0x0400019C RID: 412
	private bool m_IsDisplayedOnShelf;

	// Token: 0x0400019D RID: 413
	private float m_CurrentPrice;

	// Token: 0x0400019E RID: 414
	private Quaternion m_CardTargetLerpRot;

	// Token: 0x0400019F RID: 415
	private Customer m_CurrentCustomer;

	// Token: 0x040001A0 RID: 416
	private Transform m_ScannedItemLerpPos;
}
