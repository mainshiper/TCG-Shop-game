﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200001E RID: 30
public class InteractableCounterMoneyChange : InteractableObject
{
	// Token: 0x06000173 RID: 371 RVA: 0x00011C9C File Offset: 0x0000FE9C
	public void UpdateCurrency()
	{
		CounterMoneyChangeCurrencyData counterMoneyChangeCurrencyData = null;
		for (int i = 0; i < this.m_CounterMoneyChangeCurrencyDataList.Count; i++)
		{
			if (this.m_CounterMoneyChangeCurrencyDataList[i].currencyType == CSingleton<CGameManager>.Instance.m_CurrencyType)
			{
				counterMoneyChangeCurrencyData = this.m_CounterMoneyChangeCurrencyDataList[i];
				break;
			}
		}
		this.m_IsCoin = counterMoneyChangeCurrencyData.isCoin;
		this.m_Value = counterMoneyChangeCurrencyData.value / GameInstance.GetCurrencyConversionRate();
		if (this.m_IsCoin)
		{
			for (int j = 0; j < this.m_CoinMoneyMeshRenderer.Count; j++)
			{
				this.m_CoinMoneyMeshRenderer[j].material = InventoryBase.GetCurrencyMaterial(CSingleton<CGameManager>.Instance.m_CurrencyType);
			}
			this.m_CoinMoneyInstanceMeshRenderer.material = InventoryBase.GetCurrencyMaterial(CSingleton<CGameManager>.Instance.m_CurrencyType);
			if (this.m_CanBeCoinOrBill)
			{
				this.m_MoneyMeshRenderer.gameObject.SetActive(false);
				this.m_MoneyInstanceMeshRenderer.gameObject.SetActive(false);
				for (int k = 0; k < this.m_CoinMoneyMeshRenderer.Count; k++)
				{
					this.m_CoinMoneyMeshRenderer[k].gameObject.SetActive(true);
				}
				this.m_CoinMoneyInstanceMeshRenderer.gameObject.SetActive(true);
				this.m_CoinMoneyMeshGrp.SetActive(true);
				this.m_BillMoneyOutline.SetActive(false);
				this.m_CoinMoneyOutline.SetActive(true);
			}
		}
		else
		{
			this.m_MoneyMeshRenderer.material = InventoryBase.GetCurrencyMaterial(CSingleton<CGameManager>.Instance.m_CurrencyType);
			this.m_MoneyInstanceMeshRenderer.material = InventoryBase.GetCurrencyMaterial(CSingleton<CGameManager>.Instance.m_CurrencyType);
			if (this.m_CanBeCoinOrBill)
			{
				this.m_MoneyMeshRenderer.gameObject.SetActive(true);
				this.m_MoneyInstanceMeshRenderer.gameObject.SetActive(true);
				for (int l = 0; l < this.m_CoinMoneyMeshRenderer.Count; l++)
				{
					this.m_CoinMoneyMeshRenderer[l].gameObject.SetActive(false);
				}
				this.m_CoinMoneyInstanceMeshRenderer.gameObject.SetActive(false);
				this.m_CoinMoneyMeshGrp.SetActive(false);
				this.m_BillMoneyOutline.SetActive(true);
				this.m_CoinMoneyOutline.SetActive(false);
			}
		}
		if (this.m_IsCoin)
		{
			this.m_PosYIndexOffset = Vector3.zero;
			return;
		}
		this.m_PosYIndexOffset = Vector3.up * 0.0005f * (float)this.m_Index * (float)this.m_Index;
	}

	// Token: 0x06000174 RID: 372 RVA: 0x00011F03 File Offset: 0x00010103
	protected override void Start()
	{
		base.Start();
		this.UpdateCurrency();
	}

	// Token: 0x06000175 RID: 373 RVA: 0x00011F14 File Offset: 0x00010114
	protected override void Update()
	{
		if (!this.m_CashierCounter.IsGivingChange())
		{
			return;
		}
		base.Update();
		for (int i = 0; i < this.m_IsLerpingList.Count; i++)
		{
			if (this.m_IsLerpingList[i])
			{
				List<float> lerpTimerList = this.m_LerpTimerList;
				int index = i;
				lerpTimerList[index] += Time.deltaTime * 3f;
				this.m_MoneyModelInstanceList[i].position = Vector3.Lerp(base.transform.position, this.m_PlaceMoneyLocation + this.m_PosYOffsetList[i] + this.m_PosYIndexOffset, this.m_LerpTimerList[i]);
				if (this.m_LerpTimerList[i] >= 1f)
				{
					this.m_LerpTimerList[i] = 1f;
					this.m_IsLerpingList[i] = false;
				}
			}
			else if (this.m_IsLerpingBackList[i])
			{
				List<float> lerpTimerList = this.m_LerpTimerList;
				int index = i;
				lerpTimerList[index] -= Time.deltaTime * 3f;
				this.m_MoneyModelInstanceList[i].position = Vector3.Lerp(base.transform.position, this.m_PlaceMoneyLocation + this.m_PosYOffsetList[i] + this.m_PosYIndexOffset, this.m_LerpTimerList[i]);
				if (this.m_LerpTimerList[i] <= 0f)
				{
					this.m_LerpTimerList[i] = 0f;
					this.m_IsLerpingBackList[i] = false;
					this.m_MoneyModelInstanceList[i].gameObject.SetActive(false);
				}
			}
		}
	}

	// Token: 0x06000176 RID: 374 RVA: 0x000120D8 File Offset: 0x000102D8
	public override void OnMouseButtonUp()
	{
		if (this.m_GivenAmount >= 100 || !this.m_CashierCounter.IsGivingChange())
		{
			return;
		}
		bool flag = false;
		for (int i = 0; i < this.m_MoneyModelInstanceList.Count; i++)
		{
			if (!this.m_MoneyModelInstanceList[i].gameObject.activeSelf)
			{
				flag = true;
				this.m_IsLerpingList[i] = true;
				this.m_IsLerpingBackList[i] = false;
				this.m_PosYOffsetList[i] = this.m_CashierCounter.GetChangeMoneyPosYOffset(this.m_IsCoin, this.m_GivenAmount);
				this.m_MoneyModelInstanceList[i].gameObject.SetActive(true);
				break;
			}
		}
		if (!flag)
		{
			if (this.m_CanBeCoinOrBill)
			{
				if (this.m_IsCoin)
				{
					this.m_MoneyModelInstance = Object.Instantiate<Transform>(this.m_CoinMoneyInstanceMeshRenderer.transform, this.m_CoinMoneyInstanceMeshRenderer.transform.position, this.m_CoinMoneyInstanceMeshRenderer.transform.rotation, base.transform);
				}
				else
				{
					this.m_MoneyModelInstance = Object.Instantiate<Transform>(this.m_MoneyInstanceMeshRenderer.transform, this.m_MoneyInstanceMeshRenderer.transform.position, this.m_MoneyInstanceMeshRenderer.transform.rotation, base.transform);
				}
				this.m_MoneyModelInstance.transform.localScale = this.m_MoneyModel.localScale;
			}
			else
			{
				this.m_MoneyModelInstance = Object.Instantiate<Transform>(this.m_MoneyModel, this.m_MoneyModel.position, this.m_MoneyModel.rotation, base.transform);
			}
			this.m_LerpTimerList.Add(0f);
			this.m_IsLerpingList.Add(true);
			this.m_IsLerpingBackList.Add(false);
			this.m_PosYOffsetList.Add(this.m_CashierCounter.GetChangeMoneyPosYOffset(this.m_IsCoin, this.m_GivenAmount));
			this.m_MoneyModelInstanceList.Add(this.m_MoneyModelInstance);
		}
		Vector3 b = this.m_CashierCounter.m_PlaceMoneyLocation.forward * (float)this.m_Index * 0.04f;
		this.m_PlaceMoneyLocation = this.m_CashierCounter.m_PlaceMoneyLocation.position + b;
		if (this.m_IsCoin)
		{
			this.m_PlaceMoneyLocation = this.m_CashierCounter.m_PlaceCoinLocation.position + b;
		}
		this.m_CashierCounter.OnGiveChange(this.m_Value, false);
		this.m_GivenAmount++;
	}

	// Token: 0x06000177 RID: 375 RVA: 0x00012348 File Offset: 0x00010548
	public override void OnRightMouseButtonUp()
	{
		if (this.m_GivenAmount <= 0 || !this.m_CashierCounter.IsGivingChange())
		{
			return;
		}
		for (int i = this.m_MoneyModelInstanceList.Count - 1; i >= 0; i--)
		{
			if (this.m_MoneyModelInstanceList[i].gameObject.activeSelf && !this.m_IsLerpingBackList[i])
			{
				this.m_IsLerpingList[i] = false;
				this.m_IsLerpingBackList[i] = true;
				this.m_PosYOffsetList[i] = this.m_CashierCounter.GetChangeMoneyPosYOffset(this.m_IsCoin, this.m_GivenAmount);
				this.m_MoneyModelInstanceList[i].gameObject.SetActive(true);
				break;
			}
		}
		this.m_CashierCounter.OnGiveChange(this.m_Value, true);
		this.m_GivenAmount--;
	}

	// Token: 0x06000178 RID: 376 RVA: 0x00012428 File Offset: 0x00010628
	public void ResetAmountGiven()
	{
		this.m_GivenAmount = 0;
		for (int i = 0; i < this.m_MoneyModelInstanceList.Count; i++)
		{
			this.m_IsLerpingList[i] = false;
			this.m_IsLerpingBackList[i] = false;
			this.m_LerpTimerList[i] = 0f;
			this.m_MoneyModelInstanceList[i].transform.position = base.transform.position;
			this.m_MoneyModelInstanceList[i].gameObject.SetActive(false);
		}
	}

	// Token: 0x06000179 RID: 377 RVA: 0x000124B5 File Offset: 0x000106B5
	protected virtual void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x0600017A RID: 378 RVA: 0x000124D6 File Offset: 0x000106D6
	protected virtual void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x0600017B RID: 379 RVA: 0x000124F8 File Offset: 0x000106F8
	protected void OnMoneyCurrencyUpdated(CEventPlayer_OnMoneyCurrencyUpdated evt)
	{
		this.UpdateCurrency();
		for (int i = this.m_MoneyModelInstanceList.Count - 1; i >= 0; i--)
		{
			Object.Destroy(this.m_MoneyModelInstanceList[i].gameObject);
		}
		this.m_MoneyModelInstanceList.Clear();
		this.m_LerpTimerList.Clear();
		this.m_IsLerpingList.Clear();
		this.m_IsLerpingBackList.Clear();
		this.m_PosYOffsetList.Clear();
		this.m_GivenAmount = 0;
	}

	// Token: 0x040001E0 RID: 480
	public List<CounterMoneyChangeCurrencyData> m_CounterMoneyChangeCurrencyDataList;

	// Token: 0x040001E1 RID: 481
	public bool m_CanBeCoinOrBill;

	// Token: 0x040001E2 RID: 482
	public bool m_IsCoin;

	// Token: 0x040001E3 RID: 483
	public float m_Value = 1f;

	// Token: 0x040001E4 RID: 484
	public int m_Index;

	// Token: 0x040001E5 RID: 485
	public Transform m_MoneyModel;

	// Token: 0x040001E6 RID: 486
	public Transform m_MoneyModelInstance;

	// Token: 0x040001E7 RID: 487
	public MeshRenderer m_MoneyMeshRenderer;

	// Token: 0x040001E8 RID: 488
	public MeshRenderer m_MoneyInstanceMeshRenderer;

	// Token: 0x040001E9 RID: 489
	public GameObject m_CoinMoneyMeshGrp;

	// Token: 0x040001EA RID: 490
	public List<MeshRenderer> m_CoinMoneyMeshRenderer;

	// Token: 0x040001EB RID: 491
	public MeshRenderer m_CoinMoneyInstanceMeshRenderer;

	// Token: 0x040001EC RID: 492
	public GameObject m_BillMoneyOutline;

	// Token: 0x040001ED RID: 493
	public GameObject m_CoinMoneyOutline;

	// Token: 0x040001EE RID: 494
	public InteractableCashierCounter m_CashierCounter;

	// Token: 0x040001EF RID: 495
	private int m_GivenAmount;

	// Token: 0x040001F0 RID: 496
	private Vector3 m_PosYIndexOffset;

	// Token: 0x040001F1 RID: 497
	private List<float> m_LerpTimerList = new List<float>();

	// Token: 0x040001F2 RID: 498
	private List<bool> m_IsLerpingList = new List<bool>();

	// Token: 0x040001F3 RID: 499
	private List<bool> m_IsLerpingBackList = new List<bool>();

	// Token: 0x040001F4 RID: 500
	private List<Vector3> m_PosYOffsetList = new List<Vector3>();

	// Token: 0x040001F5 RID: 501
	private List<Transform> m_MoneyModelInstanceList = new List<Transform>();

	// Token: 0x040001F6 RID: 502
	private Vector3 m_PlaceMoneyLocation;
}
