﻿using System;
using I2.Loc;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200007A RID: 122
public class RestockItemPanelUI : UIElementBase
{
	// Token: 0x060004DA RID: 1242 RVA: 0x0002A47C File Offset: 0x0002867C
	public void Init(RestockItemScreen restockItemScreen, int index)
	{
		if (index < 0)
		{
			this.m_LicenseUIGrp.SetActive(false);
			this.m_UIGrp.SetActive(false);
			return;
		}
		this.m_RestockItemScreen = restockItemScreen;
		this.m_Index = index;
		RestockData restockData = InventoryBase.GetRestockData(index);
		if (CSingleton<CGameManager>.Instance.m_IsPrologue && !restockData.prologueShow)
		{
			this.m_LicenseUIGrp.SetActive(false);
			this.m_UIGrp.SetActive(false);
			this.m_PrologueUIGrp.SetActive(true);
		}
		else
		{
			this.m_PrologueUIGrp.SetActive(false);
		}
		this.m_Amount = restockData.amount;
		this.m_ItemType = restockData.itemType;
		ItemData itemData = InventoryBase.GetItemData(this.m_ItemType);
		this.m_ItemImage.sprite = itemData.icon;
		this.m_ItemImage2.sprite = this.m_ItemImage.sprite;
		if (restockData.isBigBox)
		{
			this.m_ItemImage.enabled = true;
			this.m_ItemImage2.enabled = true;
		}
		else
		{
			this.m_ItemImage.enabled = true;
			this.m_ItemImage2.enabled = false;
		}
		if (restockData.ignoreDoubleImage)
		{
			this.m_ItemImage2.enabled = false;
		}
		this.m_ItemImageB.sprite = this.m_ItemImage.sprite;
		this.m_ItemImage2B.sprite = this.m_ItemImage2.sprite;
		this.m_ItemImageB.enabled = this.m_ItemImage.enabled;
		this.m_ItemImage2B.enabled = this.m_ItemImage2.enabled;
		this.m_Amount = RestockManager.GetMaxItemCountInBox(this.m_ItemType, restockData.isBigBox);
		this.m_UnitPrice = CPlayerData.GetItemCost(this.m_ItemType);
		this.m_TotalPrice = this.m_UnitPrice * (float)this.m_Amount;
		this.m_LicensePrice = restockData.licensePrice;
		this.m_LevelRequired = restockData.licenseShopLevelRequired;
		this.m_ItemNameText.text = itemData.GetName() + " (" + this.m_Amount.ToString() + ")";
		this.m_AmountText.text = "Qty : " + this.m_Amount.ToString();
		this.m_UnitPriceText.text = GameInstance.GetPriceString(this.m_UnitPrice, false, true, false, "F2");
		this.m_TotalPriceText.text = GameInstance.GetPriceString(this.m_TotalPrice, false, true, false, "F2");
		if (CPlayerData.GetIsItemLicenseUnlocked(this.m_Index))
		{
			this.m_LicenseUIGrp.SetActive(false);
			this.m_UIGrp.SetActive(true);
			return;
		}
		this.m_ItemNameTextB.text = this.m_ItemNameText.text + " " + LocalizationManager.GetTranslation("License", true, 0, true, false, null, null, true);
		this.m_LicensePriceText.text = GameInstance.GetPriceString(this.m_LicensePrice, false, true, false, "F2");
		if (this.m_LevelRequirementString == "")
		{
			this.m_LevelRequirementString = this.m_LevelRequirementText.text;
		}
		if (CPlayerData.m_ShopLevel + 1 >= this.m_LevelRequired)
		{
			this.m_LevelRequirementText.gameObject.SetActive(false);
			this.m_LockPurchaseBtn.gameObject.SetActive(false);
		}
		else
		{
			this.m_LevelRequirementText.text = LocalizationManager.GetTranslation(this.m_LevelRequirementString, true, 0, true, false, null, null, true).Replace("XXX", this.m_LevelRequired.ToString());
			this.m_LevelRequirementText.gameObject.SetActive(true);
			this.m_LockPurchaseBtn.gameObject.SetActive(true);
		}
		if (restockData.isHideItemUntilUnlocked)
		{
			this.m_ItemNameTextB.text = "??? " + LocalizationManager.GetTranslation("License", true, 0, true, false, null, null, true);
			this.m_ItemImageB.sprite = InventoryBase.GetQuestionMarkSprite();
			this.m_ItemImageB.enabled = true;
			this.m_ItemImage2B.enabled = false;
		}
		this.m_LicenseUIGrp.SetActive(true);
		this.m_UIGrp.SetActive(false);
	}

	// Token: 0x060004DB RID: 1243 RVA: 0x0002A85A File Offset: 0x00028A5A
	public float GetTotalPrice()
	{
		return this.m_TotalPrice;
	}

	// Token: 0x060004DC RID: 1244 RVA: 0x0002A862 File Offset: 0x00028A62
	public float GetIndex()
	{
		return (float)this.m_Index;
	}

	// Token: 0x060004DD RID: 1245 RVA: 0x0002A86B File Offset: 0x00028A6B
	public override void OnPressButton()
	{
		this.m_RestockItemScreen.OnPressAddToCartButton(this.m_Index);
	}

	// Token: 0x060004DE RID: 1246 RVA: 0x0002A880 File Offset: 0x00028A80
	public void OnPressPurchaseButton()
	{
		if (CPlayerData.m_ShopLevel + 1 >= this.m_LevelRequired)
		{
			if (CPlayerData.m_CoinAmount < this.m_LicensePrice)
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.Money);
				return;
			}
			CEventManager.QueueEvent(new CEventPlayer_ReduceCoin(this.m_LicensePrice, false));
			CPlayerData.SetUnlockItemLicense(this.m_Index);
			this.m_LicenseUIGrp.SetActive(false);
			this.m_UIGrp.SetActive(true);
			this.m_PopupAnim.Play();
			CPlayerData.m_GameReportDataCollect.upgradeCost = CPlayerData.m_GameReportDataCollect.upgradeCost - this.m_LicensePrice;
			CPlayerData.m_GameReportDataCollectPermanent.upgradeCost = CPlayerData.m_GameReportDataCollectPermanent.upgradeCost - this.m_LicensePrice;
			AchievementManager.OnItemLicenseUnlocked(this.m_ItemType);
			SoundManager.PlayAudio("SFX_CustomerBuy", 0.6f, 1f);
			if (this.m_ItemType == EItemType.BasicCardBox)
			{
				TutorialManager.AddTaskValue(ETutorialTaskCondition.UnlockBasicCardBox, 1f);
				return;
			}
		}
		else
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.ShopLevelNotEnough);
		}
	}

	// Token: 0x04000655 RID: 1621
	public Image m_ItemImage;

	// Token: 0x04000656 RID: 1622
	public Image m_ItemImage2;

	// Token: 0x04000657 RID: 1623
	public TextMeshProUGUI m_ItemNameText;

	// Token: 0x04000658 RID: 1624
	public TextMeshProUGUI m_AmountText;

	// Token: 0x04000659 RID: 1625
	public TextMeshProUGUI m_UnitPriceText;

	// Token: 0x0400065A RID: 1626
	public TextMeshProUGUI m_TotalPriceText;

	// Token: 0x0400065B RID: 1627
	public Animation m_PopupAnim;

	// Token: 0x0400065C RID: 1628
	public Image m_ItemImageB;

	// Token: 0x0400065D RID: 1629
	public Image m_ItemImage2B;

	// Token: 0x0400065E RID: 1630
	public TextMeshProUGUI m_ItemNameTextB;

	// Token: 0x0400065F RID: 1631
	public TextMeshProUGUI m_LicensePriceText;

	// Token: 0x04000660 RID: 1632
	public TextMeshProUGUI m_LevelRequirementText;

	// Token: 0x04000661 RID: 1633
	public GameObject m_LockPurchaseBtn;

	// Token: 0x04000662 RID: 1634
	public GameObject m_LicenseUIGrp;

	// Token: 0x04000663 RID: 1635
	public GameObject m_PrologueUIGrp;

	// Token: 0x04000664 RID: 1636
	private string m_LevelRequirementString = "";

	// Token: 0x04000665 RID: 1637
	private RestockItemScreen m_RestockItemScreen;

	// Token: 0x04000666 RID: 1638
	private int m_Index;

	// Token: 0x04000667 RID: 1639
	private int m_Amount;

	// Token: 0x04000668 RID: 1640
	private int m_LevelRequired;

	// Token: 0x04000669 RID: 1641
	private float m_UnitPrice;

	// Token: 0x0400066A RID: 1642
	private float m_TotalPrice;

	// Token: 0x0400066B RID: 1643
	private float m_LicensePrice;

	// Token: 0x0400066C RID: 1644
	private EItemType m_ItemType = EItemType.None;
}
