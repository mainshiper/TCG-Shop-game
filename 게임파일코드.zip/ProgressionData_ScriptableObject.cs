﻿using System;
using System.Collections.Generic;
using I2.Loc;
using UnityEngine;

// Token: 0x02000130 RID: 304
[CreateAssetMenu(fileName = "Data", menuName = "Inventory/List", order = 8)]
public class ProgressionData_ScriptableObject : ScriptableObject
{
	// Token: 0x060008EE RID: 2286 RVA: 0x0004270B File Offset: 0x0004090B
	public string GetTamerLevelUpUnlockText(int level)
	{
		return LocalizationManager.GetTranslation(this.m_TamerLevelUpUnlockedText[level], true, 0, true, false, null, null, true);
	}

	// Token: 0x060008EF RID: 2287 RVA: 0x00042725 File Offset: 0x00040925
	public ProgressionArenaData GetProgressionData(int playerRank, bool hasFinishTutorial)
	{
		if (!hasFinishTutorial)
		{
			return this.m_TutorialArenaData;
		}
		if (playerRank >= 0 && playerRank < this.m_ProgressionArenaDataList.Count)
		{
			return this.m_ProgressionArenaDataList[playerRank];
		}
		return this.m_EmptyData;
	}

	// Token: 0x040010F3 RID: 4339
	public ProgressionArenaData m_EmptyData;

	// Token: 0x040010F4 RID: 4340
	public ProgressionArenaData m_TutorialArenaData;

	// Token: 0x040010F5 RID: 4341
	public List<ProgressionArenaData> m_ProgressionArenaDataList;

	// Token: 0x040010F6 RID: 4342
	public List<int> m_TamerLevelUpExpRequiredList;

	// Token: 0x040010F7 RID: 4343
	public List<string> m_TamerLevelUpUnlockedText;
}
