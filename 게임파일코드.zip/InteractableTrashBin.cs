﻿using System;

// Token: 0x0200002A RID: 42
public class InteractableTrashBin : InteractableObject
{
	// Token: 0x0600022C RID: 556 RVA: 0x00015535 File Offset: 0x00013735
	public void DiscardBox(InteractablePackagingBox packagingBox, bool isPlayer)
	{
		packagingBox.OnDestroyed();
		if (isPlayer)
		{
			SoundManager.PlayAudio("SFX_Dispose", 0.6f, 1f);
			CSingleton<InteractionPlayerController>.Instance.OnExitHoldBoxMode();
		}
	}
}
