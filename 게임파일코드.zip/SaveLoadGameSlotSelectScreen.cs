﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200007D RID: 125
public class SaveLoadGameSlotSelectScreen : CSingleton<SaveLoadGameSlotSelectScreen>
{
	// Token: 0x060004F1 RID: 1265 RVA: 0x0002AF68 File Offset: 0x00029168
	public static void OpenScreen(bool isSaveState)
	{
		if (CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_IsSavingGame)
		{
			return;
		}
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_IsSaveState = isSaveState;
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_LoadGameText.SetActive(!isSaveState);
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SaveGameText.SetActive(isSaveState);
		if (!isSaveState && CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Count >= 4)
		{
			CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_IsDataLoaded = true;
		}
		if (!CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_IsDataLoaded)
		{
			CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Clear();
			if (CSaveLoad.LoadSavedSlotData(0))
			{
				CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Add(CGameData.instance.GetLoadSavedSlotData(CSaveLoad.m_SavedGameBackup));
			}
			else
			{
				CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Add(default(LoadSavedSlotData));
			}
			if (CSaveLoad.LoadSavedSlotData(1))
			{
				CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Add(CGameData.instance.GetLoadSavedSlotData(CSaveLoad.m_SavedGameBackup));
			}
			else
			{
				CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Add(default(LoadSavedSlotData));
			}
			if (CSaveLoad.LoadSavedSlotData(2))
			{
				CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Add(CGameData.instance.GetLoadSavedSlotData(CSaveLoad.m_SavedGameBackup));
			}
			else
			{
				CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Add(default(LoadSavedSlotData));
			}
			if (CSaveLoad.LoadSavedSlotData(3))
			{
				CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Add(CGameData.instance.GetLoadSavedSlotData(CSaveLoad.m_SavedGameBackup));
			}
			else
			{
				CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Add(default(LoadSavedSlotData));
			}
		}
		for (int i = 0; i < CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Count; i++)
		{
			CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SaveLoadSlotPanelUIList[i].LoadSlotData(CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList[i]);
			CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SaveLoadSlotPanelUIList[i].SetSaveOrLoadState(isSaveState);
		}
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ScreenGrp.SetActive(true);
		SoundManager.GenericMenuOpen(1f, 1f);
		ControllerScreenUIExtManager.OnOpenScreen(CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ControllerScreenUIExtension);
	}

	// Token: 0x060004F2 RID: 1266 RVA: 0x0002B174 File Offset: 0x00029374
	public static void CloseScreen()
	{
		if (CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_IsSavingGame)
		{
			return;
		}
		if (CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_OverwriteSaveFileScreenGrp.activeSelf)
		{
			CSingleton<SaveLoadGameSlotSelectScreen>.Instance.CloseConfirmOverwriteSaveScreen();
			return;
		}
		if (CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_OverwriteLoadGameAutoSaveFileScreenGrp.activeSelf)
		{
			CSingleton<SaveLoadGameSlotSelectScreen>.Instance.CloseConfirmOverwriteLoadGameAutoSaveScreen();
			return;
		}
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ScreenGrp.SetActive(false);
		SoundManager.GenericMenuClose(1f, 1f);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ControllerScreenUIExtension);
	}

	// Token: 0x060004F3 RID: 1267 RVA: 0x0002B1F4 File Offset: 0x000293F4
	public void OnPressLoadGame(int slotIndex)
	{
		if (this.m_IsSavingGame)
		{
			return;
		}
		if (this.m_IsOpeningLevel)
		{
			return;
		}
		if (slotIndex != 0 && CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Count > 0 && CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList[0].hasSaveData)
		{
			SoundManager.GenericMenuOpen(1f, 1f);
			this.m_CurrentSaveSlotIndex = slotIndex;
			CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_OverwriteLoadGameAutoSaveFileScreenGrp.SetActive(true);
			ControllerScreenUIExtManager.OnOpenScreen(CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ControllerScreenUIExtension_OverwriteLoadGameAutoSaveFileScreen);
			return;
		}
		SoundManager.GenericLightTap(1f, 1f);
		this.m_IsOpeningLevel = true;
		CSingleton<CGameManager>.Instance.m_CurrentSaveLoadSlotSelectedIndex = slotIndex;
		CSingleton<CGameManager>.Instance.m_IsManualSaveLoad = true;
		CSingleton<CGameManager>.Instance.LoadMainLevelAsync("Start", 0);
	}

	// Token: 0x060004F4 RID: 1268 RVA: 0x0002B2B4 File Offset: 0x000294B4
	public void OnPressSaveGame(int slotIndex)
	{
		if (this.m_IsSavingGame)
		{
			return;
		}
		if (CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList[slotIndex].hasSaveData && CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList[slotIndex].name != CPlayerData.PlayerName)
		{
			SoundManager.GenericMenuOpen(1f, 1f);
			this.m_CurrentSaveSlotIndex = slotIndex;
			CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_OverwriteSaveFileScreenGrp.SetActive(true);
			ControllerScreenUIExtManager.OnOpenScreen(CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ControllerScreenUIExtension_OverwriteSaveFileScreen);
			return;
		}
		this.m_CurrentSaveSlotIndex = slotIndex;
		SoundManager.GenericLightTap(1f, 1f);
		CSingleton<CGameManager>.Instance.m_CurrentSaveLoadSlotSelectedIndex = slotIndex;
		CSingleton<CGameManager>.Instance.m_IsManualSaveLoad = true;
		CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
		CSingleton<CGameManager>.Instance.SaveGameData(slotIndex);
		this.m_IsSavingGame = true;
		this.m_SavingGameScreen.gameObject.SetActive(true);
		base.StartCoroutine(this.DelaySavingGame());
	}

	// Token: 0x060004F5 RID: 1269 RVA: 0x0002B3A0 File Offset: 0x000295A0
	public void OnPressConfirmOverwriteSave()
	{
		if (this.m_IsSavingGame)
		{
			return;
		}
		SoundManager.GenericLightTap(1f, 1f);
		CSingleton<CGameManager>.Instance.m_CurrentSaveLoadSlotSelectedIndex = this.m_CurrentSaveSlotIndex;
		CSingleton<CGameManager>.Instance.m_IsManualSaveLoad = true;
		CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
		CSingleton<CGameManager>.Instance.SaveGameData(this.m_CurrentSaveSlotIndex);
		this.m_IsSavingGame = true;
		this.m_SavingGameScreen.gameObject.SetActive(true);
		base.StartCoroutine(this.DelaySavingGame());
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_OverwriteSaveFileScreenGrp.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ControllerScreenUIExtension_OverwriteSaveFileScreen);
	}

	// Token: 0x060004F6 RID: 1270 RVA: 0x0002B43F File Offset: 0x0002963F
	public void CloseConfirmOverwriteSaveScreen()
	{
		if (CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_IsSavingGame)
		{
			return;
		}
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_OverwriteSaveFileScreenGrp.SetActive(false);
		SoundManager.GenericMenuClose(1f, 1f);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ControllerScreenUIExtension_OverwriteSaveFileScreen);
	}

	// Token: 0x060004F7 RID: 1271 RVA: 0x0002B47C File Offset: 0x0002967C
	public void OnPressConfirmLoadGameOverwriteAutoSave()
	{
		if (CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_IsSavingGame)
		{
			return;
		}
		if (CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_IsOpeningLevel)
		{
			return;
		}
		SoundManager.GenericLightTap(1f, 1f);
		this.m_IsOpeningLevel = true;
		CSingleton<CGameManager>.Instance.m_CurrentSaveLoadSlotSelectedIndex = this.m_CurrentSaveSlotIndex;
		CSingleton<CGameManager>.Instance.m_IsManualSaveLoad = true;
		CSingleton<CGameManager>.Instance.LoadMainLevelAsync("Start", 0);
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_OverwriteLoadGameAutoSaveFileScreenGrp.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ControllerScreenUIExtension_OverwriteLoadGameAutoSaveFileScreen);
	}

	// Token: 0x060004F8 RID: 1272 RVA: 0x0002B503 File Offset: 0x00029703
	public void CloseConfirmOverwriteLoadGameAutoSaveScreen()
	{
		if (CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_IsSavingGame)
		{
			return;
		}
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_OverwriteLoadGameAutoSaveFileScreenGrp.SetActive(false);
		SoundManager.GenericMenuClose(1f, 1f);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ControllerScreenUIExtension_OverwriteLoadGameAutoSaveFileScreen);
	}

	// Token: 0x060004F9 RID: 1273 RVA: 0x0002B540 File Offset: 0x00029740
	private IEnumerator DelaySavingGame()
	{
		yield return new WaitForSecondsRealtime(2f);
		this.m_SavingGameScreen.gameObject.SetActive(false);
		this.m_IsSavingGame = false;
		if (CSaveLoad.LoadSavedSlotData(this.m_CurrentSaveSlotIndex))
		{
			CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList[this.m_CurrentSaveSlotIndex] = CGameData.instance.GetLoadSavedSlotData(CSaveLoad.m_SavedGameBackup);
		}
		else
		{
			CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList[this.m_CurrentSaveSlotIndex] = default(LoadSavedSlotData);
		}
		for (int i = 0; i < CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Count; i++)
		{
			CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SaveLoadSlotPanelUIList[i].LoadSlotData(CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList[i]);
		}
		yield break;
	}

	// Token: 0x0400067D RID: 1661
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x0400067E RID: 1662
	public ControllerScreenUIExtension m_ControllerScreenUIExtension_OverwriteSaveFileScreen;

	// Token: 0x0400067F RID: 1663
	public ControllerScreenUIExtension m_ControllerScreenUIExtension_OverwriteLoadGameAutoSaveFileScreen;

	// Token: 0x04000680 RID: 1664
	public GameObject m_ScreenGrp;

	// Token: 0x04000681 RID: 1665
	public GameObject m_OverwriteSaveFileScreenGrp;

	// Token: 0x04000682 RID: 1666
	public GameObject m_OverwriteLoadGameAutoSaveFileScreenGrp;

	// Token: 0x04000683 RID: 1667
	public GameObject m_LoadGameText;

	// Token: 0x04000684 RID: 1668
	public GameObject m_SaveGameText;

	// Token: 0x04000685 RID: 1669
	public GameObject m_SavingGameScreen;

	// Token: 0x04000686 RID: 1670
	public List<SaveLoadSlotPanelUI> m_SaveLoadSlotPanelUIList;

	// Token: 0x04000687 RID: 1671
	public List<LoadSavedSlotData> m_SavedDataList = new List<LoadSavedSlotData>();

	// Token: 0x04000688 RID: 1672
	private bool m_IsOpeningLevel;

	// Token: 0x04000689 RID: 1673
	private bool m_IsSavingGame;

	// Token: 0x0400068A RID: 1674
	private bool m_IsSaveState;

	// Token: 0x0400068B RID: 1675
	private bool m_IsDataLoaded;

	// Token: 0x0400068C RID: 1676
	private int m_CurrentSaveSlotIndex;
}
