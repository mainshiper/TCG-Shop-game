﻿using System;

// Token: 0x020000E1 RID: 225
public enum EBoosterEffect
{
	// Token: 0x04000AAF RID: 2735
	None,
	// Token: 0x04000AB0 RID: 2736
	IncreasePrice,
	// Token: 0x04000AB1 RID: 2737
	IncreaseTapPower,
	// Token: 0x04000AB2 RID: 2738
	IncreaseCustomerSpendLimit,
	// Token: 0x04000AB3 RID: 2739
	IncreaseCustomerBuyLimit,
	// Token: 0x04000AB4 RID: 2740
	PackStorageLimit,
	// Token: 0x04000AB5 RID: 2741
	SellCardLimit
}
