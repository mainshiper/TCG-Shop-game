﻿using System;

// Token: 0x020000DB RID: 219
public enum ECollectionPackType
{
	// Token: 0x04000A25 RID: 2597
	None = -1,
	// Token: 0x04000A26 RID: 2598
	BasicCardPack,
	// Token: 0x04000A27 RID: 2599
	RareCardPack,
	// Token: 0x04000A28 RID: 2600
	EpicCardPack,
	// Token: 0x04000A29 RID: 2601
	LegendaryCardPack,
	// Token: 0x04000A2A RID: 2602
	DestinyBasicCardPack,
	// Token: 0x04000A2B RID: 2603
	DestinyRareCardPack,
	// Token: 0x04000A2C RID: 2604
	DestinyEpicCardPack,
	// Token: 0x04000A2D RID: 2605
	DestinyLegendaryCardPack,
	// Token: 0x04000A2E RID: 2606
	GhostPack,
	// Token: 0x04000A2F RID: 2607
	MegabotPack,
	// Token: 0x04000A30 RID: 2608
	FantasyRPGPack,
	// Token: 0x04000A31 RID: 2609
	CatJobPack,
	// Token: 0x04000A32 RID: 2610
	FoodieGOPack,
	// Token: 0x04000A33 RID: 2611
	FoodieGOBWPack,
	// Token: 0x04000A34 RID: 2612
	FoodieGOJPPack,
	// Token: 0x04000A35 RID: 2613
	MAX
}
