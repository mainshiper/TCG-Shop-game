﻿using System;
using System.Collections;
using System.Collections.Generic;
using CC;
using Pathfinding;
using UnityEngine;

// Token: 0x02000091 RID: 145
public class Worker : MonoBehaviour
{
	// Token: 0x060005A1 RID: 1441 RVA: 0x0002EB2B File Offset: 0x0002CD2B
	public void OnRaycasted()
	{
	}

	// Token: 0x060005A2 RID: 1442 RVA: 0x0002EB2D File Offset: 0x0002CD2D
	public void OnRaycastEnded()
	{
	}

	// Token: 0x060005A3 RID: 1443 RVA: 0x0002EB30 File Offset: 0x0002CD30
	public void OnMousePress()
	{
		this.m_IsPausingAction = true;
		CSingleton<InteractionPlayerController>.Instance.EnterWorkerInteractMode();
		this.m_RotationBeforeInteract = this.m_TargetLerpRotation;
		Vector3 forward = CSingleton<InteractionPlayerController>.Instance.m_Cam.transform.position - base.transform.position;
		forward.y = 0f;
		this.m_TargetLerpRotation = Quaternion.LookRotation(forward, Vector3.up);
		base.transform.position + forward.normalized * 1.5f;
		CSingleton<InteractionPlayerController>.Instance.EnterUIMode();
		CSingleton<InteractionPlayerController>.Instance.StartAimLookAt(this.m_PlayerLookAtTarget, 3f, 0.15f);
		CSingleton<InteractionPlayerController>.Instance.EnterLockMoveMode();
		GameUIScreen.HideToolTip();
		GameUIScreen.HideEnterGoNextDayIndicatorVisible();
		TutorialManager.SetGameUIVisible(false);
		WorkerInteractUIScreen.OpenScreen(this);
		this.m_IsExclaimationVisibleState = this.m_ExclaimationMesh.activeSelf;
		this.m_ExclaimationMesh.SetActive(false);
	}

	// Token: 0x060005A4 RID: 1444 RVA: 0x0002EC20 File Offset: 0x0002CE20
	public void OnPressStopInteract()
	{
		this.m_TargetLerpRotation = this.m_RotationBeforeInteract;
		this.m_IsPausingAction = false;
		CSingleton<InteractionPlayerController>.Instance.ExitWorkerInteractMode();
		CSingleton<InteractionPlayerController>.Instance.StopAimLookAt();
		CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.SetStopMovement(false);
		CSingleton<InteractionPlayerController>.Instance.ExitUIMode();
		GameUIScreen.ResetToolTipVisibility();
		GameUIScreen.ResetEnterGoNextDayIndicatorVisible();
		TutorialManager.SetGameUIVisible(true);
		this.m_ExclaimationMesh.SetActive(this.m_IsExclaimationVisibleState);
	}

	// Token: 0x060005A5 RID: 1445 RVA: 0x0002EC8F File Offset: 0x0002CE8F
	public void SetRestockShelfWithNoLabel(bool isFillShelfWithoutLabel)
	{
		this.m_IsFillShelfWithoutLabel = isFillShelfWithoutLabel;
	}

	// Token: 0x060005A6 RID: 1446 RVA: 0x0002EC98 File Offset: 0x0002CE98
	public void SetLastTask(EWorkerTask task)
	{
		this.m_LastWorkerTask = task;
	}

	// Token: 0x060005A7 RID: 1447 RVA: 0x0002ECA4 File Offset: 0x0002CEA4
	public void SetTask(EWorkerTask task)
	{
		if (this.m_WorkerTask != task)
		{
			this.m_WorkerTask = task;
			this.m_CurrentState = EWorkerState.Idle;
			this.m_Timer = 10f;
			this.m_HaveValidItemToRestock = false;
			if (task != EWorkerTask.Rest)
			{
				this.m_FirstTimeReachRestPosition = true;
				this.m_IsExclaimationVisibleState = false;
				this.m_ExclaimationMesh.SetActive(false);
			}
		}
	}

	// Token: 0x060005A8 RID: 1448 RVA: 0x0002ECF7 File Offset: 0x0002CEF7
	public void FireWorker()
	{
		CPlayerData.SetIsWorkerHired(this.m_WorkerIndex, false);
		this.m_WorkerCollider.gameObject.SetActive(false);
		this.m_LastWorkerTask = EWorkerTask.Rest;
		this.SetTask(EWorkerTask.Fired);
		this.DetermineShopAction();
	}

	// Token: 0x060005A9 RID: 1449 RVA: 0x0002ED2B File Offset: 0x0002CF2B
	public void CounterNextCustomer(int customerInQueueCount)
	{
		if (LightManager.GetHasDayEnded() && (!CSingleton<CustomerManager>.Instance.HasCustomerInShop() || this.m_InstantStopCounterWhenDayEnd) && customerInQueueCount <= 1)
		{
			this.SetTask(EWorkerTask.GoBackHome);
			this.DetermineShopAction();
		}
	}

	// Token: 0x060005AA RID: 1450 RVA: 0x0002ED5C File Offset: 0x0002CF5C
	public void OnDayEnded()
	{
		if (this.m_WorkerTask != EWorkerTask.ManCounter && this.m_WorkerTask != EWorkerTask.Fired)
		{
			if (this.m_InstantStopRestockWhenDayEnd)
			{
				this.SetTask(EWorkerTask.GoBackHome);
				return;
			}
		}
		else if (this.m_WorkerTask == EWorkerTask.ManCounter && (!CSingleton<CustomerManager>.Instance.HasCustomerInShop() || this.m_InstantStopCounterWhenDayEnd))
		{
			if (this.m_CurrentCashierCounter)
			{
				if (this.m_CurrentCashierCounter.GetCustomerInQueueCount() <= 0)
				{
					this.SetTask(EWorkerTask.GoBackHome);
					this.DetermineShopAction();
					return;
				}
			}
			else
			{
				this.SetTask(EWorkerTask.GoBackHome);
				this.DetermineShopAction();
			}
		}
	}

	// Token: 0x060005AB RID: 1451 RVA: 0x0002EDE4 File Offset: 0x0002CFE4
	public void RandomizeCharacterMesh()
	{
		if (!this.m_CharacterCustom.m_HasInit)
		{
			if (this.m_IsFemale)
			{
				this.m_CharacterCustom.CharacterName = "Worker" + this.m_WorkerIndex.ToString();
			}
			else
			{
				this.m_CharacterCustom.CharacterName = "Worker" + this.m_WorkerIndex.ToString();
			}
			this.m_CharacterCustom.Initialize();
		}
	}

	// Token: 0x060005AC RID: 1452 RVA: 0x0002EE54 File Offset: 0x0002D054
	private void EvaluateWorkerAttribute()
	{
		this.m_WorkerData = WorkerManager.GetWorkerData(this.m_WorkerIndex);
		this.m_ScanItemTime = this.m_WorkerData.checkoutSpeed * 1.33f;
		this.m_GiveChangeTime = this.m_WorkerData.checkoutSpeed;
		this.m_RestockTime = this.m_WorkerData.restockSpeed;
		this.m_ExtraSpeedMultiplier = 1f + this.m_WorkerData.walkSpeedMultiplier;
		this.m_InstantStopCounterWhenDayEnd = this.m_WorkerData.goBackOnTime;
		this.m_InstantStopRestockWhenDayEnd = this.m_WorkerData.goBackOnTime;
	}

	// Token: 0x060005AD RID: 1453 RVA: 0x0002EEE4 File Offset: 0x0002D0E4
	public WorkerData GetWorkerData()
	{
		return this.m_WorkerData;
	}

	// Token: 0x060005AE RID: 1454 RVA: 0x0002EEEC File Offset: 0x0002D0EC
	public void ActivateWorker(bool resetTask)
	{
		this.m_IsActive = true;
		this.m_WorkerCollider.gameObject.SetActive(true);
		this.m_ExclaimationMesh.SetActive(false);
		this.RandomizeCharacterMesh();
		this.EvaluateWorkerAttribute();
		this.m_Timer = 0f;
		this.m_FailFindShelfAttemptCount = 0;
		this.m_FailFindItemAttemptCount = 0;
		this.m_IsWaitingForPathCallback = false;
		this.m_UnableToFindQueue = false;
		this.m_FirstTimeReachRestPosition = false;
		this.m_TargetTransform = CustomerManager.GetRandomExitPoint();
		base.transform.position = this.m_TargetTransform.position;
		base.transform.rotation = this.m_TargetTransform.rotation;
		this.m_TargetLerpRotation = this.m_TargetTransform.rotation;
		this.m_CurrentCashierCounter = null;
		this.m_CurrentHoldItemBox = null;
		this.m_CurrentItemBox = null;
		if (resetTask)
		{
			this.m_WorkerTask = EWorkerTask.Rest;
			this.m_LastWorkerTask = EWorkerTask.Rest;
		}
		else
		{
			this.m_WorkerTask = this.m_LastWorkerTask;
			if (this.m_WorkerTask != EWorkerTask.Rest)
			{
				this.m_FirstTimeReachRestPosition = true;
			}
		}
		this.SetState(EWorkerState.Idle);
		this.m_Timer = 10f;
		this.m_Anim.SetBool("HoldingBag", false);
		this.m_Anim.SetBool("HandingOverCash", false);
	}

	// Token: 0x060005AF RID: 1455 RVA: 0x0002F018 File Offset: 0x0002D218
	public void DeactivateWorker()
	{
		if (!this.m_HasUpdatedCustomerCount)
		{
			this.m_HasUpdatedCustomerCount = true;
			CSingleton<WorkerManager>.Instance.UpdateWorkerCount(-1);
		}
		this.SetOutOfScreen();
		base.gameObject.SetActive(false);
		this.m_IsActive = false;
		this.m_IsInsideShop = false;
		this.m_CurrentState = EWorkerState.Idle;
		if (!CPlayerData.GetIsWorkerHired(this.m_WorkerIndex))
		{
			this.m_WorkerTask = EWorkerTask.Rest;
			this.m_LastWorkerTask = EWorkerTask.Rest;
		}
		this.m_HasUpdatedCustomerCount = false;
		this.m_FirstTimeReachRestPosition = false;
	}

	// Token: 0x060005B0 RID: 1456 RVA: 0x0002F090 File Offset: 0x0002D290
	private void DetermineShopAction()
	{
		if (this.m_CurrentState != EWorkerState.WalkingToRestOutside)
		{
			this.m_ReachedEndOfPath = false;
			this.m_Path = null;
		}
		if (this.m_CurrentCashierCounter && this.m_WorkerTask != EWorkerTask.ManCounter)
		{
			this.m_CurrentCashierCounter.StopCurrentWorker();
		}
		if (this.m_CurrentHoldItemBox && this.m_WorkerTask != EWorkerTask.RestockShelf)
		{
			this.DropBoxOnHand();
		}
		if (this.m_WorkerTask == EWorkerTask.ManCounter)
		{
			this.AttemptFindCashierCounter();
			return;
		}
		if (this.m_WorkerTask == EWorkerTask.RestockShelf)
		{
			if (this.m_CurrentHoldItemBox)
			{
				this.AttemptFindShelf();
				return;
			}
			List<InteractablePackagingBox_Item> itemPackagingBoxListWithItem = RestockManager.GetItemPackagingBoxListWithItem(false);
			List<EItemType> list = new List<EItemType>();
			List<EItemType> list2 = new List<EItemType>();
			List<EItemType> list3 = new List<EItemType>();
			for (int i = itemPackagingBoxListWithItem.Count - 1; i >= 0; i--)
			{
				if (!itemPackagingBoxListWithItem[i].IsValidObject() || !itemPackagingBoxListWithItem[i].CanWorkerTakeBox() || (!itemPackagingBoxListWithItem[i].m_IsStored && itemPackagingBoxListWithItem[i].transform.position.y > 2f))
				{
					itemPackagingBoxListWithItem.RemoveAt(i);
				}
			}
			bool flag = false;
			if (this.m_CanFindStoredItem)
			{
				itemPackagingBoxListWithItem = RestockManager.GetItemPackagingBoxListWithItem(true);
				flag = true;
			}
			for (int j = itemPackagingBoxListWithItem.Count - 1; j >= 0; j--)
			{
				if (!itemPackagingBoxListWithItem[j].IsValidObject() || !itemPackagingBoxListWithItem[j].CanWorkerTakeBox())
				{
					itemPackagingBoxListWithItem.RemoveAt(j);
				}
			}
			if (flag)
			{
				this.m_HaveValidItemToRestock = (itemPackagingBoxListWithItem.Count > 0);
			}
			for (int k = 0; k < itemPackagingBoxListWithItem.Count; k++)
			{
				EItemType eitemType = itemPackagingBoxListWithItem[k].m_ItemCompartment.GetItemType();
				if (itemPackagingBoxListWithItem[k].m_ItemCompartment.GetItemCount() <= 0)
				{
					eitemType = EItemType.None;
				}
				if (eitemType != EItemType.None)
				{
					if (!list.Contains(eitemType) && eitemType != EItemType.None)
					{
						list.Add(eitemType);
					}
					if (itemPackagingBoxListWithItem[k].m_IsBigBox && !itemPackagingBoxListWithItem[k].m_IsStored)
					{
						if (!list3.Contains(eitemType))
						{
							list3.Add(eitemType);
						}
					}
					else if (!itemPackagingBoxListWithItem[k].m_IsBigBox && !itemPackagingBoxListWithItem[k].m_IsStored && !list2.Contains(eitemType))
					{
						list2.Add(eitemType);
					}
				}
			}
			List<Shelf> list4 = new List<Shelf>();
			List<Shelf> list5 = new List<Shelf>();
			bool flag2 = false;
			for (int l = 0; l < list.Count; l++)
			{
				list5 = ShelfManager.GetShelfListToRestockItem(list[l], true);
				for (int m = 0; m < list5.Count; m++)
				{
					if (!list4.Contains(list5[m]))
					{
						if (WorkerManager.GetActiveWorkerCount() == 1)
						{
							list4.Add(list5[m]);
							flag2 = true;
						}
						else if (!false)
						{
							list4.Add(list5[m]);
							flag2 = true;
						}
					}
				}
			}
			if (this.m_IsFillShelfWithoutLabel && !flag2)
			{
				for (int n = 0; n < list.Count; n++)
				{
					list5 = ShelfManager.GetShelfListToRestockItem(list[n], false);
					for (int num = 0; num < list5.Count; num++)
					{
						if (!list4.Contains(list5[num]))
						{
							list4.Add(list5[num]);
						}
					}
				}
			}
			bool flag3 = false;
			List<ShelfCompartment> list6 = new List<ShelfCompartment>();
			List<EItemType> list7 = new List<EItemType>();
			for (int num2 = 0; num2 < list4.Count; num2++)
			{
				List<ShelfCompartment> list8 = new List<ShelfCompartment>();
				for (int num3 = 0; num3 < list.Count; num3++)
				{
					list8 = list4[num2].GetNonFullItemCompartmentList(list[num3], flag2);
					for (int num4 = 0; num4 < list8.Count; num4++)
					{
						if (!list6.Contains(list8[num4]))
						{
							list6.Add(list8[num4]);
						}
					}
				}
				for (int num5 = 0; num5 < list6.Count; num5++)
				{
					if (list6[num5].GetItemCount() < list6[num5].GetMaxItemCount() || (!flag2 && (list6[num5].GetItemType() == EItemType.None || list6[num5].GetItemCount() == 0)))
					{
						if (WorkerManager.GetActiveWorkerCount() == 1)
						{
							if (list.Contains(list6[num5].GetItemType()))
							{
								this.m_TargetBoxItemType = list6[num5].GetItemType();
								list7.Add(list6[num5].GetItemType());
								flag3 = true;
							}
							else if (list.Count > 0 && this.m_IsFillShelfWithoutLabel && (list6[num5].GetItemType() == EItemType.None || list6[num5].GetItemCount() == 0))
							{
								list7.Add(list[Random.Range(0, list.Count)]);
								flag3 = true;
							}
						}
						else
						{
							bool flag4 = false;
							for (int num6 = 0; num6 < WorkerManager.GetWorkerList().Count; num6++)
							{
								if (WorkerManager.GetWorkerList()[num6] != this && WorkerManager.GetWorkerList()[num6].IsActive() && WorkerManager.GetWorkerList()[num6].CheckWorkerSameTarget(list6[num5].m_CustomerStandLoc))
								{
									flag4 = true;
									break;
								}
							}
							if (!flag4)
							{
								if (list.Contains(list6[num5].GetItemType()))
								{
									this.m_TargetBoxItemType = list6[num5].GetItemType();
									list7.Add(list6[num5].GetItemType());
									flag3 = true;
								}
								else if (list.Count > 0 && this.m_IsFillShelfWithoutLabel && (list6[num5].GetItemType() == EItemType.None || list6[num5].GetItemCount() == 0))
								{
									list7.Add(list[Random.Range(0, list.Count)]);
									flag3 = true;
								}
							}
						}
					}
				}
			}
			if (list7.Count > 0)
			{
				this.m_TargetBoxItemType = list7[Random.Range(0, list7.Count)];
			}
			if (itemPackagingBoxListWithItem.Count <= 0)
			{
				this.GoRestPoint();
				if (!flag)
				{
					this.m_CanFindStoredItem = true;
					return;
				}
				this.m_HaveValidItemToRestock = false;
				return;
			}
			else
			{
				if (flag3)
				{
					this.m_TargetBoxSize = 0;
					this.AttemptFindBoxForRestock();
					this.m_HaveValidItemToRestock = true;
					return;
				}
				List<WarehouseShelf> list9 = new List<WarehouseShelf>();
				List<WarehouseShelf> list10 = new List<WarehouseShelf>();
				List<WarehouseShelf> list11 = new List<WarehouseShelf>();
				flag2 = false;
				for (int num7 = 0; num7 < list2.Count; num7++)
				{
					list11 = ShelfManager.GetWarehouseShelfListToStoreItem(list2[num7], false, true);
					for (int num8 = 0; num8 < list11.Count; num8++)
					{
						list9.Add(list11[num8]);
						flag2 = true;
					}
				}
				for (int num9 = 0; num9 < list3.Count; num9++)
				{
					list11 = ShelfManager.GetWarehouseShelfListToStoreItem(list3[num9], true, true);
					for (int num10 = 0; num10 < list11.Count; num10++)
					{
						if (!list10.Contains(list11[num10]))
						{
							list10.Add(list11[num10]);
							flag2 = true;
						}
					}
				}
				if (this.m_IsFillShelfWithoutLabel && !flag2)
				{
					for (int num11 = 0; num11 < list2.Count; num11++)
					{
						if (list.Contains(list2[num11]))
						{
							list11 = ShelfManager.GetWarehouseShelfListToStoreItem(list2[num11], false, false);
							for (int num12 = 0; num12 < list11.Count; num12++)
							{
								if (!list9.Contains(list11[num12]))
								{
									list9.Add(list11[num12]);
								}
							}
						}
					}
					for (int num13 = 0; num13 < list3.Count; num13++)
					{
						if (list.Contains(list3[num13]))
						{
							list11 = ShelfManager.GetWarehouseShelfListToStoreItem(list3[num13], true, false);
							for (int num14 = 0; num14 < list11.Count; num14++)
							{
								if (!list10.Contains(list11[num14]))
								{
									list10.Add(list11[num14]);
								}
							}
						}
					}
				}
				bool flag5 = false;
				List<ShelfCompartment> list12 = new List<ShelfCompartment>();
				for (int num15 = 0; num15 < list9.Count; num15++)
				{
					List<ShelfCompartment> list13 = new List<ShelfCompartment>();
					for (int num16 = 0; num16 < list2.Count; num16++)
					{
						if (list.Contains(list2[num16]))
						{
							list13 = list9[num15].GetNonFullItemCompartmentList(list2[num16], false, flag2);
							for (int num17 = 0; num17 < list13.Count; num17++)
							{
								if (!list12.Contains(list13[num17]))
								{
									list12.Add(list13[num17]);
								}
							}
						}
					}
					for (int num18 = 0; num18 < list12.Count; num18++)
					{
						if ((list12[num18].GetItemCount() < list12[num18].GetMaxItemCount() || (!flag2 && list12[num18].GetItemType() == EItemType.None) || list12[num18].GetItemCount() == 0) && !list12[num18].CheckBoxType(false))
						{
							if (WorkerManager.GetActiveWorkerCount() == 1)
							{
								this.m_TargetBoxItemType = list12[num18].GetItemType();
								if (!list2.Contains(this.m_TargetBoxItemType))
								{
									this.m_TargetBoxItemType = list2[Random.Range(0, list2.Count)];
								}
								this.m_TargetBoxSize = 1;
								flag5 = true;
								break;
							}
							if (!false)
							{
								this.m_TargetBoxItemType = list12[num18].GetItemType();
								if (!list2.Contains(this.m_TargetBoxItemType))
								{
									this.m_TargetBoxItemType = list2[Random.Range(0, list2.Count)];
								}
								this.m_TargetBoxSize = 1;
								flag5 = true;
							}
						}
						if (flag5)
						{
							break;
						}
					}
					if (flag5)
					{
						break;
					}
				}
				if (flag5)
				{
					this.AttemptFindBoxToStore();
					this.m_HaveValidItemToRestock = true;
					return;
				}
				for (int num19 = 0; num19 < list10.Count; num19++)
				{
					List<ShelfCompartment> list14 = new List<ShelfCompartment>();
					for (int num20 = 0; num20 < list3.Count; num20++)
					{
						if (list.Contains(list3[num20]))
						{
							list14 = list10[num19].GetNonFullItemCompartmentList(list3[num20], true, flag2);
							for (int num21 = 0; num21 < list14.Count; num21++)
							{
								if (!list12.Contains(list14[num21]))
								{
									list12.Add(list14[num21]);
								}
							}
						}
					}
					for (int num22 = 0; num22 < list12.Count; num22++)
					{
						if ((list12[num22].GetItemCount() < list12[num22].GetMaxItemCount() || (!flag2 && (list12[num22].GetItemType() == EItemType.None || list12[num22].GetItemCount() == 0))) && list12[num22].CheckBoxType(true))
						{
							if (WorkerManager.GetActiveWorkerCount() == 1)
							{
								this.m_TargetBoxItemType = list12[num22].GetItemType();
								if (!list3.Contains(this.m_TargetBoxItemType))
								{
									this.m_TargetBoxItemType = list3[Random.Range(0, list3.Count)];
								}
								this.m_TargetBoxSize = 2;
								flag5 = true;
								break;
							}
							if (!false)
							{
								this.m_TargetBoxItemType = list12[num22].GetItemType();
								if (!list3.Contains(this.m_TargetBoxItemType))
								{
									this.m_TargetBoxItemType = list3[Random.Range(0, list3.Count)];
								}
								this.m_TargetBoxSize = 2;
								flag5 = true;
							}
						}
						if (flag5)
						{
							break;
						}
					}
					if (flag5)
					{
						break;
					}
				}
				if (flag5)
				{
					this.AttemptFindBoxToStore();
					this.m_HaveValidItemToRestock = true;
					return;
				}
				this.GoRestPoint();
				if (!flag)
				{
					this.m_CanFindStoredItem = true;
					return;
				}
				this.m_HaveValidItemToRestock = false;
				return;
			}
		}
		else
		{
			if (this.m_WorkerTask == EWorkerTask.Fired || this.m_WorkerTask == EWorkerTask.GoBackHome)
			{
				this.ExitShop();
				return;
			}
			if (LightManager.GetHasDayEnded())
			{
				this.ExitShop();
				return;
			}
			this.GoRestPoint();
			this.m_CanFindStoredItem = false;
			return;
		}
	}

	// Token: 0x060005B1 RID: 1457 RVA: 0x0002FC6C File Offset: 0x0002DE6C
	private void OnReachedPathEnd()
	{
		if (this.m_IsPausingAction)
		{
			return;
		}
		if (this.m_TargetTransform && this.m_CurrentState != EWorkerState.SearchingForBox && this.m_CurrentState != EWorkerState.SearchingForBoxToStore)
		{
			this.m_TargetLerpRotation = this.m_TargetTransform.rotation;
		}
		if (this.m_CurrentState == EWorkerState.WalkingToCounter)
		{
			if (!this.m_CurrentCashierCounter)
			{
				this.m_CurrentCashierCounter.SetCurrentWorker(null);
				this.AttemptFindCashierCounter();
				this.m_FailFindShelfAttemptCount++;
				return;
			}
			if (this.m_CurrentCashierCounter.IsValidObject())
			{
				this.m_CurrentCashierCounter.NPCStartManCounter(this);
				this.SetState(EWorkerState.ManningCounter);
				return;
			}
			this.DetermineShopAction();
			return;
		}
		else if (this.m_CurrentState == EWorkerState.SearchingForBox || this.m_CurrentState == EWorkerState.SearchingForBoxToStore)
		{
			float num = 0f;
			if (this.m_TargetTransform)
			{
				num = (this.m_TargetTransform.position - base.transform.position).magnitude;
			}
			if (!this.m_CurrentItemBox || num > 3.5f)
			{
				this.DetermineShopAction();
				this.m_FailFindShelfAttemptCount++;
				return;
			}
			bool flag = false;
			if (!this.m_CurrentItemBox.IsValidObject() || !this.m_CurrentItemBox.CanWorkerTakeBox() || this.m_CurrentItemBox.m_ItemCompartment.GetItemCount() <= 0)
			{
				this.m_CurrentItemBox = null;
				this.DetermineShopAction();
				return;
			}
			if (this.m_CurrentItemBox.m_IsStored)
			{
				if (this.m_CurrentItemBox.GetBoxStoredCompartment().GetInteractablePackagingBoxList().Count <= 0)
				{
					this.m_CurrentItemBox = null;
					this.DetermineShopAction();
					return;
				}
				InteractablePackagingBox_Item lastInteractablePackagingBox = this.m_CurrentItemBox.GetBoxStoredCompartment().GetLastInteractablePackagingBox();
				if (!lastInteractablePackagingBox.CanPickup() || !lastInteractablePackagingBox.IsValidObject() || !lastInteractablePackagingBox.CanWorkerTakeBox())
				{
					this.m_CurrentItemBox = null;
					this.DetermineShopAction();
					return;
				}
				flag = true;
				this.m_CurrentItemBox = lastInteractablePackagingBox;
				this.m_CurrentItemBox.StartHoldBox(false, this.m_HoldBoxLoc);
				this.m_CurrentItemBox.GetBoxStoredCompartment().RemoveBox(lastInteractablePackagingBox);
			}
			else
			{
				this.m_CurrentItemBox.StartHoldBox(false, this.m_HoldBoxLoc);
			}
			this.m_CurrentHoldItemBox = this.m_CurrentItemBox;
			this.m_CurrentItemBox = null;
			this.m_Anim.SetBool("IsHoldingBox", true);
			if (this.m_CurrentState == EWorkerState.SearchingForBox || flag)
			{
				this.AttemptFindShelf();
				return;
			}
			this.AttemptFindWarehouseShelf();
			return;
		}
		else if (this.m_CurrentState == EWorkerState.WalkToShelf)
		{
			float num2 = 0f;
			if (this.m_TargetTransform)
			{
				num2 = (this.m_TargetTransform.position - base.transform.position).magnitude;
			}
			if (!this.m_CurrentShelf || num2 > 1.25f)
			{
				this.DetermineShopAction();
				this.m_FailFindShelfAttemptCount++;
				return;
			}
			if (this.m_CurrentShelf.IsValidObject())
			{
				this.SetState(EWorkerState.RestockingShelf);
				return;
			}
			this.m_CurrentShelf = null;
			this.DetermineShopAction();
			return;
		}
		else if (this.m_CurrentState == EWorkerState.WalkToWarehouseShelf)
		{
			float num3 = 0f;
			if (this.m_TargetTransform)
			{
				num3 = (this.m_TargetTransform.position - base.transform.position).magnitude;
			}
			if (!this.m_CurrentWarehouseShelf || num3 > 3f)
			{
				this.DetermineShopAction();
				this.m_FailFindShelfAttemptCount++;
				return;
			}
			if (this.m_CurrentWarehouseShelf.IsValidObject())
			{
				this.SetState(EWorkerState.StoreBoxOnWarehouseShelf);
				return;
			}
			this.m_CurrentWarehouseShelf = null;
			this.DetermineShopAction();
			return;
		}
		else
		{
			if (this.m_CurrentState == EWorkerState.TrashingBox)
			{
				Vector3 forward = CSingleton<WorkerManager>.Instance.m_TrashBin.transform.position - base.transform.position;
				forward.y = 0f;
				this.m_TargetLerpRotation = Quaternion.LookRotation(forward, Vector3.up);
				this.SetState(EWorkerState.ReadyToTrashBox);
				return;
			}
			if (this.m_CurrentState == EWorkerState.WalkingToRestOutside)
			{
				this.SetState(EWorkerState.Idle);
				if (!this.m_FirstTimeReachRestPosition && this.m_WorkerTask == EWorkerTask.Rest)
				{
					this.m_FirstTimeReachRestPosition = true;
					this.m_ExclaimationMesh.SetActive(true);
					return;
				}
			}
			else
			{
				if (this.m_CurrentState == EWorkerState.ExitingShop)
				{
					this.DeactivateWorker();
					return;
				}
				if (this.m_CurrentState == EWorkerState.Idle && !this.m_FirstTimeReachRestPosition && this.m_WorkerTask == EWorkerTask.Rest)
				{
					this.m_FirstTimeReachRestPosition = true;
					this.m_ExclaimationMesh.SetActive(true);
				}
			}
			return;
		}
	}

	// Token: 0x060005B2 RID: 1458 RVA: 0x000300AC File Offset: 0x0002E2AC
	private bool StateUpdate()
	{
		if (this.m_IsPausingAction)
		{
			return true;
		}
		if (this.m_CurrentState == EWorkerState.Idle)
		{
			this.m_Timer += Time.deltaTime;
			if (this.m_Timer > 2f)
			{
				this.m_Timer = 0f;
				this.DetermineShopAction();
			}
			return true;
		}
		if (this.m_CurrentState == EWorkerState.WalkingToRestOutside && this.m_HaveValidItemToRestock)
		{
			this.m_Timer += Time.deltaTime;
			if (this.m_Timer > 1f)
			{
				this.m_Timer = 0f;
				this.DetermineShopAction();
			}
		}
		else if (this.m_CurrentState == EWorkerState.SearchingForBox || this.m_CurrentState == EWorkerState.SearchingForBoxToStore)
		{
			this.m_Timer += Time.deltaTime;
			if (this.m_Timer > this.m_RestockTime)
			{
				this.m_Timer = 0f;
				if (!this.m_CurrentItemBox)
				{
					this.DetermineShopAction();
				}
				else if (!this.m_CurrentItemBox.IsValidObject() || !this.m_CurrentItemBox.CanWorkerTakeBox())
				{
					this.m_CurrentItemBox = null;
					this.DetermineShopAction();
				}
			}
		}
		else if (this.m_CurrentState == EWorkerState.RestockingShelf)
		{
			this.m_Timer += Time.deltaTime;
			if (this.m_Timer > this.m_RestockTime)
			{
				this.m_Timer = 0f;
				if (this.m_CurrentItemCompartment && this.m_CurrentHoldItemBox && this.m_CurrentShelf && this.m_CurrentShelf.IsValidObject())
				{
					if (this.m_CurrentHoldItemBox.IsBoxOpened())
					{
						this.m_CurrentHoldItemBox.DispenseItem(false, this.m_CurrentItemCompartment);
						if (!this.m_CurrentItemCompartment.HasEnoughSlot() || this.m_CurrentHoldItemBox.m_ItemCompartment.GetItemType() != this.m_CurrentItemCompartment.GetItemType())
						{
							if (this.m_CurrentHoldItemBox.m_ItemCompartment.GetItemCount() > 0)
							{
								this.AttemptFindShelf();
							}
							else
							{
								this.AttemptFindTrashBin();
							}
						}
						else if (this.m_CurrentHoldItemBox.m_ItemCompartment.GetItemCount() == 0)
						{
							this.AttemptFindTrashBin();
						}
					}
					else
					{
						this.m_CurrentHoldItemBox.SetOpenCloseBox(true, false);
					}
				}
				else
				{
					this.DetermineShopAction();
				}
			}
		}
		else if (this.m_CurrentState == EWorkerState.StoreBoxOnWarehouseShelf)
		{
			this.m_Timer += Time.deltaTime;
			if (this.m_Timer > this.m_RestockTime)
			{
				this.m_Timer = 0f;
				if (this.m_CurrentItemCompartment && this.m_CurrentHoldItemBox && this.m_CurrentWarehouseShelf && this.m_CurrentWarehouseShelf.IsValidObject())
				{
					this.m_CurrentHoldItemBox.DispenseItem(false, this.m_CurrentItemCompartment);
					if (this.m_CurrentHoldItemBox.m_IsStored)
					{
						this.m_CurrentHoldItemBox = null;
						this.DropBoxOnHand();
						if (LightManager.GetHasDayEnded())
						{
							this.SetTask(EWorkerTask.GoBackHome);
						}
						this.DetermineShopAction();
					}
					else if (!this.m_CurrentItemCompartment.HasEnoughSlot() || this.m_CurrentHoldItemBox.m_ItemCompartment.GetItemType() != this.m_CurrentItemCompartment.GetItemType())
					{
						if (this.m_CurrentHoldItemBox.m_ItemCompartment.GetItemCount() > 0)
						{
							this.AttemptFindWarehouseShelf();
						}
						else if (this.m_CurrentHoldItemBox.m_ItemCompartment.GetItemCount() == 0)
						{
							this.AttemptFindTrashBin();
						}
					}
				}
				else
				{
					this.DetermineShopAction();
				}
			}
		}
		else
		{
			if (this.m_CurrentState == EWorkerState.ReadyToTrashBox)
			{
				this.m_Timer += Time.deltaTime;
				if (this.m_Timer > Mathf.Clamp(this.m_RestockTime, 0.5f, 2f))
				{
					this.m_Timer = 0f;
					if (this.m_CurrentHoldItemBox)
					{
						CSingleton<WorkerManager>.Instance.m_TrashBin.DiscardBox(this.m_CurrentHoldItemBox, false);
						this.m_CurrentHoldItemBox = null;
						this.DropBoxOnHand();
					}
					if (LightManager.GetHasDayEnded())
					{
						this.SetTask(EWorkerTask.GoBackHome);
					}
					this.DetermineShopAction();
				}
				return true;
			}
			if (this.m_CurrentState == EWorkerState.ManningCounter && LightManager.GetHasDayEnded())
			{
				this.m_Timer += Time.deltaTime;
				if (this.m_Timer > 10f)
				{
					this.m_Timer = 0f;
					if (!CSingleton<CustomerManager>.Instance.HasCustomerInShop())
					{
						this.SetTask(EWorkerTask.GoBackHome);
						this.DetermineShopAction();
					}
				}
			}
		}
		return false;
	}

	// Token: 0x060005B3 RID: 1459 RVA: 0x00030514 File Offset: 0x0002E714
	private void AttemptFindBoxForRestock()
	{
		this.m_ReachedEndOfPath = false;
		this.m_CurrentItemBox = null;
		List<InteractablePackagingBox_Item> itemPackagingBoxListWithItem = RestockManager.GetItemPackagingBoxListWithItem(false);
		List<InteractablePackagingBox_Item> list = new List<InteractablePackagingBox_Item>();
		if (itemPackagingBoxListWithItem.Count == 0 || this.m_CanFindStoredItem)
		{
			itemPackagingBoxListWithItem = RestockManager.GetItemPackagingBoxListWithItem(true);
			this.m_CanFindStoredItem = false;
		}
		for (int i = itemPackagingBoxListWithItem.Count - 1; i >= 0; i--)
		{
			if (!itemPackagingBoxListWithItem[i].IsValidObject() || !itemPackagingBoxListWithItem[i].CanWorkerTakeBox() || (!itemPackagingBoxListWithItem[i].m_IsStored && itemPackagingBoxListWithItem[i].transform.position.y > 2f))
			{
				itemPackagingBoxListWithItem.RemoveAt(i);
			}
		}
		for (int j = 0; j < itemPackagingBoxListWithItem.Count; j++)
		{
			if ((this.m_TargetBoxItemType == EItemType.None || this.m_TargetBoxItemType == itemPackagingBoxListWithItem[j].m_ItemCompartment.GetItemType()) && (this.m_TargetBoxSize != 1 || !itemPackagingBoxListWithItem[j].m_IsBigBox) && (this.m_TargetBoxSize != 2 || itemPackagingBoxListWithItem[j].m_IsBigBox))
			{
				if (WorkerManager.GetActiveWorkerCount() == 1)
				{
					list.Add(itemPackagingBoxListWithItem[j]);
				}
				else
				{
					for (int k = 0; k < WorkerManager.GetWorkerList().Count; k++)
					{
						if (WorkerManager.GetWorkerList()[k] != this && WorkerManager.GetWorkerList()[k].IsActive() && WorkerManager.GetWorkerList()[k].GetCurrentItemBox() != itemPackagingBoxListWithItem[j] && this.m_LastStoredItemBox != itemPackagingBoxListWithItem[j])
						{
							list.Add(itemPackagingBoxListWithItem[j]);
						}
					}
				}
			}
		}
		if (list.Count > 0)
		{
			this.m_CurrentItemBox = list[Random.Range(0, list.Count)];
		}
		if (this.m_CurrentItemBox)
		{
			this.m_TargetTransform = this.m_CurrentItemBox.transform;
			this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
			this.m_IsWaitingForPathCallback = true;
			this.m_UnableToFindQueue = false;
			this.SetState(EWorkerState.SearchingForBox);
			return;
		}
		this.m_TargetTransform = null;
		this.GoRestPoint();
		this.m_CanFindStoredItem = true;
	}

	// Token: 0x060005B4 RID: 1460 RVA: 0x0003075C File Offset: 0x0002E95C
	private void AttemptFindBoxToStore()
	{
		this.m_ReachedEndOfPath = false;
		this.m_CurrentItemBox = null;
		List<InteractablePackagingBox_Item> itemPackagingBoxListWithItem = RestockManager.GetItemPackagingBoxListWithItem(false);
		List<InteractablePackagingBox_Item> list = new List<InteractablePackagingBox_Item>();
		for (int i = itemPackagingBoxListWithItem.Count - 1; i >= 0; i--)
		{
			if (!itemPackagingBoxListWithItem[i].IsValidObject() || !itemPackagingBoxListWithItem[i].CanWorkerTakeBox() || (!itemPackagingBoxListWithItem[i].m_IsStored && itemPackagingBoxListWithItem[i].transform.position.y > 2f))
			{
				itemPackagingBoxListWithItem.RemoveAt(i);
			}
		}
		for (int j = 0; j < itemPackagingBoxListWithItem.Count; j++)
		{
			if ((this.m_TargetBoxItemType == EItemType.None || this.m_TargetBoxItemType == itemPackagingBoxListWithItem[j].m_ItemCompartment.GetItemType()) && (this.m_TargetBoxSize != 1 || !itemPackagingBoxListWithItem[j].m_IsBigBox) && (this.m_TargetBoxSize != 2 || itemPackagingBoxListWithItem[j].m_IsBigBox))
			{
				if (WorkerManager.GetActiveWorkerCount() == 1)
				{
					list.Add(itemPackagingBoxListWithItem[j]);
				}
				else
				{
					for (int k = 0; k < WorkerManager.GetWorkerList().Count; k++)
					{
						if (WorkerManager.GetWorkerList()[k] != this && WorkerManager.GetWorkerList()[k].IsActive() && WorkerManager.GetWorkerList()[k].GetCurrentItemBox() != itemPackagingBoxListWithItem[j] && this.m_LastStoredItemBox != itemPackagingBoxListWithItem[j])
						{
							list.Add(itemPackagingBoxListWithItem[j]);
						}
					}
				}
			}
		}
		if (list.Count > 0)
		{
			this.m_CurrentItemBox = list[Random.Range(0, list.Count)];
		}
		if (this.m_CurrentItemBox)
		{
			this.m_TargetTransform = this.m_CurrentItemBox.transform;
			this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
			this.m_IsWaitingForPathCallback = true;
			this.m_UnableToFindQueue = false;
			this.SetState(EWorkerState.SearchingForBoxToStore);
			return;
		}
		this.m_TargetTransform = null;
		if (list.Count == 0)
		{
			if (this.m_HaveValidItemToRestock)
			{
				this.m_CanFindStoredItem = false;
				this.m_HaveValidItemToRestock = false;
			}
		}
		else
		{
			this.m_CanFindStoredItem = true;
		}
		this.GoRestPoint();
	}

	// Token: 0x060005B5 RID: 1461 RVA: 0x000309A8 File Offset: 0x0002EBA8
	private void AttemptFindCashierCounter()
	{
		this.m_ReachedEndOfPath = false;
		this.m_CurrentCashierCounter = ShelfManager.GetUnmannedCashierCounter();
		if (this.m_CurrentCashierCounter)
		{
			this.m_TargetTransform = this.m_CurrentCashierCounter.m_LockPlayerPos;
			this.m_CurrentCashierCounter.SetCurrentWorker(this);
			this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
			this.m_IsWaitingForPathCallback = true;
			this.m_UnableToFindQueue = false;
			this.SetState(EWorkerState.WalkingToCounter);
			return;
		}
		this.m_TargetTransform = null;
		this.GoRestPoint();
		this.m_CanFindStoredItem = false;
	}

	// Token: 0x060005B6 RID: 1462 RVA: 0x00030A4C File Offset: 0x0002EC4C
	private void AttemptFindTrashBin()
	{
		this.m_Path = null;
		this.SetState(EWorkerState.TrashingBox);
		this.m_ReachedEndOfPath = false;
		this.m_TargetTransform = CSingleton<WorkerManager>.Instance.m_TrashBin.transform;
		this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
		this.m_IsWaitingForPathCallback = true;
		this.m_UnableToFindQueue = false;
	}

	// Token: 0x060005B7 RID: 1463 RVA: 0x00030AC0 File Offset: 0x0002ECC0
	public bool CheckWorkerSameTarget(Transform targetTransform)
	{
		return !(this.m_TargetTransform == null) && !(targetTransform == null) && (this.m_TargetTransform == targetTransform || (this.m_TargetTransform.position - targetTransform.position).magnitude < 0.1f);
	}

	// Token: 0x060005B8 RID: 1464 RVA: 0x00030B1E File Offset: 0x0002ED1E
	private void DropBoxOnHand()
	{
		if (this.m_CurrentHoldItemBox)
		{
			this.m_CurrentHoldItemBox.DropBox(false);
		}
		this.m_CurrentHoldItemBox = null;
		this.m_Anim.SetBool("IsHoldingBox", false);
	}

	// Token: 0x060005B9 RID: 1465 RVA: 0x00030B54 File Offset: 0x0002ED54
	private void AttemptFindShelf()
	{
		this.SetState(EWorkerState.FindingShelfToRestock);
		this.m_ReachedEndOfPath = false;
		this.m_CurrentShelf = null;
		this.m_CurrentItemCompartment = null;
		bool flag = false;
		bool ignoreNoneType = true;
		List<Shelf> shelfListToRestockItem = ShelfManager.GetShelfListToRestockItem(this.m_CurrentHoldItemBox.m_ItemCompartment.GetItemType(), ignoreNoneType);
		for (int i = 0; i < WorkerManager.GetWorkerList().Count; i++)
		{
			if (WorkerManager.GetWorkerList()[i] != this)
			{
				WorkerManager.GetWorkerList()[i].IsActive();
			}
		}
		if (this.m_IsFillShelfWithoutLabel)
		{
			ignoreNoneType = false;
			shelfListToRestockItem = ShelfManager.GetShelfListToRestockItem(this.m_CurrentHoldItemBox.m_ItemCompartment.GetItemType(), ignoreNoneType);
		}
		List<ShelfCompartment> list = new List<ShelfCompartment>();
		List<ShelfCompartment> list2 = new List<ShelfCompartment>();
		for (int j = 0; j < shelfListToRestockItem.Count; j++)
		{
			list = shelfListToRestockItem[j].GetNonFullItemCompartmentList(this.m_CurrentHoldItemBox.m_ItemCompartment.GetItemType(), ignoreNoneType);
			for (int k = 0; k < list.Count; k++)
			{
				if (WorkerManager.GetActiveWorkerCount() == 1)
				{
					flag = true;
					list2.Add(list[k]);
				}
				else
				{
					bool flag2 = false;
					for (int l = 0; l < WorkerManager.GetWorkerList().Count; l++)
					{
						if (WorkerManager.GetWorkerList()[l] != this && WorkerManager.GetWorkerList()[l].IsActive() && WorkerManager.GetWorkerList()[l].CheckWorkerSameTarget(list[k].m_CustomerStandLoc))
						{
							flag2 = true;
							break;
						}
					}
					if (!flag2)
					{
						list2.Add(list[k]);
					}
				}
				if (flag)
				{
					break;
				}
			}
			if (flag)
			{
				break;
			}
		}
		if (list2.Count > 0)
		{
			this.m_CurrentItemCompartment = list2[Random.Range(0, list2.Count)];
			this.m_CurrentShelf = this.m_CurrentItemCompartment.GetShelf();
		}
		if (this.m_CurrentShelf && this.m_CurrentItemCompartment)
		{
			this.m_TargetTransform = this.m_CurrentItemCompartment.m_CustomerStandLoc;
			this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
			this.m_IsWaitingForPathCallback = true;
			this.m_UnableToFindQueue = false;
			this.m_ReachedEndOfPath = false;
			this.SetState(EWorkerState.WalkToShelf);
			return;
		}
		if (this.m_CurrentHoldItemBox)
		{
			this.AttemptFindWarehouseShelf();
			return;
		}
		this.m_UnableToFindQueue = true;
		this.GoRestPoint();
		this.m_CanFindStoredItem = false;
	}

	// Token: 0x060005BA RID: 1466 RVA: 0x00030DCC File Offset: 0x0002EFCC
	private void AttemptFindWarehouseShelf()
	{
		this.SetState(EWorkerState.FindingWarehouseShelf);
		this.m_ReachedEndOfPath = false;
		this.m_CurrentWarehouseShelf = null;
		this.m_CurrentItemCompartment = null;
		bool flag = false;
		bool ignoreNoneType = true;
		List<WarehouseShelf> warehouseShelfListToStoreItem = ShelfManager.GetWarehouseShelfListToStoreItem(this.m_CurrentHoldItemBox.m_ItemCompartment.GetItemType(), this.m_CurrentHoldItemBox.m_IsBigBox, ignoreNoneType);
		if (this.m_IsFillShelfWithoutLabel)
		{
			ignoreNoneType = false;
			warehouseShelfListToStoreItem = ShelfManager.GetWarehouseShelfListToStoreItem(this.m_CurrentHoldItemBox.m_ItemCompartment.GetItemType(), this.m_CurrentHoldItemBox.m_IsBigBox, ignoreNoneType);
		}
		List<ShelfCompartment> list = new List<ShelfCompartment>();
		List<int> list2 = new List<int>();
		List<ShelfCompartment> list3 = new List<ShelfCompartment>();
		for (int i = 0; i < warehouseShelfListToStoreItem.Count; i++)
		{
			list = warehouseShelfListToStoreItem[i].GetNonFullItemCompartmentList(this.m_CurrentHoldItemBox.m_ItemCompartment.GetItemType(), this.m_CurrentHoldItemBox.m_IsBigBox, ignoreNoneType);
			for (int j = 0; j < list.Count; j++)
			{
				if (WorkerManager.GetActiveWorkerCount() == 1)
				{
					flag = true;
					list2.Add(i);
					list3.Add(list[j]);
				}
				else if (!false)
				{
					list2.Add(i);
					list3.Add(list[j]);
				}
				if (flag)
				{
					break;
				}
			}
			if (flag)
			{
				break;
			}
		}
		if (list3.Count > 0)
		{
			int index = Random.Range(0, list3.Count);
			this.m_CurrentWarehouseShelf = warehouseShelfListToStoreItem[list2[index]];
			this.m_CurrentItemCompartment = list3[index];
		}
		if (this.m_CurrentWarehouseShelf && this.m_CurrentItemCompartment)
		{
			this.m_TargetTransform = this.m_CurrentItemCompartment.m_CustomerStandLoc;
			this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
			this.m_IsWaitingForPathCallback = true;
			this.m_UnableToFindQueue = false;
			this.m_ReachedEndOfPath = false;
			this.SetState(EWorkerState.WalkToWarehouseShelf);
			return;
		}
		this.m_UnableToFindQueue = true;
		this.DropBoxOnHand();
		this.GoRestPoint();
		this.m_CanFindStoredItem = false;
	}

	// Token: 0x060005BB RID: 1467 RVA: 0x00030FC9 File Offset: 0x0002F1C9
	public void PlayWorkerActionAnim()
	{
		this.m_Anim.SetTrigger("ScanItem");
	}

	// Token: 0x060005BC RID: 1468 RVA: 0x00030FDB File Offset: 0x0002F1DB
	public void StopManningCounter()
	{
		this.m_CurrentCashierCounter = null;
		this.DetermineShopAction();
	}

	// Token: 0x060005BD RID: 1469 RVA: 0x00030FEC File Offset: 0x0002F1EC
	public void GoRestPoint()
	{
		if (this.m_CurrentState == EWorkerState.WalkingToRestOutside)
		{
			return;
		}
		this.m_Path = null;
		this.m_ReachedEndOfPath = false;
		if (LightManager.GetHasDayEnded())
		{
			this.SetTask(EWorkerTask.GoBackHome);
			this.ExitShop();
			return;
		}
		this.SetState(EWorkerState.WalkingToRestOutside);
		this.m_TargetTransform = WorkerManager.GetWorkerRestPoint(this.m_WorkerIndex);
		this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
		this.m_IsWaitingForPathCallback = true;
		this.m_UnableToFindQueue = false;
	}

	// Token: 0x060005BE RID: 1470 RVA: 0x0003107B File Offset: 0x0002F27B
	public void SetOutOfScreen()
	{
		base.transform.position = Vector3.one * 10000f;
	}

	// Token: 0x060005BF RID: 1471 RVA: 0x00031097 File Offset: 0x0002F297
	private void WaypointEndUpdate()
	{
	}

	// Token: 0x060005C0 RID: 1472 RVA: 0x0003109C File Offset: 0x0002F29C
	private void ExitShop()
	{
		this.m_TargetTransform = CustomerManager.GetRandomExitPoint();
		this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
		this.m_IsWaitingForPathCallback = true;
		this.SetState(EWorkerState.ExitingShop);
		this.m_WorkerCollider.gameObject.SetActive(false);
		if (!this.m_HasUpdatedCustomerCount)
		{
			this.m_HasUpdatedCustomerCount = true;
			CSingleton<WorkerManager>.Instance.UpdateWorkerCount(-1);
		}
	}

	// Token: 0x060005C1 RID: 1473 RVA: 0x0003111C File Offset: 0x0002F31C
	private IEnumerator DelayExitShop(float delayTime)
	{
		yield return new WaitForSeconds(delayTime);
		this.ExitShop();
		yield break;
	}

	// Token: 0x060005C2 RID: 1474 RVA: 0x00031132 File Offset: 0x0002F332
	private void SetState(EWorkerState state)
	{
		this.m_CurrentState = state;
	}

	// Token: 0x060005C3 RID: 1475 RVA: 0x0003113C File Offset: 0x0002F33C
	public void OnPathComplete(Path p)
	{
		p.Claim(this);
		if (!p.error)
		{
			if (this.m_Path != null)
			{
				this.m_Path.Release(this, false);
			}
			this.m_Path = p;
			this.m_CurrentWaypoint = 0;
		}
		else
		{
			p.Release(this, false);
		}
		this.m_IsWaitingForPathCallback = false;
		this.m_ReachedEndOfPath = false;
	}

	// Token: 0x060005C4 RID: 1476 RVA: 0x00031194 File Offset: 0x0002F394
	public void Update()
	{
		if (!this.m_IsActive)
		{
			return;
		}
		base.transform.rotation = Quaternion.Lerp(base.transform.rotation, this.m_TargetLerpRotation, Time.fixedDeltaTime * this.m_RotationLerpSpeed);
		this.m_CurrentMoveSpeed = (this.m_LastFramePos - base.transform.position).magnitude * 50f;
		this.m_LastFramePos = base.transform.position;
		this.m_Anim.SetFloat("MoveSpeed", this.m_CurrentMoveSpeed);
		this.m_HoldBoxLoc.position = Vector3.Lerp(this.m_WristBoneL.position, this.m_WristBoneR.position, 0.5f);
		this.m_HoldBoxLoc.position = this.m_HoldBoxLoc.position + this.m_HoldBoxLoc.up * 0.04f;
		if (this.StateUpdate())
		{
			return;
		}
		if (!this.m_ReachedEndOfPath && Time.time > this.m_LastRepath + this.m_RepathRate && this.m_Seeker.IsDone() && this.m_TargetTransform)
		{
			this.m_LastRepath = Time.time;
			this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
			this.m_IsWaitingForPathCallback = true;
		}
		if (this.m_Path == null)
		{
			return;
		}
		while (Vector3.Distance(base.transform.position, this.m_Path.vectorPath[this.m_CurrentWaypoint]) < this.m_NextWaypointDistance)
		{
			if (!this.m_IsInsideShop && this.m_CurrentState != EWorkerState.ExitingShop)
			{
				this.m_IsInsideShop = CustomerManager.CheckIsInsideShop(base.transform.position);
				if (this.m_IsInsideShop)
				{
				}
			}
			else if (this.m_IsInsideShop && this.m_CurrentState == EWorkerState.ExitingShop && CustomerManager.CheckIsInsideShop(base.transform.position))
			{
				this.m_IsInsideShop = false;
			}
			if (this.m_CurrentWaypoint + 1 >= this.m_Path.vectorPath.Count)
			{
				if (!this.m_ReachedEndOfPath)
				{
					this.m_ReachedEndOfPath = true;
					this.OnReachedPathEnd();
				}
				this.WaypointEndUpdate();
				break;
			}
			this.m_CurrentWaypoint++;
		}
		if (this.m_Path != null)
		{
			base.transform.position = Vector3.MoveTowards(base.transform.position, this.m_Path.vectorPath[this.m_CurrentWaypoint], this.m_Speed * this.m_ExtraSpeedMultiplier * Time.deltaTime);
			if (!this.m_ReachedEndOfPath)
			{
				Vector3 vector = this.m_Path.vectorPath[this.m_CurrentWaypoint] - base.transform.position;
				vector.y = 0f;
				if (vector != Vector3.zero)
				{
					this.m_TargetLerpRotation = Quaternion.LookRotation(vector, Vector3.up);
				}
			}
		}
	}

	// Token: 0x060005C5 RID: 1477 RVA: 0x00031489 File Offset: 0x0002F689
	public void ForceGoHome()
	{
		this.SetTask(EWorkerTask.GoBackHome);
		this.DetermineShopAction();
	}

	// Token: 0x060005C6 RID: 1478 RVA: 0x00031499 File Offset: 0x0002F699
	public bool IsActive()
	{
		return this.m_IsActive;
	}

	// Token: 0x060005C7 RID: 1479 RVA: 0x000314A1 File Offset: 0x0002F6A1
	public void SetExtraSpeedMultiplier(float extraSpeedMultiplier)
	{
		this.m_OriginalSpeedMultiplier = this.m_ExtraSpeedMultiplier;
		this.m_ExtraSpeedMultiplier = extraSpeedMultiplier;
	}

	// Token: 0x060005C8 RID: 1480 RVA: 0x000314B6 File Offset: 0x0002F6B6
	public void ResetExtraSpeedMultiplier()
	{
		this.m_ExtraSpeedMultiplier = this.m_OriginalSpeedMultiplier;
	}

	// Token: 0x060005C9 RID: 1481 RVA: 0x000314C4 File Offset: 0x0002F6C4
	public WorkerSaveData GetWorkerSaveData()
	{
		WorkerSaveData workerSaveData = new WorkerSaveData();
		if (this.m_CurrentState == EWorkerState.ExitingShop)
		{
			workerSaveData.currentState = this.m_CurrentState;
		}
		else
		{
			workerSaveData.currentState = EWorkerState.Idle;
		}
		workerSaveData.workerTask = this.m_WorkerTask;
		workerSaveData.pos.SetData(base.transform.position);
		workerSaveData.rot.SetData(base.transform.rotation);
		workerSaveData.isFillShelfWithoutLabel = this.m_IsFillShelfWithoutLabel;
		return workerSaveData;
	}

	// Token: 0x060005CA RID: 1482 RVA: 0x0003153C File Offset: 0x0002F73C
	public void LoadWorkerSaveData(WorkerSaveData data)
	{
		this.m_Timer = 0f;
		this.m_IsFillShelfWithoutLabel = data.isFillShelfWithoutLabel;
		this.m_CurrentState = data.currentState;
		this.m_WorkerTask = data.workerTask;
		if (this.m_WorkerTask == EWorkerTask.GoBackHome && !LightManager.GetHasDayEnded())
		{
			this.m_WorkerTask = EWorkerTask.Rest;
		}
		if (this.m_CurrentState == EWorkerState.ExitingShop && !LightManager.GetHasDayEnded())
		{
			this.m_CurrentState = EWorkerState.Idle;
		}
		this.SetLastTask(this.m_WorkerTask);
		base.transform.position = data.pos.Data;
		base.transform.rotation = data.rot.Data;
		if (base.transform.position.x > 5000f || base.transform.position.y > 5000f)
		{
			this.m_TargetTransform = CustomerManager.GetRandomExitPoint();
			base.transform.position = this.m_TargetTransform.position;
			base.transform.rotation = this.m_TargetTransform.rotation;
			this.m_TargetLerpRotation = this.m_TargetTransform.rotation;
		}
	}

	// Token: 0x060005CB RID: 1483 RVA: 0x00031656 File Offset: 0x0002F856
	public InteractablePackagingBox_Item GetCurrentItemBox()
	{
		return this.m_CurrentItemBox;
	}

	// Token: 0x04000754 RID: 1876
	public CharacterCustomization m_CharacterCustom;

	// Token: 0x04000755 RID: 1877
	public Animator m_Anim;

	// Token: 0x04000756 RID: 1878
	public WorkerCollider m_WorkerCollider;

	// Token: 0x04000757 RID: 1879
	public int m_WorkerIndex;

	// Token: 0x04000758 RID: 1880
	public EWorkerTask m_WorkerTask;

	// Token: 0x04000759 RID: 1881
	public EWorkerTask m_LastWorkerTask;

	// Token: 0x0400075A RID: 1882
	public Transform m_PlayerLookAtTarget;

	// Token: 0x0400075B RID: 1883
	public Transform m_HoldBoxLoc;

	// Token: 0x0400075C RID: 1884
	public Transform m_WristBoneL;

	// Token: 0x0400075D RID: 1885
	public Transform m_WristBoneR;

	// Token: 0x0400075E RID: 1886
	public GameObject m_ExclaimationMesh;

	// Token: 0x0400075F RID: 1887
	public float m_RestockTime = 1.5f;

	// Token: 0x04000760 RID: 1888
	public float m_ScanItemTime = 1.5f;

	// Token: 0x04000761 RID: 1889
	public float m_GiveChangeTime = 1.5f;

	// Token: 0x04000762 RID: 1890
	public float m_CurrentMoveSpeed;

	// Token: 0x04000763 RID: 1891
	private Vector3 m_LastFramePos;

	// Token: 0x04000764 RID: 1892
	public bool m_IsFemale;

	// Token: 0x04000765 RID: 1893
	public bool m_IsActive;

	// Token: 0x04000766 RID: 1894
	public bool m_IsPausingAction;

	// Token: 0x04000767 RID: 1895
	public Seeker m_Seeker;

	// Token: 0x04000768 RID: 1896
	public float m_Speed = 1f;

	// Token: 0x04000769 RID: 1897
	public float m_NextWaypointDistance = 0.1f;

	// Token: 0x0400076A RID: 1898
	public float m_RepathRate = 2f;

	// Token: 0x0400076B RID: 1899
	public float m_RotationLerpSpeed = 2f;

	// Token: 0x0400076C RID: 1900
	private Path m_Path;

	// Token: 0x0400076D RID: 1901
	public EWorkerState m_CurrentState;

	// Token: 0x0400076E RID: 1902
	public Shelf m_CurrentShelf;

	// Token: 0x0400076F RID: 1903
	public WarehouseShelf m_CurrentWarehouseShelf;

	// Token: 0x04000770 RID: 1904
	public ShelfCompartment m_CurrentItemCompartment;

	// Token: 0x04000771 RID: 1905
	private InteractableCardCompartment m_CurrentCardCompartment;

	// Token: 0x04000772 RID: 1906
	private InteractableCashierCounter m_CurrentCashierCounter;

	// Token: 0x04000773 RID: 1907
	private InteractablePackagingBox_Item m_CurrentItemBox;

	// Token: 0x04000774 RID: 1908
	private InteractablePackagingBox_Item m_CurrentHoldItemBox;

	// Token: 0x04000775 RID: 1909
	private InteractablePackagingBox_Item m_LastStoredItemBox;

	// Token: 0x04000776 RID: 1910
	public EItemType m_TargetBoxItemType = EItemType.None;

	// Token: 0x04000777 RID: 1911
	public int m_TargetBoxSize;

	// Token: 0x04000778 RID: 1912
	private WorkerData m_WorkerData;

	// Token: 0x04000779 RID: 1913
	private bool m_ReachedEndOfPath;

	// Token: 0x0400077A RID: 1914
	private bool m_InstantStopRestockWhenDayEnd;

	// Token: 0x0400077B RID: 1915
	private bool m_InstantStopCounterWhenDayEnd;

	// Token: 0x0400077C RID: 1916
	private bool m_IsFillShelfWithoutLabel;

	// Token: 0x0400077D RID: 1917
	private int m_CurrentWaypoint;

	// Token: 0x0400077E RID: 1918
	private int m_FailFindShelfAttemptCount;

	// Token: 0x0400077F RID: 1919
	private int m_FailFindItemAttemptCount;

	// Token: 0x04000780 RID: 1920
	private float m_LastRepath = float.NegativeInfinity;

	// Token: 0x04000781 RID: 1921
	private float m_ExtraSpeedMultiplier = 1f;

	// Token: 0x04000782 RID: 1922
	private float m_OriginalSpeedMultiplier = 1f;

	// Token: 0x04000783 RID: 1923
	public Transform m_TargetTransform;

	// Token: 0x04000784 RID: 1924
	private Quaternion m_RotationBeforeInteract;

	// Token: 0x04000785 RID: 1925
	private Quaternion m_TargetLerpRotation;

	// Token: 0x04000786 RID: 1926
	private Vector3 m_LerpStartPos;

	// Token: 0x04000787 RID: 1927
	private Vector3 m_TargetLerpPos;

	// Token: 0x04000788 RID: 1928
	private bool m_IsInsideShop;

	// Token: 0x04000789 RID: 1929
	private bool m_IsWaitingForPathCallback;

	// Token: 0x0400078A RID: 1930
	private bool m_UnableToFindQueue;

	// Token: 0x0400078B RID: 1931
	private bool m_HasUpdatedCustomerCount;

	// Token: 0x0400078C RID: 1932
	private bool m_FirstTimeReachRestPosition;

	// Token: 0x0400078D RID: 1933
	private bool m_IsExclaimationVisibleState;

	// Token: 0x0400078E RID: 1934
	public bool m_CanFindStoredItem;

	// Token: 0x0400078F RID: 1935
	public bool m_HaveValidItemToRestock;

	// Token: 0x04000790 RID: 1936
	private float m_Timer;

	// Token: 0x04000791 RID: 1937
	private float m_TimerMax;

	// Token: 0x04000792 RID: 1938
	private float m_SecondaryTimer;

	// Token: 0x04000793 RID: 1939
	private float m_SecondaryTimerMax;
}
