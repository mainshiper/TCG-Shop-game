﻿using System;

// Token: 0x02000116 RID: 278
public enum EGamepadControlBtn
{
	// Token: 0x04000F80 RID: 3968
	None = -1,
	// Token: 0x04000F81 RID: 3969
	X,
	// Token: 0x04000F82 RID: 3970
	O,
	// Token: 0x04000F83 RID: 3971
	Square,
	// Token: 0x04000F84 RID: 3972
	Triangle,
	// Token: 0x04000F85 RID: 3973
	L1,
	// Token: 0x04000F86 RID: 3974
	R1,
	// Token: 0x04000F87 RID: 3975
	L2,
	// Token: 0x04000F88 RID: 3976
	R2,
	// Token: 0x04000F89 RID: 3977
	L3,
	// Token: 0x04000F8A RID: 3978
	R3,
	// Token: 0x04000F8B RID: 3979
	DpadLeft,
	// Token: 0x04000F8C RID: 3980
	DpadRight,
	// Token: 0x04000F8D RID: 3981
	DpadUp,
	// Token: 0x04000F8E RID: 3982
	DpadDown,
	// Token: 0x04000F8F RID: 3983
	LStickLeft,
	// Token: 0x04000F90 RID: 3984
	LStickRight,
	// Token: 0x04000F91 RID: 3985
	LStickUp,
	// Token: 0x04000F92 RID: 3986
	LStickDown,
	// Token: 0x04000F93 RID: 3987
	RStickLeft,
	// Token: 0x04000F94 RID: 3988
	RStickRight,
	// Token: 0x04000F95 RID: 3989
	RStickUp,
	// Token: 0x04000F96 RID: 3990
	RStickDown,
	// Token: 0x04000F97 RID: 3991
	Start,
	// Token: 0x04000F98 RID: 3992
	Select,
	// Token: 0x04000F99 RID: 3993
	Home
}
