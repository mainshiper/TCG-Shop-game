﻿using System;

// Token: 0x020000EF RID: 239
public enum EStatusEffect
{
	// Token: 0x04000D56 RID: 3414
	None,
	// Token: 0x04000D57 RID: 3415
	Poison,
	// Token: 0x04000D58 RID: 3416
	Blind,
	// Token: 0x04000D59 RID: 3417
	Stun,
	// Token: 0x04000D5A RID: 3418
	Beserk,
	// Token: 0x04000D5B RID: 3419
	Drain,
	// Token: 0x04000D5C RID: 3420
	Wall,
	// Token: 0x04000D5D RID: 3421
	PowerUp,
	// Token: 0x04000D5E RID: 3422
	DefUp,
	// Token: 0x04000D5F RID: 3423
	HPRegen,
	// Token: 0x04000D60 RID: 3424
	Splash,
	// Token: 0x04000D61 RID: 3425
	SPRegen,
	// Token: 0x04000D62 RID: 3426
	Sticky,
	// Token: 0x04000D63 RID: 3427
	Cleanse,
	// Token: 0x04000D64 RID: 3428
	FocusFire,
	// Token: 0x04000D65 RID: 3429
	Sleep,
	// Token: 0x04000D66 RID: 3430
	SpeedUp,
	// Token: 0x04000D67 RID: 3431
	SpeedDown,
	// Token: 0x04000D68 RID: 3432
	Guard,
	// Token: 0x04000D69 RID: 3433
	MAX
}
