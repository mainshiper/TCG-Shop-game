﻿using System;

// Token: 0x020000FD RID: 253
public enum EAnalyticLogSpendingEvent
{
	// Token: 0x04000E73 RID: 3699
	GemABuyUGSuperGiant,
	// Token: 0x04000E74 RID: 3700
	GemABuyUGGiant,
	// Token: 0x04000E75 RID: 3701
	GemABuyGold,
	// Token: 0x04000E76 RID: 3702
	GemABuyBaseSuperGiant,
	// Token: 0x04000E77 RID: 3703
	GemABuyBaseGiant,
	// Token: 0x04000E78 RID: 3704
	GemABuyBaseWeapon,
	// Token: 0x04000E79 RID: 3705
	GemABuyBaseChip,
	// Token: 0x04000E7A RID: 3706
	GemAStartUGQuickFight,
	// Token: 0x04000E7B RID: 3707
	GemASwitchUGOpponent,
	// Token: 0x04000E7C RID: 3708
	GemAFusePart,
	// Token: 0x04000E7D RID: 3709
	GemABuyBaseCrate,
	// Token: 0x04000E7E RID: 3710
	GemABuyUGCrate,
	// Token: 0x04000E7F RID: 3711
	GemAOpenBaseCrate,
	// Token: 0x04000E80 RID: 3712
	GemAOpenUGCrate,
	// Token: 0x04000E81 RID: 3713
	GemARefreshTitleMatch,
	// Token: 0x04000E82 RID: 3714
	GoldAStartUGQuickFight,
	// Token: 0x04000E83 RID: 3715
	GoldASwitchUGOpponent,
	// Token: 0x04000E84 RID: 3716
	GoldAFusePart,
	// Token: 0x04000E85 RID: 3717
	GoldABuySecretPartA,
	// Token: 0x04000E86 RID: 3718
	GoldABuySecretPartB,
	// Token: 0x04000E87 RID: 3719
	GoldSpend20To40K,
	// Token: 0x04000E88 RID: 3720
	GoldSpend40To60K,
	// Token: 0x04000E89 RID: 3721
	GoldSpend60To80K,
	// Token: 0x04000E8A RID: 3722
	GoldSpend80To100K,
	// Token: 0x04000E8B RID: 3723
	GoldSpend100To200K,
	// Token: 0x04000E8C RID: 3724
	GoldSpend200To400K,
	// Token: 0x04000E8D RID: 3725
	GoldSpend400T0600K,
	// Token: 0x04000E8E RID: 3726
	GoldSpend600To1Mil,
	// Token: 0x04000E8F RID: 3727
	GoldSpend1To2Mil,
	// Token: 0x04000E90 RID: 3728
	GoldSpend2To4Mil,
	// Token: 0x04000E91 RID: 3729
	GoldSpend4To6Mil,
	// Token: 0x04000E92 RID: 3730
	GoldSpend6To10Mil,
	// Token: 0x04000E93 RID: 3731
	GoldSpendMore10Mil,
	// Token: 0x04000E94 RID: 3732
	IAPAPressMegabotDetail,
	// Token: 0x04000E95 RID: 3733
	IAPAPressMegabot1Purchase,
	// Token: 0x04000E96 RID: 3734
	IAPAPressMegabot2Purchase,
	// Token: 0x04000E97 RID: 3735
	IAPAPressMegabot3Purchase,
	// Token: 0x04000E98 RID: 3736
	IAPAPressInstantCratePurchase,
	// Token: 0x04000E99 RID: 3737
	IAPAPressGem1Purchase,
	// Token: 0x04000E9A RID: 3738
	IAPAPressGem2Purchase,
	// Token: 0x04000E9B RID: 3739
	IAPAPressGem3Purchase,
	// Token: 0x04000E9C RID: 3740
	IAPAPressGem4Purchase,
	// Token: 0x04000E9D RID: 3741
	IAPAPressGem5Purchase,
	// Token: 0x04000E9E RID: 3742
	IAPAPressGem6Purchase,
	// Token: 0x04000E9F RID: 3743
	IAPAPressMassiveGemDiscountPurchase,
	// Token: 0x04000EA0 RID: 3744
	IAPAPressGemDiscountLegendPurchase,
	// Token: 0x04000EA1 RID: 3745
	IAPAPressInstantCrateLegendPurchase,
	// Token: 0x04000EA2 RID: 3746
	IAPAPressGemDiscountPurchase,
	// Token: 0x04000EA3 RID: 3747
	IAPAPressInstantCrateHalfPurchase,
	// Token: 0x04000EA4 RID: 3748
	StartTitleMatch,
	// Token: 0x04000EA5 RID: 3749
	UnlockUGMode,
	// Token: 0x04000EA6 RID: 3750
	UGModeStartLeagueMatch,
	// Token: 0x04000EA7 RID: 3751
	UGModeStay1d,
	// Token: 0x04000EA8 RID: 3752
	UGModeStay3d,
	// Token: 0x04000EA9 RID: 3753
	UGModeStay7d,
	// Token: 0x04000EAA RID: 3754
	UGModeStay14d,
	// Token: 0x04000EAB RID: 3755
	UGModeStay30d,
	// Token: 0x04000EAC RID: 3756
	UGModeStay60d,
	// Token: 0x04000EAD RID: 3757
	UGModeStay90d,
	// Token: 0x04000EAE RID: 3758
	UGModeStay120d,
	// Token: 0x04000EAF RID: 3759
	UGModeStay150d,
	// Token: 0x04000EB0 RID: 3760
	GoldSpend10To20K
}
