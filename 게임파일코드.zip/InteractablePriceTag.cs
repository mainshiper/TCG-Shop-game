﻿using System;
using UnityEngine;

// Token: 0x02000027 RID: 39
public class InteractablePriceTag : InteractableObject
{
	// Token: 0x06000215 RID: 533 RVA: 0x00015234 File Offset: 0x00013434
	public void Init(ShelfCompartment shelfCompartment)
	{
		this.m_ShelfCompartment = shelfCompartment;
	}

	// Token: 0x06000216 RID: 534 RVA: 0x00015240 File Offset: 0x00013440
	protected override void ShowToolTip()
	{
		if (this.m_IsWarehouseTag)
		{
			InteractionPlayerController.AddToolTip(EGameAction.RemoveLabel, false, false);
			return;
		}
		for (int i = 0; i < this.m_GameActionInputDisplayList.Count; i++)
		{
			if (this.m_GameActionInputDisplayList[i] == EGameAction.RemoveLabel)
			{
				if (this.m_ShelfCompartment.GetItemCount() == 0)
				{
					InteractionPlayerController.AddToolTip(this.m_GameActionInputDisplayList[i], false, false);
				}
			}
			else
			{
				InteractionPlayerController.AddToolTip(this.m_GameActionInputDisplayList[i], false, false);
			}
		}
	}

	// Token: 0x06000217 RID: 535 RVA: 0x000152BA File Offset: 0x000134BA
	public void SetPriceTagUI(UI_PriceTag PriceTagUI)
	{
		this.m_PriceTagUI = PriceTagUI;
	}

	// Token: 0x06000218 RID: 536 RVA: 0x000152C3 File Offset: 0x000134C3
	public UI_PriceTag GetPriceTagUI()
	{
		return this.m_PriceTagUI;
	}

	// Token: 0x06000219 RID: 537 RVA: 0x000152CB File Offset: 0x000134CB
	public override void OnMouseButtonUp()
	{
		if (this.m_IsWarehouseTag)
		{
			return;
		}
		CSingleton<SetItemPriceScreen>.Instance.OpenScreen(this.m_PriceTagUI.GetItemType());
	}

	// Token: 0x0600021A RID: 538 RVA: 0x000152EB File Offset: 0x000134EB
	public override void OnRightMouseButtonUp()
	{
		if (this.m_ShelfCompartment)
		{
			this.m_ShelfCompartment.RemoveLabel(true);
		}
	}

	// Token: 0x0600021B RID: 539 RVA: 0x00015306 File Offset: 0x00013506
	public void SetVisibility(bool isVisible)
	{
		base.gameObject.SetActive(isVisible);
		this.m_PriceTagUI.gameObject.SetActive(isVisible);
	}

	// Token: 0x0600021C RID: 540 RVA: 0x00015325 File Offset: 0x00013525
	public void SetItemImage(EItemType itemType)
	{
		this.m_PriceTagUI.SetItemImage(itemType);
	}

	// Token: 0x0600021D RID: 541 RVA: 0x00015333 File Offset: 0x00013533
	public void SetAmountText(int amount)
	{
		this.m_PriceTagUI.SetAmountText(amount);
	}

	// Token: 0x0600021E RID: 542 RVA: 0x00015341 File Offset: 0x00013541
	public void SetPriceText(float price)
	{
		this.m_PriceTagUI.SetPriceText(price);
	}

	// Token: 0x0600021F RID: 543 RVA: 0x0001534F File Offset: 0x0001354F
	public void RefreshPriceText()
	{
		this.m_PriceTagUI.RefreshPriceText();
	}

	// Token: 0x06000220 RID: 544 RVA: 0x0001535C File Offset: 0x0001355C
	public void SetPriceTagScale(float scale)
	{
		this.m_PriceTagUI.transform.localScale = Vector3.one * scale;
	}

	// Token: 0x06000221 RID: 545 RVA: 0x00015379 File Offset: 0x00013579
	public void SetIgnoreCull(bool ignoreCull)
	{
		this.m_PriceTagUI.m_IgnoreCull = ignoreCull;
		if (ignoreCull)
		{
			this.m_PriceTagUI.m_UIGrp.gameObject.SetActive(true);
		}
	}

	// Token: 0x04000266 RID: 614
	private ShelfCompartment m_ShelfCompartment;

	// Token: 0x04000267 RID: 615
	public UI_PriceTag m_PriceTagUI;

	// Token: 0x04000268 RID: 616
	public bool m_IsWarehouseTag;
}
