﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200006A RID: 106
public class GenericSliderScreen : UIScreenBase
{
	// Token: 0x0600048C RID: 1164 RVA: 0x000279F0 File Offset: 0x00025BF0
	protected override void Awake()
	{
		base.Awake();
		this.m_DefaultMinimizedY = this.m_AnimGrp.offsetMax.y;
	}

	// Token: 0x0600048D RID: 1165 RVA: 0x00027A0E File Offset: 0x00025C0E
	protected override void Start()
	{
		base.Start();
		this.m_ScreenRatio = 1920f / (float)Screen.height;
		this.m_ScrollSpeed = (float)Screen.width;
		this.m_MouseWheelScrollSpeed = 96f;
	}

	// Token: 0x0600048E RID: 1166 RVA: 0x00027A3F File Offset: 0x00025C3F
	protected override void Init()
	{
		base.Init();
		if (this.m_EvalSliderMaxOnInit)
		{
			base.StartCoroutine(this.EvaluateActiveRestockUIScroller());
		}
	}

	// Token: 0x0600048F RID: 1167 RVA: 0x00027A5C File Offset: 0x00025C5C
	protected IEnumerator EvaluateActiveRestockUIScroller()
	{
		yield return new WaitForSeconds(0.01f);
		this.m_MaxPosX = 90000f;
		this.m_MaxPosFound = false;
		this.m_MaxPosAccurateFound = false;
		if (!this.m_ScrollEndPosParent)
		{
			this.m_ScrollEndPos.transform.SetParent(this.m_ScrollEndComparer.transform, false);
			this.m_ScrollEndPos.transform.localPosition = Vector3.zero;
			this.m_UseAccurateMaxPos = false;
		}
		else
		{
			this.m_ScrollEndPos.transform.SetParent(this.m_ScrollEndPosParent.transform, false);
			this.m_ScrollEndPos.transform.localPosition = new Vector3(0f, this.m_ScrollEndPosOffsetYAmount, 0f);
		}
		yield break;
	}

	// Token: 0x06000490 RID: 1168 RVA: 0x00027A6B File Offset: 0x00025C6B
	protected override void RunUpdate()
	{
		base.RunUpdate();
		GameInstance.m_CanDragMainMenuSlider = false;
		this.EvaluateScrollMaxPos();
		this.EvaluateScreenDrag();
	}

	// Token: 0x06000491 RID: 1169 RVA: 0x00027A88 File Offset: 0x00025C88
	protected override void OnOpenScreen()
	{
		base.OnOpenScreen();
		if (this.m_EvalSliderMaxOnOpen)
		{
			base.StartCoroutine(this.EvaluateActiveRestockUIScroller());
		}
		if (this.m_ResetScrollPosOnOpen)
		{
			this.m_PosX = 0f;
			this.m_LerpPosX = 0f;
		}
		this.UpdateSliderGroupPosition();
		base.StartCoroutine(this.DelayCanEvaluateMaxScrollPos());
		GameInstance.m_CanDragMainMenuSlider = false;
	}

	// Token: 0x06000492 RID: 1170 RVA: 0x00027AE7 File Offset: 0x00025CE7
	protected override void OnCloseScreen()
	{
		base.OnCloseScreen();
		this.m_IsScreenOpen = false;
		this.m_CanEvaluateMaxScrollPos = false;
		GameInstance.m_CanDragMainMenuSlider = true;
		this.m_ScreenGroup.SetActive(false);
	}

	// Token: 0x06000493 RID: 1171 RVA: 0x00027B0F File Offset: 0x00025D0F
	protected IEnumerator DelayCanEvaluateMaxScrollPos()
	{
		yield return new WaitForSeconds(0.05f);
		if (this.m_ScrollEndPos.transform.position.y > this.m_ScrollEndComparer.transform.position.y)
		{
			this.m_UseAccurateMaxPos = false;
		}
		else
		{
			this.m_UseAccurateMaxPos = true;
		}
		this.m_CanEvaluateMaxScrollPos = true;
		yield break;
	}

	// Token: 0x06000494 RID: 1172 RVA: 0x00027B20 File Offset: 0x00025D20
	protected unsafe void EvaluateScreenDrag()
	{
		this.m_PosX += CSingleton<TouchManager>.Instance.m_DragRatioY * this.m_ScrollSpeed * this.m_ScrollSpeedMultiplier;
		if (this.m_MouseWheelScrollInverted)
		{
			this.m_PosX += Input.mouseScrollDelta.y * this.m_MouseWheelScrollSpeed * this.m_ScrollSpeedMultiplier;
			if (!CSingleton<CGameManager>.Instance.m_DisableController && CSingleton<InputManager>.Instance.m_IsControllerActive)
			{
				this.m_PosX += *CSingleton<InputManager>.Instance.m_CurrentGamepad.rightStick.y.value * this.m_GamepadScrollSpeed * this.m_ScrollSpeedMultiplier;
			}
		}
		else
		{
			this.m_PosX -= Input.mouseScrollDelta.y * this.m_MouseWheelScrollSpeed * this.m_ScrollSpeedMultiplier;
			if (!CSingleton<CGameManager>.Instance.m_DisableController && CSingleton<InputManager>.Instance.m_IsControllerActive)
			{
				this.m_PosX -= *CSingleton<InputManager>.Instance.m_CurrentGamepad.rightStick.y.value * this.m_GamepadScrollSpeed * this.m_ScrollSpeedMultiplier;
			}
		}
		if (!CSingleton<TouchManager>.Instance.m_IsPressed)
		{
			this.m_PosX = Mathf.Clamp(this.m_PosX, this.m_MinPosX, this.m_MaxPosX);
		}
		else
		{
			this.m_PosX = Mathf.Clamp(this.m_PosX, this.m_MinPosX - this.m_MinHardLimit * this.m_ScrollSpeedMultiplier, this.m_MaxPosX + this.m_MaxHardLimit * this.m_ScrollSpeedMultiplier);
		}
		if (TouchManager.IsSnappingToFinger())
		{
			this.m_PosX = this.m_LerpPosX;
		}
		this.m_LerpPosX = Mathf.Lerp(this.m_LerpPosX, this.m_PosX, Time.deltaTime * CSingleton<TouchManager>.Instance.m_LerpSpeed);
		this.UpdateSliderGroupPosition();
	}

	// Token: 0x06000495 RID: 1173 RVA: 0x00027CEA File Offset: 0x00025EEA
	protected void UpdateSliderGroupPosition()
	{
		this.m_SliderGrp.transform.localPosition = new Vector3(0f, this.m_LerpPosX, 0f);
	}

	// Token: 0x06000496 RID: 1174 RVA: 0x00027D14 File Offset: 0x00025F14
	protected void EvaluateScrollMaxPos()
	{
		if (!this.m_CanEvaluateMaxScrollPos)
		{
			return;
		}
		if (!this.m_MaxPosFound || !this.m_MaxPosAccurateFound)
		{
			float num = this.m_ScrollEndComparer.transform.position.y - this.m_ScrollEndPos.transform.position.y;
			if (!this.m_MaxPosFound && num <= 0f)
			{
				this.m_MaxPosFound = true;
				this.m_MaxPosX = this.m_SliderGrp.transform.localPosition.y;
				if (this.m_MaxPosX < 0f)
				{
					this.m_MaxPosX = 0f;
				}
			}
			if (!this.m_UseAccurateMaxPos)
			{
				this.m_MaxPosAccurateFound = true;
			}
			int num2 = 0;
			while (this.m_MaxPosFound && !this.m_MaxPosAccurateFound && num2 < 1000)
			{
				num2++;
				if (num < 0f)
				{
					this.m_SliderGrp.transform.localPosition -= new Vector3(0f, 1f * this.m_ScrollSpeedMultiplier, 0f);
					this.m_MaxPosX -= 1f * this.m_ScrollSpeedMultiplier;
					if (Mathf.Abs(num) < 5f * this.m_ScrollSpeedMultiplier * this.m_GamepadJoystickSpeedMultiplier)
					{
						this.m_MaxPosAccurateFound = true;
						this.m_MaxPosX = this.m_SliderGrp.transform.localPosition.y;
						this.m_MaxPosX = Mathf.Clamp(this.m_MaxPosX, 0f, this.m_MaxPosXClamp);
					}
					num = this.m_ScrollEndComparer.transform.position.y - this.m_ScrollEndPos.transform.position.y;
				}
			}
		}
	}

	// Token: 0x06000497 RID: 1175 RVA: 0x00027EC8 File Offset: 0x000260C8
	public void OnPressMinMaximize()
	{
		if (this.m_IsMinimized)
		{
			this.m_IsMinimized = false;
			this.m_AnimGrp.offsetMax = new Vector2(this.m_AnimGrp.offsetMax.x, this.m_DefaultMinimizedY);
		}
		else
		{
			this.m_IsMinimized = true;
			this.m_AnimGrp.offsetMax = new Vector2(this.m_AnimGrp.offsetMax.x, this.m_MaximizePosY);
		}
		this.m_MaxPosFound = false;
		this.m_MaxPosAccurateFound = false;
		this.m_MaxPosX = 90000f;
	}

	// Token: 0x06000498 RID: 1176 RVA: 0x00027F52 File Offset: 0x00026152
	public void ScrollToUIDelayed(GameObject targetUI, bool instantSnapToPos, float offsetY)
	{
		base.StartCoroutine(this.DelayScroll(targetUI, instantSnapToPos, offsetY));
	}

	// Token: 0x06000499 RID: 1177 RVA: 0x00027F64 File Offset: 0x00026164
	private IEnumerator DelayScroll(GameObject targetUI, bool instantSnapToPos, float offsetY)
	{
		yield return new WaitForSeconds(0.02f);
		this.ScrollToUI(targetUI, instantSnapToPos, offsetY);
		yield break;
	}

	// Token: 0x0600049A RID: 1178 RVA: 0x00027F88 File Offset: 0x00026188
	public void ScrollToUI(GameObject targetUI, bool instantSnapToPos, float offsetY)
	{
		bool flag = false;
		float lerpPosX = this.m_LerpPosX;
		int num = 0;
		float num2 = this.m_ScrollEndComparer.transform.position.y - targetUI.transform.position.y;
		while (!flag && num < 10000)
		{
			num++;
			if (num2 < 0f)
			{
				this.m_PosX -= Mathf.Clamp(Mathf.Abs(num2) * Time.deltaTime, 1f, 30f);
				this.m_LerpPosX = this.m_PosX;
				this.UpdateSliderGroupPosition();
				num2 = this.m_ScrollEndComparer.transform.position.y - targetUI.transform.position.y + offsetY;
				if (Mathf.Abs(num2) < 5f * this.m_ScrollSpeedMultiplier * this.m_GamepadJoystickSpeedMultiplier)
				{
					flag = true;
				}
			}
			else if (num2 > 0f)
			{
				this.m_PosX += Mathf.Clamp(Mathf.Abs(num2) * Time.deltaTime, 1f, 30f);
				this.m_LerpPosX = this.m_PosX;
				this.UpdateSliderGroupPosition();
				num2 = this.m_ScrollEndComparer.transform.position.y - targetUI.transform.position.y + offsetY;
				if (Mathf.Abs(num2) < 5f * this.m_ScrollSpeedMultiplier * this.m_GamepadJoystickSpeedMultiplier)
				{
					flag = true;
				}
			}
			if (this.m_PosX <= this.m_MinPosX || this.m_PosX >= this.m_MaxPosX)
			{
				flag = true;
			}
		}
		if (!instantSnapToPos)
		{
			this.m_LerpPosX = lerpPosX;
		}
		this.UpdateSliderGroupPosition();
	}

	// Token: 0x0400059A RID: 1434
	public RectTransform m_AnimGrp;

	// Token: 0x0400059B RID: 1435
	public Transform m_VerticalLayoutGrp;

	// Token: 0x0400059C RID: 1436
	public VerticalLayoutGroup m_VerticalLayout;

	// Token: 0x0400059D RID: 1437
	public bool m_ResetScrollPosOnOpen = true;

	// Token: 0x0400059E RID: 1438
	public bool m_EvalSliderMaxOnInit = true;

	// Token: 0x0400059F RID: 1439
	public bool m_EvalSliderMaxOnOpen;

	// Token: 0x040005A0 RID: 1440
	private bool m_IsMinimized;

	// Token: 0x040005A1 RID: 1441
	public float m_DefaultMinimizedY;

	// Token: 0x040005A2 RID: 1442
	public float m_MaximizePosY = -100f;

	// Token: 0x040005A3 RID: 1443
	public float m_ScrollSpeedMultiplier = 1f;

	// Token: 0x040005A4 RID: 1444
	public float m_GamepadJoystickSpeedMultiplier = 1f;

	// Token: 0x040005A5 RID: 1445
	public float m_MaxPosXClamp = 100000f;

	// Token: 0x040005A6 RID: 1446
	private float m_ScreenRatio = 1f;

	// Token: 0x040005A7 RID: 1447
	[Space(10f)]
	[Header("Slider")]
	public GameObject m_SliderGrp;

	// Token: 0x040005A8 RID: 1448
	public bool m_MouseWheelScrollInverted;

	// Token: 0x040005A9 RID: 1449
	protected bool m_CanEvaluateMaxScrollPos;

	// Token: 0x040005AA RID: 1450
	protected bool m_MaxPosFound;

	// Token: 0x040005AB RID: 1451
	protected bool m_UseAccurateMaxPos;

	// Token: 0x040005AC RID: 1452
	protected bool m_MaxPosAccurateFound;

	// Token: 0x040005AD RID: 1453
	public GameObject m_ScrollEndComparer;

	// Token: 0x040005AE RID: 1454
	public GameObject m_ScrollEndPos;

	// Token: 0x040005AF RID: 1455
	protected GameObject m_ScrollEndPosParent;

	// Token: 0x040005B0 RID: 1456
	public float m_ScrollEndPosOffsetYAmount;

	// Token: 0x040005B1 RID: 1457
	protected float m_MinPosX;

	// Token: 0x040005B2 RID: 1458
	protected float m_MaxPosX = 5000f;

	// Token: 0x040005B3 RID: 1459
	protected float m_MinHardLimit = 100f;

	// Token: 0x040005B4 RID: 1460
	protected float m_MaxHardLimit = 100f;

	// Token: 0x040005B5 RID: 1461
	private float m_ScrollSpeed = 1f;

	// Token: 0x040005B6 RID: 1462
	private float m_MouseWheelScrollSpeed = 100f;

	// Token: 0x040005B7 RID: 1463
	private float m_GamepadScrollSpeed = 50f;

	// Token: 0x040005B8 RID: 1464
	protected float m_LerpPosX;

	// Token: 0x040005B9 RID: 1465
	protected float m_PosX;

	// Token: 0x040005BA RID: 1466
	private bool m_LastEnableOverrideCameraCanDrag;
}
