﻿using System;

// Token: 0x020000AF RID: 175
public class CEventPlayer_ReduceCoin : CEvent
{
	// Token: 0x1700000E RID: 14
	// (get) Token: 0x060006FE RID: 1790 RVA: 0x000392A3 File Offset: 0x000374A3
	// (set) Token: 0x060006FF RID: 1791 RVA: 0x000392AB File Offset: 0x000374AB
	public float m_CoinValue { get; private set; }

	// Token: 0x1700000F RID: 15
	// (get) Token: 0x06000700 RID: 1792 RVA: 0x000392B4 File Offset: 0x000374B4
	// (set) Token: 0x06000701 RID: 1793 RVA: 0x000392BC File Offset: 0x000374BC
	public bool m_NoLerp { get; private set; }

	// Token: 0x06000702 RID: 1794 RVA: 0x000392C5 File Offset: 0x000374C5
	public CEventPlayer_ReduceCoin(float coinValue, bool noLerp = false)
	{
		this.m_CoinValue = coinValue;
		this.m_NoLerp = noLerp;
	}
}
