﻿using System;
using System.Collections.Generic;
using I2.Loc;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000069 RID: 105
public class GameUIScreen : CSingleton<GameUIScreen>
{
	// Token: 0x0600046D RID: 1133 RVA: 0x00026DC6 File Offset: 0x00024FC6
	private void Awake()
	{
		this.m_AddMoneyText.gameObject.SetActive(false);
		this.m_AddShopExpText.gameObject.SetActive(false);
		this.m_PressEnterGoNextDayIndicator.SetActive(false);
		this.m_DeodorantBarGrp.SetActive(false);
	}

	// Token: 0x0600046E RID: 1134 RVA: 0x00026E04 File Offset: 0x00025004
	private void Init()
	{
		this.m_CurrentCoin = CPlayerData.m_CoinAmount;
		this.m_FinalCoin = this.m_CurrentCoin;
		this.m_CoinText.text = GameInstance.GetPriceString(this.m_CurrentCoin, false, true, false, "F2");
		this.m_DayText.text = LocalizationManager.GetTranslation("Day XXX", true, 0, true, false, null, null, true).Replace("XXX", (CPlayerData.m_CurrentDay + 1).ToString());
		this.EvaluateShopLevelAndExp();
	}

	// Token: 0x0600046F RID: 1135 RVA: 0x00026E84 File Offset: 0x00025084
	private void Update()
	{
		this.EvaluateAddMoneyPopup();
		this.EvaluateAddShopExpPopup();
		this.m_TimeText.text = CSingleton<LightManager>.Instance.m_TimeString;
		if (this.m_IsShowingCanvasGrpAlpha)
		{
			this.m_CanvasGrpAlphaLerpTimer += Time.deltaTime * 2f;
			this.m_CanvasGrp.alpha = Mathf.Lerp(0f, 1f, this.m_CanvasGrpAlphaLerpTimer);
			if (this.m_CanvasGrpAlphaLerpTimer >= 1f)
			{
				this.m_IsShowingCanvasGrpAlpha = false;
				this.m_CanvasGrpAlphaLerpTimer = 1f;
			}
		}
		else if (this.m_IsHidingCanvasGrpAlpha)
		{
			this.m_CanvasGrpAlphaLerpTimer -= Time.deltaTime * 2f;
			this.m_CanvasGrp.alpha = Mathf.Lerp(0f, 1f, this.m_CanvasGrpAlphaLerpTimer);
			if (this.m_CanvasGrpAlphaLerpTimer <= 0f)
			{
				this.m_IsShowingCanvasGrpAlpha = false;
				this.m_CanvasGrpAlphaLerpTimer = 0f;
			}
		}
		if (this.m_IsPlayingAddCoinSFX)
		{
			this.m_PlayAddCoinSFXTimer += Time.deltaTime;
			if (this.m_PlayAddCoinSFXTimer > 0.05f)
			{
				SoundManager.SetEnableSound_CoinIncrease(false);
				this.m_IsPlayingAddCoinSFX = false;
				this.m_PlayAddCoinSFXTimer = 0f;
			}
		}
		if (GameInstance.m_StopCoinGemTextLerp)
		{
			return;
		}
		bool stopCoinGemTextLerp = GameInstance.m_StopCoinGemTextLerp;
	}

	// Token: 0x06000470 RID: 1136 RVA: 0x00026FC0 File Offset: 0x000251C0
	private void EvaluateAddMoneyPopup()
	{
		if (this.m_AddMoneyPopupList.Count > 0)
		{
			this.m_AddMoneyPopupTimer += Time.deltaTime;
			if (this.m_AddMoneyPopupTimer >= 1f)
			{
				this.m_AddMoneyPopupTimer = 0f;
				this.m_AddMoneyText.gameObject.SetActive(false);
				if (this.m_AddMoneyPopupList[0] > 0f)
				{
					this.m_AddMoneyText.text = "+" + GameInstance.GetPriceString(this.m_AddMoneyPopupList[0], false, true, false, "F2");
					this.m_AddMoneyText.color = this.m_AddMoneyColor;
					this.m_AddMoneyText.gameObject.SetActive(true);
				}
				else if (this.m_AddMoneyPopupList[0] < 0f)
				{
					this.m_AddMoneyText.text = "-" + GameInstance.GetPriceString(-this.m_AddMoneyPopupList[0], false, true, false, "F2");
					this.m_AddMoneyText.color = this.m_ReduceMoneyColor;
					this.m_AddMoneyText.gameObject.SetActive(true);
				}
				this.m_AddMoneyPopupList.RemoveAt(0);
				return;
			}
		}
		else if (this.m_AddMoneyText.gameObject.activeSelf)
		{
			this.m_AddMoneyPopupTimer += Time.deltaTime;
			if (this.m_AddMoneyPopupTimer >= 2f)
			{
				this.m_AddMoneyPopupTimer = 0f;
				this.m_AddMoneyText.gameObject.SetActive(false);
			}
		}
	}

	// Token: 0x06000471 RID: 1137 RVA: 0x00027140 File Offset: 0x00025340
	private void EvaluateAddShopExpPopup()
	{
		if (this.m_AddShopExpPopupList.Count > 0)
		{
			this.m_AddShopExpPopupTimer += Time.deltaTime;
			if (this.m_AddShopExpPopupTimer >= 1f)
			{
				this.m_AddShopExpPopupTimer = 0f;
				this.m_AddShopExpText.gameObject.SetActive(false);
				if (this.m_AddShopExpPopupList[0] > 0)
				{
					this.m_AddShopExpText.text = "+" + this.m_AddShopExpPopupList[0].ToString() + " xp";
					this.m_AddShopExpText.gameObject.SetActive(true);
				}
				this.m_AddShopExpPopupList.RemoveAt(0);
				return;
			}
		}
		else if (this.m_AddShopExpText.gameObject.activeSelf)
		{
			this.m_AddShopExpPopupTimer += Time.deltaTime;
			if (this.m_AddShopExpPopupTimer >= 2f)
			{
				this.m_AddShopExpPopupTimer = 0f;
				this.m_AddShopExpText.gameObject.SetActive(false);
			}
		}
	}

	// Token: 0x06000472 RID: 1138 RVA: 0x00027244 File Offset: 0x00025444
	public void AddCoin(float coinValue, bool noLerp)
	{
		this.m_FinalCoin += coinValue;
		if (noLerp)
		{
			this.m_CurrentCoin = this.m_FinalCoin;
			this.m_CoinText.text = GameInstance.GetPriceString(this.m_FinalCoin, false, true, false, "F2");
			this.PlayAddCoinAnimation();
			this.m_PlayAddCoinSFXTimer = 0f;
			this.m_IsPlayingAddCoinSFX = true;
		}
		if (!GameInstance.m_StopCoinGemTextLerp)
		{
			this.m_CoinText.text = GameInstance.GetPriceString(this.m_FinalCoin, false, true, false, "F2");
		}
	}

	// Token: 0x06000473 RID: 1139 RVA: 0x000272D4 File Offset: 0x000254D4
	public void ReduceCoin(float coinValue, bool noLerp)
	{
		this.m_FinalCoin -= coinValue;
		if (noLerp)
		{
			this.m_CurrentCoin = this.m_FinalCoin;
			this.m_CoinText.text = GameInstance.GetPriceString(this.m_FinalCoin, false, true, false, "F2");
			this.PlayAddCoinAnimation();
			this.m_PlayAddCoinSFXTimer = 0f;
			this.m_IsPlayingAddCoinSFX = true;
		}
		this.m_CoinText.text = GameInstance.GetPriceString(this.m_FinalCoin, false, true, false, "F2");
	}

	// Token: 0x06000474 RID: 1140 RVA: 0x00027352 File Offset: 0x00025552
	public void PlayAddCoinAnimation()
	{
	}

	// Token: 0x06000475 RID: 1141 RVA: 0x00027354 File Offset: 0x00025554
	private void EvaluateShopLevelAndExp()
	{
		this.m_ShopLevelText.text = LocalizationManager.GetTranslation("Shop Level XXX", true, 0, true, false, null, null, true).Replace("XXX", (CPlayerData.m_ShopLevel + 1).ToString());
		this.m_ShopExpBar.fillAmount = (float)CPlayerData.m_ShopExpPoint / (float)CPlayerData.GetExpRequiredToLevelUp();
		this.m_ShopEXPText.text = CPlayerData.m_ShopExpPoint.ToString() + "/" + CPlayerData.GetExpRequiredToLevelUp().ToString() + " XP";
	}

	// Token: 0x06000476 RID: 1142 RVA: 0x000273DF File Offset: 0x000255DF
	public static void HideEnterGoNextDayIndicatorVisible()
	{
		CSingleton<GameUIScreen>.Instance.m_PressEnterGoNextDayIndicatorText.SetActive(false);
	}

	// Token: 0x06000477 RID: 1143 RVA: 0x000273F1 File Offset: 0x000255F1
	public static void ResetEnterGoNextDayIndicatorVisible()
	{
		CSingleton<GameUIScreen>.Instance.UpdateGoNextDayText();
		CSingleton<GameUIScreen>.Instance.m_PressEnterGoNextDayIndicatorText.SetActive(true);
	}

	// Token: 0x06000478 RID: 1144 RVA: 0x00027410 File Offset: 0x00025610
	public static void SetGameUIVisible(bool isVisible)
	{
		if (isVisible)
		{
			if (CSingleton<GameUIScreen>.Instance.m_CanvasGrp.alpha != 1f)
			{
				CSingleton<GameUIScreen>.Instance.m_IsShowingCanvasGrpAlpha = true;
				CSingleton<GameUIScreen>.Instance.m_IsHidingCanvasGrpAlpha = false;
				return;
			}
		}
		else if (CSingleton<GameUIScreen>.Instance.m_CanvasGrp.alpha != 0f)
		{
			CSingleton<GameUIScreen>.Instance.m_IsShowingCanvasGrpAlpha = false;
			CSingleton<GameUIScreen>.Instance.m_IsHidingCanvasGrpAlpha = true;
		}
	}

	// Token: 0x06000479 RID: 1145 RVA: 0x0002747C File Offset: 0x0002567C
	public static void HideToolTip()
	{
		CSingleton<GameUIScreen>.Instance.m_IsTooltipVisible = CSingleton<GameUIScreen>.Instance.m_PhoneTooltipUI.gameObject.activeSelf;
		CSingleton<GameUIScreen>.Instance.m_PhoneTooltipUI.gameObject.SetActive(false);
		CSingleton<GameUIScreen>.Instance.m_AlbumTooltipUI.gameObject.SetActive(false);
	}

	// Token: 0x0600047A RID: 1146 RVA: 0x000274D1 File Offset: 0x000256D1
	public static void ResetToolTipVisibility()
	{
		CSingleton<GameUIScreen>.Instance.m_PhoneTooltipUI.gameObject.SetActive(CSingleton<GameUIScreen>.Instance.m_IsTooltipVisible);
		CSingleton<GameUIScreen>.Instance.m_AlbumTooltipUI.gameObject.SetActive(CSingleton<GameUIScreen>.Instance.m_IsTooltipVisible);
	}

	// Token: 0x0600047B RID: 1147 RVA: 0x0002750F File Offset: 0x0002570F
	private void EvaluateCoinTextColor()
	{
		if (this.m_FinalCoin < 0f)
		{
			this.m_CoinText.color = this.m_ReduceMoneyColor;
			return;
		}
		this.m_CoinText.color = this.m_AddMoneyColor;
	}

	// Token: 0x0600047C RID: 1148 RVA: 0x00027544 File Offset: 0x00025744
	public void UpdateGoNextDayText()
	{
		string newValue = "Enter";
		if (CSingleton<InputManager>.Instance.m_IsControllerActive)
		{
			newValue = "R3";
		}
		this.m_GoNextDayText.text = LocalizationManager.GetTranslation("Press XXX to start next day", true, 0, true, false, null, null, true).Replace("XXX", newValue);
	}

	// Token: 0x0600047D RID: 1149 RVA: 0x00027590 File Offset: 0x00025790
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.AddListener<CEventPlayer_SetCoin>(new CEventManager.EventDelegate<CEventPlayer_SetCoin>(this.CPlayer_OnSetCoin));
			CEventManager.AddListener<CEventPlayer_AddCoin>(new CEventManager.EventDelegate<CEventPlayer_AddCoin>(this.CPlayer_OnAddCoin));
			CEventManager.AddListener<CEventPlayer_ReduceCoin>(new CEventManager.EventDelegate<CEventPlayer_ReduceCoin>(this.CPlayer_OnReduceCoin));
			CEventManager.AddListener<CEventPlayer_AddShopExp>(new CEventManager.EventDelegate<CEventPlayer_AddShopExp>(this.CPlayer_OnAddShopExp));
			CEventManager.AddListener<CEventPlayer_SetShopExp>(new CEventManager.EventDelegate<CEventPlayer_SetShopExp>(this.CPlayer_OnSetShopExp));
			CEventManager.AddListener<CEventPlayer_ShopLeveledUp>(new CEventManager.EventDelegate<CEventPlayer_ShopLeveledUp>(this.CPlayer_OnShopLeveledUp));
			CEventManager.AddListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.AddListener<CEventPlayer_OnDayEnded>(new CEventManager.EventDelegate<CEventPlayer_OnDayEnded>(this.OnDayEnded));
			CEventManager.AddListener<CEventPlayer_OnLanguageChanged>(new CEventManager.EventDelegate<CEventPlayer_OnLanguageChanged>(this.OnLanguageChanged));
			CEventManager.AddListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
			CEventManager.AddListener<CEventPlayer_OnSaveStatusUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnSaveStatusUpdated>(this.OnSaveStatusUpdated));
		}
	}

	// Token: 0x0600047E RID: 1150 RVA: 0x0002767C File Offset: 0x0002587C
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.RemoveListener<CEventPlayer_SetCoin>(new CEventManager.EventDelegate<CEventPlayer_SetCoin>(this.CPlayer_OnSetCoin));
			CEventManager.RemoveListener<CEventPlayer_AddCoin>(new CEventManager.EventDelegate<CEventPlayer_AddCoin>(this.CPlayer_OnAddCoin));
			CEventManager.RemoveListener<CEventPlayer_ReduceCoin>(new CEventManager.EventDelegate<CEventPlayer_ReduceCoin>(this.CPlayer_OnReduceCoin));
			CEventManager.RemoveListener<CEventPlayer_AddShopExp>(new CEventManager.EventDelegate<CEventPlayer_AddShopExp>(this.CPlayer_OnAddShopExp));
			CEventManager.RemoveListener<CEventPlayer_SetShopExp>(new CEventManager.EventDelegate<CEventPlayer_SetShopExp>(this.CPlayer_OnSetShopExp));
			CEventManager.RemoveListener<CEventPlayer_ShopLeveledUp>(new CEventManager.EventDelegate<CEventPlayer_ShopLeveledUp>(this.CPlayer_OnShopLeveledUp));
			CEventManager.RemoveListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.RemoveListener<CEventPlayer_OnDayEnded>(new CEventManager.EventDelegate<CEventPlayer_OnDayEnded>(this.OnDayEnded));
			CEventManager.RemoveListener<CEventPlayer_OnLanguageChanged>(new CEventManager.EventDelegate<CEventPlayer_OnLanguageChanged>(this.OnLanguageChanged));
			CEventManager.RemoveListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
			CEventManager.RemoveListener<CEventPlayer_OnSaveStatusUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnSaveStatusUpdated>(this.OnSaveStatusUpdated));
		}
	}

	// Token: 0x0600047F RID: 1151 RVA: 0x00027766 File Offset: 0x00025966
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.Init();
	}

	// Token: 0x06000480 RID: 1152 RVA: 0x00027770 File Offset: 0x00025970
	private void CPlayer_OnAddCoin(CEventPlayer_AddCoin evt)
	{
		if (this.m_AddMoneyPopupList.Count == 0)
		{
			this.m_AddMoneyPopupTimer = 10f;
		}
		this.m_AddMoneyPopupList.Add(evt.m_CoinValue);
		this.AddCoin(evt.m_CoinValue, evt.m_NoLerp);
		this.EvaluateCoinTextColor();
	}

	// Token: 0x06000481 RID: 1153 RVA: 0x000277C0 File Offset: 0x000259C0
	private void CPlayer_OnReduceCoin(CEventPlayer_ReduceCoin evt)
	{
		if (this.m_AddMoneyPopupList.Count == 0)
		{
			this.m_AddMoneyPopupTimer = 10f;
		}
		this.m_AddMoneyPopupList.Add(-evt.m_CoinValue);
		this.ReduceCoin(evt.m_CoinValue, evt.m_NoLerp);
		this.EvaluateCoinTextColor();
	}

	// Token: 0x06000482 RID: 1154 RVA: 0x0002780F File Offset: 0x00025A0F
	private void CPlayer_OnSetCoin(CEventPlayer_SetCoin evt)
	{
		this.m_CurrentCoin = evt.m_CoinValue;
		this.m_FinalCoin = evt.m_CoinValue;
		this.m_CoinText.text = GameInstance.GetPriceString(evt.m_CoinValue, false, true, false, "F2");
		this.EvaluateCoinTextColor();
	}

	// Token: 0x06000483 RID: 1155 RVA: 0x0002784D File Offset: 0x00025A4D
	private void CPlayer_OnAddShopExp(CEventPlayer_AddShopExp evt)
	{
		if (this.m_AddShopExpPopupList.Count == 0)
		{
			this.m_AddShopExpPopupTimer = 10f;
		}
		this.m_AddShopExpPopupList.Add(evt.m_ExpValue);
		this.EvaluateShopLevelAndExp();
	}

	// Token: 0x06000484 RID: 1156 RVA: 0x0002787E File Offset: 0x00025A7E
	private void CPlayer_OnSetShopExp(CEventPlayer_SetShopExp evt)
	{
		this.EvaluateShopLevelAndExp();
	}

	// Token: 0x06000485 RID: 1157 RVA: 0x00027886 File Offset: 0x00025A86
	private void CPlayer_OnShopLeveledUp(CEventPlayer_ShopLeveledUp evt)
	{
		this.EvaluateShopLevelAndExp();
	}

	// Token: 0x06000486 RID: 1158 RVA: 0x00027890 File Offset: 0x00025A90
	protected void OnDayStarted(CEventPlayer_OnDayStarted evt)
	{
		this.m_DayText.text = LocalizationManager.GetTranslation("Day XXX", true, 0, true, false, null, null, true).Replace("XXX", (CPlayerData.m_CurrentDay + 1).ToString());
		this.m_PressEnterGoNextDayIndicator.SetActive(false);
	}

	// Token: 0x06000487 RID: 1159 RVA: 0x000278DE File Offset: 0x00025ADE
	protected void OnDayEnded(CEventPlayer_OnDayEnded evt)
	{
		this.m_PressEnterGoNextDayIndicator.SetActive(true);
	}

	// Token: 0x06000488 RID: 1160 RVA: 0x000278EC File Offset: 0x00025AEC
	protected void OnLanguageChanged(CEventPlayer_OnLanguageChanged evt)
	{
		this.UpdateGoNextDayText();
		this.m_DayText.text = LocalizationManager.GetTranslation("Day XXX", true, 0, true, false, null, null, true).Replace("XXX", (CPlayerData.m_CurrentDay + 1).ToString());
		this.EvaluateShopLevelAndExp();
	}

	// Token: 0x06000489 RID: 1161 RVA: 0x0002793A File Offset: 0x00025B3A
	protected void OnMoneyCurrencyUpdated(CEventPlayer_OnMoneyCurrencyUpdated evt)
	{
		this.m_CoinText.text = GameInstance.GetPriceString(this.m_FinalCoin, false, true, false, "F2");
	}

	// Token: 0x0600048A RID: 1162 RVA: 0x0002795C File Offset: 0x00025B5C
	protected void OnSaveStatusUpdated(CEventPlayer_OnSaveStatusUpdated evt)
	{
		if (evt.m_IsAutosaving)
		{
			if (!this.m_AutoSavingSucessGrp.activeSelf && !this.m_AutoSavingFailedGrp.activeSelf)
			{
				this.m_AutoSavingGrp.SetActive(true);
				return;
			}
			this.m_AutoSavingGrp.SetActive(false);
			return;
		}
		else
		{
			this.m_AutoSavingGrp.SetActive(false);
			if (evt.m_IsSuccess)
			{
				this.m_AutoSavingSucessGrp.SetActive(true);
				return;
			}
			this.m_AutoSavingFailedGrp.SetActive(true);
			return;
		}
	}

	// Token: 0x04000578 RID: 1400
	public CanvasGroup m_CanvasGrp;

	// Token: 0x04000579 RID: 1401
	public GameObject m_AutoSavingGrp;

	// Token: 0x0400057A RID: 1402
	public GameObject m_AutoSavingSucessGrp;

	// Token: 0x0400057B RID: 1403
	public GameObject m_AutoSavingFailedGrp;

	// Token: 0x0400057C RID: 1404
	public TextMeshProUGUI m_CoinText;

	// Token: 0x0400057D RID: 1405
	public TextMeshProUGUI m_TimeText;

	// Token: 0x0400057E RID: 1406
	public TextMeshProUGUI m_DayText;

	// Token: 0x0400057F RID: 1407
	public TextMeshProUGUI m_ShopLevelText;

	// Token: 0x04000580 RID: 1408
	public TextMeshProUGUI m_ShopEXPText;

	// Token: 0x04000581 RID: 1409
	public TextMeshProUGUI m_AddMoneyText;

	// Token: 0x04000582 RID: 1410
	public TextMeshProUGUI m_AddShopExpText;

	// Token: 0x04000583 RID: 1411
	public TextMeshProUGUI m_GoNextDayText;

	// Token: 0x04000584 RID: 1412
	public Color m_AddMoneyColor;

	// Token: 0x04000585 RID: 1413
	public Color m_ReduceMoneyColor;

	// Token: 0x04000586 RID: 1414
	public Image m_ShopExpBar;

	// Token: 0x04000587 RID: 1415
	public Image m_DeodorantBar;

	// Token: 0x04000588 RID: 1416
	public GameObject m_DeodorantBarGrp;

	// Token: 0x04000589 RID: 1417
	public GameObject m_PressEnterGoNextDayIndicator;

	// Token: 0x0400058A RID: 1418
	public GameObject m_PressEnterGoNextDayIndicatorText;

	// Token: 0x0400058B RID: 1419
	public InputTooltipUI m_PhoneTooltipUI;

	// Token: 0x0400058C RID: 1420
	public InputTooltipUI m_AlbumTooltipUI;

	// Token: 0x0400058D RID: 1421
	private float m_CurrentCoin;

	// Token: 0x0400058E RID: 1422
	private float m_FinalCoin;

	// Token: 0x0400058F RID: 1423
	private float m_CoinLerpAmount;

	// Token: 0x04000590 RID: 1424
	private bool m_IsShowingCanvasGrpAlpha;

	// Token: 0x04000591 RID: 1425
	private bool m_IsHidingCanvasGrpAlpha;

	// Token: 0x04000592 RID: 1426
	private bool m_IsPlayingAddCoinSFX;

	// Token: 0x04000593 RID: 1427
	private bool m_IsTooltipVisible;

	// Token: 0x04000594 RID: 1428
	private float m_PlayAddCoinSFXTimer;

	// Token: 0x04000595 RID: 1429
	private float m_AddShopExpPopupTimer;

	// Token: 0x04000596 RID: 1430
	private float m_AddMoneyPopupTimer;

	// Token: 0x04000597 RID: 1431
	private float m_CanvasGrpAlphaLerpTimer;

	// Token: 0x04000598 RID: 1432
	private List<int> m_AddShopExpPopupList = new List<int>();

	// Token: 0x04000599 RID: 1433
	private List<float> m_AddMoneyPopupList = new List<float>();
}
