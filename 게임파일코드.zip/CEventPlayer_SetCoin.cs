﻿using System;

// Token: 0x020000B0 RID: 176
public class CEventPlayer_SetCoin : CEvent
{
	// Token: 0x17000010 RID: 16
	// (get) Token: 0x06000703 RID: 1795 RVA: 0x000392DB File Offset: 0x000374DB
	// (set) Token: 0x06000704 RID: 1796 RVA: 0x000392E3 File Offset: 0x000374E3
	public float m_CoinValue { get; private set; }

	// Token: 0x06000705 RID: 1797 RVA: 0x000392EC File Offset: 0x000374EC
	public CEventPlayer_SetCoin(float coinValue)
	{
		this.m_CoinValue = coinValue;
	}
}
