﻿using System;

// Token: 0x020000B6 RID: 182
public class CEventPlayer_ShopLeveledUp : CEvent
{
	// Token: 0x17000018 RID: 24
	// (get) Token: 0x06000719 RID: 1817 RVA: 0x000393CB File Offset: 0x000375CB
	// (set) Token: 0x0600071A RID: 1818 RVA: 0x000393D3 File Offset: 0x000375D3
	public int m_ShopLevel { get; private set; }

	// Token: 0x0600071B RID: 1819 RVA: 0x000393DC File Offset: 0x000375DC
	public CEventPlayer_ShopLeveledUp(int shopLevel)
	{
		this.m_ShopLevel = shopLevel;
	}
}
