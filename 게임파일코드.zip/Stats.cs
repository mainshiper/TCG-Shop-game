﻿using System;
using I2.Loc;
using UnityEngine;

// Token: 0x0200003B RID: 59
[Serializable]
public struct Stats
{
	// Token: 0x060002F9 RID: 761 RVA: 0x0001C588 File Offset: 0x0001A788
	public void DeepCopy(Stats stat)
	{
		this.HP = stat.HP;
		this.Strength = stat.Strength;
		this.Magic = stat.Magic;
		this.Vitality = stat.Vitality;
		this.Spirit = stat.Spirit;
		this.Speed = stat.Speed;
	}

	// Token: 0x060002FA RID: 762 RVA: 0x0001C5E0 File Offset: 0x0001A7E0
	public void Difference(Stats stat)
	{
		this.HP -= stat.HP;
		this.Strength -= stat.Strength;
		this.Magic -= stat.Magic;
		this.Vitality -= stat.Vitality;
		this.Spirit -= stat.Spirit;
		this.Speed -= stat.Speed;
	}

	// Token: 0x060002FB RID: 763 RVA: 0x0001C65F File Offset: 0x0001A85F
	public int GetStatMultiplied(int statAmount)
	{
		return Mathf.CeilToInt((float)statAmount * 1.1f);
	}

	// Token: 0x060002FC RID: 764 RVA: 0x0001C670 File Offset: 0x0001A870
	public void UpdateStatBasedOnLevel(int level)
	{
		if (level <= 1)
		{
			return;
		}
		for (int i = 0; i < level - 1; i++)
		{
			this.HP = this.GetStatMultiplied(this.HP) + Mathf.CeilToInt((float)this.HP * 0.01f);
			this.Strength = this.GetStatMultiplied(this.Strength);
			this.Magic = this.GetStatMultiplied(this.Magic);
			this.Vitality = this.GetStatMultiplied(this.Vitality);
			this.Spirit = this.GetStatMultiplied(this.Spirit);
			this.Speed = this.GetStatMultiplied(this.Speed);
		}
	}

	// Token: 0x060002FD RID: 765 RVA: 0x0001C718 File Offset: 0x0001A918
	public string GetStatName(int index)
	{
		string term = "";
		switch (index)
		{
		case 0:
			term = "HP";
			break;
		case 1:
			term = "Strength";
			break;
		case 2:
			term = "Magic";
			break;
		case 3:
			term = "Vitality";
			break;
		case 4:
			term = "Spirit";
			break;
		case 5:
			term = "Speed";
			break;
		}
		return LocalizationManager.GetTranslation(term, true, 0, true, false, null, null, true);
	}

	// Token: 0x060002FE RID: 766 RVA: 0x0001C788 File Offset: 0x0001A988
	public int GetStatAmount(int index)
	{
		int result = 0;
		switch (index)
		{
		case 0:
			result = this.HP;
			break;
		case 1:
			result = this.Strength;
			break;
		case 2:
			result = this.Magic;
			break;
		case 3:
			result = this.Vitality;
			break;
		case 4:
			result = this.Spirit;
			break;
		case 5:
			result = this.Speed;
			break;
		}
		return result;
	}

	// Token: 0x0400039C RID: 924
	public int HP;

	// Token: 0x0400039D RID: 925
	public int Strength;

	// Token: 0x0400039E RID: 926
	public int Magic;

	// Token: 0x0400039F RID: 927
	public int Vitality;

	// Token: 0x040003A0 RID: 928
	public int Spirit;

	// Token: 0x040003A1 RID: 929
	public int Speed;

	// Token: 0x040003A2 RID: 930
	public int HP_LevelAdd;

	// Token: 0x040003A3 RID: 931
	public int Strength_LevelAdd;

	// Token: 0x040003A4 RID: 932
	public int Magic_LevelAdd;

	// Token: 0x040003A5 RID: 933
	public int Vitality_LevelAdd;

	// Token: 0x040003A6 RID: 934
	public int Spirit_LevelAdd;

	// Token: 0x040003A7 RID: 935
	public int Speed_LevelAdd;
}
