﻿using System;
using UnityEngine;

// Token: 0x02000104 RID: 260
public class FollowObject : MonoBehaviour
{
	// Token: 0x060007AC RID: 1964 RVA: 0x0003A6F3 File Offset: 0x000388F3
	private void Awake()
	{
		if (this.m_Target == null)
		{
			return;
		}
		this.m_PosOffset = this.m_Target.transform.position - base.transform.position;
	}

	// Token: 0x060007AD RID: 1965 RVA: 0x0003A72C File Offset: 0x0003892C
	private void LateUpdate()
	{
		if (this.m_Target == null)
		{
			return;
		}
		if (this.m_MaintainCurrentPos)
		{
			base.transform.position = this.m_Target.transform.position - this.m_PosOffset;
			return;
		}
		if (this.m_IgnoreY)
		{
			base.transform.position = new Vector3(this.m_Target.transform.position.x, base.transform.position.y, this.m_Target.transform.position.z);
			return;
		}
		base.transform.position = this.m_Target.transform.position;
		if (this.m_FollowRot)
		{
			base.transform.rotation = this.m_Target.transform.rotation;
		}
		if (this.m_FollowScale)
		{
			base.transform.localScale = this.m_Target.transform.lossyScale;
		}
	}

	// Token: 0x060007AE RID: 1966 RVA: 0x0003A82B File Offset: 0x00038A2B
	public void SetFollowTarget(Transform followTarget)
	{
		this.m_Target = followTarget.gameObject;
	}

	// Token: 0x060007AF RID: 1967 RVA: 0x0003A839 File Offset: 0x00038A39
	private void OnEnable()
	{
		if (this.m_Target == null)
		{
			this.m_Target = this.m_LastFollowTarget;
		}
	}

	// Token: 0x060007B0 RID: 1968 RVA: 0x0003A855 File Offset: 0x00038A55
	private void OnDisable()
	{
		if (this.m_IgnoreDisableTarget)
		{
			return;
		}
		this.m_LastFollowTarget = this.m_Target;
		this.m_Target = null;
	}

	// Token: 0x04000EF0 RID: 3824
	public GameObject m_Target;

	// Token: 0x04000EF1 RID: 3825
	public GameObject m_LastFollowTarget;

	// Token: 0x04000EF2 RID: 3826
	public bool m_MaintainCurrentPos;

	// Token: 0x04000EF3 RID: 3827
	public bool m_FollowRot;

	// Token: 0x04000EF4 RID: 3828
	public bool m_FollowScale;

	// Token: 0x04000EF5 RID: 3829
	private Vector3 m_PosOffset;

	// Token: 0x04000EF6 RID: 3830
	public bool m_IgnoreY;

	// Token: 0x04000EF7 RID: 3831
	public bool m_IgnoreDisableTarget;
}
