﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000097 RID: 151
public class KeybindSetting : MonoBehaviour
{
	// Token: 0x060005F2 RID: 1522 RVA: 0x00031EBB File Offset: 0x000300BB
	public void Start()
	{
		this.UpdateInputUI();
	}

	// Token: 0x060005F3 RID: 1523 RVA: 0x00031EC4 File Offset: 0x000300C4
	public void UpdateInputUI()
	{
		if (this.m_IsGamepad)
		{
			EGamepadControlBtn baseGamepadBtnBind = InputManager.GetBaseGamepadBtnBind(this.m_GameBaseKey);
			this.m_TooltipUI.SetGamepadInputTooltip(EGameAction.None, baseGamepadBtnBind, InputManager.GetGamepadButtonName(baseGamepadBtnBind), false);
			return;
		}
		KeyCode baseKeycodeBind = InputManager.GetBaseKeycodeBind(this.m_GameBaseKey);
		this.m_TooltipUI.SetInputTooltip(EGameAction.None, baseKeycodeBind, InputManager.GetKeycodeName(baseKeycodeBind), false);
	}

	// Token: 0x060005F4 RID: 1524 RVA: 0x00031F1C File Offset: 0x0003011C
	public void OnPressButton()
	{
		if (this.m_IsGamepad && !CSingleton<InputManager>.Instance.m_IsControllerActive)
		{
			return;
		}
		if (!this.m_IsGamepad && CSingleton<InputManager>.Instance.m_IsControllerActive)
		{
			return;
		}
		if (!SettingScreen.IsChangingKeybind())
		{
			this.m_UpdatingGrp.SetActive(true);
			CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(true);
			InputManager.OnPressKeybindButton(this, this.m_IsGamepad, this.m_GameBaseKey, this.m_GameBaseKeySecondary);
		}
	}

	// Token: 0x060005F5 RID: 1525 RVA: 0x00031F89 File Offset: 0x00030189
	public void OnFinishSetKeybind(KeyCode keycode)
	{
		this.m_UpdatingGrp.SetActive(false);
		CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(false);
		this.UpdateInputUI();
	}

	// Token: 0x060005F6 RID: 1526 RVA: 0x00031FA8 File Offset: 0x000301A8
	public void OnFinishSetGamepadKeybind(EGamepadControlBtn controlBtn)
	{
		if (this.m_GamepadSettingLinker)
		{
			this.m_GamepadSettingLinker.OnFinishSetGamepadKeybind();
		}
		this.m_UpdatingGrp.SetActive(false);
		base.StartCoroutine(this.DelaySetIsChangingKeybind(false));
		this.UpdateInputUI();
	}

	// Token: 0x060005F7 RID: 1527 RVA: 0x00031FE2 File Offset: 0x000301E2
	private IEnumerator DelaySetIsChangingKeybind(bool isChangingKeybind)
	{
		yield return new WaitForSecondsRealtime(0.1f);
		CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(isChangingKeybind);
		yield break;
	}

	// Token: 0x040007BC RID: 1980
	public EGameBaseKey m_GameBaseKey;

	// Token: 0x040007BD RID: 1981
	public EGameBaseKey m_GameBaseKeySecondary;

	// Token: 0x040007BE RID: 1982
	public bool m_IsGamepad;

	// Token: 0x040007BF RID: 1983
	public GameObject m_UpdatingGrp;

	// Token: 0x040007C0 RID: 1984
	public InputTooltipUI m_TooltipUI;

	// Token: 0x040007C1 RID: 1985
	public GamepadSettingLinker m_GamepadSettingLinker;
}
