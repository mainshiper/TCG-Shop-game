﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using UnityEngine.Networking;
using UnityEngine.UI;

// Token: 0x02000107 RID: 263
public class LoadStreamTexture : CSingleton<LoadStreamTexture>
{
	// Token: 0x060007BA RID: 1978 RVA: 0x0003AB24 File Offset: 0x00038D24
	private void Awake()
	{
		if (LoadStreamTexture.m_Instance == null)
		{
			LoadStreamTexture.m_Instance = this;
		}
		else if (LoadStreamTexture.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
	}

	// Token: 0x060007BB RID: 1979 RVA: 0x0003AB5C File Offset: 0x00038D5C
	private void Update()
	{
		if (this.m_IsPreloading && !this.m_IsWaitingPreloadCallback && this.m_CurrentPreloadExpansionIndex >= this.m_ExpasionTypeToPreLoadList.Count && this.m_CurrentPreloadExpansionIndex >= this.m_ExpasionTypeToPreLoadList.Count)
		{
			this.m_IsPreloading = false;
			this.m_IsWaitingPreloadCallback = false;
		}
	}

	// Token: 0x060007BC RID: 1980 RVA: 0x0003ABAD File Offset: 0x00038DAD
	private void OnPreloadFinish()
	{
		this.m_CurrentPreloadIndex++;
		this.m_IsWaitingPreloadCallback = false;
	}

	// Token: 0x060007BD RID: 1981 RVA: 0x0003ABC4 File Offset: 0x00038DC4
	public static Sprite GetImage(string fileName)
	{
		Sprite sprite = null;
		if (CSingleton<LoadStreamTexture>.Instance.m_LoadedSpriteDict.ContainsKey(fileName))
		{
			CSingleton<LoadStreamTexture>.Instance.m_LoadedSpriteDict.TryGetValue(fileName, out sprite);
			if (sprite != null)
			{
				CSingleton<LoadStreamTexture>.Instance.m_Image.sprite = sprite;
				return sprite;
			}
		}
		Texture2D texture2D = LoadStreamTexture.LoadPNG(fileName);
		if (texture2D != null)
		{
			sprite = Sprite.Create(texture2D, new Rect(0f, 0f, (float)texture2D.width, (float)texture2D.height), Vector2.zero);
			sprite.name = fileName;
			if (!CSingleton<LoadStreamTexture>.Instance.m_LoadedSpriteDict.ContainsKey(fileName))
			{
				CSingleton<LoadStreamTexture>.Instance.m_LoadedSpriteList.Add(sprite);
				CSingleton<LoadStreamTexture>.Instance.m_LoadedSpriteDict.TryAdd(fileName, sprite);
			}
			else
			{
				CSingleton<LoadStreamTexture>.Instance.m_LoadedSpriteDict[fileName] = sprite;
			}
			return sprite;
		}
		if (!CSingleton<LoadStreamTexture>.Instance.m_CurrentLoadingFileNameList.Contains(fileName))
		{
			CSingleton<LoadStreamTexture>.Instance.m_CurrentLoadingFileNameList.Add(fileName);
			CSingleton<LoadStreamTexture>.Instance.StartCoroutine(CSingleton<LoadStreamTexture>.Instance.LoadTextureFromWeb(fileName));
		}
		return null;
	}

	// Token: 0x060007BE RID: 1982 RVA: 0x0003ACD5 File Offset: 0x00038ED5
	private IEnumerator LoadTextureFromWeb(string fileName)
	{
		UnityWebRequest www = UnityWebRequestTexture.GetTexture(this.m_ImageURL + fileName + ".png");
		yield return www.SendWebRequest();
		if (www.result == 2 || www.result == 4 || www.result == 3)
		{
			Debug.LogError("Error: " + www.error);
			CSingleton<LoadStreamTexture>.Instance.m_CurrentLoadingFileNameList.Remove(fileName);
			if (this.m_IsPreloading)
			{
				this.OnPreloadFinish();
			}
		}
		else
		{
			Texture2D content = DownloadHandlerTexture.GetContent(www);
			content.ignoreMipmapLimit = true;
			Sprite sprite = Sprite.Create(content, new Rect(0f, 0f, (float)content.width, (float)content.height), Vector2.zero);
			sprite.name = fileName;
			if (!this.m_LoadedSpriteDict.ContainsKey(fileName))
			{
				this.m_LoadedSpriteList.Add(sprite);
				this.m_LoadedSpriteDict.TryAdd(fileName, sprite);
			}
			else
			{
				this.m_LoadedSpriteDict[fileName] = sprite;
			}
			CSingleton<LoadStreamTexture>.Instance.m_Image.sprite = sprite;
			this.WriteImageOnDisk(content, fileName);
			CSingleton<LoadStreamTexture>.Instance.m_CurrentLoadingFileNameList.Remove(fileName);
			if (this.m_IsPreloading)
			{
				this.OnPreloadFinish();
			}
		}
		yield break;
	}

	// Token: 0x060007BF RID: 1983 RVA: 0x0003ACEC File Offset: 0x00038EEC
	private void WriteImageOnDisk(Texture2D texture, string fileName)
	{
		byte[] array = ImageConversion.EncodeToPNG(texture);
		File.WriteAllBytes(Application.persistentDataPath + "/" + fileName + ".png", array);
	}

	// Token: 0x060007C0 RID: 1984 RVA: 0x0003AD1C File Offset: 0x00038F1C
	private static Texture2D LoadPNG(string fileName)
	{
		string text = Application.persistentDataPath + "/" + fileName + ".png";
		if (File.Exists(text))
		{
			byte[] array = File.ReadAllBytes(text);
			Texture2D texture2D = new Texture2D(2, 2, DefaultFormat.LDR, TextureCreationFlags.None);
			ImageConversion.LoadImage(texture2D, array);
			return texture2D;
		}
		return null;
	}

	// Token: 0x060007C1 RID: 1985 RVA: 0x0003AD61 File Offset: 0x00038F61
	private void OnEnable()
	{
		if (!Application.isPlaying)
		{
			bool isMobilePlatform = Application.isMobilePlatform;
		}
	}

	// Token: 0x060007C2 RID: 1986 RVA: 0x0003AD70 File Offset: 0x00038F70
	private void OnDisable()
	{
		if (!Application.isPlaying)
		{
			bool isMobilePlatform = Application.isMobilePlatform;
		}
	}

	// Token: 0x04000F02 RID: 3842
	public static LoadStreamTexture m_Instance;

	// Token: 0x04000F03 RID: 3843
	public Sprite m_LoadingSprite;

	// Token: 0x04000F04 RID: 3844
	public List<Sprite> m_LoadedSpriteList;

	// Token: 0x04000F05 RID: 3845
	private Dictionary<string, Sprite> m_LoadedSpriteDict = new Dictionary<string, Sprite>();

	// Token: 0x04000F06 RID: 3846
	public string m_ImageURL = "https://www.opneon.com/streamTexture/";

	// Token: 0x04000F07 RID: 3847
	public Image m_Image;

	// Token: 0x04000F08 RID: 3848
	public List<string> m_CurrentLoadingFileNameList = new List<string>();

	// Token: 0x04000F09 RID: 3849
	public bool m_IsPreloading;

	// Token: 0x04000F0A RID: 3850
	public bool m_IsWaitingPreloadCallback;

	// Token: 0x04000F0B RID: 3851
	public int m_CurrentPreloadExpansionIndex;

	// Token: 0x04000F0C RID: 3852
	public int m_CurrentPreloadIndex;

	// Token: 0x04000F0D RID: 3853
	public List<ECardExpansionType> m_ExpasionTypeToPreLoadList;
}
