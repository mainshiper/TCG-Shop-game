﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000D5 RID: 213
public class SoundManager : CSingleton<SoundManager>
{
	// Token: 0x0600076C RID: 1900 RVA: 0x0003984C File Offset: 0x00037A4C
	protected SoundManager()
	{
	}

	// Token: 0x17000030 RID: 48
	// (get) Token: 0x0600076D RID: 1901 RVA: 0x0003988B File Offset: 0x00037A8B
	// (set) Token: 0x0600076E RID: 1902 RVA: 0x00039892 File Offset: 0x00037A92
	public static int MusicIndex
	{
		get
		{
			return SoundManager.m_MusicIndex;
		}
		set
		{
			SoundManager.m_MusicIndex = value;
		}
	}

	// Token: 0x17000031 RID: 49
	// (get) Token: 0x0600076F RID: 1903 RVA: 0x0003989A File Offset: 0x00037A9A
	// (set) Token: 0x06000770 RID: 1904 RVA: 0x000398A1 File Offset: 0x00037AA1
	public static int SFXIndex
	{
		get
		{
			return SoundManager.m_SFXIndex;
		}
		set
		{
			SoundManager.m_SFXIndex = value;
		}
	}

	// Token: 0x17000032 RID: 50
	// (get) Token: 0x06000771 RID: 1905 RVA: 0x000398A9 File Offset: 0x00037AA9
	// (set) Token: 0x06000772 RID: 1906 RVA: 0x000398B0 File Offset: 0x00037AB0
	public static float MusicVolume
	{
		get
		{
			return SoundManager.m_MusicVolume;
		}
		set
		{
			SoundManager.m_MusicVolume = value;
			SoundManager.SaveData();
		}
	}

	// Token: 0x17000033 RID: 51
	// (get) Token: 0x06000773 RID: 1907 RVA: 0x000398BD File Offset: 0x00037ABD
	// (set) Token: 0x06000774 RID: 1908 RVA: 0x000398C4 File Offset: 0x00037AC4
	public static float SFXVolume
	{
		get
		{
			return SoundManager.m_SFXVolume;
		}
		set
		{
			SoundManager.m_SFXVolume = value;
			SoundManager.SaveData();
		}
	}

	// Token: 0x06000775 RID: 1909 RVA: 0x000398D4 File Offset: 0x00037AD4
	private void Awake()
	{
		if (CSingleton<SoundManager>.Instance != null && CSingleton<SoundManager>.Instance != this)
		{
			Object.Destroy(base.gameObject);
			return;
		}
		Object.DontDestroyOnLoad(base.gameObject);
		this.m_FrameLoopLimit = this.m_AudioSrcList.Count;
		this.m_MusicVolume01 = 1f;
		this.m_MusicVolume02 = 0f;
	}

	// Token: 0x06000776 RID: 1910 RVA: 0x00039939 File Offset: 0x00037B39
	public static void MuteAllSound()
	{
		SoundManager.m_IsMute = true;
		CSingleton<SoundManager>.Instance.EvaluateSoundVolume();
	}

	// Token: 0x06000777 RID: 1911 RVA: 0x0003994B File Offset: 0x00037B4B
	public static void UnMuteAllSound()
	{
		SoundManager.m_IsMute = false;
		CSingleton<SoundManager>.Instance.EvaluateSoundVolume();
	}

	// Token: 0x06000778 RID: 1912 RVA: 0x0003995D File Offset: 0x00037B5D
	private IEnumerator DelayLoadData()
	{
		SoundManager.m_MusicVolume = 0f;
		SoundManager.m_SFXVolume = 0f;
		yield return new WaitForSeconds(0.1f);
		this.LoadData();
		yield break;
	}

	// Token: 0x06000779 RID: 1913 RVA: 0x0003996C File Offset: 0x00037B6C
	private void Update()
	{
		this.EvaluateAudioSourceOver();
		this.EvaluateFrame();
		this.EvaluateLerpMusic();
	}

	// Token: 0x0600077A RID: 1914 RVA: 0x00039980 File Offset: 0x00037B80
	private void EvaluateMusicEnding()
	{
	}

	// Token: 0x0600077B RID: 1915 RVA: 0x00039982 File Offset: 0x00037B82
	private void EvaluateFrame()
	{
		this.m_CurrentFrame++;
		this.m_CheckFrameIndex = this.m_CurrentFrame % this.m_FrameLoopLimit;
	}

	// Token: 0x0600077C RID: 1916 RVA: 0x000399A5 File Offset: 0x00037BA5
	public static void PlayAudio(string audioName, float volume = 1f, float pitch = 1f)
	{
		CSingleton<SoundManager>.Instance.PlayAudioPrivate(audioName, volume, pitch);
	}

	// Token: 0x0600077D RID: 1917 RVA: 0x000399B4 File Offset: 0x00037BB4
	public static void PlayAudioDelayed(string audioName, float delayTime, float volume = 1f, float pitch = 1f)
	{
		CSingleton<SoundManager>.Instance.StartCoroutine(CSingleton<SoundManager>.Instance.DelayPlayAudio(audioName, delayTime, volume, pitch));
	}

	// Token: 0x0600077E RID: 1918 RVA: 0x000399CF File Offset: 0x00037BCF
	private IEnumerator DelayPlayAudio(string audioName, float delayTime, float volume = 1f, float pitch = 1f)
	{
		yield return new WaitForSeconds(delayTime);
		CSingleton<SoundManager>.Instance.PlayAudioPrivate(audioName, volume, pitch);
		yield break;
	}

	// Token: 0x0600077F RID: 1919 RVA: 0x000399F4 File Offset: 0x00037BF4
	private void PlayAudioPrivate(string audioName, float volume = 1f, float pitch = 1f)
	{
		if (!GameInstance.m_HasFinishHideLoadingScreen)
		{
			return;
		}
		AudioSource emptyAudioSource = this.GetEmptyAudioSource();
		if (emptyAudioSource != null)
		{
			emptyAudioSource.clip = this.GetAudioClip(audioName);
			emptyAudioSource.pitch = pitch;
			emptyAudioSource.volume = volume * SoundManager.m_SFXVolume * SoundManager.m_SFXVolume * this.m_SFXVolumeMultiplier;
			emptyAudioSource.Play();
		}
	}

	// Token: 0x06000780 RID: 1920 RVA: 0x00039A4D File Offset: 0x00037C4D
	public static void PlayAudioForceChannel(string audioName, float volume = 1f, float pitch = 1f, int channel = 0)
	{
		CSingleton<SoundManager>.Instance.PlayAudioForceChannelPrivate(audioName, volume, pitch, channel);
	}

	// Token: 0x06000781 RID: 1921 RVA: 0x00039A60 File Offset: 0x00037C60
	private void PlayAudioForceChannelPrivate(string audioName, float volume = 1f, float pitch = 1f, int channel = 0)
	{
		if (!GameInstance.m_HasFinishHideLoadingScreen)
		{
			return;
		}
		AudioSource audioSource = this.m_AudioSrcList[channel];
		if (audioSource != null)
		{
			AudioClip audioClip = this.GetAudioClip(audioName);
			if (audioClip == audioSource.clip)
			{
				return;
			}
			audioSource.clip = audioClip;
			audioSource.pitch = pitch;
			audioSource.volume = volume * SoundManager.m_SFXVolume * SoundManager.m_SFXVolume * this.m_SFXVolumeMultiplier;
			audioSource.Play();
		}
	}

	// Token: 0x06000782 RID: 1922 RVA: 0x00039AD4 File Offset: 0x00037CD4
	private AudioClip GetAudioClip(string audioName)
	{
		AudioClip audioClip;
		if (!this.m_LoadedAudioClip.TryGetValue(audioName, out audioClip))
		{
			audioClip = (Resources.Load("SFX/" + audioName) as AudioClip);
			this.m_LoadedAudioClip.Add(audioName, audioClip);
		}
		if (audioClip)
		{
			return audioClip;
		}
		return null;
	}

	// Token: 0x06000783 RID: 1923 RVA: 0x00039B20 File Offset: 0x00037D20
	private AudioSource GetEmptyAudioSource()
	{
		for (int i = 0; i < this.m_AudioSrcList.Count; i++)
		{
			if (this.m_AudioSrcList[i].clip == null)
			{
				return this.m_AudioSrcList[i];
			}
		}
		return null;
	}

	// Token: 0x06000784 RID: 1924 RVA: 0x00039B6C File Offset: 0x00037D6C
	private void EvaluateAudioSourceOver()
	{
		if (this.m_AudioSrcList[this.m_CheckFrameIndex].clip && !this.m_AudioSrcList[this.m_CheckFrameIndex].isPlaying)
		{
			this.m_AudioSrcList[this.m_CheckFrameIndex].clip = null;
		}
	}

	// Token: 0x06000785 RID: 1925 RVA: 0x00039BC5 File Offset: 0x00037DC5
	public static void SetAndPlayMusic(string audioName, int index)
	{
		CSingleton<SoundManager>.Instance.SetAndPlayMusicPrivate(audioName, index);
	}

	// Token: 0x06000786 RID: 1926 RVA: 0x00039BD3 File Offset: 0x00037DD3
	private void SetAndPlayMusicPrivate(string audioName, int index)
	{
		if (index == 0)
		{
			this.m_MusicSrc01.clip = this.GetAudioClip(audioName);
			this.m_MusicSrc01.Play();
			return;
		}
		this.m_MusicSrc02.clip = this.GetAudioClip(audioName);
		this.m_MusicSrc02.Play();
	}

	// Token: 0x06000787 RID: 1927 RVA: 0x00039C13 File Offset: 0x00037E13
	public static void PlayMusic()
	{
		CSingleton<SoundManager>.Instance.PlayMusicPrivate();
	}

	// Token: 0x06000788 RID: 1928 RVA: 0x00039C1F File Offset: 0x00037E1F
	private void PlayMusicPrivate()
	{
		if (this.m_IsMusic02)
		{
			this.m_MusicSrc02.Play();
			return;
		}
		this.m_MusicSrc01.Play();
	}

	// Token: 0x06000789 RID: 1929 RVA: 0x00039C40 File Offset: 0x00037E40
	public static void PauseMusic()
	{
		CSingleton<SoundManager>.Instance.PauseMusicPrivate();
	}

	// Token: 0x0600078A RID: 1930 RVA: 0x00039C4C File Offset: 0x00037E4C
	private void PauseMusicPrivate()
	{
		this.m_MusicSrc01.Pause();
		this.m_MusicSrc02.Pause();
	}

	// Token: 0x0600078B RID: 1931 RVA: 0x00039C64 File Offset: 0x00037E64
	public static void StopMusic()
	{
		CSingleton<SoundManager>.Instance.StopMusicPrivate();
	}

	// Token: 0x0600078C RID: 1932 RVA: 0x00039C70 File Offset: 0x00037E70
	private void StopMusicPrivate()
	{
		this.m_MusicSrc01.Stop();
		this.m_MusicSrc02.Stop();
	}

	// Token: 0x0600078D RID: 1933 RVA: 0x00039C88 File Offset: 0x00037E88
	public static void QueueMusic(string startAudioName, string audioName, float blendSpeed)
	{
		CSingleton<SoundManager>.Instance.QueueMusicPrivate(startAudioName, audioName, blendSpeed);
	}

	// Token: 0x0600078E RID: 1934 RVA: 0x00039C98 File Offset: 0x00037E98
	private void QueueMusicPrivate(string startAudioName, string audioName, float blendSpeed)
	{
		double dspTime = AudioSettings.dspTime;
		AudioClip audioClip = this.GetAudioClip(startAudioName);
		double num = (double)audioClip.samples / (double)audioClip.frequency;
		float smoothDeltaTime = Time.smoothDeltaTime;
		Debug.Log("timeOffset " + smoothDeltaTime.ToString());
		this.m_QueuedMusic = this.GetAudioClip(audioName);
		if (this.m_IsMusic02)
		{
			this.m_MusicSrc01.Stop();
			this.m_MusicSrc01.volume = this.m_MusicSrc02.volume;
			this.m_MusicSrc01.clip = this.m_QueuedMusic;
			this.m_MusicSrc01.PlayScheduled(dspTime + num + (double)smoothDeltaTime);
			this.m_MusicSrc02.SetScheduledEndTime(dspTime + num + (double)smoothDeltaTime);
			return;
		}
		this.m_MusicSrc02.Stop();
		this.m_MusicSrc02.volume = this.m_MusicSrc01.volume;
		this.m_MusicSrc02.clip = this.m_QueuedMusic;
		this.m_MusicSrc02.PlayScheduled(dspTime + num + (double)smoothDeltaTime);
		this.m_MusicSrc01.SetScheduledEndTime(dspTime + num + (double)smoothDeltaTime);
	}

	// Token: 0x0600078F RID: 1935 RVA: 0x00039DA0 File Offset: 0x00037FA0
	public static void StopQueueMusic()
	{
		CSingleton<SoundManager>.Instance.m_QueuedMusic = null;
		if (CSingleton<SoundManager>.Instance.m_IsMusic02)
		{
			CSingleton<SoundManager>.Instance.m_MusicSrc01.Stop();
			CSingleton<SoundManager>.Instance.m_MusicSrc01.clip = null;
			return;
		}
		CSingleton<SoundManager>.Instance.m_MusicSrc02.Stop();
		CSingleton<SoundManager>.Instance.m_MusicSrc02.clip = null;
	}

	// Token: 0x06000790 RID: 1936 RVA: 0x00039E03 File Offset: 0x00038003
	public static void BlendToMusic(string audioName, float blendSpeed, bool isLinearBlend)
	{
		CSingleton<SoundManager>.Instance.BlendToMusicPrivate(audioName, blendSpeed, isLinearBlend);
	}

	// Token: 0x06000791 RID: 1937 RVA: 0x00039E14 File Offset: 0x00038014
	private void BlendToMusicPrivate(string audioName, float blendSpeed, bool isLinearBlend)
	{
		if (this.m_IsMusic02)
		{
			if (this.m_MusicSrc02.clip == this.GetAudioClip(audioName))
			{
				return;
			}
		}
		else if (this.m_MusicSrc01.clip == this.GetAudioClip(audioName))
		{
			return;
		}
		this.m_QueuedMusic = null;
		this.m_MusicBlendSpeed = blendSpeed;
		this.m_IsLinearBlend = isLinearBlend;
		if (this.m_MusicSrc02.clip == null)
		{
			this.m_MusicSrc02.clip = this.GetAudioClip(audioName);
			this.m_IsMusic02 = true;
			this.m_IsBlendingMusic = true;
			this.m_MusicSrc02.Play();
		}
		else if (this.m_MusicSrc01.clip == null)
		{
			this.m_MusicSrc01.clip = this.GetAudioClip(audioName);
			this.m_IsMusic02 = false;
			this.m_IsBlendingMusic = true;
			this.m_MusicSrc01.Play();
		}
		else
		{
			this.m_MusicSrc01.clip = this.GetAudioClip(audioName);
			this.m_IsMusic02 = false;
			this.m_IsBlendingMusic = true;
			this.m_MusicSrc01.Play();
		}
		this.m_StopEvaluateMusicEnd = false;
	}

	// Token: 0x06000792 RID: 1938 RVA: 0x00039F24 File Offset: 0x00038124
	private void EvaluateLerpMusic()
	{
		if (this.m_IsBlendingMusic)
		{
			if (this.m_IsMusic02)
			{
				if (this.m_IsLinearBlend)
				{
					this.m_LinearBlendAmount += Time.deltaTime * this.m_MusicBlendSpeed;
					this.m_MusicVolume01 = Mathf.Lerp(1f, 0f, this.m_LinearBlendAmount);
					this.m_MusicVolume02 = Mathf.Lerp(0f, 1f, this.m_LinearBlendAmount);
				}
				else
				{
					this.m_MusicVolume01 = Mathf.Lerp(this.m_MusicVolume01, 0f, Time.deltaTime * this.m_MusicBlendSpeed);
					this.m_MusicVolume02 = Mathf.Lerp(this.m_MusicVolume02, 1f, Time.deltaTime * this.m_MusicBlendSpeed);
				}
				if (this.m_MusicVolume01 < this.m_MusicLerpClipLower)
				{
					this.m_LinearBlendAmount = 0f;
					this.m_MusicVolume01 = 0f;
					this.m_MusicVolume02 = 1f;
					this.m_IsBlendingMusic = false;
					if (this.m_QueuedMusic == null)
					{
						this.m_MusicSrc01.clip = null;
						this.m_MusicSrc01.Stop();
					}
				}
			}
			else if (!this.m_IsMusic02)
			{
				if (this.m_IsLinearBlend)
				{
					this.m_LinearBlendAmount += Time.deltaTime * this.m_MusicBlendSpeed;
					this.m_MusicVolume01 = Mathf.Lerp(0f, 1f, this.m_LinearBlendAmount);
					this.m_MusicVolume02 = Mathf.Lerp(1f, 0f, this.m_LinearBlendAmount);
				}
				else
				{
					this.m_MusicVolume02 = Mathf.Lerp(this.m_MusicVolume02, 0f, Time.deltaTime * this.m_MusicBlendSpeed);
					this.m_MusicVolume01 = Mathf.Lerp(this.m_MusicVolume01, 1f, Time.deltaTime * this.m_MusicBlendSpeed);
				}
				if (this.m_MusicVolume02 < this.m_MusicLerpClipLower)
				{
					this.m_LinearBlendAmount = 0f;
					this.m_MusicVolume02 = 0f;
					this.m_MusicVolume01 = 1f;
					this.m_IsBlendingMusic = false;
					if (this.m_QueuedMusic == null)
					{
						this.m_MusicSrc02.clip = null;
						this.m_MusicSrc02.Stop();
					}
				}
			}
			if (this.m_QueuedMusic)
			{
				this.m_MusicVolume02 = 1f;
				this.m_MusicVolume01 = 1f;
			}
			this.m_MusicSrc01.volume = this.m_MusicVolume01 * SoundManager.m_MusicVolume * this.m_MusicVolumeMultiplier;
			this.m_MusicSrc02.volume = this.m_MusicVolume02 * SoundManager.m_MusicVolume * this.m_MusicVolumeMultiplier;
		}
	}

	// Token: 0x06000793 RID: 1939 RVA: 0x0003A1AC File Offset: 0x000383AC
	private void LoadData()
	{
		this.EvaluateSoundVolume();
	}

	// Token: 0x06000794 RID: 1940 RVA: 0x0003A1B4 File Offset: 0x000383B4
	private static void SaveData()
	{
	}

	// Token: 0x06000795 RID: 1941 RVA: 0x0003A1B6 File Offset: 0x000383B6
	private void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_VolumeChanged>(new CEventManager.EventDelegate<CEventPlayer_VolumeChanged>(this.CPlayer_OnVolumeChanged));
		}
	}

	// Token: 0x06000796 RID: 1942 RVA: 0x0003A1D7 File Offset: 0x000383D7
	private void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_VolumeChanged>(new CEventManager.EventDelegate<CEventPlayer_VolumeChanged>(this.CPlayer_OnVolumeChanged));
		}
	}

	// Token: 0x06000797 RID: 1943 RVA: 0x0003A1F8 File Offset: 0x000383F8
	private void CPlayer_OnVolumeChanged(CEventPlayer_VolumeChanged evt)
	{
	}

	// Token: 0x06000798 RID: 1944 RVA: 0x0003A1FC File Offset: 0x000383FC
	public void EvaluateSoundVolume()
	{
		float musicVolume = SoundManager.m_MusicVolume;
		float volume = SoundManager.m_SFXVolume;
		if (SoundManager.m_IsMute)
		{
			volume = 0f;
		}
		for (int i = 0; i < this.m_AudioSrcList.Count; i++)
		{
			this.m_AudioSrcList[i].volume = volume;
		}
		this.m_MusicSrc01.volume = this.m_MusicVolume01 * musicVolume * this.m_MusicVolumeMultiplier;
		this.m_MusicSrc02.volume = this.m_MusicVolume02 * musicVolume * this.m_MusicVolumeMultiplier;
		this.m_ExpIncrease.volume = volume;
		this.m_CoinIncrease.volume = volume;
		this.m_GemIncrease.volume = volume;
		this.m_TPIncrease.volume = volume;
		for (int j = 0; j < this.m_ExternalAudioSrcList.Count; j++)
		{
			this.m_ExternalAudioSrcList[j].volume = volume;
		}
	}

	// Token: 0x06000799 RID: 1945 RVA: 0x0003A2D6 File Offset: 0x000384D6
	public static void GenericLightTap(float volume = 1f, float pitch = 1f)
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.4f, pitch);
	}

	// Token: 0x0600079A RID: 1946 RVA: 0x0003A2E8 File Offset: 0x000384E8
	public static void GenericPop(float volume = 1f, float pitch = 1f)
	{
		SoundManager.PlayAudio("SFX_Popup_Low", volume, pitch);
	}

	// Token: 0x0600079B RID: 1947 RVA: 0x0003A2F6 File Offset: 0x000384F6
	public static void GenericConfirm(float volume = 1f, float pitch = 1f)
	{
		SoundManager.PlayAudio("SFX_Popup2", 0.6f, 0.5f);
	}

	// Token: 0x0600079C RID: 1948 RVA: 0x0003A30C File Offset: 0x0003850C
	public static void GenericCancel(float volume = 1f, float pitch = 1f)
	{
		SoundManager.PlayAudio("SFX_Popup2", 0.6f, 0.4f);
	}

	// Token: 0x0600079D RID: 1949 RVA: 0x0003A322 File Offset: 0x00038522
	public static void GenericMenuOpen(float volume = 1f, float pitch = 1f)
	{
		SoundManager.PlayAudio("SFX_Popup2", 0.6f, 0.5f);
	}

	// Token: 0x0600079E RID: 1950 RVA: 0x0003A338 File Offset: 0x00038538
	public static void GenericMenuClose(float volume = 1f, float pitch = 1f)
	{
		SoundManager.PlayAudio("SFX_Popup2", 0.6f, 0.4f);
	}

	// Token: 0x0600079F RID: 1951 RVA: 0x0003A34E File Offset: 0x0003854E
	public static void GenericPurchase(float volume = 1f, float pitch = 1f)
	{
		SoundManager.PlayAudio("SFX_CustomerBuy", volume, pitch);
	}

	// Token: 0x060007A0 RID: 1952 RVA: 0x0003A35C File Offset: 0x0003855C
	public static void SetEnableSound_ExpIncrease(bool isEnable)
	{
		if (SoundManager.m_SFXVolume == 0f)
		{
			CSingleton<SoundManager>.Instance.m_ExpIncrease.Stop();
			return;
		}
		if (CSingleton<SoundManager>.Instance.m_ExpIncrease.enabled != isEnable)
		{
			CSingleton<SoundManager>.Instance.m_ExpIncrease.enabled = isEnable;
			if (isEnable)
			{
				CSingleton<SoundManager>.Instance.m_ExpIncrease.volume = SoundManager.m_SFXVolume;
				CSingleton<SoundManager>.Instance.m_ExpIncrease.Play();
				return;
			}
			CSingleton<SoundManager>.Instance.m_ExpIncrease.Stop();
		}
	}

	// Token: 0x060007A1 RID: 1953 RVA: 0x0003A3E0 File Offset: 0x000385E0
	public static void SetEnableSound_CoinIncrease(bool isEnable)
	{
		if (SoundManager.m_SFXVolume == 0f)
		{
			CSingleton<SoundManager>.Instance.m_CoinIncrease.Stop();
			return;
		}
		if (CSingleton<SoundManager>.Instance.m_CoinIncrease.enabled != isEnable)
		{
			CSingleton<SoundManager>.Instance.m_CoinIncrease.enabled = isEnable;
			if (isEnable)
			{
				CSingleton<SoundManager>.Instance.m_CoinIncrease.volume = SoundManager.m_SFXVolume;
				CSingleton<SoundManager>.Instance.m_CoinIncrease.Play();
				return;
			}
			CSingleton<SoundManager>.Instance.m_CoinIncrease.Stop();
		}
	}

	// Token: 0x060007A2 RID: 1954 RVA: 0x0003A464 File Offset: 0x00038664
	public static void SetEnableSound_GemIncrease(bool isEnable)
	{
		if (SoundManager.m_SFXVolume == 0f)
		{
			CSingleton<SoundManager>.Instance.m_GemIncrease.Stop();
			return;
		}
		if (CSingleton<SoundManager>.Instance.m_GemIncrease.enabled != isEnable)
		{
			CSingleton<SoundManager>.Instance.m_GemIncrease.enabled = isEnable;
			if (isEnable)
			{
				CSingleton<SoundManager>.Instance.m_GemIncrease.volume = SoundManager.m_SFXVolume;
				CSingleton<SoundManager>.Instance.m_GemIncrease.Play();
				return;
			}
			CSingleton<SoundManager>.Instance.m_GemIncrease.Stop();
		}
	}

	// Token: 0x060007A3 RID: 1955 RVA: 0x0003A4E8 File Offset: 0x000386E8
	public static void SetEnableSound_TamerPointIncrease(bool isEnable)
	{
		if (SoundManager.m_SFXVolume == 0f)
		{
			CSingleton<SoundManager>.Instance.m_TPIncrease.Stop();
			return;
		}
		if (CSingleton<SoundManager>.Instance.m_TPIncrease.enabled != isEnable)
		{
			CSingleton<SoundManager>.Instance.m_TPIncrease.enabled = isEnable;
			if (isEnable)
			{
				CSingleton<SoundManager>.Instance.m_TPIncrease.volume = SoundManager.m_SFXVolume;
				CSingleton<SoundManager>.Instance.m_TPIncrease.Play();
				return;
			}
			CSingleton<SoundManager>.Instance.m_TPIncrease.Stop();
		}
	}

	// Token: 0x060007A4 RID: 1956 RVA: 0x0003A56C File Offset: 0x0003876C
	public static void SetEnableSound_LevelupExpLoop(bool isEnable)
	{
		if (SoundManager.m_SFXVolume == 0f)
		{
			CSingleton<SoundManager>.Instance.m_LevelUpExpLoop.Stop();
			return;
		}
		if (CSingleton<SoundManager>.Instance.m_LevelUpExpLoop.enabled != isEnable)
		{
			CSingleton<SoundManager>.Instance.m_LevelUpExpLoop.enabled = isEnable;
			if (isEnable)
			{
				CSingleton<SoundManager>.Instance.m_LevelUpExpLoop.volume = SoundManager.m_SFXVolume;
				CSingleton<SoundManager>.Instance.m_LevelUpExpLoop.Play();
				return;
			}
			CSingleton<SoundManager>.Instance.m_LevelUpExpLoop.Stop();
		}
	}

	// Token: 0x060007A5 RID: 1957 RVA: 0x0003A5F0 File Offset: 0x000387F0
	public static void SetEnableSound_SprayLoop(bool isEnable)
	{
		if (SoundManager.m_SFXVolume == 0f)
		{
			CSingleton<SoundManager>.Instance.m_SprayLoop.Stop();
			return;
		}
		if (CSingleton<SoundManager>.Instance.m_SprayLoop.enabled != isEnable)
		{
			CSingleton<SoundManager>.Instance.m_SprayLoop.enabled = isEnable;
			if (isEnable)
			{
				CSingleton<SoundManager>.Instance.m_SprayLoop.volume = SoundManager.m_SFXVolume;
				CSingleton<SoundManager>.Instance.m_SprayLoop.Play();
				return;
			}
			CSingleton<SoundManager>.Instance.m_SprayLoop.Stop();
		}
	}

	// Token: 0x04000977 RID: 2423
	private int m_CurrentFrame;

	// Token: 0x04000978 RID: 2424
	private int m_FrameLoopLimit;

	// Token: 0x04000979 RID: 2425
	private int m_CheckFrameIndex;

	// Token: 0x0400097A RID: 2426
	private float m_MusicVolume01;

	// Token: 0x0400097B RID: 2427
	private float m_MusicVolume02;

	// Token: 0x0400097C RID: 2428
	private float m_MusicBlendSpeed = 1f;

	// Token: 0x0400097D RID: 2429
	private float m_LinearBlendAmount;

	// Token: 0x0400097E RID: 2430
	private float m_MusicLerpClipLower = 0.05f;

	// Token: 0x0400097F RID: 2431
	private float m_MusicVolumeMultiplier = 0.3f;

	// Token: 0x04000980 RID: 2432
	private float m_SFXVolumeMultiplier = 2f;

	// Token: 0x04000981 RID: 2433
	private bool m_IsMusic02;

	// Token: 0x04000982 RID: 2434
	private bool m_IsBlendingMusic;

	// Token: 0x04000983 RID: 2435
	private bool m_IsLinearBlend;

	// Token: 0x04000984 RID: 2436
	private bool m_StopEvaluateMusicEnd;

	// Token: 0x04000985 RID: 2437
	private AudioClip m_VoiceRecordClip1;

	// Token: 0x04000986 RID: 2438
	private string m_VoiceRecordFilePath;

	// Token: 0x04000987 RID: 2439
	private bool m_IsRecording;

	// Token: 0x04000988 RID: 2440
	public AudioSource m_MusicSrc01;

	// Token: 0x04000989 RID: 2441
	public AudioSource m_MusicSrc02;

	// Token: 0x0400098A RID: 2442
	public List<AudioSource> m_AudioSrcList;

	// Token: 0x0400098B RID: 2443
	public List<AudioSource> m_ExternalAudioSrcList;

	// Token: 0x0400098C RID: 2444
	private Dictionary<string, AudioClip> m_LoadedAudioClip = new Dictionary<string, AudioClip>();

	// Token: 0x0400098D RID: 2445
	private AudioClip m_QueuedMusic;

	// Token: 0x0400098E RID: 2446
	public AudioSource m_ExpIncrease;

	// Token: 0x0400098F RID: 2447
	public AudioSource m_CoinIncrease;

	// Token: 0x04000990 RID: 2448
	public AudioSource m_GemIncrease;

	// Token: 0x04000991 RID: 2449
	public AudioSource m_TPIncrease;

	// Token: 0x04000992 RID: 2450
	public AudioSource m_LevelUpExpLoop;

	// Token: 0x04000993 RID: 2451
	public AudioSource m_SprayLoop;

	// Token: 0x04000994 RID: 2452
	private static int m_MusicIndex = 7;

	// Token: 0x04000995 RID: 2453
	private static int m_SFXIndex = 7;

	// Token: 0x04000996 RID: 2454
	private static float m_MusicVolume = 1f;

	// Token: 0x04000997 RID: 2455
	private static float m_SFXVolume = 1f;

	// Token: 0x04000998 RID: 2456
	private static bool m_IsMute;
}
