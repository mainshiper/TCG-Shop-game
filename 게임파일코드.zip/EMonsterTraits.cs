﻿using System;

// Token: 0x020000EE RID: 238
public enum EMonsterTraits
{
	// Token: 0x04000D4E RID: 3406
	None,
	// Token: 0x04000D4F RID: 3407
	Power1,
	// Token: 0x04000D50 RID: 3408
	Power2,
	// Token: 0x04000D51 RID: 3409
	Power3,
	// Token: 0x04000D52 RID: 3410
	HpUp1,
	// Token: 0x04000D53 RID: 3411
	HpUp2,
	// Token: 0x04000D54 RID: 3412
	HpUp3
}
