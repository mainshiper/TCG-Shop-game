﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000047 RID: 71
public class ShelfCompartment : MonoBehaviour
{
	// Token: 0x06000372 RID: 882 RVA: 0x0001F77C File Offset: 0x0001D97C
	private void Awake()
	{
		for (int i = 0; i < this.m_PosListGrp.childCount; i++)
		{
			this.m_PosList.Add(this.m_PosListGrp.GetChild(i).transform);
		}
	}

	// Token: 0x06000373 RID: 883 RVA: 0x0001F7BC File Offset: 0x0001D9BC
	public void InitShelf(Shelf shelf)
	{
		this.m_Shelf = shelf;
		Vector3 position = this.m_CustomerStandLoc.position;
		position.y = 0f;
		this.m_CustomerStandLoc.position = position;
		for (int i = 0; i < this.m_InteractablePriceTagList.Count; i++)
		{
			this.m_InteractablePriceTagList[i].Init(this);
		}
		if (this.m_ItemNotForSale)
		{
			for (int j = 0; j < this.m_InteractablePriceTagList.Count; j++)
			{
				this.m_InteractablePriceTagList[j].gameObject.SetActive(false);
			}
		}
	}

	// Token: 0x06000374 RID: 884 RVA: 0x0001F851 File Offset: 0x0001DA51
	public bool CheckBoxType(bool isBigBox)
	{
		if (this.m_ItemAmount <= 0)
		{
			this.SetCompartmentBoxType(isBigBox);
			this.CalculatePositionList();
		}
		return this.m_IsBigBox;
	}

	// Token: 0x06000375 RID: 885 RVA: 0x0001F870 File Offset: 0x0001DA70
	public bool CheckBoxItemType(EItemType itemType)
	{
		if (this.m_InteractablePackagingBoxList.Count > 0)
		{
			EItemType itemType2 = this.m_InteractablePackagingBoxList[0].m_ItemCompartment.GetItemType();
			return itemType == itemType2;
		}
		return true;
	}

	// Token: 0x06000376 RID: 886 RVA: 0x0001F8B0 File Offset: 0x0001DAB0
	public void SetCompartmentBoxType(bool isBigBox)
	{
		this.m_IsBigBox = isBigBox;
		if (isBigBox)
		{
			this.m_CurrentItemSizeX = 4f;
			this.m_CurrentItemSizeY = 4f;
			this.m_CurrentItemSizeZ = 2f;
			return;
		}
		this.m_CurrentItemSizeX = 4f;
		this.m_CurrentItemSizeY = 4f;
		this.m_CurrentItemSizeZ = 1f;
	}

	// Token: 0x06000377 RID: 887 RVA: 0x0001F90A File Offset: 0x0001DB0A
	public void AddBox(InteractablePackagingBox_Item interactablePackagingBox)
	{
		this.m_ItemAmount++;
		this.m_InteractablePackagingBoxList.Add(interactablePackagingBox);
		this.SetCompartmentItemType(interactablePackagingBox.m_ItemCompartment.GetItemType());
		this.SetPriceTagItemAmountText();
		this.SetPriceTagVisibility(true);
	}

	// Token: 0x06000378 RID: 888 RVA: 0x0001F944 File Offset: 0x0001DB44
	public void ArrangeBoxItemBasedOnItemCount()
	{
		List<InteractablePackagingBox_Item> list = new List<InteractablePackagingBox_Item>();
		for (int i = 0; i < this.m_InteractablePackagingBoxList.Count; i++)
		{
			if (list.Count == 0)
			{
				list.Add(this.m_InteractablePackagingBoxList[i]);
			}
			else
			{
				bool flag = false;
				for (int j = 0; j < list.Count; j++)
				{
					if (this.m_InteractablePackagingBoxList[i].m_ItemCompartment.GetItemCount() >= list[j].m_ItemCompartment.GetItemCount())
					{
						flag = true;
						list.Insert(j, this.m_InteractablePackagingBoxList[i]);
						break;
					}
				}
				if (!flag)
				{
					list.Add(this.m_InteractablePackagingBoxList[i]);
				}
			}
		}
		this.m_InteractablePackagingBoxList = list;
		for (int k = 0; k < this.m_InteractablePackagingBoxList.Count; k++)
		{
			this.m_InteractablePackagingBoxList[k].transform.position = this.m_PosList[k].position;
		}
	}

	// Token: 0x06000379 RID: 889 RVA: 0x0001FA44 File Offset: 0x0001DC44
	public void RemoveBox(InteractablePackagingBox_Item interactablePackagingBox)
	{
		this.m_ItemAmount--;
		this.m_InteractablePackagingBoxList.Remove(interactablePackagingBox);
		if (this.m_ItemAmount <= 0 && (!this.m_CanLockItemLabel || !CSingleton<CGameManager>.Instance.m_LockItemLabel))
		{
			this.SetCompartmentItemType(EItemType.None);
			this.SetPriceTagVisibility(false);
		}
		this.SetPriceTagItemAmountText();
	}

	// Token: 0x0600037A RID: 890 RVA: 0x0001FA9D File Offset: 0x0001DC9D
	public EItemType CheckItemType(EItemType itemType)
	{
		if (this.m_ItemAmount <= 0)
		{
			this.SetCompartmentItemType(itemType);
			this.CalculatePositionList();
		}
		return this.m_ItemType;
	}

	// Token: 0x0600037B RID: 891 RVA: 0x0001FABB File Offset: 0x0001DCBB
	public EItemType GetItemType()
	{
		return this.m_ItemType;
	}

	// Token: 0x0600037C RID: 892 RVA: 0x0001FAC3 File Offset: 0x0001DCC3
	public int GetItemCount()
	{
		return this.m_ItemAmount;
	}

	// Token: 0x0600037D RID: 893 RVA: 0x0001FACB File Offset: 0x0001DCCB
	public int GetMaxItemCount()
	{
		return this.m_MaxItemCount;
	}

	// Token: 0x0600037E RID: 894 RVA: 0x0001FAD3 File Offset: 0x0001DCD3
	public void AddItem(Item item, bool addToFront)
	{
		this.m_ItemAmount++;
		if (addToFront)
		{
			this.m_StoredItemList.Insert(0, item);
		}
		else
		{
			this.m_StoredItemList.Add(item);
		}
		this.SetPriceTagItemAmountText();
		this.SetPriceTagItemPriceText();
	}

	// Token: 0x0600037F RID: 895 RVA: 0x0001FB10 File Offset: 0x0001DD10
	public void RemoveItem(Item item)
	{
		this.m_ItemAmount--;
		this.m_StoredItemList.Remove(item);
		if (this.m_ItemAmount <= 0 && (!this.m_CanLockItemLabel || !CSingleton<CGameManager>.Instance.m_LockItemLabel))
		{
			this.SetCompartmentItemType(EItemType.None);
		}
		this.SetPriceTagItemAmountText();
		this.SetPriceTagItemPriceText();
	}

	// Token: 0x06000380 RID: 896 RVA: 0x0001FB68 File Offset: 0x0001DD68
	public Item TakeItemToHand(bool getLastItem = true)
	{
		if (this.m_ItemAmount <= 0)
		{
			return null;
		}
		Item item = this.GetLastItem();
		if (!getLastItem)
		{
			item = this.GetFirstItem();
		}
		this.m_ItemAmount--;
		this.m_StoredItemList.Remove(item);
		if (this.m_ItemAmount <= 0 && (!this.m_CanLockItemLabel || !CSingleton<CGameManager>.Instance.m_LockItemLabel))
		{
			this.SetCompartmentItemType(EItemType.None);
		}
		this.SetPriceTagItemAmountText();
		this.SetPriceTagItemPriceText();
		return item;
	}

	// Token: 0x06000381 RID: 897 RVA: 0x0001FBDD File Offset: 0x0001DDDD
	public void RemoveLabel(bool playSound)
	{
		if (this.m_ItemAmount <= 0)
		{
			if (playSound)
			{
				SoundManager.GenericConfirm(1f, 1f);
			}
			this.SetCompartmentItemType(EItemType.None);
		}
	}

	// Token: 0x06000382 RID: 898 RVA: 0x0001FC01 File Offset: 0x0001DE01
	public bool HasEnoughSlot()
	{
		return this.m_ItemAmount < this.m_MaxItemCount;
	}

	// Token: 0x06000383 RID: 899 RVA: 0x0001FC14 File Offset: 0x0001DE14
	public Transform GetEmptySlotTransform()
	{
		return this.m_PosList[this.m_ItemAmount];
	}

	// Token: 0x06000384 RID: 900 RVA: 0x0001FC27 File Offset: 0x0001DE27
	public Transform GetLastEmptySlotTransform()
	{
		return this.m_PosList[this.m_MaxItemCount - this.m_ItemAmount - 1];
	}

	// Token: 0x06000385 RID: 901 RVA: 0x0001FC43 File Offset: 0x0001DE43
	public Transform GetEmptySlotParent()
	{
		return this.m_StoredItemListGrp;
	}

	// Token: 0x06000386 RID: 902 RVA: 0x0001FC4B File Offset: 0x0001DE4B
	public Item GetFirstItem()
	{
		return this.m_StoredItemList[0];
	}

	// Token: 0x06000387 RID: 903 RVA: 0x0001FC59 File Offset: 0x0001DE59
	public Item GetLastItem()
	{
		if (this.m_StoredItemList.Count <= 0)
		{
			return null;
		}
		return this.m_StoredItemList[this.m_ItemAmount - 1];
	}

	// Token: 0x06000388 RID: 904 RVA: 0x0001FC7E File Offset: 0x0001DE7E
	public List<InteractablePackagingBox_Item> GetInteractablePackagingBoxList()
	{
		return this.m_InteractablePackagingBoxList;
	}

	// Token: 0x06000389 RID: 905 RVA: 0x0001FC86 File Offset: 0x0001DE86
	public InteractablePackagingBox_Item GetLastInteractablePackagingBox()
	{
		return this.m_InteractablePackagingBoxList[this.m_InteractablePackagingBoxList.Count - 1];
	}

	// Token: 0x0600038A RID: 906 RVA: 0x0001FCA0 File Offset: 0x0001DEA0
	public void SetIndex(int index)
	{
		this.m_Index = index;
	}

	// Token: 0x0600038B RID: 907 RVA: 0x0001FCA9 File Offset: 0x0001DEA9
	public int GetIndex()
	{
		return this.m_Index;
	}

	// Token: 0x0600038C RID: 908 RVA: 0x0001FCB1 File Offset: 0x0001DEB1
	public int GetWarehouseIndex()
	{
		return this.m_WarehouseShelf.GetIndex();
	}

	// Token: 0x0600038D RID: 909 RVA: 0x0001FCC0 File Offset: 0x0001DEC0
	public void SetWarehouseShelf(WarehouseShelf warehouseShelf)
	{
		this.m_WarehouseShelf = warehouseShelf;
		for (int i = 0; i < this.m_InteractablePriceTagList.Count; i++)
		{
			this.m_InteractablePriceTagList[i].Init(this);
		}
	}

	// Token: 0x0600038E RID: 910 RVA: 0x0001FCFC File Offset: 0x0001DEFC
	public void SetCompartmentItemType(EItemType itemType)
	{
		this.m_ItemType = itemType;
		if (itemType == EItemType.None)
		{
			this.m_PosYOffsetInBox = 0f;
			this.m_ScaleOffsetInBox = 0f;
			this.m_CurrentItemSizeX = 1f;
			this.m_CurrentItemSizeY = 1f;
			this.m_CurrentItemSizeZ = 1f;
			this.SetPriceTagVisibility(false);
			return;
		}
		Vector3 itemDimension = InventoryBase.GetItemData(this.m_ItemType).itemDimension;
		this.m_IsTallItem = InventoryBase.GetItemData(this.m_ItemType).isTallItem;
		if (this.m_ApplyScaleOffset)
		{
			this.m_PosYOffsetInBox = InventoryBase.GetItemData(this.m_ItemType).posYOffsetInBox;
			this.m_ScaleOffsetInBox = InventoryBase.GetItemData(this.m_ItemType).scaleOffsetInBox;
		}
		this.m_CurrentItemSizeX = itemDimension.x;
		this.m_CurrentItemSizeY = itemDimension.y;
		this.m_CurrentItemSizeZ = itemDimension.z;
		this.SetPriceTagItemImage(EItemType.None);
		this.SetPriceTagVisibility(true);
	}

	// Token: 0x0600038F RID: 911 RVA: 0x0001FDE0 File Offset: 0x0001DFE0
	public void CalculatePositionList()
	{
		this.m_Width = (this.m_EndWidthLoc.position - this.m_StartLoc.position).magnitude;
		this.m_Depth = (this.m_EndDepthLoc.position - this.m_StartLoc.position).magnitude;
		this.m_Height = (this.m_EndHeightLoc.position - this.m_StartLoc.position).magnitude;
		this.m_MaxItemX = Mathf.RoundToInt((float)this.m_SizeX / this.m_CurrentItemSizeX);
		this.m_MaxItemY = Mathf.RoundToInt((float)this.m_SizeY / this.m_CurrentItemSizeY);
		this.m_MaxItemZ = Mathf.RoundToInt((float)this.m_SizeZ / this.m_CurrentItemSizeZ);
		if (this.m_IsTallItem && this.m_AffectedByTallItem)
		{
			this.m_MaxItemZ = Mathf.RoundToInt((float)this.m_SizeZ / (this.m_CurrentItemSizeZ * 2f));
		}
		this.m_MaxItemCount = this.m_MaxItemX * this.m_MaxItemY * this.m_MaxItemZ;
		this.m_ItemPosList.Clear();
		Vector3 item = default(Vector3);
		Vector3 a = this.m_StartLoc.up;
		if (!this.m_HeightGoesUp)
		{
			a = -this.m_StartLoc.up;
		}
		for (int i = 0; i < this.m_MaxItemZ; i++)
		{
			float num = this.m_Height / (float)this.m_MaxItemZ / 2f;
			if (this.m_IsTallItem && this.m_AffectedByTallItem)
			{
				num = this.m_Height / (float)this.m_MaxItemZ;
			}
			float d = num * (float)(i * 2 + 1);
			for (int j = 0; j < this.m_MaxItemY; j++)
			{
				float d2 = this.m_Depth / (float)this.m_MaxItemY / 2f * (float)(j * 2 + 1);
				for (int k = 0; k < this.m_MaxItemX; k++)
				{
					float d3 = this.m_Width / (float)this.m_MaxItemX / 2f * (float)(k * 2 + 1);
					item = this.m_StartLoc.position + -this.m_StartLoc.right * d3 + this.m_StartLoc.forward * d2 + (a * d + a * -this.m_PosYOffsetInBox);
					this.m_ItemPosList.Add(item);
				}
			}
		}
		for (int l = 0; l < this.m_ItemPosList.Count; l++)
		{
			this.m_PosList[l].transform.position = this.m_ItemPosList[l];
			this.m_PosList[l].transform.rotation = this.m_StartLoc.rotation;
			this.m_PosList[l].transform.localScale = Vector3.one + Vector3.one * this.m_ScaleOffsetInBox;
		}
	}

	// Token: 0x06000390 RID: 912 RVA: 0x000200FC File Offset: 0x0001E2FC
	public void SpawnItem(int amount, bool spawnFromFront)
	{
		ItemMeshData itemMeshData = InventoryBase.GetItemMeshData(this.m_ItemType);
		this.m_ItemAmount = Mathf.Clamp(amount, 0, this.m_ItemPosList.Count);
		int num = 0;
		while (num < this.m_ItemPosList.Count && num < amount)
		{
			Item item = ItemSpawnManager.GetItem(this.m_StoredItemListGrp);
			item.SetMesh(itemMeshData.mesh, itemMeshData.material, this.m_ItemType, itemMeshData.meshSecondary, itemMeshData.materialSecondary);
			if (spawnFromFront)
			{
				item.transform.position = this.m_PosList[num].transform.position;
				item.transform.localScale = this.m_PosList[num].localScale;
			}
			else
			{
				item.transform.position = this.m_PosList[this.m_MaxItemCount - num - 1].transform.position;
				item.transform.localScale = this.m_PosList[this.m_MaxItemCount - num - 1].localScale;
			}
			item.transform.rotation = this.m_StartLoc.rotation;
			item.gameObject.SetActive(true);
			if (spawnFromFront)
			{
				this.m_StoredItemList.Add(item);
			}
			else
			{
				this.m_StoredItemList.Insert(0, item);
			}
			num++;
		}
		this.SetPriceTagItemAmountText();
		this.SetPriceTagItemPriceText();
	}

	// Token: 0x06000391 RID: 913 RVA: 0x00020260 File Offset: 0x0001E460
	public void RefreshItemPosition(bool spawnFromFront)
	{
		for (int i = 0; i < this.m_StoredItemList.Count; i++)
		{
			if (spawnFromFront)
			{
				this.m_StoredItemList[i].transform.position = this.m_PosList[i].transform.position;
			}
			else
			{
				this.m_StoredItemList[this.m_StoredItemList.Count - i - 1].transform.position = this.m_PosList[this.m_MaxItemCount - i - 1].transform.position;
			}
		}
	}

	// Token: 0x06000392 RID: 914 RVA: 0x000202FC File Offset: 0x0001E4FC
	public void SetPriceTagVisibility(bool isVisible)
	{
		if (this.m_ItemNotForSale)
		{
			return;
		}
		for (int i = 0; i < this.m_InteractablePriceTagList.Count; i++)
		{
			this.m_InteractablePriceTagList[i].SetVisibility(isVisible);
		}
	}

	// Token: 0x06000393 RID: 915 RVA: 0x0002033C File Offset: 0x0001E53C
	public void SetIgnoreCull(bool ignoreCull)
	{
		if (this.m_ItemNotForSale)
		{
			return;
		}
		for (int i = 0; i < this.m_InteractablePriceTagList.Count; i++)
		{
			this.m_InteractablePriceTagList[i].SetIgnoreCull(ignoreCull);
		}
	}

	// Token: 0x06000394 RID: 916 RVA: 0x0002037C File Offset: 0x0001E57C
	public void SetPriceTagItemImage(EItemType itemType = EItemType.None)
	{
		if (this.m_ItemNotForSale)
		{
			return;
		}
		if (this.m_CanPutItem)
		{
			itemType = this.GetItemType();
		}
		else if (this.m_CanPutBox && this.m_InteractablePackagingBoxList.Count > 0)
		{
			itemType = this.m_InteractablePackagingBoxList[0].m_ItemCompartment.GetItemType();
		}
		for (int i = 0; i < this.m_InteractablePriceTagList.Count; i++)
		{
			this.m_InteractablePriceTagList[i].SetItemImage(itemType);
		}
	}

	// Token: 0x06000395 RID: 917 RVA: 0x000203FC File Offset: 0x0001E5FC
	public void SetPriceTagItemAmountText()
	{
		if (this.m_ItemNotForSale)
		{
			return;
		}
		if (this.m_CanPutItem)
		{
			for (int i = 0; i < this.m_InteractablePriceTagList.Count; i++)
			{
				this.m_InteractablePriceTagList[i].SetAmountText(this.m_ItemAmount);
			}
			return;
		}
		if (this.m_CanPutBox)
		{
			int num = 0;
			for (int j = 0; j < this.m_InteractablePackagingBoxList.Count; j++)
			{
				num += this.m_InteractablePackagingBoxList[j].m_ItemCompartment.GetItemCount();
			}
			for (int k = 0; k < this.m_InteractablePriceTagList.Count; k++)
			{
				this.m_InteractablePriceTagList[k].SetAmountText(num);
			}
		}
	}

	// Token: 0x06000396 RID: 918 RVA: 0x000204AC File Offset: 0x0001E6AC
	public void SetPriceTagItemPriceText()
	{
		if (this.m_ItemNotForSale)
		{
			return;
		}
		if (this.m_CanPutItem)
		{
			this.m_CurrentPrice = CPlayerData.GetItemPrice(this.m_ItemType, false);
			for (int i = 0; i < this.m_InteractablePriceTagList.Count; i++)
			{
				this.m_InteractablePriceTagList[i].SetPriceText(this.m_CurrentPrice);
			}
			return;
		}
		if (this.m_CanPutBox)
		{
			for (int j = 0; j < this.m_InteractablePriceTagList.Count; j++)
			{
			}
		}
	}

	// Token: 0x06000397 RID: 919 RVA: 0x00020528 File Offset: 0x0001E728
	public void RefreshPriceTagItemPriceText()
	{
		if (this.m_ItemNotForSale)
		{
			return;
		}
		for (int i = 0; i < this.m_InteractablePriceTagList.Count; i++)
		{
			this.m_InteractablePriceTagList[i].RefreshPriceText();
		}
	}

	// Token: 0x06000398 RID: 920 RVA: 0x00020568 File Offset: 0x0001E768
	public void SetVisibilityHalfItemMesh(bool isVisible)
	{
		for (int i = 0; i < this.m_StoredItemList.Count; i++)
		{
			if (isVisible)
			{
				this.m_StoredItemList[i].m_Mesh.enabled = true;
			}
			else if (this.m_StoredItemList.Count > 8)
			{
				if (i / this.m_MaxItemX % 2 == 1)
				{
					this.m_StoredItemList[i].m_Mesh.enabled = false;
				}
				else
				{
					this.m_StoredItemList[i].m_Mesh.enabled = true;
				}
			}
		}
	}

	// Token: 0x06000399 RID: 921 RVA: 0x000205F4 File Offset: 0x0001E7F4
	public void DisableAllItem()
	{
		for (int i = 0; i < this.m_StoredItemList.Count; i++)
		{
			if (this.m_StoredItemList[i])
			{
				this.m_StoredItemList[i].DisableItem();
			}
		}
	}

	// Token: 0x0600039A RID: 922 RVA: 0x0002063B File Offset: 0x0001E83B
	public Shelf GetShelf()
	{
		return this.m_Shelf;
	}

	// Token: 0x0600039B RID: 923 RVA: 0x00020643 File Offset: 0x0001E843
	public WarehouseShelf GetWarehouseShelf()
	{
		return this.m_WarehouseShelf;
	}

	// Token: 0x0400040C RID: 1036
	private Shelf m_Shelf;

	// Token: 0x0400040D RID: 1037
	public bool m_CanPutItem = true;

	// Token: 0x0400040E RID: 1038
	public bool m_CanPutBox;

	// Token: 0x0400040F RID: 1039
	public bool m_ItemNotForSale;

	// Token: 0x04000410 RID: 1040
	public bool m_CanLockItemLabel = true;

	// Token: 0x04000411 RID: 1041
	public Transform m_StartLoc;

	// Token: 0x04000412 RID: 1042
	public Transform m_EndWidthLoc;

	// Token: 0x04000413 RID: 1043
	public Transform m_EndDepthLoc;

	// Token: 0x04000414 RID: 1044
	public Transform m_EndHeightLoc;

	// Token: 0x04000415 RID: 1045
	public Transform m_PosListGrp;

	// Token: 0x04000416 RID: 1046
	public Transform m_CustomerStandLoc;

	// Token: 0x04000417 RID: 1047
	public Transform m_StoredItemListGrp;

	// Token: 0x04000418 RID: 1048
	private List<Item> m_StoredItemList = new List<Item>();

	// Token: 0x04000419 RID: 1049
	private List<Transform> m_PosList = new List<Transform>();

	// Token: 0x0400041A RID: 1050
	private List<InteractablePackagingBox_Item> m_InteractablePackagingBoxList = new List<InteractablePackagingBox_Item>();

	// Token: 0x0400041B RID: 1051
	public List<InteractablePriceTag> m_InteractablePriceTagList;

	// Token: 0x0400041C RID: 1052
	public bool m_ApplyScaleOffset;

	// Token: 0x0400041D RID: 1053
	public bool m_HeightGoesUp;

	// Token: 0x0400041E RID: 1054
	public bool m_AffectedByTallItem;

	// Token: 0x0400041F RID: 1055
	public int m_SizeX = 4;

	// Token: 0x04000420 RID: 1056
	public int m_SizeY = 8;

	// Token: 0x04000421 RID: 1057
	public int m_SizeZ = 1;

	// Token: 0x04000422 RID: 1058
	private int m_Index;

	// Token: 0x04000423 RID: 1059
	private int m_ItemAmount;

	// Token: 0x04000424 RID: 1060
	private int m_MaxItemCount;

	// Token: 0x04000425 RID: 1061
	private float m_Width;

	// Token: 0x04000426 RID: 1062
	private float m_Depth;

	// Token: 0x04000427 RID: 1063
	private float m_Height;

	// Token: 0x04000428 RID: 1064
	private float m_CurrentItemSizeX = 1f;

	// Token: 0x04000429 RID: 1065
	private float m_CurrentItemSizeY = 1f;

	// Token: 0x0400042A RID: 1066
	private float m_CurrentItemSizeZ = 1f;

	// Token: 0x0400042B RID: 1067
	private float m_PosYOffsetInBox;

	// Token: 0x0400042C RID: 1068
	private float m_ScaleOffsetInBox;

	// Token: 0x0400042D RID: 1069
	private float m_CurrentPrice;

	// Token: 0x0400042E RID: 1070
	private int m_MaxItemX;

	// Token: 0x0400042F RID: 1071
	private int m_MaxItemY;

	// Token: 0x04000430 RID: 1072
	private int m_MaxItemZ;

	// Token: 0x04000431 RID: 1073
	private EItemType m_ItemType = EItemType.None;

	// Token: 0x04000432 RID: 1074
	private bool m_IsTallItem;

	// Token: 0x04000433 RID: 1075
	private bool m_IsBigBox;

	// Token: 0x04000434 RID: 1076
	private List<Vector3> m_ItemPosList = new List<Vector3>();

	// Token: 0x04000435 RID: 1077
	private WarehouseShelf m_WarehouseShelf;
}
