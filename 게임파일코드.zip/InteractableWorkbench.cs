﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200002C RID: 44
public class InteractableWorkbench : InteractableObject
{
	// Token: 0x06000235 RID: 565 RVA: 0x0001564C File Offset: 0x0001384C
	protected override void Awake()
	{
		base.Awake();
		ShelfManager.InitWorkbench(this);
		this.m_JankBoxAnim.gameObject.SetActive(false);
		for (int i = 0; i < this.m_CardEnterBoxAnimList.Count; i++)
		{
			Card3dUIGroup cardUI = CSingleton<Card3dUISpawner>.Instance.GetCardUI();
			cardUI.transform.position = this.m_InteractableCard3dList[i].transform.position;
			cardUI.transform.rotation = this.m_InteractableCard3dList[i].transform.rotation;
			this.m_InteractableCard3dList[i].SetCardUIFollow(cardUI);
			cardUI.SetVisibility(false);
			this.m_CardEnterBoxAnimList[i].gameObject.SetActive(false);
		}
	}

	// Token: 0x06000236 RID: 566 RVA: 0x00015710 File Offset: 0x00013910
	protected override void Update()
	{
		base.Update();
		if (this.m_IsPlayCardEnterAnim)
		{
			this.m_CardEnterTimer += Time.deltaTime;
			if (this.m_CardEnterTimer > 0.1f)
			{
				this.m_CardEnterBoxAnimList[this.m_CardEnterIndex].gameObject.SetActive(false);
				this.m_CardEnterBoxAnimList[this.m_CardEnterIndex].gameObject.SetActive(true);
				this.m_InteractableCard3dList[this.m_CardEnterIndex].m_Card3dUI.SetVisibility(true);
				this.m_CardEnterBoxAnimList[this.m_CardEnterIndex].Play();
				this.m_CardEnterTimer = 0f;
				this.m_CardEnterIndex++;
				if (this.m_CardEnterIndex >= this.m_InteractableCard3dList.Count)
				{
					this.m_IsPlayCardEnterAnim = false;
					this.m_CardEnterIndex = 0;
				}
			}
		}
	}

	// Token: 0x06000237 RID: 567 RVA: 0x000157F8 File Offset: 0x000139F8
	public override void OnMouseButtonUp()
	{
		CSingleton<InteractionPlayerController>.Instance.OnEnterWorkbenchMode();
		this.OnRaycastEnded();
		InteractionPlayerController.SetPlayerPos(this.m_LockPlayerPos.position);
		CSingleton<InteractionPlayerController>.Instance.EnterUIMode();
		CSingleton<InteractionPlayerController>.Instance.ForceLookAt(this.m_PlayerLookRot, 3f);
		this.m_NavMeshCutWhenManned.SetActive(true);
		WorkbenchUIScreen.OpenScreen(this);
	}

	// Token: 0x06000238 RID: 568 RVA: 0x00015856 File Offset: 0x00013A56
	public override void OnRightMouseButtonUp()
	{
		base.OnRightMouseButtonUp();
	}

	// Token: 0x06000239 RID: 569 RVA: 0x00015860 File Offset: 0x00013A60
	public override void OnPressEsc()
	{
		CSingleton<InteractionPlayerController>.Instance.OnExitWorkbenchMode();
		this.m_NavMeshCutWhenManned.SetActive(false);
		this.m_JankBoxAnim.gameObject.SetActive(false);
		this.m_JankBoxAnim.SetBool("IsClosing", false);
		for (int i = 0; i < this.m_CardEnterBoxAnimList.Count; i++)
		{
			this.m_InteractableCard3dList[i].m_Card3dUI.SetVisibility(false);
			this.m_CardEnterBoxAnimList[i].gameObject.SetActive(false);
		}
	}

	// Token: 0x0600023A RID: 570 RVA: 0x000158EC File Offset: 0x00013AEC
	public void PlayBundlingCardBoxSequence(List<CardData> cardDataListShown, ECardExpansionType cardExpansionType)
	{
		this.m_JankBoxAnim.gameObject.SetActive(true);
		this.m_JankBoxAnim.SetBool("IsClosing", true);
		ItemMeshData itemMeshData = InventoryBase.GetItemMeshData(this.GetBulkBoxItemType(cardExpansionType));
		this.m_JankBoxSkinMesh.material = itemMeshData.material;
		for (int i = 0; i < cardDataListShown.Count; i++)
		{
			this.m_InteractableCard3dList[i].m_Card3dUI.m_CardUI.SetCardUI(cardDataListShown[i]);
		}
		this.m_IsPlayCardEnterAnim = true;
	}

	// Token: 0x0600023B RID: 571 RVA: 0x00015974 File Offset: 0x00013B74
	public void OnTaskCompleted(ECardExpansionType cardExpansionType)
	{
		this.m_JankBoxAnim.gameObject.SetActive(false);
		EItemType bulkBoxItemType = this.GetBulkBoxItemType(cardExpansionType);
		ItemMeshData itemMeshData = InventoryBase.GetItemMeshData(bulkBoxItemType);
		Item item = ItemSpawnManager.GetItem(this.m_SpawnItemPos);
		item.SetMesh(itemMeshData.mesh, itemMeshData.material, bulkBoxItemType, itemMeshData.meshSecondary, itemMeshData.materialSecondary);
		item.transform.position = this.m_SpawnItemPos.position;
		item.transform.rotation = this.m_SpawnItemPos.rotation;
		item.gameObject.SetActive(true);
		CSingleton<InteractionPlayerController>.Instance.AddHoldItemToFront(item);
	}

	// Token: 0x0600023C RID: 572 RVA: 0x00015A14 File Offset: 0x00013C14
	public EItemType GetBulkBoxItemType(ECardExpansionType cardExpansionType)
	{
		EItemType result = EItemType.BulkBox_TetramonBase;
		if (cardExpansionType == ECardExpansionType.Destiny)
		{
			result = EItemType.BulkBox_TetramonDestiny;
		}
		return result;
	}

	// Token: 0x0600023D RID: 573 RVA: 0x00015A2C File Offset: 0x00013C2C
	public void DispenseItemFromBox(InteractablePackagingBox_Item itemBox, bool isPlayer)
	{
		if (itemBox && itemBox.IsBoxOpened())
		{
			if (this.IsValidItemType(itemBox.m_ItemCompartment.GetItemType()))
			{
				if (itemBox.m_ItemCompartment.GetItemCount() > 0)
				{
					if (this.HasEnoughSlot())
					{
						Item firstItem = itemBox.m_ItemCompartment.GetFirstItem();
						this.AddItem(firstItem, true);
						itemBox.m_ItemCompartment.RemoveItem(firstItem);
						if (isPlayer)
						{
							SoundManager.GenericPop(1f, 1f);
							return;
						}
					}
					else if (isPlayer)
					{
						NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.AutoCleanserNoSlot);
						return;
					}
				}
				else if (isPlayer)
				{
					NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.BoxNoItem);
					return;
				}
			}
			else if (isPlayer)
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.CanOnlyPutBulkBox);
			}
		}
	}

	// Token: 0x0600023E RID: 574 RVA: 0x00015AC8 File Offset: 0x00013CC8
	public void AddItem(Item item, bool addToFront)
	{
		this.m_ItemAmount++;
		if (addToFront)
		{
			this.m_StoredItemList.Insert(0, item);
		}
		else
		{
			this.m_StoredItemList.Add(item);
		}
		item.LerpToTransform(this.m_PosList[this.m_ItemAmount - 1], this.m_PosList[this.m_ItemAmount - 1], false);
	}

	// Token: 0x0600023F RID: 575 RVA: 0x00015B2E File Offset: 0x00013D2E
	public void RemoveItem(Item item)
	{
		this.m_ItemAmount--;
		this.m_StoredItemList.Remove(item);
	}

	// Token: 0x06000240 RID: 576 RVA: 0x00015B4C File Offset: 0x00013D4C
	public Item TakeItemToHand(bool getLastItem = true)
	{
		if (this.m_ItemAmount <= 0)
		{
			return null;
		}
		Item item = this.GetLastItem();
		if (!getLastItem)
		{
			item = this.GetFirstItem();
		}
		this.m_ItemAmount--;
		this.m_StoredItemList.Remove(item);
		return item;
	}

	// Token: 0x06000241 RID: 577 RVA: 0x00015B94 File Offset: 0x00013D94
	public void RemoveItemFromShelf(bool isPlayer, InteractablePackagingBox_Item packageBox)
	{
		if (packageBox.IsBoxOpened())
		{
			if (this.m_StoredItemList.Count <= 0)
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.ShelfNoItem);
				return;
			}
			Item item = this.GetFirstItem();
			if (item)
			{
				if (item.GetItemType() != packageBox.GetItemType() && packageBox.m_ItemCompartment.GetItemCount() != 0)
				{
					NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.BoxWrongItemType);
					Debug.Log("Item type not match");
					return;
				}
				packageBox.SetItemType(item.GetItemType());
				packageBox.m_ItemCompartment.CheckItemType(item.GetItemType());
				if (!packageBox.m_ItemCompartment.HasEnoughSlot())
				{
					NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.BoxNoSlot);
					Debug.Log("Box no slot");
					return;
				}
				Transform lastEmptySlotTransform = packageBox.m_ItemCompartment.GetLastEmptySlotTransform();
				Transform emptySlotParent = packageBox.m_ItemCompartment.GetEmptySlotParent();
				item.LerpToTransform(lastEmptySlotTransform, emptySlotParent, false);
				item = this.TakeItemToHand(false);
				packageBox.m_ItemCompartment.AddItem(item, true);
				packageBox.m_ItemCompartment.SetPriceTagVisibility(false);
				if (isPlayer)
				{
					SoundManager.GenericPop(1f, 0.9f);
					return;
				}
			}
			else
			{
				Debug.Log("No item on workbench");
			}
		}
	}

	// Token: 0x06000242 RID: 578 RVA: 0x00015C9F File Offset: 0x00013E9F
	public bool HasEnoughSlot()
	{
		return this.m_ItemAmount < this.m_PosList.Count;
	}

	// Token: 0x06000243 RID: 579 RVA: 0x00015CB7 File Offset: 0x00013EB7
	public int GetItemCount()
	{
		return this.m_ItemAmount;
	}

	// Token: 0x06000244 RID: 580 RVA: 0x00015CBF File Offset: 0x00013EBF
	public Item GetFirstItem()
	{
		return this.m_StoredItemList[0];
	}

	// Token: 0x06000245 RID: 581 RVA: 0x00015CCD File Offset: 0x00013ECD
	public Item GetLastItem()
	{
		if (this.m_StoredItemList.Count <= 0)
		{
			return null;
		}
		return this.m_StoredItemList[this.m_ItemAmount - 1];
	}

	// Token: 0x06000246 RID: 582 RVA: 0x00015CF2 File Offset: 0x00013EF2
	public bool IsValidItemType(EItemType itemType)
	{
		return itemType == EItemType.BulkBox_TetramonBase || itemType == EItemType.BulkBox_TetramonDestiny;
	}

	// Token: 0x06000247 RID: 583 RVA: 0x00015D04 File Offset: 0x00013F04
	public void LoadData(WorkbenchSaveData saveData)
	{
		for (int i = 0; i < saveData.itemTypeList.Count; i++)
		{
			ItemMeshData itemMeshData = InventoryBase.GetItemMeshData(saveData.itemTypeList[i]);
			Item item = ItemSpawnManager.GetItem(this.m_PosList[i]);
			item.SetMesh(itemMeshData.mesh, itemMeshData.material, saveData.itemTypeList[i], itemMeshData.meshSecondary, itemMeshData.materialSecondary);
			item.transform.localPosition = Vector3.zero;
			item.transform.localRotation = Quaternion.identity;
			item.gameObject.SetActive(true);
			this.AddItem(item, true);
		}
	}

	// Token: 0x04000273 RID: 627
	public Transform m_LockPlayerPos;

	// Token: 0x04000274 RID: 628
	public Transform m_PlayerLookRot;

	// Token: 0x04000275 RID: 629
	public Transform m_SpawnItemPos;

	// Token: 0x04000276 RID: 630
	public List<Transform> m_PosList;

	// Token: 0x04000277 RID: 631
	public GameObject m_NavMeshCutWhenManned;

	// Token: 0x04000278 RID: 632
	public Animator m_JankBoxAnim;

	// Token: 0x04000279 RID: 633
	public SkinnedMeshRenderer m_JankBoxSkinMesh;

	// Token: 0x0400027A RID: 634
	public List<Animation> m_CardEnterBoxAnimList;

	// Token: 0x0400027B RID: 635
	public List<InteractableCard3d> m_InteractableCard3dList;

	// Token: 0x0400027C RID: 636
	private bool m_IsPlayCardEnterAnim;

	// Token: 0x0400027D RID: 637
	private int m_CardEnterIndex;

	// Token: 0x0400027E RID: 638
	private float m_CardEnterTimer;

	// Token: 0x0400027F RID: 639
	private int m_ItemAmount;

	// Token: 0x04000280 RID: 640
	public List<Item> m_StoredItemList;
}
