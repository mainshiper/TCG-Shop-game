﻿using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000111 RID: 273
public class GamepadSettingLinker : MonoBehaviour
{
	// Token: 0x06000806 RID: 2054 RVA: 0x0003C7EA File Offset: 0x0003A9EA
	private void Awake()
	{
		if (this.m_SliderActiveThumbstickIcon)
		{
			this.m_SliderActiveThumbstickIcon.SetActive(false);
		}
	}

	// Token: 0x06000807 RID: 2055 RVA: 0x0003C808 File Offset: 0x0003AA08
	public void OnPressConfirm()
	{
		if (this.m_Toggle)
		{
			this.m_Toggle.isOn = !this.m_Toggle.isOn;
		}
		if (this.m_Dropdown)
		{
			if (!this.m_IsShown)
			{
				this.m_Dropdown.Show();
				this.m_IsShown = true;
				ControllerScreenUIExtManager.SetLockLJoystickVertical(true);
				CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(true);
				InputManager.SetSliderActive(true);
			}
			else
			{
				this.m_Dropdown.Hide();
				this.m_Dropdown.interactable = false;
				this.m_Dropdown.interactable = true;
				this.m_IsShown = false;
				ControllerScreenUIExtManager.SetLockLJoystickVertical(false);
				CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(false);
				InputManager.SetSliderActive(false);
			}
		}
		if (this.m_Slider)
		{
			if (!this.m_IsShown)
			{
				this.m_Slider.interactable = true;
				this.m_Slider.Select();
				this.m_IsShown = true;
				ControllerScreenUIExtManager.SetLockLJoystickVertical(true);
				CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(true);
				this.m_SliderActiveThumbstickIcon.SetActive(true);
				InputManager.SetSliderActive(true);
			}
			else
			{
				this.m_Slider.interactable = false;
				this.m_Slider.interactable = true;
				this.m_IsShown = false;
				ControllerScreenUIExtManager.SetLockLJoystickVertical(false);
				CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(false);
				this.m_SliderActiveThumbstickIcon.SetActive(false);
				InputManager.SetSliderActive(false);
			}
		}
		if (this.m_KeybindSetting && this.m_KeybindSetting.m_IsGamepad && this.m_CanUpdateKeybind && !this.m_IsShown)
		{
			this.m_IsShown = true;
			this.m_KeybindSetting.OnPressButton();
			ControllerScreenUIExtManager.SetLockLJoystickVertical(true);
		}
	}

	// Token: 0x06000808 RID: 2056 RVA: 0x0003C99C File Offset: 0x0003AB9C
	public void OnPressCancel()
	{
		if (this.m_Dropdown && this.m_IsShown)
		{
			this.m_Dropdown.Hide();
			this.m_Dropdown.interactable = false;
			this.m_Dropdown.interactable = true;
			this.m_IsShown = false;
			ControllerScreenUIExtManager.SetLockLJoystickVertical(false);
			CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(false);
			InputManager.SetSliderActive(false);
		}
		if (this.m_Slider && this.m_IsShown)
		{
			this.m_Slider.interactable = false;
			this.m_Slider.interactable = true;
			this.m_IsShown = false;
			ControllerScreenUIExtManager.SetLockLJoystickVertical(false);
			CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(false);
			InputManager.SetSliderActive(false);
			this.m_SliderActiveThumbstickIcon.SetActive(false);
		}
	}

	// Token: 0x06000809 RID: 2057 RVA: 0x0003CA56 File Offset: 0x0003AC56
	public void OnFinishSetGamepadKeybind()
	{
		if (this.m_KeybindSetting && this.m_IsShown)
		{
			this.m_IsShown = false;
			ControllerScreenUIExtManager.SetLockLJoystickVertical(false);
			base.StartCoroutine(this.ResetCanUpdateKeybind());
		}
	}

	// Token: 0x0600080A RID: 2058 RVA: 0x0003CA87 File Offset: 0x0003AC87
	private IEnumerator ResetCanUpdateKeybind()
	{
		this.m_CanUpdateKeybind = false;
		yield return new WaitForSecondsRealtime(0.1f);
		this.m_CanUpdateKeybind = true;
		yield break;
	}

	// Token: 0x04000F55 RID: 3925
	public Toggle m_Toggle;

	// Token: 0x04000F56 RID: 3926
	public TMP_Dropdown m_Dropdown;

	// Token: 0x04000F57 RID: 3927
	public Slider m_Slider;

	// Token: 0x04000F58 RID: 3928
	public GameObject m_SliderActiveThumbstickIcon;

	// Token: 0x04000F59 RID: 3929
	public KeybindSetting m_KeybindSetting;

	// Token: 0x04000F5A RID: 3930
	private bool m_IsShown;

	// Token: 0x04000F5B RID: 3931
	private bool m_CanUpdateKeybind = true;
}
