﻿using System;

// Token: 0x020000F8 RID: 248
public enum EIAPDataType
{
	// Token: 0x04000DAB RID: 3499
	GoldCount,
	// Token: 0x04000DAC RID: 3500
	GemCount,
	// Token: 0x04000DAD RID: 3501
	InstantCrate,
	// Token: 0x04000DAE RID: 3502
	IAPGem1,
	// Token: 0x04000DAF RID: 3503
	IAPGem2,
	// Token: 0x04000DB0 RID: 3504
	IAPGem3,
	// Token: 0x04000DB1 RID: 3505
	IAPGem4,
	// Token: 0x04000DB2 RID: 3506
	IAPGem5,
	// Token: 0x04000DB3 RID: 3507
	IAPGem6,
	// Token: 0x04000DB4 RID: 3508
	IAPGem7,
	// Token: 0x04000DB5 RID: 3509
	PermaGoldCount,
	// Token: 0x04000DB6 RID: 3510
	PermaGemCount
}
