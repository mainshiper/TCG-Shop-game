﻿using System;
using System.Collections;
using System.Collections.Generic;
using I2.Loc;
using TMPro;
using UnityEngine;

// Token: 0x02000065 RID: 101
public class ExpansionShopUIScreen : GenericSliderScreen
{
	// Token: 0x06000457 RID: 1111 RVA: 0x000265BF File Offset: 0x000247BF
	protected override void Init()
	{
		this.EvaluateShopPanelUI();
		base.Init();
	}

	// Token: 0x06000458 RID: 1112 RVA: 0x000265CD File Offset: 0x000247CD
	protected override void OnOpenScreen()
	{
		this.Init();
		base.OnOpenScreen();
	}

	// Token: 0x06000459 RID: 1113 RVA: 0x000265DC File Offset: 0x000247DC
	private void EvaluateShopPanelUI()
	{
		for (int i = 0; i < this.m_ExpansionShopPanelUIList.Count; i++)
		{
			this.m_ExpansionShopPanelUIList[i].SetActive(false);
		}
		this.m_ShopA_HighlightBtn.SetActive(!this.m_IsShopB);
		this.m_ShopB_HighlightBtn.SetActive(this.m_IsShopB);
		if (this.m_IsShopB)
		{
			if (this.m_LevelRequirementString == "")
			{
				this.m_LevelRequirementString = this.m_ShopB_LevelRequirementText.text;
			}
			this.m_ShopB_PriceText.text = GameInstance.GetPriceString(this.m_ShopB_UnlockPrice, false, true, false, "F2");
			this.m_ShopB_LevelRequirementText.text = LocalizationManager.GetTranslation(this.m_LevelRequirementString, true, 0, true, false, null, null, true).Replace("XXX", this.m_ShopB_UnlockLevelRequired.ToString());
			this.m_ShopB_UnlockGrp.SetActive(!CPlayerData.m_IsWarehouseRoomUnlocked);
			if (CSingleton<CGameManager>.Instance.m_IsPrologue)
			{
				this.m_ShopB_UnlockGrpPrologue.SetActive(true);
			}
			if (CPlayerData.m_ShopLevel + 1 >= this.m_ShopB_UnlockLevelRequired)
			{
				this.m_ShopB_LevelRequirementText.enabled = false;
				this.m_ShopB_LockPurchaseBtn.SetActive(false);
			}
			else
			{
				this.m_ShopB_LevelRequirementText.enabled = true;
				this.m_ShopB_LockPurchaseBtn.SetActive(true);
			}
			if (!CPlayerData.m_IsWarehouseRoomUnlocked)
			{
				return;
			}
		}
		else
		{
			this.m_ShopB_UnlockGrp.SetActive(false);
		}
		int num = 20;
		if (this.m_IsShopB)
		{
			num = 8;
		}
		for (int j = 0; j < num; j++)
		{
			this.m_ExpansionShopPanelUIList[j].Init(this, j, this.m_IsShopB);
			this.m_ExpansionShopPanelUIList[j].SetActive(true);
			this.m_ScrollEndPosParent = this.m_ExpansionShopPanelUIList[j].gameObject;
		}
	}

	// Token: 0x0600045A RID: 1114 RVA: 0x0002678F File Offset: 0x0002498F
	public void OnPressPanelUIButton(int index)
	{
	}

	// Token: 0x0600045B RID: 1115 RVA: 0x00026791 File Offset: 0x00024991
	public void OnPressShopSubButton(bool isShopB)
	{
		this.m_IsShopB = isShopB;
		this.EvaluateShopPanelUI();
		base.StartCoroutine(base.EvaluateActiveRestockUIScroller());
		this.m_PosX = 0f;
		this.m_LerpPosX = 0f;
	}

	// Token: 0x0600045C RID: 1116 RVA: 0x000267C4 File Offset: 0x000249C4
	public void OnPressUnlockShopB()
	{
		if (CSingleton<CGameManager>.Instance.m_IsPrologue)
		{
			return;
		}
		if (CPlayerData.m_IsWarehouseRoomUnlocked)
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.AlreadyPurchased);
			return;
		}
		if (CPlayerData.m_ShopLevel + 1 < this.m_ShopB_UnlockLevelRequired)
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.ShopLevelNotEnough);
			return;
		}
		if (CPlayerData.m_CoinAmount >= this.m_ShopB_UnlockPrice)
		{
			CEventManager.QueueEvent(new CEventPlayer_ReduceCoin(this.m_ShopB_UnlockPrice, false));
			CSingleton<UnlockRoomManager>.Instance.SetUnlockWarehouseRoom(true);
			AchievementManager.OnShopLotBUnlocked();
			CEventManager.QueueEvent(new CEventPlayer_AddShopExp(Mathf.Clamp(Mathf.RoundToInt(this.m_ShopB_UnlockPrice / 100f), 5, 100), false));
			base.StartCoroutine(this.DelaySaveShelfData());
			this.m_ShopB_UnlockGrp.SetActive(false);
			this.OnPressShopSubButton(true);
			CPlayerData.m_GameReportDataCollect.upgradeCost = CPlayerData.m_GameReportDataCollect.upgradeCost - this.m_ShopB_UnlockPrice;
			CPlayerData.m_GameReportDataCollectPermanent.upgradeCost = CPlayerData.m_GameReportDataCollectPermanent.upgradeCost - this.m_ShopB_UnlockPrice;
			SoundManager.PlayAudio("SFX_CustomerBuy", 0.6f, 1f);
			return;
		}
		NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.Money);
	}

	// Token: 0x0600045D RID: 1117 RVA: 0x000268BC File Offset: 0x00024ABC
	public void EvaluateCartCheckout(float totalCost, int index, bool isShopB)
	{
		if (this.m_IsShopB != isShopB)
		{
			return;
		}
		CPlayerData.GetUnlockShopRoomCost(CPlayerData.m_UnlockRoomCount);
		if (isShopB)
		{
			CPlayerData.GetUnlockWarehouseRoomCost(CPlayerData.m_UnlockWarehouseRoomCount);
		}
		CEventManager.QueueEvent(new CEventPlayer_ReduceCoin(totalCost, false));
		if (isShopB)
		{
			CSingleton<UnlockRoomManager>.Instance.StartUnlockNextWarehouseRoom();
		}
		else
		{
			CSingleton<UnlockRoomManager>.Instance.StartUnlockNextRoom();
		}
		CEventManager.QueueEvent(new CEventPlayer_AddShopExp(Mathf.Clamp(Mathf.RoundToInt(totalCost / 100f), 5, 100), false));
		base.StartCoroutine(this.DelaySaveShelfData());
		for (int i = 0; i < this.m_ExpansionShopPanelUIList.Count; i++)
		{
			this.m_ExpansionShopPanelUIList[i].Init(this, i, this.m_IsShopB);
		}
		CPlayerData.m_GameReportDataCollect.upgradeCost = CPlayerData.m_GameReportDataCollect.upgradeCost - totalCost;
		CPlayerData.m_GameReportDataCollectPermanent.upgradeCost = CPlayerData.m_GameReportDataCollectPermanent.upgradeCost - totalCost;
		SoundManager.PlayAudio("SFX_CustomerBuy", 0.6f, 1f);
	}

	// Token: 0x0600045E RID: 1118 RVA: 0x0002699E File Offset: 0x00024B9E
	private IEnumerator DelaySaveShelfData()
	{
		yield return new WaitForSeconds(1f);
		CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
		yield break;
	}

	// Token: 0x04000558 RID: 1368
	public List<ExpansionShopPanelUI> m_ExpansionShopPanelUIList;

	// Token: 0x04000559 RID: 1369
	public int m_ShopB_UnlockLevelRequired = 15;

	// Token: 0x0400055A RID: 1370
	public float m_ShopB_UnlockPrice = 5000f;

	// Token: 0x0400055B RID: 1371
	public TextMeshProUGUI m_ShopB_PriceText;

	// Token: 0x0400055C RID: 1372
	public TextMeshProUGUI m_ShopB_LevelRequirementText;

	// Token: 0x0400055D RID: 1373
	public GameObject m_ShopB_LockPurchaseBtn;

	// Token: 0x0400055E RID: 1374
	public GameObject m_ShopB_UnlockGrp;

	// Token: 0x0400055F RID: 1375
	public GameObject m_ShopB_UnlockGrpPrologue;

	// Token: 0x04000560 RID: 1376
	public GameObject m_ShopA_HighlightBtn;

	// Token: 0x04000561 RID: 1377
	public GameObject m_ShopB_HighlightBtn;

	// Token: 0x04000562 RID: 1378
	private bool m_IsShopB;

	// Token: 0x04000563 RID: 1379
	private string m_LevelRequirementString = "";
}
