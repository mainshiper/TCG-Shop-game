﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000009 RID: 9
public class CardOpeningSequence : CSingleton<CardOpeningSequence>
{
	// Token: 0x06000032 RID: 50 RVA: 0x00002EF4 File Offset: 0x000010F4
	private void Start()
	{
		this.m_CardPackAnimator.gameObject.SetActive(false);
		this.m_CardPackAnimator.speed = 0f;
		this.m_StateIndex = 0;
		this.m_CardOpeningUIGroup.SetActive(false);
		this.m_NewCardIcon.SetActive(false);
		this.m_HighValueCardIcon.SetActive(false);
		this.m_CardOpeningSequenceUI.m_CardValueTextGrp.SetActive(false);
		this.m_CardOpeningSequenceUI.m_TotalCardValueTextGrp.SetActive(false);
		this.m_CardOpeningSequenceUI.m_FoilRainbowGlowingBG.SetActive(false);
	}

	// Token: 0x06000033 RID: 51 RVA: 0x00002F80 File Offset: 0x00001180
	private void InitOpenSequence()
	{
		this.m_CardPackAnimator.speed = 0f;
		this.m_CardPackAnimator.gameObject.SetActive(true);
		this.m_CardPackAnimator.Play("PackOpenAnim", -1, 0f);
		this.m_CardOpeningRotateToFrontAnim.Play("CardOpenSeq0_Idle");
		this.m_CardOpeningUIGroup.SetActive(true);
		this.m_NewCardIcon.SetActive(false);
		this.m_HighValueCardIcon.SetActive(false);
		InteractionPlayerController.RemoveToolTip(EGameAction.CancelOpenPack);
		InteractionPlayerController.RemoveToolTip(EGameAction.OpenPack);
		InteractionPlayerController.AddToolTip(EGameAction.OpenPack, true, false);
		this.m_MultiplierStateTimer = 1f + 2.5f * CSingleton<CGameManager>.Instance.m_OpenPackSpeedSlider;
	}

	// Token: 0x06000034 RID: 52 RVA: 0x0000302C File Offset: 0x0000122C
	public void ReadyingCardPack(Item item)
	{
		if (this.m_IsReadyingToOpen)
		{
			return;
		}
		this.m_IsScreenActive = true;
		CSingleton<InteractionPlayerController>.Instance.EnterLockMoveMode();
		CSingleton<InteractionPlayerController>.Instance.OnEnterOpenPackState();
		this.m_IsReadyingToOpen = true;
		this.m_IsReadyToOpen = false;
		this.m_LerpPosTimer = 0f;
		this.m_CurrentItem = item;
		this.m_CardPackAnimator.transform.position = this.m_StartLerpTransform.position;
		this.m_CardPackAnimator.transform.rotation = this.m_StartLerpTransform.rotation;
		this.m_CardPackAnimator.transform.localScale = this.m_StartLerpTransform.localScale;
		this.m_CardPackMesh.material = this.m_CurrentItem.m_Mesh.sharedMaterial;
		this.m_CardPackAnimator.gameObject.SetActive(true);
		this.m_CurrentItem.gameObject.SetActive(false);
		this.m_CardOpeningUIGroup.SetActive(false);
		this.m_CardPackAnimator.Play("PackOpenAnim", -1, 0f);
		CSingleton<InteractionPlayerController>.Instance.m_BlackBGWorldUIFade.SetFadeIn(3f, 0f);
		TutorialManager.SetGameUIVisible(false);
		CenterDot.SetVisibility(false);
		GameUIScreen.HideEnterGoNextDayIndicatorVisible();
		InteractionPlayerController.TempHideToolTip();
		InteractionPlayerController.AddToolTip(EGameAction.OpenPack, true, false);
		InteractionPlayerController.AddToolTip(EGameAction.CancelOpenPack, false, false);
		InteractionPlayerController.SetAllHoldItemVisibility(false);
		CSingleton<InteractionPlayerController>.Instance.m_CameraFOVController.StartLerpToFOV(40f);
		SoundManager.GenericPop(1f, 1f);
	}

	// Token: 0x06000035 RID: 53 RVA: 0x00003198 File Offset: 0x00001398
	private void Update()
	{
		this.m_IsAutoFire = false;
		if (!this.m_IsScreenActive)
		{
			return;
		}
		if (InputManager.GetKeyDownAction(EGameAction.OpenPack))
		{
			this.m_IsAutoFireKeydown = true;
		}
		if (InputManager.GetKeyUpAction(EGameAction.OpenPack))
		{
			this.m_IsAutoFireKeydown = false;
		}
		if (this.m_IsAutoFireKeydown)
		{
			this.m_AutoFireTimer += Time.deltaTime;
			if (this.m_AutoFireTimer >= 0.05f)
			{
				this.m_AutoFireTimer = 0f;
				this.m_IsAutoFire = true;
			}
		}
		else if (this.m_AutoFireTimer > 0f)
		{
			this.m_AutoFireTimer = 0f;
			this.m_IsAutoFire = true;
		}
		if (this.m_IsReadyingToOpen)
		{
			if (!this.m_IsReadyToOpen)
			{
				if (this.m_IsCanceling)
				{
					this.m_LerpPosTimer -= Time.deltaTime * this.m_LerpPosSpeed;
					if (this.m_LerpPosTimer < 0f)
					{
						this.m_LerpPosTimer = 0f;
						this.m_IsReadyToOpen = false;
						this.m_IsReadyingToOpen = false;
						this.m_IsCanceling = false;
						this.m_IsScreenActive = false;
						this.m_CardPackAnimator.gameObject.SetActive(false);
						CSingleton<InteractionPlayerController>.Instance.ExitLockMoveMode();
						CSingleton<InteractionPlayerController>.Instance.OnExitOpenPackState();
						InteractionPlayerController.RestoreHiddenToolTip();
						this.m_CurrentItem.gameObject.SetActive(true);
						InteractionPlayerController.SetAllHoldItemVisibility(true);
						this.m_CurrentItem = null;
						TutorialManager.SetGameUIVisible(true);
						CenterDot.SetVisibility(true);
						GameUIScreen.ResetEnterGoNextDayIndicatorVisible();
					}
				}
				else
				{
					this.m_LerpPosTimer += Time.deltaTime * this.m_LerpPosSpeed;
					if (this.m_LerpPosTimer > 1f)
					{
						this.m_LerpPosTimer = 1f;
						this.m_IsReadyToOpen = true;
					}
				}
				this.m_CardPackAnimator.transform.localPosition = Vector3.Lerp(this.m_StartLerpTransform.localPosition, Vector3.zero, this.m_LerpPosTimer);
				this.m_CardPackAnimator.transform.localRotation = Quaternion.Lerp(this.m_StartLerpTransform.localRotation, Quaternion.identity, this.m_LerpPosTimer);
				this.m_CardPackAnimator.transform.localScale = Vector3.Lerp(this.m_StartLerpTransform.localScale, Vector3.one, this.m_LerpPosTimer);
				return;
			}
			if (this.m_IsAutoFire)
			{
				this.m_IsReadyingToOpen = false;
				this.OpenScreen(InventoryBase.ItemTypeToCollectionPackType(this.m_CurrentItem.GetItemType()), false, false);
				return;
			}
			if (InputManager.GetKeyDownAction(EGameAction.CancelOpenPack) && !this.m_IsCanceling)
			{
				CSingleton<InteractionPlayerController>.Instance.AddHoldItemToFront(this.m_CurrentItem);
				this.m_IsCanceling = true;
				this.m_IsReadyToOpen = false;
				CSingleton<InteractionPlayerController>.Instance.m_BlackBGWorldUIFade.SetFadeOut(3f, 0f);
				InteractionPlayerController.RestoreHiddenToolTip();
				CSingleton<InteractionPlayerController>.Instance.m_CameraFOVController.StopLerpFOV();
				SoundManager.GenericPop(1f, 0.9f);
			}
			return;
		}
		else
		{
			if (!this.m_IsScreenActive)
			{
				return;
			}
			if (this.m_StateIndex == 0)
			{
				this.InitOpenSequence();
				this.m_StateIndex++;
				return;
			}
			if (this.m_StateIndex == 1)
			{
				this.m_StateTimer += Time.deltaTime * this.m_MultiplierStateTimer;
				if (this.m_StateTimer > 0.05f)
				{
					this.m_StateTimer = 0f;
					if (this.m_TempIndex < this.m_Card3dUIList.Count)
					{
						this.m_Card3dUIList[this.m_TempIndex].gameObject.SetActive(true);
						this.m_TempIndex++;
					}
				}
				if (this.m_IsAutoFire || this.m_IsAutoFireKeydown || CSingleton<CGameManager>.Instance.m_OpenPacAutoNextCard)
				{
					this.m_Slider += 0.0065f * this.m_MultiplierStateTimer;
					this.m_CardPackAnimator.Play("PackOpenAnim", -1, this.m_Slider);
					if (this.m_Slider >= 0.3f)
					{
						this.m_OpenPackVFX.Play();
						SoundManager.PlayAudio("SFX_OpenPack", 0.6f, 1f);
						SoundManager.PlayAudio("SFX_BoxOpen", 0.5f, 1f);
						this.m_StateIndex++;
						return;
					}
				}
			}
			else if (this.m_StateIndex == 2)
			{
				this.m_Slider += Time.deltaTime * 1f * this.m_MultiplierStateTimer;
				this.m_CardPackAnimator.Play("PackOpenAnim", -1, this.m_Slider);
				this.m_StateTimer += Time.deltaTime;
				if (this.m_StateTimer > 0.05f)
				{
					this.m_StateTimer = 0f;
					if (this.m_TempIndex < this.m_Card3dUIList.Count)
					{
						this.m_Card3dUIList[this.m_TempIndex].gameObject.SetActive(true);
						this.m_TempIndex++;
					}
				}
				if (this.m_Slider >= 1f)
				{
					InteractionPlayerController.RemoveToolTip(EGameAction.OpenPack);
					this.m_TempIndex = 0;
					this.m_StateTimer = 0f;
					this.m_Slider = 0f;
					this.m_StateIndex++;
					for (int i = 0; i < this.m_Card3dUIList.Count; i++)
					{
						this.m_Card3dUIList[i].gameObject.SetActive(true);
					}
					return;
				}
			}
			else if (this.m_StateIndex == 3)
			{
				this.m_Slider += Time.deltaTime * 1f * this.m_MultiplierStateTimer;
				if (this.m_Slider >= 0.15f)
				{
					this.m_Slider = 0f;
					this.m_StateIndex++;
					this.m_CardOpeningRotateToFrontAnim.Play("CardOpenSeq1_RotateToFront");
				}
				if (this.m_IsAutoFire || CSingleton<CGameManager>.Instance.m_OpenPacAutoNextCard)
				{
					float num = 0.002f * (float)this.m_CurrentOpenedCardIndex;
					float num2 = 0.001f * (float)this.m_CurrentOpenedCardIndex;
					SoundManager.PlayAudio("SFX_CardReveal1", 0.6f + num2, 1f + num);
					this.m_CardOpeningRotateToFrontAnim.Play("CardOpenSeq1_RotateToFront");
					this.m_StateTimer = 0f;
					this.m_StateIndex++;
					return;
				}
			}
			else if (this.m_StateIndex == 4)
			{
				this.m_Slider += Time.deltaTime * 1f * this.m_MultiplierStateTimer;
				if (!this.m_CardOpeningSequenceUI.m_CardValueTextGrp.activeSelf && this.m_CurrentOpenedCardIndex < 6 && this.m_Slider >= 0.45f && !this.m_IsNewlList[this.m_CurrentOpenedCardIndex] && this.m_CardValueList[this.m_CurrentOpenedCardIndex] < this.m_HighValueCardThreshold)
				{
					this.m_TotalCardValue += this.m_CardValueList[this.m_CurrentOpenedCardIndex];
					this.m_CardOpeningSequenceUI.ShowSingleCardValue(this.m_CardValueList[this.m_CurrentOpenedCardIndex]);
				}
				if (this.m_Slider >= 0.8f)
				{
					this.m_Slider = 0f;
					if (this.m_CardValueList[this.m_CurrentOpenedCardIndex] >= this.m_HighValueCardThreshold)
					{
						SoundManager.PlayAudio("SFX_FinalizeCard", 0.6f, 1.2f);
						this.m_CardAnimList[this.m_CurrentOpenedCardIndex].Play("OpenCardNewCard");
						this.m_HighValueCardIcon.SetActive(true);
						base.StartCoroutine(this.DelayToState(5, 0.9f));
						this.m_TotalCardValue += this.m_CardValueList[this.m_CurrentOpenedCardIndex];
						this.m_CardOpeningSequenceUI.ShowSingleCardValue(this.m_CardValueList[this.m_CurrentOpenedCardIndex]);
						this.m_IsGetHighValueCard = true;
						return;
					}
					if (this.m_IsNewlList[this.m_CurrentOpenedCardIndex])
					{
						SoundManager.PlayAudio("SFX_CardReveal0", 0.6f, 1f);
						this.m_CardAnimList[this.m_CurrentOpenedCardIndex].Play("OpenCardNewCard");
						this.m_NewCardIcon.SetActive(true);
						base.StartCoroutine(this.DelayToState(5, 0.9f));
						this.m_TotalCardValue += this.m_CardValueList[this.m_CurrentOpenedCardIndex];
						this.m_CardOpeningSequenceUI.ShowSingleCardValue(this.m_CardValueList[this.m_CurrentOpenedCardIndex]);
						return;
					}
					this.m_StateIndex++;
					return;
				}
			}
			else if (this.m_StateIndex == 5)
			{
				if (this.m_IsAutoFire || (!this.m_IsGetHighValueCard && CSingleton<CGameManager>.Instance.m_OpenPacAutoNextCard))
				{
					int num3 = Random.Range(0, 3);
					float num4 = 0.002f * (float)this.m_CurrentOpenedCardIndex;
					float num5 = 0.001f * (float)this.m_CurrentOpenedCardIndex;
					if (num3 == 0)
					{
						SoundManager.PlayAudio("SFX_CardReveal1", 0.6f + num5, 1f + num4);
					}
					else if (num3 == 1)
					{
						SoundManager.PlayAudio("SFX_CardReveal2", 0.6f + num5, 1f + num4);
					}
					else
					{
						SoundManager.PlayAudio("SFX_CardReveal3", 0.6f + num5, 1f + num4);
					}
					if (this.m_CurrentOpenedCardIndex >= 7)
					{
						this.m_StateIndex = 7;
					}
					else
					{
						this.m_StateIndex++;
						this.m_NewCardIcon.SetActive(false);
						this.m_HighValueCardIcon.SetActive(false);
						this.m_CardAnimList[this.m_CurrentOpenedCardIndex].Play("OpenCardSlideExit");
						this.m_CardAnimList[this.m_CurrentOpenedCardIndex]["OpenCardSlideExit"].speed = 1f * this.m_MultiplierStateTimer;
						this.m_CardOpeningSequenceUI.HideSingleCardValue();
					}
					this.m_IsGetHighValueCard = false;
					return;
				}
			}
			else if (this.m_StateIndex == 6)
			{
				this.m_Slider += Time.deltaTime * 1f * this.m_MultiplierStateTimer;
				if (!this.m_CardOpeningSequenceUI.m_CardValueTextGrp.activeSelf && this.m_CurrentOpenedCardIndex < 6 && this.m_Slider >= 0.3f && !this.m_IsNewlList[this.m_CurrentOpenedCardIndex + 1] && this.m_CardValueList[this.m_CurrentOpenedCardIndex + 1] < this.m_HighValueCardThreshold)
				{
					this.m_TotalCardValue += this.m_CardValueList[this.m_CurrentOpenedCardIndex + 1];
					this.m_CardOpeningSequenceUI.ShowSingleCardValue(this.m_CardValueList[this.m_CurrentOpenedCardIndex + 1]);
				}
				if (this.m_Slider >= 0.5f)
				{
					this.m_Slider = 0f;
					if (this.m_Card3dUIList.Count > this.m_CurrentOpenedCardIndex)
					{
						this.m_CardAnimList[this.m_CurrentOpenedCardIndex].transform.localPosition = Vector3.zero;
						this.m_Card3dUIList[this.m_CurrentOpenedCardIndex].gameObject.SetActive(false);
					}
					this.m_CurrentOpenedCardIndex++;
					if (this.m_CurrentOpenedCardIndex >= 7)
					{
						this.m_IsGetHighValueCard = false;
						this.m_StateIndex = 7;
						return;
					}
					if (this.m_Card3dUIList.Count > this.m_CurrentOpenedCardIndex + 1)
					{
						this.m_Card3dUIList[this.m_CurrentOpenedCardIndex + 1].gameObject.SetActive(true);
					}
					if (this.m_CardValueList[this.m_CurrentOpenedCardIndex] >= this.m_HighValueCardThreshold)
					{
						SoundManager.PlayAudio("SFX_FinalizeCard", 0.6f, 1.2f);
						this.m_CardAnimList[this.m_CurrentOpenedCardIndex].Play("OpenCardNewCard");
						this.m_HighValueCardIcon.SetActive(true);
						base.StartCoroutine(this.DelayToState(5, 0.9f));
						this.m_TotalCardValue += this.m_CardValueList[this.m_CurrentOpenedCardIndex];
						this.m_CardOpeningSequenceUI.ShowSingleCardValue(this.m_CardValueList[this.m_CurrentOpenedCardIndex]);
						this.m_IsGetHighValueCard = true;
						return;
					}
					if (this.m_IsNewlList[this.m_CurrentOpenedCardIndex])
					{
						SoundManager.PlayAudio("SFX_CardReveal0", 0.6f, 1f);
						this.m_CardAnimList[this.m_CurrentOpenedCardIndex].Play("OpenCardNewCard");
						this.m_NewCardIcon.SetActive(true);
						base.StartCoroutine(this.DelayToState(5, 0.9f));
						this.m_TotalCardValue += this.m_CardValueList[this.m_CurrentOpenedCardIndex];
						this.m_CardOpeningSequenceUI.ShowSingleCardValue(this.m_CardValueList[this.m_CurrentOpenedCardIndex]);
						return;
					}
					this.m_StateIndex = 5;
					return;
				}
			}
			else if (this.m_StateIndex == 7)
			{
				if (this.m_StateTimer == 0f && this.m_Slider == 0f)
				{
					SoundManager.PlayAudio("SFX_PercStarJingle3", 0.6f, 1f);
					SoundManager.PlayAudio("SFX_Gift", 0.6f, 1f);
				}
				this.m_Slider += Time.deltaTime;
				if (this.m_Slider >= 0.05f)
				{
					this.m_Slider = 0f;
					this.m_CardAnimList[(int)this.m_StateTimer].transform.position = this.m_ShowAllCardPosList[(int)this.m_StateTimer].position;
					this.m_CardAnimList[(int)this.m_StateTimer].transform.rotation = this.m_ShowAllCardPosList[(int)this.m_StateTimer].rotation;
					this.m_Card3dUIList[(int)this.m_StateTimer].gameObject.SetActive(true);
					this.m_CardAnimList[(int)this.m_StateTimer].Play("OpenCardFinalReveal");
					this.m_StateTimer += 1f;
					if (this.m_StateTimer >= (float)this.m_Card3dUIList.Count)
					{
						this.m_StateTimer = 0f;
						this.m_StateIndex++;
						this.m_CardOpeningSequenceUI.StartShowTotalValue(this.m_TotalCardValue, this.m_HasFoilCard);
						return;
					}
				}
			}
			else if (this.m_StateIndex == 8)
			{
				this.m_StateTimer += Time.deltaTime;
				if (this.m_StateTimer >= 0.02f)
				{
					this.m_Slider = 0f;
					this.m_Card3dUIList[(int)this.m_StateTimer].m_NewCardIndicator.gameObject.SetActive(this.m_RolledCardDataList[(int)this.m_StateTimer].isNew);
					this.m_StateTimer += 1f;
					if (this.m_StateTimer >= (float)this.m_Card3dUIList.Count)
					{
						this.m_StateIndex++;
						return;
					}
				}
			}
			else if (this.m_StateIndex == 9)
			{
				this.m_Slider += Time.deltaTime;
				if (this.m_Slider >= 1f)
				{
					this.m_Slider = 0f;
					this.m_StateIndex++;
					return;
				}
			}
			else if (this.m_StateIndex == 10)
			{
				if (this.m_IsAutoFire)
				{
					this.m_StateIndex++;
					return;
				}
			}
			else if (this.m_StateIndex == 11)
			{
				this.m_StateTimer += Time.deltaTime * 1f;
				if (this.m_StateTimer >= 0.01f)
				{
					this.m_Slider = 0f;
					this.m_IsScreenActive = false;
					this.m_IsReadyToOpen = false;
					this.m_CardPackAnimator.gameObject.SetActive(false);
					this.m_CardOpeningUIGroup.SetActive(false);
					this.m_CardOpeningSequenceUI.HideTotalValue();
					CSingleton<InteractionPlayerController>.Instance.ExitLockMoveMode();
					CSingleton<InteractionPlayerController>.Instance.OnExitOpenPackState();
					this.m_CurrentItem.DisableItem();
					this.m_CurrentItem = null;
					int num6 = 0;
					this.m_TotalCardValue = 0f;
					this.m_TotalExpGained = 0;
					bool isGet = false;
					bool isGet2 = false;
					for (int j = 0; j < this.m_RolledCardDataList.Count; j++)
					{
						int num7 = (int)((this.m_RolledCardDataList[j].GetCardBorderType() + 1) * (ECardBorderType)Mathf.CeilToInt((float)(this.m_RolledCardDataList[j].borderType + 1) / 2f));
						if (this.m_RolledCardDataList[j].isFoil)
						{
							num7 *= 8;
						}
						this.m_TotalExpGained += num7;
						if (this.m_RolledCardDataList[j].GetCardBorderType() == ECardBorderType.FullArt && this.m_RolledCardDataList[j].isFoil)
						{
							isGet = true;
							if (this.m_RolledCardDataList[j].expansionType == ECardExpansionType.Ghost)
							{
								isGet2 = true;
							}
						}
						if (this.m_RolledCardDataList[j].isNew)
						{
							num6++;
						}
					}
					if (this.m_TotalExpGained > 0)
					{
						CEventManager.QueueEvent(new CEventPlayer_AddShopExp(this.m_TotalExpGained, false));
					}
					for (int k = 0; k < this.m_CardAnimList.Count; k++)
					{
						this.m_CardAnimList[k].transform.localPosition = Vector3.zero;
						this.m_CardAnimList[k].transform.localRotation = Quaternion.identity;
						this.m_Card3dUIList[k].m_NewCardIndicator.gameObject.SetActive(false);
						this.m_CardAnimList[k].Play("OpenCardDefaultPos");
					}
					if (CSingleton<InteractionPlayerController>.Instance.GetHoldItemCount() <= 0)
					{
						TutorialManager.SetGameUIVisible(true);
						CenterDot.SetVisibility(true);
						GameUIScreen.ResetEnterGoNextDayIndicatorVisible();
						CSingleton<InteractionPlayerController>.Instance.m_BlackBGWorldUIFade.SetFadeOut(3f, 0f);
						CSingleton<InteractionPlayerController>.Instance.m_CameraFOVController.StopLerpFOV();
						this.m_IsAutoFireKeydown = false;
						this.m_AutoFireTimer = 0f;
					}
					CSingleton<InteractionPlayerController>.Instance.EvaluateOpenCardPack();
					TutorialManager.AddTaskValue(ETutorialTaskCondition.OpenPack, 1f);
					CPlayerData.m_GameReportDataCollect.cardPackOpened = CPlayerData.m_GameReportDataCollect.cardPackOpened + 1;
					CPlayerData.m_GameReportDataCollectPermanent.cardPackOpened = CPlayerData.m_GameReportDataCollectPermanent.cardPackOpened + 1;
					AchievementManager.OnCardPackOpened(CPlayerData.m_GameReportDataCollectPermanent.cardPackOpened);
					AchievementManager.OnGetFullArtFoil(isGet);
					AchievementManager.OnGetFullArtGhostFoil(isGet2);
					if (num6 > 0)
					{
						AchievementManager.OnCheckAlbumCardCount(CPlayerData.GetTotalCardCollectedAmount());
					}
					UnityAnalytic.OpenPack();
					return;
				}
			}
			else
			{
				if (this.m_StateIndex == 12)
				{
					this.m_IsScreenActive = false;
					return;
				}
				if (this.m_StateIndex == 101)
				{
					float stateTimer = this.m_StateTimer;
					this.m_StateTimer += Time.deltaTime;
					if (this.m_StateTimer >= 0.05f)
					{
						int num8 = Random.Range(0, 3);
						float num9 = 0.002f * (float)this.m_CurrentOpenedCardIndex;
						float num10 = 0.001f * (float)this.m_CurrentOpenedCardIndex;
						if (num8 == 0)
						{
							SoundManager.PlayAudio("SFX_CardReveal1", 0.6f + num10, 1f + num9);
						}
						else if (num8 == 1)
						{
							SoundManager.PlayAudio("SFX_CardReveal2", 0.6f + num10, 1f + num9);
						}
						else
						{
							SoundManager.PlayAudio("SFX_CardReveal3", 0.6f + num10, 1f + num9);
						}
						this.m_CurrentOpenedCardIndex++;
						return;
					}
				}
				else
				{
					int stateIndex = this.m_StateIndex;
				}
			}
			return;
		}
	}

	// Token: 0x06000036 RID: 54 RVA: 0x0000442D File Offset: 0x0000262D
	public void OnPressFinishGetCard()
	{
		SoundManager.GenericConfirm(1f, 1f);
		this.m_StateIndex = 11;
	}

	// Token: 0x06000037 RID: 55 RVA: 0x00004446 File Offset: 0x00002646
	private IEnumerator DelayToState(int stateIndex, float delayTime)
	{
		this.m_StateIndex = -1;
		yield return new WaitForSeconds(delayTime);
		this.m_StateIndex = stateIndex;
		yield break;
	}

	// Token: 0x06000038 RID: 56 RVA: 0x00004464 File Offset: 0x00002664
	public void OpenScreen(ECollectionPackType collectionPackType, bool isMultiPack, bool isPremiumPack = false)
	{
		this.m_IsScreenActive = true;
		this.m_CollectionPackType = collectionPackType;
		this.m_IsNewlList.Clear();
		this.m_TotalExpGained = 0;
		this.m_TotalCardValue = 0f;
		this.m_HasFoilCard = false;
		if (isMultiPack)
		{
			this.m_RolledCardDataList.Clear();
			this.m_CardValueList.Clear();
			this.m_SecondaryRolledCardDataList.Clear();
			this.m_StateIndex = -1;
			this.GetPackContent(false, isPremiumPack, false, ECollectionPackType.None);
			this.GetPackContent(false, isPremiumPack, false, ECollectionPackType.None);
			this.GetPackContent(false, isPremiumPack, false, ECollectionPackType.None);
			this.GetPackContent(false, isPremiumPack, false, ECollectionPackType.None);
			this.GetPackContent(false, isPremiumPack, false, ECollectionPackType.None);
		}
		else
		{
			this.m_StateIndex = 0;
			this.GetPackContent(true, isPremiumPack, false, ECollectionPackType.None);
			ECardExpansionType cardExpansionType = InventoryBase.GetCardExpansionType(collectionPackType);
			if (cardExpansionType == ECardExpansionType.Tetramon || cardExpansionType == ECardExpansionType.Destiny)
			{
				int num = Random.Range(0, 10000);
				if (cardExpansionType == ECardExpansionType.Tetramon)
				{
					num = Random.Range(0, 20000);
				}
				if (num < 20 && CPlayerData.m_ShopLevel > 1)
				{
					this.GetPackContent(true, isPremiumPack, true, ECollectionPackType.GhostPack);
					if (this.m_SecondaryRolledCardDataList.Count > 0)
					{
						int index = Random.Range(0, this.m_SecondaryRolledCardDataList.Count);
						this.m_RolledCardDataList[this.m_RolledCardDataList.Count - 1] = this.m_SecondaryRolledCardDataList[index];
						this.m_CardValueList[this.m_RolledCardDataList.Count - 1] = CPlayerData.GetCardMarketPrice(this.m_SecondaryRolledCardDataList[index]);
					}
				}
			}
		}
		this.m_CurrentOpenedCardIndex = 0;
		for (int i = 0; i < this.m_Card3dUIList.Count; i++)
		{
			this.m_Card3dUIList[i].gameObject.SetActive(false);
		}
		for (int j = 0; j < this.m_RolledCardDataList.Count; j++)
		{
			CPlayerData.AddCard(this.m_RolledCardDataList[j], 1);
			this.m_Card3dUIList[j].m_CardUI.SetCardUI(this.m_RolledCardDataList[j]);
			if (this.m_RolledCardDataList[j].monsterType > EMonsterType.None && CPlayerData.GetCardAmount(this.m_RolledCardDataList[j]) == 1)
			{
				this.m_RolledCardDataList[j].isNew = true;
				if (CSingleton<CGameManager>.Instance.m_OpenPackShowNewCard)
				{
					this.m_IsNewlList.Add(true);
				}
				else
				{
					this.m_IsNewlList.Add(false);
				}
			}
			else
			{
				this.m_RolledCardDataList[j].isNew = false;
				this.m_IsNewlList.Add(false);
			}
		}
		CSingleton<InteractionPlayerController>.Instance.m_CollectionBinderFlipAnimCtrl.SetCanUpdateSort(true);
		if (isMultiPack)
		{
			this.m_StateTimer = 0f;
			this.m_StateTimer = 0f;
			this.m_StateIndex = 101;
			for (int k = 0; k < this.m_RolledCardDataList.Count; k++)
			{
				this.m_Card3dUIList[k].m_CardUI.SetCardUI(this.m_RolledCardDataList[k]);
				if (this.m_RolledCardDataList[k].monsterType > EMonsterType.None && CPlayerData.GetCardAmount(this.m_RolledCardDataList[k]) == 1)
				{
					this.m_RolledCardDataList[k].isNew = true;
					if (CSingleton<CGameManager>.Instance.m_OpenPackShowNewCard)
					{
						this.m_IsNewlList.Add(true);
					}
					else
					{
						this.m_IsNewlList.Add(false);
					}
				}
				else
				{
					this.m_RolledCardDataList[k].isNew = false;
					this.m_IsNewlList.Add(false);
				}
			}
			CEventManager.QueueEvent(new CEventPlayer_SetCanvasGroupVisibility(false));
		}
	}

	// Token: 0x06000039 RID: 57 RVA: 0x000047DC File Offset: 0x000029DC
	private void GetPackContent(bool clearList, bool isPremiumPack, bool isSecondaryRolledData = false, ECollectionPackType overrideCollectionPackType = ECollectionPackType.None)
	{
		if (clearList)
		{
			if (isSecondaryRolledData)
			{
				this.m_SecondaryRolledCardDataList.Clear();
			}
			else
			{
				this.m_RolledCardDataList.Clear();
				this.m_CardValueList.Clear();
			}
		}
		List<EMonsterType> list = new List<EMonsterType>();
		List<EMonsterType> list2 = new List<EMonsterType>();
		List<EMonsterType> list3 = new List<EMonsterType>();
		List<EMonsterType> list4 = new List<EMonsterType>();
		List<EMonsterType> list5 = new List<EMonsterType>();
		ECardExpansionType cardExpansionType = InventoryBase.GetCardExpansionType(this.m_CollectionPackType);
		if (isSecondaryRolledData)
		{
			cardExpansionType = InventoryBase.GetCardExpansionType(overrideCollectionPackType);
		}
		List<EMonsterType> shownMonsterList = InventoryBase.GetShownMonsterList(cardExpansionType);
		CardUISetting cardUISetting = InventoryBase.GetCardUISetting(cardExpansionType);
		bool openPackCanUseRarity = cardUISetting.openPackCanUseRarity;
		bool openPackCanHaveDuplicate = cardUISetting.openPackCanHaveDuplicate;
		for (int i = 0; i < shownMonsterList.Count; i++)
		{
			MonsterData monsterData = InventoryBase.GetMonsterData(shownMonsterList[i]);
			EMonsterType monsterType = monsterData.MonsterType;
			ERarity rarity = monsterData.Rarity;
			list.Add(monsterType);
			if (rarity == ERarity.Legendary)
			{
				list5.Add(monsterType);
			}
			else if (rarity == ERarity.Epic)
			{
				list4.Add(monsterType);
			}
			else if (rarity == ERarity.Rare)
			{
				list3.Add(monsterType);
			}
			else
			{
				list2.Add(monsterType);
			}
		}
		int num = 0;
		int num2 = 0;
		int num3 = 0;
		int num4 = 0;
		int num5 = 1;
		int num6 = 0;
		int num7 = 0;
		int num8 = 0;
		float num9 = 10f;
		float num10 = 2f;
		float num11 = 0.1f;
		float num12 = 5f;
		ECardBorderType borderType = ECardBorderType.Base;
		float num13 = 20f;
		float num14 = 8f;
		float num15 = 4f;
		float num16 = 1f;
		float num17 = 0.25f;
		ERarity erarity = ERarity.Common;
		int num18 = 7;
		if (this.m_CollectionPackType == ECollectionPackType.RareCardPack || this.m_CollectionPackType == ECollectionPackType.DestinyRareCardPack)
		{
			num5 = 0;
			num6 = 7;
			num9 += 45f;
			num10 += 2f;
			num11 += 1f;
		}
		else if (this.m_CollectionPackType == ECollectionPackType.EpicCardPack || this.m_CollectionPackType == ECollectionPackType.DestinyEpicCardPack)
		{
			num5 = 0;
			num6 = 1;
			num7 = 7;
			num8 = 0;
			num9 += 65f;
			num10 += 45f;
			num11 += 3f;
		}
		else if (this.m_CollectionPackType == ECollectionPackType.LegendaryCardPack || this.m_CollectionPackType == ECollectionPackType.DestinyLegendaryCardPack)
		{
			num5 = 0;
			num6 = 0;
			num7 = 1;
			num8 = 7;
			num9 += 65f;
			num10 += 55f;
			num11 += 35f;
		}
		else if (this.m_CollectionPackType == ECollectionPackType.BasicCardPack || this.m_CollectionPackType == ECollectionPackType.DestinyBasicCardPack)
		{
			num5 = 7;
		}
		int num19 = 0;
		while (num19 < num18 && list.Count > 0)
		{
			int index = Random.Range(0, list.Count);
			if (num8 - num4 > 0 && list5.Count > 0)
			{
				erarity = ERarity.Legendary;
				num4++;
			}
			else if (num7 - num3 > 0 && list4.Count > 0)
			{
				erarity = ERarity.Epic;
				num3++;
			}
			else if (num6 - num2 > 0 && list3.Count > 0)
			{
				erarity = ERarity.Rare;
				num2++;
			}
			else if (num5 - num > 0 && list2.Count > 0)
			{
				erarity = ERarity.Common;
				num++;
			}
			else
			{
				int num20 = Random.Range(0, 10000);
				int num21 = 4 - num2;
				int num22 = 4 - num3;
				int num23 = 4 - num4;
				bool flag = false;
				if (!flag && num11 > 0f && list5.Count > 0 && num23 > 0)
				{
					int num24 = Mathf.RoundToInt(num11 * 100f);
					if (num20 < num24)
					{
						flag = true;
						erarity = ERarity.Legendary;
						num4++;
					}
				}
				if (!flag && num10 > 0f && list4.Count > 0 && num22 > 0)
				{
					int num24 = Mathf.RoundToInt(num10 * 100f);
					if (num20 < num24)
					{
						flag = true;
						erarity = ERarity.Epic;
						num3++;
					}
				}
				if (!flag && num9 > 0f && list3.Count > 0 && num21 > 0)
				{
					int num24 = Mathf.RoundToInt(num9 * 100f);
					if (num20 < num24)
					{
						flag = true;
						erarity = ERarity.Rare;
						num2++;
					}
				}
				if (!flag)
				{
					erarity = ERarity.Common;
					num++;
				}
			}
			int monsterType2;
			if (openPackCanUseRarity)
			{
				if (erarity == ERarity.Legendary)
				{
					index = Random.Range(0, list5.Count);
					monsterType2 = (int)list5[index];
					if (!openPackCanHaveDuplicate)
					{
						list5.RemoveAt(index);
					}
				}
				else if (erarity == ERarity.Epic)
				{
					index = Random.Range(0, list4.Count);
					monsterType2 = (int)list4[index];
					if (!openPackCanHaveDuplicate)
					{
						list4.RemoveAt(index);
					}
				}
				else if (erarity == ERarity.Rare)
				{
					index = Random.Range(0, list3.Count);
					monsterType2 = (int)list3[index];
					if (!openPackCanHaveDuplicate)
					{
						list3.RemoveAt(index);
					}
				}
				else
				{
					index = Random.Range(0, list2.Count);
					monsterType2 = (int)list2[index];
					if (!openPackCanHaveDuplicate)
					{
						list2.RemoveAt(index);
					}
				}
			}
			else
			{
				index = Random.Range(0, list.Count);
				monsterType2 = (int)list[index];
				if (!openPackCanHaveDuplicate)
				{
					list.RemoveAt(index);
				}
			}
			CardData cardData = new CardData();
			cardData.monsterType = (EMonsterType)monsterType2;
			if (Random.Range(0, 10000) < Mathf.RoundToInt(num12 * 100f))
			{
				cardData.isFoil = true;
				this.m_HasFoilCard = true;
			}
			else
			{
				cardData.isFoil = false;
			}
			if (CPlayerData.m_TutorialIndex < 10 && CPlayerData.m_GameReportDataCollectPermanent.cardPackOpened == 0 && !this.m_HasFoilCard && num19 == num18 - 1)
			{
				cardData.isFoil = true;
				this.m_HasFoilCard = true;
			}
			bool flag2 = false;
			if (Random.Range(0, 10000) < Mathf.RoundToInt(num17 * 100f))
			{
				borderType = ECardBorderType.FullArt;
				flag2 = true;
			}
			if (!flag2 && Random.Range(0, 10000) < Mathf.RoundToInt(num16 * 100f))
			{
				borderType = ECardBorderType.EX;
				flag2 = true;
			}
			if (!flag2 && Random.Range(0, 10000) < Mathf.RoundToInt(num15 * 100f))
			{
				borderType = ECardBorderType.Gold;
				flag2 = true;
			}
			if (!flag2 && Random.Range(0, 10000) < Mathf.RoundToInt(num14 * 100f))
			{
				borderType = ECardBorderType.Silver;
				flag2 = true;
			}
			if (!flag2 && Random.Range(0, 10000) < Mathf.RoundToInt(num13 * 100f))
			{
				borderType = ECardBorderType.FirstEdition;
				flag2 = true;
			}
			if (!flag2 || cardExpansionType == ECardExpansionType.Ghost)
			{
				borderType = ECardBorderType.Base;
			}
			cardData.borderType = borderType;
			cardData.expansionType = cardExpansionType;
			if (cardData.expansionType == ECardExpansionType.Tetramon)
			{
				cardData.isDestiny = false;
			}
			else if (cardData.expansionType == ECardExpansionType.Destiny)
			{
				cardData.isDestiny = true;
			}
			else if (cardData.expansionType == ECardExpansionType.Ghost)
			{
				int num25 = Random.Range(0, 100);
				cardData.isDestiny = (num25 < 50);
			}
			else
			{
				cardData.isDestiny = false;
			}
			if (isSecondaryRolledData)
			{
				this.m_SecondaryRolledCardDataList.Add(cardData);
			}
			else
			{
				this.m_RolledCardDataList.Add(cardData);
				this.m_CardValueList.Add(CPlayerData.GetCardMarketPrice(cardData));
			}
			num19++;
		}
	}

	// Token: 0x0600003A RID: 58 RVA: 0x00004E4F File Offset: 0x0000304F
	public bool IsActive()
	{
		return this.m_IsScreenActive;
	}

	// Token: 0x04000036 RID: 54
	public SkinnedMeshRenderer m_CardPackMesh;

	// Token: 0x04000037 RID: 55
	public Animator m_CardPackAnimator;

	// Token: 0x04000038 RID: 56
	public Transform m_StartLerpTransform;

	// Token: 0x04000039 RID: 57
	public GameObject m_CardOpeningUIGroup;

	// Token: 0x0400003A RID: 58
	public GameObject m_NewCardIcon;

	// Token: 0x0400003B RID: 59
	public GameObject m_HighValueCardIcon;

	// Token: 0x0400003C RID: 60
	public Animation m_CardOpeningRotateToFrontAnim;

	// Token: 0x0400003D RID: 61
	public List<Card3dUIGroup> m_Card3dUIList;

	// Token: 0x0400003E RID: 62
	public List<Animation> m_CardAnimList;

	// Token: 0x0400003F RID: 63
	public List<Transform> m_ShowAllCardPosList;

	// Token: 0x04000040 RID: 64
	public CardOpeningSequenceUI m_CardOpeningSequenceUI;

	// Token: 0x04000041 RID: 65
	public ParticleSystem m_OpenPackVFX;

	// Token: 0x04000042 RID: 66
	private bool m_IsReadyingToOpen;

	// Token: 0x04000043 RID: 67
	private bool m_IsReadyToOpen;

	// Token: 0x04000044 RID: 68
	private bool m_IsCanceling;

	// Token: 0x04000045 RID: 69
	private bool m_IsAutoFire;

	// Token: 0x04000046 RID: 70
	private bool m_IsAutoFireKeydown;

	// Token: 0x04000047 RID: 71
	public int m_StateIndex;

	// Token: 0x04000048 RID: 72
	private int m_TempIndex;

	// Token: 0x04000049 RID: 73
	private float m_StateTimer;

	// Token: 0x0400004A RID: 74
	private float m_MultiplierStateTimer = 10f;

	// Token: 0x0400004B RID: 75
	private float m_Slider;

	// Token: 0x0400004C RID: 76
	private float m_LerpPosTimer;

	// Token: 0x0400004D RID: 77
	private float m_LerpPosSpeed = 10f;

	// Token: 0x0400004E RID: 78
	private float m_AutoFireTimer;

	// Token: 0x0400004F RID: 79
	private float m_TotalCardValue;

	// Token: 0x04000050 RID: 80
	private Vector3 m_TargetMoveObjectPosition;

	// Token: 0x04000051 RID: 81
	private Transform m_TargetLerpTransform;

	// Token: 0x04000052 RID: 82
	private Item m_CurrentItem;

	// Token: 0x04000053 RID: 83
	private List<CardData> m_RolledCardDataList = new List<CardData>();

	// Token: 0x04000054 RID: 84
	private List<CardData> m_SecondaryRolledCardDataList = new List<CardData>();

	// Token: 0x04000055 RID: 85
	private bool m_HasFoilCard;

	// Token: 0x04000056 RID: 86
	private ECollectionPackType m_CollectionPackType = ECollectionPackType.None;

	// Token: 0x04000057 RID: 87
	private List<bool> m_IsNewlList = new List<bool>();

	// Token: 0x04000058 RID: 88
	private List<float> m_CardValueList = new List<float>();

	// Token: 0x04000059 RID: 89
	private bool m_IsScreenActive;

	// Token: 0x0400005A RID: 90
	private bool m_IsGetHighValueCard;

	// Token: 0x0400005B RID: 91
	private int m_CurrentOpenedCardIndex;

	// Token: 0x0400005C RID: 92
	private int m_TotalExpGained;

	// Token: 0x0400005D RID: 93
	private float m_HighValueCardThreshold = 10f;
}
