﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x0200005C RID: 92
public class CheckPriceScreen : GenericSliderScreen
{
	// Token: 0x06000413 RID: 1043 RVA: 0x0002486E File Offset: 0x00022A6E
	protected override void Init()
	{
		this.m_PageIndex = -1;
		this.m_CardPageOptionGrp.SetActive(false);
		this.OnPressChangePageButton(0);
		base.Init();
	}

	// Token: 0x06000414 RID: 1044 RVA: 0x00024890 File Offset: 0x00022A90
	public void OnPressChangePageButton(int index)
	{
		if (this.m_PageIndex == index)
		{
			return;
		}
		this.m_PageIndex = index;
		for (int i = 0; i < this.m_PageButtonHighlightList.Count; i++)
		{
			this.m_PageButtonHighlightList[i].SetActive(false);
		}
		this.m_PageButtonHighlightList[this.m_PageIndex].SetActive(true);
		if (index < 4)
		{
			this.EvaluateItemPanelUI(index);
		}
		else
		{
			this.EvaluateCardPanelUI(this.m_CardPageIndex);
		}
		base.StartCoroutine(base.EvaluateActiveRestockUIScroller());
		this.m_PosX = 0f;
		this.m_LerpPosX = 0f;
	}

	// Token: 0x06000415 RID: 1045 RVA: 0x0002492C File Offset: 0x00022B2C
	private void EvaluateItemPanelUI(int pageIndex)
	{
		List<EItemType> list = new List<EItemType>();
		if (pageIndex == 0)
		{
			list = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownItemType;
		}
		else if (pageIndex == 1)
		{
			list = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownAccessoryItemType;
		}
		else if (pageIndex == 2)
		{
			list = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownFigurineItemType;
		}
		else if (pageIndex == 3)
		{
			for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownItemType.Count; i++)
			{
				list.Add(CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownItemType[i]);
			}
			for (int j = 0; j < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownAccessoryItemType.Count; j++)
			{
				list.Add(CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownAccessoryItemType[j]);
			}
			for (int k = 0; k < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownFigurineItemType.Count; k++)
			{
				list.Add(CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownFigurineItemType[k]);
			}
			for (int l = 0; l < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownBoardGameItemType.Count; l++)
			{
				if (CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownBoardGameItemType[l] != EItemType.None)
				{
					list.Add(CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownBoardGameItemType[l]);
				}
			}
		}
		for (int m = 0; m < this.m_CheckPricePanelUIList.Count; m++)
		{
			this.m_CheckPricePanelUIList[m].SetActive(false);
		}
		for (int n = 0; n < list.Count; n++)
		{
			this.m_CheckPricePanelUIList[n].InitItem(this, list[n]);
			this.m_CheckPricePanelUIList[n].SetActive(true);
			this.m_ScrollEndParent.transform.parent = this.m_CheckPricePanelUIList[n].transform;
			this.m_ScrollEndParent.transform.position = this.m_CheckPricePanelUIList[n].transform.position;
			this.m_ScrollEndPosParent = this.m_ScrollEndParent;
		}
		this.m_CardPageOptionGrp.SetActive(false);
	}

	// Token: 0x06000416 RID: 1046 RVA: 0x00024B6D File Offset: 0x00022D6D
	public void OnPressNextCardPage()
	{
		if (this.m_CardPageIndex < this.m_CardPageMaxIndex)
		{
			this.m_CardPageIndex++;
			this.EvaluateCardPanelUI(this.m_CardPageIndex);
		}
	}

	// Token: 0x06000417 RID: 1047 RVA: 0x00024B97 File Offset: 0x00022D97
	public void OnPressPreviousCardPage()
	{
		if (this.m_CardPageIndex > 0)
		{
			this.m_CardPageIndex--;
			this.EvaluateCardPanelUI(this.m_CardPageIndex);
		}
	}

	// Token: 0x06000418 RID: 1048 RVA: 0x00024BBC File Offset: 0x00022DBC
	public void OnPressNext10CardPage()
	{
		if (this.m_CardPageIndex < this.m_CardPageMaxIndex)
		{
			this.m_CardPageIndex += 10;
			if (this.m_CardPageIndex > this.m_CardPageMaxIndex)
			{
				this.m_CardPageIndex = this.m_CardPageMaxIndex;
			}
			this.EvaluateCardPanelUI(this.m_CardPageIndex);
		}
	}

	// Token: 0x06000419 RID: 1049 RVA: 0x00024C0C File Offset: 0x00022E0C
	public void OnPressPrevious10CardPage()
	{
		if (this.m_CardPageIndex > 0)
		{
			this.m_CardPageIndex -= 10;
			if (this.m_CardPageIndex < 0)
			{
				this.m_CardPageIndex = 0;
			}
			this.EvaluateCardPanelUI(this.m_CardPageIndex);
		}
	}

	// Token: 0x0600041A RID: 1050 RVA: 0x00024C42 File Offset: 0x00022E42
	public void OnPressChangeCardExpansion()
	{
		SoundManager.GenericMenuOpen(1f, 1f);
		CardExpansionSelectScreen.OpenScreen(this.m_CurrentExpansionType);
		CEventManager.AddListener<CEventPlayer_OnCardExpansionSelectScreenUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnCardExpansionSelectScreenUpdated>(this.OnCardExpansionUpdated));
	}

	// Token: 0x0600041B RID: 1051 RVA: 0x00024C70 File Offset: 0x00022E70
	protected void OnCardExpansionUpdated(CEventPlayer_OnCardExpansionSelectScreenUpdated evt)
	{
		this.m_CurrentExpansionType = (ECardExpansionType)evt.m_CardExpansionTypeIndex;
		this.m_CardExpansionText.text = InventoryBase.GetCardExpansionName(this.m_CurrentExpansionType);
		this.m_CardPageIndex = 0;
		this.m_CardPageMaxIndex = InventoryBase.GetShownMonsterList(this.m_CurrentExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(this.m_CurrentExpansionType, true) / this.m_MaxCardUICountPerPage - 1;
		if (this.m_CurrentExpansionType == ECardExpansionType.Ghost)
		{
			this.m_CardPageMaxIndex *= 2;
		}
		this.EvaluateCardPanelUI(this.m_CardPageIndex);
		CEventManager.RemoveListener<CEventPlayer_OnCardExpansionSelectScreenUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnCardExpansionSelectScreenUpdated>(this.OnCardExpansionUpdated));
	}

	// Token: 0x0600041C RID: 1052 RVA: 0x00024D08 File Offset: 0x00022F08
	private void EvaluateCardPanelUI(int cardPageIndex)
	{
		this.m_PosX = 0f;
		this.m_LerpPosX = 0f;
		for (int i = 0; i < this.m_CheckPricePanelUIList.Count; i++)
		{
			this.m_CheckPricePanelUIList[i].SetActive(false);
		}
		this.m_CardExpansionText.text = InventoryBase.GetCardExpansionName(this.m_CurrentExpansionType);
		int num = cardPageIndex * this.m_MaxCardUICountPerPage;
		int num2 = num;
		int num3 = InventoryBase.GetShownMonsterList(this.m_CurrentExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(this.m_CurrentExpansionType, true);
		if (this.m_CurrentExpansionType == ECardExpansionType.Ghost)
		{
			num3 *= 2;
		}
		this.m_CardPageMaxIndex = Mathf.CeilToInt((float)num3 / (float)this.m_MaxCardUICountPerPage) - 1;
		for (int j = 0; j < this.m_MaxCardUICountPerPage; j++)
		{
			if (num >= num3)
			{
				this.m_CheckPricePanelUIList[j].SetActive(false);
			}
			else
			{
				bool isDestiny = false;
				if (this.m_CurrentExpansionType == ECardExpansionType.Ghost)
				{
					if (num2 >= InventoryBase.GetShownMonsterList(this.m_CurrentExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(this.m_CurrentExpansionType, true))
					{
						isDestiny = true;
						num2 -= InventoryBase.GetShownMonsterList(this.m_CurrentExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(this.m_CurrentExpansionType, true);
					}
					this.m_CheckPricePanelUIList[j].InitCard(this, num2, this.m_CurrentExpansionType, isDestiny);
				}
				else
				{
					this.m_CheckPricePanelUIList[j].InitCard(this, num, this.m_CurrentExpansionType, isDestiny);
				}
				this.m_CheckPricePanelUIList[j].SetActive(true);
				this.m_ScrollEndParent.transform.parent = this.m_CheckPricePanelUIList[j].transform;
				this.m_ScrollEndParent.transform.position = this.m_CheckPricePanelUIList[j].transform.position;
				Vector3 position = this.m_ScrollEndParent.transform.position;
				position.y += this.m_CardScrollOffsetPosEnd.position.y - this.m_CardScrollOffsetPosStart.position.y;
				this.m_ScrollEndParent.transform.position = position;
				this.m_ScrollEndPosParent = this.m_ScrollEndParent;
				num++;
				num2 = num;
			}
		}
		this.m_PageText.text = (this.m_CardPageIndex + 1).ToString() + " / " + (this.m_CardPageMaxIndex + 1).ToString();
		this.m_CardPageOptionGrp.SetActive(true);
	}

	// Token: 0x0600041D RID: 1053 RVA: 0x00024F77 File Offset: 0x00023177
	protected override void OnOpenScreen()
	{
		this.Init();
		base.OnOpenScreen();
	}

	// Token: 0x0600041E RID: 1054 RVA: 0x00024F85 File Offset: 0x00023185
	public void OnPressOpenItemPriceGraph(EItemType itemType)
	{
		this.m_ItemPriceGraphScreen.ShowItemPriceChart(itemType);
		base.OpenChildScreen(this.m_ItemPriceGraphScreen);
	}

	// Token: 0x0600041F RID: 1055 RVA: 0x00024F9F File Offset: 0x0002319F
	public void OnPressOpenCardPriceGraph(int cardIndex, ECardExpansionType expansionType, bool isDestiny)
	{
		this.m_ItemPriceGraphScreen.ShowCardPriceChart(cardIndex, expansionType, isDestiny);
		base.OpenChildScreen(this.m_ItemPriceGraphScreen);
	}

	// Token: 0x040004EE RID: 1262
	public List<CheckPricePanelUI> m_CheckPricePanelUIList;

	// Token: 0x040004EF RID: 1263
	public List<GameObject> m_PageButtonHighlightList;

	// Token: 0x040004F0 RID: 1264
	public ItemPriceGraphScreen m_ItemPriceGraphScreen;

	// Token: 0x040004F1 RID: 1265
	public GameObject m_CardPageOptionGrp;

	// Token: 0x040004F2 RID: 1266
	public GameObject m_ScrollEndParent;

	// Token: 0x040004F3 RID: 1267
	public Transform m_CardScrollOffsetPosStart;

	// Token: 0x040004F4 RID: 1268
	public Transform m_CardScrollOffsetPosEnd;

	// Token: 0x040004F5 RID: 1269
	public TextMeshProUGUI m_PageText;

	// Token: 0x040004F6 RID: 1270
	public TextMeshProUGUI m_CardExpansionText;

	// Token: 0x040004F7 RID: 1271
	public Color m_PositiveColor;

	// Token: 0x040004F8 RID: 1272
	public Color m_NegativeColor;

	// Token: 0x040004F9 RID: 1273
	public Color m_NeutralColor;

	// Token: 0x040004FA RID: 1274
	private int m_PageIndex = -1;

	// Token: 0x040004FB RID: 1275
	private int m_CardPageIndex;

	// Token: 0x040004FC RID: 1276
	private int m_CardPageMaxIndex;

	// Token: 0x040004FD RID: 1277
	public int m_MaxCardUICountPerPage = 12;

	// Token: 0x040004FE RID: 1278
	private ECardExpansionType m_CurrentExpansionType;
}
