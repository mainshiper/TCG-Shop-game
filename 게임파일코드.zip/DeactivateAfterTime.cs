﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000103 RID: 259
public class DeactivateAfterTime : MonoBehaviour
{
	// Token: 0x060007A8 RID: 1960 RVA: 0x0003A69B File Offset: 0x0003889B
	private void OnEnable()
	{
		this.m_CurrentCoroutine = base.StartCoroutine(this.DestroyDelay());
	}

	// Token: 0x060007A9 RID: 1961 RVA: 0x0003A6AF File Offset: 0x000388AF
	private void OnDisable()
	{
		if (this.m_CurrentCoroutine != null)
		{
			base.StopCoroutine(this.m_CurrentCoroutine);
			base.gameObject.SetActive(false);
		}
	}

	// Token: 0x060007AA RID: 1962 RVA: 0x0003A6D1 File Offset: 0x000388D1
	private IEnumerator DestroyDelay()
	{
		if (this.m_IgnoreTimescale)
		{
			yield return new WaitForSecondsRealtime(this.m_Timer);
		}
		else
		{
			yield return new WaitForSeconds(this.m_Timer);
		}
		base.gameObject.SetActive(false);
		yield break;
	}

	// Token: 0x04000EED RID: 3821
	public float m_Timer = 1f;

	// Token: 0x04000EEE RID: 3822
	public bool m_IgnoreTimescale;

	// Token: 0x04000EEF RID: 3823
	private Coroutine m_CurrentCoroutine;
}
