﻿using System;

// Token: 0x020000CD RID: 205
public class CEventUI_GameVersionNotLatest : CEvent
{
	// Token: 0x17000027 RID: 39
	// (get) Token: 0x0600074E RID: 1870 RVA: 0x000395EB File Offset: 0x000377EB
	// (set) Token: 0x0600074F RID: 1871 RVA: 0x000395F3 File Offset: 0x000377F3
	public float m_CurrentVersion { get; private set; }

	// Token: 0x17000028 RID: 40
	// (get) Token: 0x06000750 RID: 1872 RVA: 0x000395FC File Offset: 0x000377FC
	// (set) Token: 0x06000751 RID: 1873 RVA: 0x00039604 File Offset: 0x00037804
	public float m_LatestVersion { get; private set; }

	// Token: 0x17000029 RID: 41
	// (get) Token: 0x06000752 RID: 1874 RVA: 0x0003960D File Offset: 0x0003780D
	// (set) Token: 0x06000753 RID: 1875 RVA: 0x00039615 File Offset: 0x00037815
	public string m_LatestVersionString { get; private set; }

	// Token: 0x06000754 RID: 1876 RVA: 0x0003961E File Offset: 0x0003781E
	public CEventUI_GameVersionNotLatest(float CurrentVersion, float LatestVersion, string LatestVersionString)
	{
		this.m_CurrentVersion = CurrentVersion;
		this.m_LatestVersion = LatestVersion;
		this.m_LatestVersionString = LatestVersionString;
	}
}
