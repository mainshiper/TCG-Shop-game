﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000137 RID: 311
[CreateAssetMenu(fileName = "Data", menuName = "Inventory/List", order = 6)]
public class Text_ScriptableObject : ScriptableObject
{
	// Token: 0x060008FB RID: 2299 RVA: 0x0004283C File Offset: 0x00040A3C
	public string GetRandomName()
	{
		int num = Mathf.Clamp(Random.Range(-4, 4), 1, 3);
		int num2 = Random.Range(0, 100);
		int num3 = Random.Range(0, 100);
		List<string> randomName = this.m_RandomName1;
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		List<string> list3 = new List<string>();
		string text = "";
		string text2 = "";
		if (num >= 1)
		{
			if (Random.Range(0, 2) == 0)
			{
				list = this.m_RandomName2;
			}
			else
			{
				list = this.m_RandomName3;
			}
		}
		if (num >= 2)
		{
			if (Random.Range(0, 2) == 0)
			{
				list2 = this.m_RandomName2;
			}
			else
			{
				list2 = this.m_RandomName3;
			}
		}
		if (num >= 3)
		{
			if (Random.Range(0, 2) == 0)
			{
				list3 = this.m_RandomName2;
			}
			else
			{
				list3 = this.m_RandomName3;
			}
		}
		if (num2 < 15)
		{
			text = Random.Range(0, 10000).ToString();
		}
		if (num3 < 15)
		{
			if (Random.Range(0, 2) == 0)
			{
				int index = Random.Range(0, this.m_RandomName2.Count);
				text2 = this.m_RandomName2[index];
			}
			else
			{
				int index2 = Random.Range(0, this.m_RandomName3.Count);
				text2 = this.m_RandomName3[index2];
			}
		}
		int index3 = Random.Range(0, randomName.Count);
		int index4 = Random.Range(0, list.Count);
		int index5 = Random.Range(0, list2.Count);
		int index6 = Random.Range(0, list3.Count);
		string text3 = text2;
		if (randomName.Count > 0)
		{
			text3 += randomName[index3];
		}
		if (list.Count > 0)
		{
			text3 += list[index4];
		}
		if (list2.Count > 0)
		{
			text3 += list2[index5];
		}
		if (list3.Count > 0)
		{
			text3 += list3[index6];
		}
		if (text != "")
		{
			text3 += text;
		}
		if (!char.IsUpper(text3[0]) && Random.Range(0, 100) < 30)
		{
			text3 = char.ToUpper(text3[0]).ToString() + text3.Substring(1);
		}
		return text3;
	}

	// Token: 0x04001116 RID: 4374
	public List<string> m_RandomName1;

	// Token: 0x04001117 RID: 4375
	public List<string> m_RandomName2;

	// Token: 0x04001118 RID: 4376
	public List<string> m_RandomName3;

	// Token: 0x04001119 RID: 4377
	public List<string> m_CardExpansionNameList;

	// Token: 0x0400111A RID: 4378
	public List<Material> m_CurrencyMaterialList;

	// Token: 0x0400111B RID: 4379
	public List<PriceChangeTypeText> m_PriceChangeTypeTextList;

	// Token: 0x0400111C RID: 4380
	public List<Sprite> m_GamepadCtrlBtnSpriteList;

	// Token: 0x0400111D RID: 4381
	public List<Sprite> m_XBoxCtrlBtnSpriteList;

	// Token: 0x0400111E RID: 4382
	public List<Sprite> m_PSCtrlBtnSpriteList;

	// Token: 0x0400111F RID: 4383
	public Sprite m_KeyboardBtnImage;

	// Token: 0x04001120 RID: 4384
	public Sprite m_LeftMouseClickImage;

	// Token: 0x04001121 RID: 4385
	public Sprite m_RightMouseClickImage;

	// Token: 0x04001122 RID: 4386
	public Sprite m_LeftMouseHoldImage;

	// Token: 0x04001123 RID: 4387
	public Sprite m_RightMouseHoldImage;

	// Token: 0x04001124 RID: 4388
	public Sprite m_MiddleMouseScrollImage;

	// Token: 0x04001125 RID: 4389
	public Sprite m_EnterImage;

	// Token: 0x04001126 RID: 4390
	public Sprite m_SpacebarImage;

	// Token: 0x04001127 RID: 4391
	public Sprite m_TabImage;

	// Token: 0x04001128 RID: 4392
	public Sprite m_ShiftImage;

	// Token: 0x04001129 RID: 4393
	public Sprite m_QuestionMarkImage;
}
