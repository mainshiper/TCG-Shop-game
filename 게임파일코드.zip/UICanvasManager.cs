﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000140 RID: 320
public class UICanvasManager : MonoBehaviour
{
	// Token: 0x0600091A RID: 2330 RVA: 0x0004343B File Offset: 0x0004163B
	private void Awake()
	{
		UICanvasManager.GlobalAccess = this;
	}

	// Token: 0x0600091B RID: 2331 RVA: 0x00043443 File Offset: 0x00041643
	private void Start()
	{
		if (this.PENameText != null)
		{
			this.PENameText.text = ParticleEffectsLibrary.GlobalAccess.GetCurrentPENameString();
		}
	}

	// Token: 0x0600091C RID: 2332 RVA: 0x00043468 File Offset: 0x00041668
	private void Update()
	{
		if (!this.MouseOverButton && Input.GetMouseButtonUp(0))
		{
			this.SpawnCurrentParticleEffect();
		}
		if (Input.GetKeyUp(KeyCode.A))
		{
			this.SelectPreviousPE();
		}
		if (Input.GetKeyUp(KeyCode.D))
		{
			this.SelectNextPE();
		}
	}

	// Token: 0x0600091D RID: 2333 RVA: 0x0004349E File Offset: 0x0004169E
	public void UpdateToolTip(ButtonTypes toolTipType)
	{
		if (this.ToolTipText != null)
		{
			if (toolTipType == ButtonTypes.Previous)
			{
				this.ToolTipText.text = "Select Previous Particle Effect";
				return;
			}
			if (toolTipType == ButtonTypes.Next)
			{
				this.ToolTipText.text = "Select Next Particle Effect";
			}
		}
	}

	// Token: 0x0600091E RID: 2334 RVA: 0x000434D7 File Offset: 0x000416D7
	public void ClearToolTip()
	{
		if (this.ToolTipText != null)
		{
			this.ToolTipText.text = "";
		}
	}

	// Token: 0x0600091F RID: 2335 RVA: 0x000434F7 File Offset: 0x000416F7
	private void SelectPreviousPE()
	{
		ParticleEffectsLibrary.GlobalAccess.PreviousParticleEffect();
		if (this.PENameText != null)
		{
			this.PENameText.text = ParticleEffectsLibrary.GlobalAccess.GetCurrentPENameString();
		}
	}

	// Token: 0x06000920 RID: 2336 RVA: 0x00043526 File Offset: 0x00041726
	private void SelectNextPE()
	{
		ParticleEffectsLibrary.GlobalAccess.NextParticleEffect();
		if (this.PENameText != null)
		{
			this.PENameText.text = ParticleEffectsLibrary.GlobalAccess.GetCurrentPENameString();
		}
	}

	// Token: 0x06000921 RID: 2337 RVA: 0x00043555 File Offset: 0x00041755
	private void SpawnCurrentParticleEffect()
	{
		if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), ref this.rayHit))
		{
			ParticleEffectsLibrary.GlobalAccess.SpawnParticleEffect(this.rayHit.point);
		}
	}

	// Token: 0x06000922 RID: 2338 RVA: 0x00043588 File Offset: 0x00041788
	public void UIButtonClick(ButtonTypes buttonTypeClicked)
	{
		if (buttonTypeClicked == ButtonTypes.Previous)
		{
			this.SelectPreviousPE();
			return;
		}
		if (buttonTypeClicked != ButtonTypes.Next)
		{
			return;
		}
		this.SelectNextPE();
	}

	// Token: 0x0400114A RID: 4426
	public static UICanvasManager GlobalAccess;

	// Token: 0x0400114B RID: 4427
	public bool MouseOverButton;

	// Token: 0x0400114C RID: 4428
	public Text PENameText;

	// Token: 0x0400114D RID: 4429
	public Text ToolTipText;

	// Token: 0x0400114E RID: 4430
	private RaycastHit rayHit;
}
