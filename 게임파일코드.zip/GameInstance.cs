﻿using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

// Token: 0x020000A7 RID: 167
public class GameInstance : CSingleton<GameInstance>
{
	// Token: 0x060006B5 RID: 1717 RVA: 0x00037FA4 File Offset: 0x000361A4
	public void Start()
	{
		if (GameInstance.m_Instance == null)
		{
			GameInstance.m_Instance = this;
		}
		else if (GameInstance.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
	}

	// Token: 0x060006B6 RID: 1718 RVA: 0x00037FDC File Offset: 0x000361DC
	public static float GetInvariantCultureDecimal(string text)
	{
		string text2 = text.Replace(",", ".");
		List<int> list = new List<int>();
		int num = 0;
		string text3 = text2;
		for (int i = 0; i < text3.Length; i++)
		{
			if (text3[i] == '.')
			{
				list.Add(num);
			}
			num++;
		}
		if (list.Count > 1)
		{
			for (int j = list.Count - 2; j >= 0; j--)
			{
				text2 = text2.Remove(list[j], 1);
			}
		}
		float result;
		try
		{
			result = float.Parse(text2, CultureInfo.InvariantCulture);
		}
		catch
		{
			result = 0f;
		}
		return result;
	}

	// Token: 0x060006B7 RID: 1719 RVA: 0x0003808C File Offset: 0x0003628C
	public static string GetPriceString(float price, bool useDashAsZero = false, bool useCurrencySymbol = true, bool useCentSymbol = false, string decimalString = "F2")
	{
		if (price <= 0f && useDashAsZero)
		{
			return "-";
		}
		if (GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price) < 1f)
		{
			decimalString = "F2";
		}
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.Euro)
		{
			if (!useCurrencySymbol)
			{
				return GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price).ToString(decimalString);
			}
			if (useCentSymbol && price < 1f)
			{
				return (GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price) * 100f).ToString("F0") + "¢";
			}
			return "€" + GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price).ToString(decimalString);
		}
		else if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.Yen)
		{
			if (decimalString == "F2" || decimalString == "N2")
			{
				decimalString = "N0";
			}
			if (useCurrencySymbol)
			{
				return "¥" + Mathf.RoundToInt(GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price)).ToString(decimalString);
			}
			return Mathf.RoundToInt(GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price)).ToString(decimalString);
		}
		else if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.GBP)
		{
			if (!useCurrencySymbol)
			{
				return GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price).ToString(decimalString);
			}
			if (useCentSymbol && price < 1f)
			{
				return (GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price) * 100f).ToString("F0") + "p";
			}
			return "£" + GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price).ToString(decimalString);
		}
		else if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.CNY)
		{
			if (useCurrencySymbol)
			{
				return "¥" + GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price).ToString(decimalString);
			}
			return GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price).ToString(decimalString);
		}
		else if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.MYR)
		{
			if (!useCurrencySymbol)
			{
				return GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price).ToString(decimalString);
			}
			float currencyValue = GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price);
			if (useCentSymbol && price < 1f && currencyValue < 1f)
			{
				return (GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price) * 100f).ToString("F0") + " sen";
			}
			return "RM" + GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price).ToString(decimalString);
		}
		else if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.AUD)
		{
			if (!useCurrencySymbol)
			{
				return GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price).ToString(decimalString);
			}
			float currencyValue2 = GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price);
			if (useCentSymbol && price < 1f && currencyValue2 < 1f)
			{
				return (GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price) * 100f).ToString("F0") + "¢";
			}
			return "$" + GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price).ToString(decimalString);
		}
		else
		{
			if (!useCurrencySymbol)
			{
				return price.ToString(decimalString);
			}
			if (useCentSymbol && price < 1f)
			{
				return (price * 100f).ToString("F0") + "¢";
			}
			return "$" + price.ToString(decimalString);
		}
	}

	// Token: 0x060006B8 RID: 1720 RVA: 0x0003843F File Offset: 0x0003663F
	public static float GetConvertedCurrencyPrice(float price)
	{
		return (float)Mathf.RoundToInt(price * GameInstance.GetCurrencyConversionRate() * 100f) / 100f;
	}

	// Token: 0x060006B9 RID: 1721 RVA: 0x0003845C File Offset: 0x0003665C
	public static float GetCurrencyConversionRate()
	{
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.Euro)
		{
			return 1f;
		}
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.Yen)
		{
			return 100f;
		}
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.GBP)
		{
			return 1f;
		}
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.CNY)
		{
			return 2.5f;
		}
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.MYR)
		{
			return 2f;
		}
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.AUD)
		{
			return 2f;
		}
		return 1f;
	}

	// Token: 0x060006BA RID: 1722 RVA: 0x000384E0 File Offset: 0x000366E0
	public static float GetCurrencyRoundDivideAmount()
	{
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.CNY)
		{
			return 1000f;
		}
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.MYR)
		{
			return 1000f;
		}
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.AUD)
		{
			return 1000f;
		}
		return 100f;
	}

	// Token: 0x060006BB RID: 1723 RVA: 0x00038520 File Offset: 0x00036720
	public static float GetCurrencyValue(EMoneyCurrencyType currencyType, float baseValue)
	{
		return baseValue * GameInstance.GetCurrencyConversionRate();
	}

	// Token: 0x060006BC RID: 1724 RVA: 0x00038529 File Offset: 0x00036729
	public static bool GetCurrencyHasDecimal(EMoneyCurrencyType currencyType)
	{
		return currencyType != EMoneyCurrencyType.Yen;
	}

	// Token: 0x060006BD RID: 1725 RVA: 0x00038534 File Offset: 0x00036734
	public static string GetTimeString(float time, bool showDay = true, bool showHour = true, bool showMinutes = true, bool showSeconds = true, bool removeZero = false, bool convertDayToHour = false)
	{
		if (time < 0f)
		{
			time = 0f;
		}
		GameInstance.m_Day = (int)time / 86400;
		GameInstance.m_Hour = (int)time / 3600;
		if (!convertDayToHour)
		{
			GameInstance.m_Hour = (int)time % 86400 / 3600;
		}
		GameInstance.m_Minute = (int)time % 3600 / 60;
		GameInstance.m_Second = (int)time % 60;
		if (GameInstance.m_Day == 0)
		{
			showDay = false;
		}
		if (GameInstance.m_Hour == 0)
		{
			showHour = false;
		}
		if (GameInstance.m_Minute == 0)
		{
			showMinutes = false;
		}
		if (GameInstance.m_Second == 0)
		{
			showSeconds = false;
		}
		GameInstance.m_TimeString = "";
		if (showDay)
		{
			GameInstance.m_TimeString = GameInstance.m_Day.ToString() + GameInstance.m_DayTranslatedText;
			if (showMinutes || showSeconds)
			{
				showHour = true;
			}
		}
		if (showHour)
		{
			if (GameInstance.m_TimeString != "")
			{
				GameInstance.m_TimeString = GameInstance.m_TimeString + " " + GameInstance.m_Hour.ToString() + GameInstance.m_HourTranslatedText;
			}
			else
			{
				GameInstance.m_TimeString = GameInstance.m_TimeString + GameInstance.m_Hour.ToString() + GameInstance.m_HourTranslatedText;
			}
			if (showSeconds)
			{
				showMinutes = true;
			}
		}
		if (showDay && showHour && removeZero)
		{
			if (GameInstance.m_Minute == 0)
			{
				showMinutes = false;
				showSeconds = false;
			}
			else
			{
				showMinutes = true;
			}
		}
		if (showMinutes)
		{
			if (GameInstance.m_TimeString != "")
			{
				GameInstance.m_TimeString = GameInstance.m_TimeString + " " + GameInstance.m_Minute.ToString() + GameInstance.m_MinTranslatedText;
			}
			else
			{
				GameInstance.m_TimeString = GameInstance.m_TimeString + GameInstance.m_Minute.ToString() + GameInstance.m_MinTranslatedText;
			}
		}
		if (!showDay && !showHour && !showMinutes)
		{
			showSeconds = true;
		}
		if (!showDay && !showHour)
		{
			showSeconds = true;
		}
		if (removeZero && GameInstance.m_Second == 0)
		{
			showSeconds = false;
		}
		if (showSeconds)
		{
			if (GameInstance.m_TimeString != "")
			{
				GameInstance.m_TimeString = GameInstance.m_TimeString + " " + GameInstance.m_Second.ToString() + GameInstance.m_SecondTranslatedText;
			}
			else
			{
				GameInstance.m_TimeString = GameInstance.m_TimeString + GameInstance.m_Second.ToString() + GameInstance.m_SecondTranslatedText;
			}
		}
		return GameInstance.m_TimeString;
	}

	// Token: 0x060006BE RID: 1726 RVA: 0x00038742 File Offset: 0x00036942
	public static int GetDigit(float value, int digit)
	{
		return (int)(value / Mathf.Pow(10f, (float)(digit - 1))) % 10;
	}

	// Token: 0x060006BF RID: 1727 RVA: 0x00038759 File Offset: 0x00036959
	public static int GetDecimal(float value, int digit)
	{
		return GameInstance.GetDigit((float)Mathf.FloorToInt(value * Mathf.Pow(10f, (float)digit)), digit);
	}

	// Token: 0x060006C0 RID: 1728 RVA: 0x00038778 File Offset: 0x00036978
	public static void SetIsSaveDataDirtySyncToCloud(bool isDirty, int priorityPoint = 1, float upgradeTime = 0f)
	{
		if (GameInstance.m_IsSaveDataDirtySyncToCloud != isDirty)
		{
			GameInstance.m_IsSaveDataDirtySyncToCloud = isDirty;
		}
		if (isDirty)
		{
			GameInstance.m_SaveDataDirtySyncToCloudCount += priorityPoint + Mathf.FloorToInt(upgradeTime / 1800f);
			if (GameInstance.m_SaveDataDirtySyncToCloudCount > 2 && CGameManager.m_ForceSyncCloudResetTimer > 6f)
			{
				CGameManager.m_ForceSyncCloudResetTimer = 0f;
				GameInstance.m_SaveDataDirtySyncToCloudCount = 0;
				CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
				CSingleton<CGameManager>.Instance.SaveGameData(0);
				return;
			}
		}
		else
		{
			GameInstance.m_SaveDataDirtySyncToCloudCount = 0;
			CGameManager.m_ForceSyncCloudResetTimer = 0f;
		}
	}

	// Token: 0x040008ED RID: 2285
	public static GameInstance m_Instance = null;

	// Token: 0x040008EE RID: 2286
	public static bool m_HasFinishHideLoadingScreen = false;

	// Token: 0x040008EF RID: 2287
	public static bool m_IsRestartingGameDeleteAll = false;

	// Token: 0x040008F0 RID: 2288
	public static bool m_HasLoadingError = false;

	// Token: 0x040008F1 RID: 2289
	public static bool m_IsSaveDataDirtySyncToCloud = false;

	// Token: 0x040008F2 RID: 2290
	public static bool m_SaveFileNotFound = false;

	// Token: 0x040008F3 RID: 2291
	public static bool m_LoadingDifferentAccount = false;

	// Token: 0x040008F4 RID: 2292
	public static bool m_StopCoinGemTextLerp = false;

	// Token: 0x040008F5 RID: 2293
	public static bool m_CanDragMainMenuSlider = false;

	// Token: 0x040008F6 RID: 2294
	public static bool m_FinishedSavefileLoading = false;

	// Token: 0x040008F7 RID: 2295
	public static int m_SaveDataDirtySyncToCloudCount = 0;

	// Token: 0x040008F8 RID: 2296
	public static int m_CurrentSceneIndex = 0;

	// Token: 0x040008F9 RID: 2297
	private static string m_DayTranslatedText = "d";

	// Token: 0x040008FA RID: 2298
	private static string m_HourTranslatedText = "h";

	// Token: 0x040008FB RID: 2299
	private static string m_MinTranslatedText = "min";

	// Token: 0x040008FC RID: 2300
	private static string m_SecondTranslatedText = "s";

	// Token: 0x040008FD RID: 2301
	private static int m_Day = 0;

	// Token: 0x040008FE RID: 2302
	private static int m_Hour = 0;

	// Token: 0x040008FF RID: 2303
	private static int m_Minute = 0;

	// Token: 0x04000900 RID: 2304
	private static int m_Second = 0;

	// Token: 0x04000901 RID: 2305
	private static string m_TimeString;
}
