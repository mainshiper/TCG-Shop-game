﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000041 RID: 65
public class PricePopupSpawner : CSingleton<PricePopupSpawner>
{
	// Token: 0x06000326 RID: 806 RVA: 0x0001D628 File Offset: 0x0001B828
	public void ShowPricePopup(float price, float offsetUp, Transform followTransform)
	{
		if (CSingleton<InteractionPlayerController>.Instance.IsInUIMode())
		{
			return;
		}
		for (int i = 0; i < this.m_PricePopupList.Count; i++)
		{
			if (!this.m_PricePopupList[i].gameObject.activeSelf)
			{
				this.m_PricePopupList[i].SetFollowTransform(followTransform, offsetUp);
				this.m_PricePopupList[i].m_Transform.position = this.m_PricePopupList[i].m_FollowTransform.position + Vector3.up * this.m_PricePopupList[i].m_OffsetUp;
				this.m_PricePopupList[i].m_Transform.LookAt(new Vector3(this.m_Cam.position.x, this.m_Cam.position.y, this.m_Cam.position.z));
				this.m_PricePopupList[i].m_Text.color = this.m_AddMoneyColor;
				this.m_PricePopupList[i].m_Text.text = "+" + GameInstance.GetPriceString(price, false, true, false, "F2");
				this.m_PricePopupList[i].gameObject.SetActive(true);
				return;
			}
		}
	}

	// Token: 0x06000327 RID: 807 RVA: 0x0001D788 File Offset: 0x0001B988
	public void ShowTextPopup(string text, float offsetUp, Transform followTransform)
	{
		if (CSingleton<InteractionPlayerController>.Instance.IsInUIMode())
		{
			return;
		}
		for (int i = 0; i < this.m_PricePopupList.Count; i++)
		{
			if (!this.m_PricePopupList[i].gameObject.activeSelf)
			{
				this.m_PricePopupList[i].SetFollowTransform(followTransform, offsetUp);
				this.m_PricePopupList[i].m_Transform.position = this.m_PricePopupList[i].m_FollowTransform.position + Vector3.up * this.m_PricePopupList[i].m_OffsetUp;
				this.m_PricePopupList[i].m_Transform.LookAt(new Vector3(this.m_Cam.position.x, this.m_Cam.position.y, this.m_Cam.position.z));
				this.m_PricePopupList[i].m_Text.color = Color.white;
				this.m_PricePopupList[i].m_Text.text = text;
				this.m_PricePopupList[i].gameObject.SetActive(true);
				return;
			}
		}
	}

	// Token: 0x06000328 RID: 808 RVA: 0x0001D8D0 File Offset: 0x0001BAD0
	private void Awake()
	{
		for (int i = 0; i < this.m_PricePopupList.Count; i++)
		{
			this.m_PricePopupList[i].gameObject.SetActive(false);
			this.m_PricePopupList[i].Init();
		}
	}

	// Token: 0x06000329 RID: 809 RVA: 0x0001D91C File Offset: 0x0001BB1C
	private void Update()
	{
		for (int i = 0; i < this.m_PricePopupList.Count; i++)
		{
			if (this.m_PricePopupList[i].gameObject.activeSelf)
			{
				this.m_PricePopupList[i].m_Transform.position = this.m_PricePopupList[i].m_FollowTransform.position + Vector3.up * this.m_PricePopupList[i].m_OffsetUp;
				this.m_PricePopupList[i].m_Transform.LookAt(new Vector3(this.m_Cam.position.x, this.m_Cam.position.y, this.m_Cam.position.z));
			}
		}
	}

	// Token: 0x040003D4 RID: 980
	public List<PricePopupUI> m_PricePopupList;

	// Token: 0x040003D5 RID: 981
	public Transform m_Cam;

	// Token: 0x040003D6 RID: 982
	public Color m_AddMoneyColor;
}
