﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;

// Token: 0x0200012C RID: 300
public static class CSaveLoad
{
	// Token: 0x060008D4 RID: 2260 RVA: 0x00041C8C File Offset: 0x0003FE8C
	public static void AutoSaveMoveToEmptySaveSlot()
	{
		string text = Application.persistentDataPath + "/savedGames_Release0.gd";
		if (File.Exists(text))
		{
			if (!File.Exists(Application.persistentDataPath + "/savedGames_Release1.gd"))
			{
				string text2 = Application.persistentDataPath + "/savedGames_Release1.gd";
				File.Copy(text, text2);
				return;
			}
			if (!File.Exists(Application.persistentDataPath + "/savedGames_Release2.gd"))
			{
				string text2 = Application.persistentDataPath + "/savedGames_Release2.gd";
				File.Copy(text, text2);
				return;
			}
			if (!File.Exists(Application.persistentDataPath + "/savedGames_Release3.gd"))
			{
				string text2 = Application.persistentDataPath + "/savedGames_Release3.gd";
				File.Copy(text, text2);
			}
		}
	}

	// Token: 0x060008D5 RID: 2261 RVA: 0x00041D44 File Offset: 0x0003FF44
	public static void Save(int saveSlotIndex, bool skipJSONSave = false)
	{
		Debug.Log("Save saveSlotIndex " + saveSlotIndex.ToString());
		CSaveLoad.m_SavedGame = CGameData.instance;
		string text = Application.persistentDataPath + "/savedGames_Release" + saveSlotIndex.ToString() + ".gd";
		string text2 = Application.persistentDataPath + "/savedGames_ReleaseBackupFile" + saveSlotIndex.ToString() + ".gd";
		string text3 = Application.persistentDataPath + "Temp" + saveSlotIndex.ToString() + ".gd";
		if (!skipJSONSave)
		{
			string text4 = Application.persistentDataPath + "/savedGames_Release" + saveSlotIndex.ToString() + ".json";
			try
			{
				string text5 = JsonUtility.ToJson(CSaveLoad.m_SavedGame);
				File.WriteAllText(text4, text5);
			}
			catch
			{
				Debug.Log("Error saving JSON");
			}
		}
		using (FileStream fileStream = File.Create(text3))
		{
			new BinaryFormatter().Serialize(fileStream, CSaveLoad.m_SavedGame);
			fileStream.Close();
			CSaveLoad.m_SavedGame = null;
		}
		if (CSaveLoad.ValidateSavedSlotData(text3))
		{
			if (File.Exists(text))
			{
				if (File.Exists(text2))
				{
					File.Delete(text2);
				}
				File.Move(text, text2);
			}
			if (File.Exists(text3))
			{
				File.Move(text3, text);
			}
			CSaveLoad.m_ValidateSaveCount = 0;
			Debug.Log("Save process done");
			if (saveSlotIndex == 0)
			{
				CEventManager.QueueEvent(new CEventPlayer_OnSaveStatusUpdated(true, false));
				return;
			}
		}
		else
		{
			CSaveLoad.m_ValidateSaveCount++;
			Debug.Log("ValidateSavedSlotData Save file invalid, try resave m_ValidateSaveCount " + CSaveLoad.m_ValidateSaveCount.ToString());
			if (CSaveLoad.m_ValidateSaveCount < 10)
			{
				CSaveLoad.Save(saveSlotIndex, true);
				return;
			}
			Debug.Log("Error - Cannot save");
			CEventManager.QueueEvent(new CEventPlayer_OnSaveStatusUpdated(false, false));
		}
	}

	// Token: 0x060008D6 RID: 2262 RVA: 0x00041EF8 File Offset: 0x000400F8
	public static bool Load(int slotIndex)
	{
		string text = Application.persistentDataPath + "/savedGames_Release" + slotIndex.ToString() + ".gd";
		string text2 = Application.persistentDataPath + "/savedGames_Release" + slotIndex.ToString() + ".json";
		bool flag = false;
		if (File.Exists(text))
		{
			using (FileStream fileStream = File.Open(text, FileMode.Open))
			{
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				if (fileStream.Length > 0L)
				{
					try
					{
						fileStream.Position = 0L;
						CSaveLoad.m_SavedGame = (CGameData)binaryFormatter.Deserialize(fileStream);
						fileStream.Close();
						return true;
					}
					catch
					{
						fileStream.Close();
						flag = true;
						goto IL_AA;
					}
				}
				fileStream.Close();
				flag = true;
				goto IL_AA;
			}
		}
		flag = true;
		IL_AA:
		if (flag)
		{
			if (File.Exists(text2))
			{
				try
				{
					CSaveLoad.m_SavedGame = JsonUtility.FromJson<CGameData>(File.ReadAllText(text2));
					return true;
				}
				catch
				{
					return false;
				}
			}
			return false;
		}
		return false;
	}

	// Token: 0x060008D7 RID: 2263 RVA: 0x00042004 File Offset: 0x00040204
	public static bool LoadBackup(int slotIndex)
	{
		string text = Application.persistentDataPath + "/savedGames_ReleaseBackupFile" + slotIndex.ToString() + ".gd";
		Debug.Log("LoadBackup " + text);
		if (File.Exists(text))
		{
			using (FileStream fileStream = File.Open(text, FileMode.Open))
			{
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				if (fileStream.Length > 0L)
				{
					try
					{
						fileStream.Position = 0L;
						CSaveLoad.m_SavedGame = (CGameData)binaryFormatter.Deserialize(fileStream);
						fileStream.Close();
						return true;
					}
					catch
					{
						fileStream.Close();
						return false;
					}
				}
				fileStream.Close();
				return false;
			}
			return false;
		}
		return false;
	}

	// Token: 0x060008D8 RID: 2264 RVA: 0x000420C0 File Offset: 0x000402C0
	public static void SaveSetting()
	{
		CSaveLoad.m_SavedSetting = CSettingData.instance;
		using (FileStream fileStream = File.Create(Application.persistentDataPath + "/savedGames_KeybindSetting.gd"))
		{
			new BinaryFormatter().Serialize(fileStream, CSaveLoad.m_SavedSetting);
			fileStream.Close();
		}
	}

	// Token: 0x060008D9 RID: 2265 RVA: 0x00042120 File Offset: 0x00040320
	public static bool LoadSetting()
	{
		if (File.Exists(Application.persistentDataPath + "/savedGames_KeybindSetting.gd"))
		{
			using (FileStream fileStream = File.Open(Application.persistentDataPath + "/savedGames_KeybindSetting.gd", FileMode.Open))
			{
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				if (fileStream.Length > 0L)
				{
					try
					{
						fileStream.Position = 0L;
						CSaveLoad.m_SavedSetting = (CSettingData)binaryFormatter.Deserialize(fileStream);
						fileStream.Close();
						return true;
					}
					catch
					{
						fileStream.Close();
						return false;
					}
				}
				fileStream.Close();
				return false;
			}
			return false;
		}
		return false;
	}

	// Token: 0x060008DA RID: 2266 RVA: 0x000421D0 File Offset: 0x000403D0
	public static void Delete()
	{
		if (File.Exists(Application.persistentDataPath + "/savedGames_Release"))
		{
			File.Delete(Application.persistentDataPath + "/savedGames_Release");
		}
	}

	// Token: 0x060008DB RID: 2267 RVA: 0x000421FC File Offset: 0x000403FC
	public static void DeleteBackup()
	{
		if (File.Exists(Application.persistentDataPath + "/savedGames_ReleaseBackupFile0.gd"))
		{
			File.Delete(Application.persistentDataPath + "/savedGames_ReleaseBackupFile0.gd");
		}
	}

	// Token: 0x060008DC RID: 2268 RVA: 0x00042228 File Offset: 0x00040428
	public static void DeleteCloudFile()
	{
		if (File.Exists(Application.persistentDataPath + "/savedGames_Debug02.gd"))
		{
			File.Delete(Application.persistentDataPath + "/savedGames_Debug02.gd");
		}
	}

	// Token: 0x060008DD RID: 2269 RVA: 0x00042254 File Offset: 0x00040454
	public static byte[] GetLocalSaveFileAsByteArray()
	{
		if (!File.Exists(Application.persistentDataPath + "/savedGames_Release"))
		{
			return null;
		}
		return File.ReadAllBytes(Application.persistentDataPath + "/savedGames_Release");
	}

	// Token: 0x060008DE RID: 2270 RVA: 0x00042284 File Offset: 0x00040484
	public static void LoadCloudFile(byte[] data)
	{
		Debug.Log("DSCloudSaveLoadTest LoadingCloudFile");
		try
		{
			using (FileStream fileStream = new FileStream(Application.persistentDataPath + "/savedGames_Debug02.gd", FileMode.Create, FileAccess.Write))
			{
				fileStream.Write(data, 0, data.Length);
				fileStream.Close();
				if (File.Exists(Application.persistentDataPath + "/savedGames_Debug02.gd"))
				{
					using (FileStream fileStream2 = File.Open(Application.persistentDataPath + "/savedGames_Debug02.gd", FileMode.Open))
					{
						BinaryFormatter binaryFormatter = new BinaryFormatter();
						if (fileStream2.Length > 0L)
						{
							try
							{
								fileStream2.Position = 0L;
								CSaveLoad.m_SavedGameBackup = (CGameData)binaryFormatter.Deserialize(fileStream2);
								fileStream2.Close();
								Debug.Log("DSCloudSaveLoadTest LoadCloudFile sucess");
								goto IL_C5;
							}
							catch
							{
								fileStream2.Close();
								Debug.Log("DSCloudSaveLoadTest LoadCloudFile failed to deserialize");
								goto IL_C5;
							}
						}
						fileStream2.Close();
						Debug.Log("DSCloudSaveLoadTest LoadCloudFile failed, file length 0");
						IL_C5:;
					}
				}
			}
		}
		catch
		{
			Debug.Log("DSCloudSaveLoadTest LoadCloudFile failed");
		}
	}

	// Token: 0x060008DF RID: 2271 RVA: 0x000423B4 File Offset: 0x000405B4
	public static bool HasSaveFile(int saveloadSlotIndex)
	{
		return File.Exists(Application.persistentDataPath + "/savedGames_Release" + saveloadSlotIndex.ToString() + ".gd") || File.Exists(Application.persistentDataPath + "/savedGames_Release" + saveloadSlotIndex.ToString() + ".json");
	}

	// Token: 0x060008E0 RID: 2272 RVA: 0x00042408 File Offset: 0x00040608
	public static bool LoadSavedSlotData(int slotIndex)
	{
		string text = Application.persistentDataPath + "/savedGames_Release" + slotIndex.ToString() + ".gd";
		string text2 = Application.persistentDataPath + "/savedGames_Release" + slotIndex.ToString() + ".json";
		bool flag = false;
		if (File.Exists(text))
		{
			using (FileStream fileStream = File.Open(text, FileMode.Open))
			{
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				if (fileStream.Length > 0L)
				{
					try
					{
						fileStream.Position = 0L;
						CSaveLoad.m_SavedGameBackup = (CGameData)binaryFormatter.Deserialize(fileStream);
						fileStream.Close();
						return true;
					}
					catch
					{
						fileStream.Close();
						flag = true;
						goto IL_AA;
					}
				}
				fileStream.Close();
				flag = true;
				goto IL_AA;
			}
		}
		flag = true;
		IL_AA:
		if (flag)
		{
			if (File.Exists(text2))
			{
				try
				{
					CSaveLoad.m_SavedGameBackup = JsonUtility.FromJson<CGameData>(File.ReadAllText(text2));
					return true;
				}
				catch
				{
					return false;
				}
			}
			return false;
		}
		return false;
	}

	// Token: 0x060008E1 RID: 2273 RVA: 0x00042514 File Offset: 0x00040714
	public static bool ValidateSavedSlotData(string filePath)
	{
		if (File.Exists(filePath))
		{
			using (FileStream fileStream = File.Open(filePath, FileMode.Open))
			{
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				if (fileStream.Length > 0L)
				{
					try
					{
						fileStream.Position = 0L;
						CSaveLoad.m_SavedGameBackup = (CGameData)binaryFormatter.Deserialize(fileStream);
						fileStream.Close();
						CSaveLoad.m_SavedGameBackup = null;
						return true;
					}
					catch
					{
						fileStream.Close();
						return false;
					}
				}
				fileStream.Close();
				return false;
			}
			return false;
		}
		return false;
	}

	// Token: 0x040010C7 RID: 4295
	public static CGameData m_SavedGame = new CGameData();

	// Token: 0x040010C8 RID: 4296
	public static CGameData m_SavedGameBackup = new CGameData();

	// Token: 0x040010C9 RID: 4297
	public static CSettingData m_SavedSetting = new CSettingData();

	// Token: 0x040010CA RID: 4298
	private const string m_FileName = "/savedGames_Release";

	// Token: 0x040010CB RID: 4299
	private const string m_FileNameExt = ".gd";

	// Token: 0x040010CC RID: 4300
	private const string m_JSONFileNameExt = ".json";

	// Token: 0x040010CD RID: 4301
	private const string m_BackupFileName = "/savedGames_ReleaseBackupFile";

	// Token: 0x040010CE RID: 4302
	private const string m_CloudFileName = "/savedGames_Debug02.gd";

	// Token: 0x040010CF RID: 4303
	private const string m_SettingFileName = "/savedGames_KeybindSetting.gd";

	// Token: 0x040010D0 RID: 4304
	private static int m_ValidateSaveCount = 0;
}
