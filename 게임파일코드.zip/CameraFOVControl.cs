﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000006 RID: 6
public class CameraFOVControl : MonoBehaviour
{
	// Token: 0x0600000F RID: 15 RVA: 0x000022B4 File Offset: 0x000004B4
	private void Init()
	{
		this.m_CurrentFOVSlider = CSingleton<CGameManager>.Instance.m_CameraFOVSlider;
		this.m_CurrentFOV = this.m_DefaultFOV + this.m_CurrentFOVSlider * 20f;
		this.UpdateFOV(this.m_CurrentFOV);
		this.UpdateHoldPositionLoc(this.m_CurrentFOV);
	}

	// Token: 0x06000010 RID: 16 RVA: 0x00002304 File Offset: 0x00000504
	public void UpdateFOV(float fov)
	{
		for (int i = 0; i < this.m_CamList.Count; i++)
		{
			this.m_CamList[i].fieldOfView = fov;
		}
		this.UpdateHoldPositionLoc(fov);
	}

	// Token: 0x06000011 RID: 17 RVA: 0x00002340 File Offset: 0x00000540
	private void UpdateHoldPositionLoc(float fov)
	{
		float num = (fov - 40f) / 10f * -0.2f;
		Vector3 one = Vector3.one;
		one.z = 1f + num;
		this.m_PosLocScalerGrp.localScale = one;
	}

	// Token: 0x06000012 RID: 18 RVA: 0x00002381 File Offset: 0x00000581
	public void StartLerpToFOV(float targetFOV)
	{
		this.m_IsLerping = true;
		this.m_TargetLerpFOV = targetFOV;
	}

	// Token: 0x06000013 RID: 19 RVA: 0x00002391 File Offset: 0x00000591
	public void StopLerpFOV()
	{
		this.m_IsLerping = false;
	}

	// Token: 0x06000014 RID: 20 RVA: 0x0000239C File Offset: 0x0000059C
	private void Update()
	{
		if (this.m_CurrentFOVSlider != CSingleton<CGameManager>.Instance.m_CameraFOVSlider)
		{
			this.m_CurrentFOVSlider = CSingleton<CGameManager>.Instance.m_CameraFOVSlider;
			this.m_CurrentFOV = this.m_DefaultFOV + this.m_CurrentFOVSlider * 20f;
			if (!this.m_IsLerping)
			{
				this.UpdateFOV(this.m_CurrentFOV);
				this.UpdateHoldPositionLoc(this.m_CurrentFOV);
			}
		}
		if (this.m_IsLerping && this.m_LerpTimer < 1f)
		{
			this.m_LerpTimer += Time.deltaTime * this.m_LerpSpeed;
			if (this.m_LerpTimer > 1f)
			{
				this.m_LerpTimer = 1f;
			}
			this.UpdateFOV(Mathf.Lerp(this.m_CurrentFOV, this.m_TargetLerpFOV, this.m_LerpTimer));
			return;
		}
		if (!this.m_IsLerping && this.m_LerpTimer > 0f)
		{
			this.m_LerpTimer -= Time.deltaTime * this.m_LerpSpeed;
			if (this.m_LerpTimer < 0f)
			{
				this.m_LerpTimer = 0f;
			}
			this.UpdateFOV(Mathf.Lerp(this.m_CurrentFOV, this.m_TargetLerpFOV, this.m_LerpTimer));
		}
	}

	// Token: 0x06000015 RID: 21 RVA: 0x000024CB File Offset: 0x000006CB
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x06000016 RID: 22 RVA: 0x000024EC File Offset: 0x000006EC
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x06000017 RID: 23 RVA: 0x0000250D File Offset: 0x0000070D
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.Init();
	}

	// Token: 0x04000009 RID: 9
	public List<Camera> m_CamList;

	// Token: 0x0400000A RID: 10
	public Transform m_PosLocScalerGrp;

	// Token: 0x0400000B RID: 11
	public float m_DefaultFOV = 40f;

	// Token: 0x0400000C RID: 12
	private bool m_IsLerping;

	// Token: 0x0400000D RID: 13
	private float m_CurrentFOV = 40f;

	// Token: 0x0400000E RID: 14
	private float m_TargetLerpFOV = 40f;

	// Token: 0x0400000F RID: 15
	private float m_LerpTimer;

	// Token: 0x04000010 RID: 16
	public float m_LerpSpeed = 5f;

	// Token: 0x04000011 RID: 17
	private float m_CurrentFOVSlider;
}
