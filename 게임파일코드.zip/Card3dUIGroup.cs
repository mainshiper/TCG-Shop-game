﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000007 RID: 7
public class Card3dUIGroup : MonoBehaviour
{
	// Token: 0x06000019 RID: 25 RVA: 0x00002549 File Offset: 0x00000749
	private void Awake()
	{
		this.m_NewCardIndicator.SetActive(false);
	}

	// Token: 0x0600001A RID: 26 RVA: 0x00002557 File Offset: 0x00000757
	private void Start()
	{
		Card3dUISpawner.AddCardToManager(this);
		this.m_CardUI.SetBrightness(CSingleton<LightManager>.Instance.GetBrightness());
	}

	// Token: 0x0600001B RID: 27 RVA: 0x00002574 File Offset: 0x00000774
	public void SetVisibility(bool isVisible)
	{
		base.gameObject.SetActive(isVisible);
	}

	// Token: 0x0600001C RID: 28 RVA: 0x00002582 File Offset: 0x00000782
	public void SetCardCountText(int count)
	{
		this.m_CardCountText.text = "X " + count.ToString();
	}

	// Token: 0x0600001D RID: 29 RVA: 0x000025A0 File Offset: 0x000007A0
	public void SetCardCountTextVisibility(bool isVisible)
	{
		this.m_CardCountText.gameObject.SetActive(isVisible);
	}

	// Token: 0x0600001E RID: 30 RVA: 0x000025B3 File Offset: 0x000007B3
	public void ActivateCard()
	{
		this.m_IsActive = true;
	}

	// Token: 0x0600001F RID: 31 RVA: 0x000025BC File Offset: 0x000007BC
	public void DisableCard()
	{
		this.m_IsActive = false;
		Card3dUISpawner.DisableCard(this);
	}

	// Token: 0x06000020 RID: 32 RVA: 0x000025CB File Offset: 0x000007CB
	public void SetLocalScale(Vector3 localScale)
	{
		this.m_ScaleGrp.transform.localScale = localScale;
	}

	// Token: 0x06000021 RID: 33 RVA: 0x000025E0 File Offset: 0x000007E0
	public void SmoothLerpToTransform(Transform targetTransform, Transform targetParent, bool ignoreUpForce = false)
	{
		this.m_Timer = 0f;
		this.m_UpTimer = 0f;
		this.m_Accelration = 0f;
		base.transform.parent = targetParent;
		this.m_StartPos = base.transform.position;
		this.m_StartRot = base.transform.rotation;
		this.m_StartScale = base.transform.localScale;
		this.m_TargetTransform = targetTransform;
		this.m_IsSmoothLerpingToPos = true;
		this.m_IsIgnoreUpForce = ignoreUpForce;
	}

	// Token: 0x06000022 RID: 34 RVA: 0x00002664 File Offset: 0x00000864
	private void Update()
	{
		if (this.m_IsSmoothLerpingToPos)
		{
			this.m_UpTimer += Time.deltaTime * this.m_UpLerpSpeed * 0.75f;
			Vector3 b = Vector3.up * (Mathf.PingPong(Mathf.Clamp(this.m_UpTimer, 0f, 2f), 1f) * this.m_UpLerpHeight);
			if (this.m_UpTimer > 0.2f)
			{
				this.m_Timer += Time.deltaTime * this.m_LerpSpeed * (1f + this.m_Accelration);
				this.m_Accelration += Time.deltaTime;
				base.transform.position = Vector3.Lerp(base.transform.position, this.m_TargetTransform.position + b, Time.deltaTime * 10f);
				base.transform.rotation = Quaternion.Lerp(base.transform.rotation, this.m_TargetTransform.rotation, Time.deltaTime * 10f);
				base.transform.localScale = Vector3.Lerp(base.transform.localScale, this.m_TargetTransform.localScale, Time.deltaTime * 10f);
			}
			else
			{
				this.m_Timer += Time.deltaTime * this.m_LerpSpeed * 0.1f;
				base.transform.position = Vector3.Lerp(base.transform.position, this.m_TargetTransform.position + b, Time.deltaTime * 2f) + b;
				base.transform.rotation = Quaternion.Lerp(base.transform.rotation, this.m_TargetTransform.rotation, Time.deltaTime * 2f);
				base.transform.localScale = Vector3.Lerp(base.transform.localScale, this.m_TargetTransform.localScale, Time.deltaTime * 2f);
			}
			if (this.m_IsIgnoreUpForce)
			{
				b = Vector3.zero;
				this.m_UpTimer = 2f;
			}
		}
	}

	// Token: 0x06000023 RID: 35 RVA: 0x00002889 File Offset: 0x00000A89
	public bool IsActive()
	{
		return this.m_IsActive;
	}

	// Token: 0x04000012 RID: 18
	public CardUI m_CardUI;

	// Token: 0x04000013 RID: 19
	public GameObject m_CardFrontMeshPos;

	// Token: 0x04000014 RID: 20
	public GameObject m_CardBackMesh;

	// Token: 0x04000015 RID: 21
	public GameObject m_NewCardIndicator;

	// Token: 0x04000016 RID: 22
	public Transform m_ScaleGrp;

	// Token: 0x04000017 RID: 23
	public Transform m_CardUIAnimGrp;

	// Token: 0x04000018 RID: 24
	public TextMeshProUGUI m_CardCountText;

	// Token: 0x04000019 RID: 25
	public bool m_IgnoreCulling;

	// Token: 0x0400001A RID: 26
	private bool m_IsActive;

	// Token: 0x0400001B RID: 27
	private bool m_IsSmoothLerpingToPos;

	// Token: 0x0400001C RID: 28
	private bool m_IsIgnoreUpForce;

	// Token: 0x0400001D RID: 29
	private float m_Timer;

	// Token: 0x0400001E RID: 30
	private float m_UpTimer;

	// Token: 0x0400001F RID: 31
	private float m_LerpSpeed = 3f;

	// Token: 0x04000020 RID: 32
	private float m_UpLerpSpeed = 5f;

	// Token: 0x04000021 RID: 33
	private float m_UpLerpHeight = 0.1f;

	// Token: 0x04000022 RID: 34
	private float m_Accelration;

	// Token: 0x04000023 RID: 35
	private Vector3 m_StartPos;

	// Token: 0x04000024 RID: 36
	private Quaternion m_StartRot;

	// Token: 0x04000025 RID: 37
	private Vector3 m_StartScale;

	// Token: 0x04000026 RID: 38
	private Transform m_TargetTransform;
}
