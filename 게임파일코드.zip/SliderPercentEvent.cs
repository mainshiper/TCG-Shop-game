﻿using System;
using UnityEngine.Events;

// Token: 0x02000126 RID: 294
[Serializable]
public class SliderPercentEvent : UnityEvent<float>
{
}
