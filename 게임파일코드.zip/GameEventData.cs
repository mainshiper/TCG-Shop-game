﻿using System;
using I2.Loc;

// Token: 0x02000035 RID: 53
[Serializable]
public class GameEventData
{
	// Token: 0x060002AC RID: 684 RVA: 0x0001A16B File Offset: 0x0001836B
	public string GetName()
	{
		return LocalizationManager.GetTranslation(this.name, true, 0, true, false, null, null, true);
	}

	// Token: 0x04000323 RID: 803
	public string name;

	// Token: 0x04000324 RID: 804
	public EGameEventFormat format;

	// Token: 0x04000325 RID: 805
	public int unlockPlayCountRequired;

	// Token: 0x04000326 RID: 806
	public int hostEventCost;

	// Token: 0x04000327 RID: 807
	public float baseFee;

	// Token: 0x04000328 RID: 808
	public float marketPriceMinPercent;

	// Token: 0x04000329 RID: 809
	public float marketPriceMaxPercent;

	// Token: 0x0400032A RID: 810
	public EPriceChangeType positivePriceChangeType;

	// Token: 0x0400032B RID: 811
	public EPriceChangeType negativePriceChangeType;
}
