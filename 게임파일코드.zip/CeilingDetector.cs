﻿using System;
using UnityEngine;

// Token: 0x0200014B RID: 331
public class CeilingDetector : MonoBehaviour
{
	// Token: 0x0600095E RID: 2398 RVA: 0x00044D1B File Offset: 0x00042F1B
	private void Awake()
	{
		this.tr = base.transform;
	}

	// Token: 0x0600095F RID: 2399 RVA: 0x00044D29 File Offset: 0x00042F29
	private void OnCollisionEnter(Collision _collision)
	{
		this.CheckCollisionAngles(_collision);
	}

	// Token: 0x06000960 RID: 2400 RVA: 0x00044D32 File Offset: 0x00042F32
	private void OnCollisionStay(Collision _collision)
	{
		this.CheckCollisionAngles(_collision);
	}

	// Token: 0x06000961 RID: 2401 RVA: 0x00044D3C File Offset: 0x00042F3C
	private void CheckCollisionAngles(Collision _collision)
	{
		float num = 0f;
		if (this.ceilingDetectionMethod == CeilingDetector.CeilingDetectionMethod.OnlyCheckFirstContact)
		{
			num = Vector3.Angle(-this.tr.up, _collision.contacts[0].normal);
			if (num < this.ceilingAngleLimit)
			{
				this.ceilingWasHit = true;
			}
			if (this.isInDebugMode)
			{
				Debug.DrawRay(_collision.contacts[0].point, _collision.contacts[0].normal, Color.red, this.debugDrawDuration);
			}
		}
		if (this.ceilingDetectionMethod == CeilingDetector.CeilingDetectionMethod.CheckAllContacts)
		{
			for (int i = 0; i < _collision.contacts.Length; i++)
			{
				num = Vector3.Angle(-this.tr.up, _collision.contacts[i].normal);
				if (num < this.ceilingAngleLimit)
				{
					this.ceilingWasHit = true;
				}
				if (this.isInDebugMode)
				{
					Debug.DrawRay(_collision.contacts[i].point, _collision.contacts[i].normal, Color.red, this.debugDrawDuration);
				}
			}
		}
		if (this.ceilingDetectionMethod == CeilingDetector.CeilingDetectionMethod.CheckAverageOfAllContacts)
		{
			for (int j = 0; j < _collision.contacts.Length; j++)
			{
				num += Vector3.Angle(-this.tr.up, _collision.contacts[j].normal);
				if (this.isInDebugMode)
				{
					Debug.DrawRay(_collision.contacts[j].point, _collision.contacts[j].normal, Color.red, this.debugDrawDuration);
				}
			}
			if (num / (float)_collision.contacts.Length < this.ceilingAngleLimit)
			{
				this.ceilingWasHit = true;
			}
		}
	}

	// Token: 0x06000962 RID: 2402 RVA: 0x00044EF4 File Offset: 0x000430F4
	public bool HitCeiling()
	{
		return this.ceilingWasHit;
	}

	// Token: 0x06000963 RID: 2403 RVA: 0x00044EFC File Offset: 0x000430FC
	public void ResetFlags()
	{
		this.ceilingWasHit = false;
	}

	// Token: 0x040011A6 RID: 4518
	private bool ceilingWasHit;

	// Token: 0x040011A7 RID: 4519
	public float ceilingAngleLimit = 10f;

	// Token: 0x040011A8 RID: 4520
	public CeilingDetector.CeilingDetectionMethod ceilingDetectionMethod;

	// Token: 0x040011A9 RID: 4521
	public bool isInDebugMode;

	// Token: 0x040011AA RID: 4522
	private float debugDrawDuration = 2f;

	// Token: 0x040011AB RID: 4523
	private Transform tr;

	// Token: 0x0200023D RID: 573
	public enum CeilingDetectionMethod
	{
		// Token: 0x04001600 RID: 5632
		OnlyCheckFirstContact,
		// Token: 0x04001601 RID: 5633
		CheckAllContacts,
		// Token: 0x04001602 RID: 5634
		CheckAverageOfAllContacts
	}
}
