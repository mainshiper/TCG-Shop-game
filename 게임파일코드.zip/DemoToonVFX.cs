﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000146 RID: 326
public class DemoToonVFX : MonoBehaviour
{
	// Token: 0x0600093F RID: 2367 RVA: 0x00043E34 File Offset: 0x00042034
	private void Start()
	{
		if (Screen.dpi < 1f)
		{
			this.windowDpi = 1f;
		}
		if (Screen.dpi < 200f)
		{
			this.windowDpi = 1f;
		}
		else
		{
			this.windowDpi = Screen.dpi / 200f;
		}
		Vector3 eulerAngles = base.transform.eulerAngles;
		this.x = eulerAngles.y;
		this.y = eulerAngles.x;
		this.Counter(0);
		this.animObject.GetComponent<Animator>();
	}

	// Token: 0x06000940 RID: 2368 RVA: 0x00043EBC File Offset: 0x000420BC
	private void OnGUI()
	{
		if (GUI.Button(new Rect(5f * this.windowDpi, 5f * this.windowDpi, 110f * this.windowDpi, 35f * this.windowDpi), "Previous effect"))
		{
			this.Counter(-1);
		}
		if (GUI.Button(new Rect(120f * this.windowDpi, 5f * this.windowDpi, 110f * this.windowDpi, 35f * this.windowDpi), "Play again"))
		{
			this.Counter(0);
		}
		if (GUI.Button(new Rect(235f * this.windowDpi, 5f * this.windowDpi, 110f * this.windowDpi, 35f * this.windowDpi), "Next effect"))
		{
			this.Counter(1);
		}
		this.StartColor = this.HueColor;
		this.HueColor = GUI.HorizontalSlider(new Rect(5f * this.windowDpi, 45f * this.windowDpi, 340f * this.windowDpi, 35f * this.windowDpi), this.HueColor, 0f, 1f);
		GUI.DrawTexture(new Rect(5f * this.windowDpi, 65f * this.windowDpi, 340f * this.windowDpi, 15f * this.windowDpi), this.HueTexture, 0, false, 0f);
		if (this.HueColor != this.StartColor)
		{
			int num = 0;
			ParticleSystem[] array = this.particleSystems;
			for (int i = 0; i < array.Length; i++)
			{
				ParticleSystem.MainModule main = array[i].main;
				Color color = Color.HSVToRGB(this.HueColor + this.H * 0f, this.svList[num].S, this.svList[num].V);
				main.startColor = new Color(color.r, color.g, color.b, this.svList[num].A);
				num++;
			}
		}
	}

	// Token: 0x06000941 RID: 2369 RVA: 0x000440F4 File Offset: 0x000422F4
	private void Counter(int count)
	{
		this.Prefab += count;
		if (this.Prefab > this.Prefabs.Length - 1)
		{
			this.Prefab = 0;
		}
		else if (this.Prefab < 0)
		{
			this.Prefab = this.Prefabs.Length - 1;
		}
		if (this.Instance != null)
		{
			Object.Destroy(this.Instance);
		}
		this.Instance = Object.Instantiate<GameObject>(this.Prefabs[this.Prefab]);
		this.Instance.SetActive(false);
		if (this.activationTime.Length == this.Prefabs.Length)
		{
			base.CancelInvoke();
			if (this.activationTime[this.Prefab] > 0.01f)
			{
				base.Invoke("Activate", this.activationTime[this.Prefab]);
			}
			if (this.activationTime[this.Prefab] == 0f)
			{
				this.Instance.SetActive(true);
			}
		}
		this.particleSystems = this.Instance.GetComponentsInChildren<ParticleSystem>();
		this.svList.Clear();
		ParticleSystem[] array = this.particleSystems;
		for (int i = 0; i < array.Length; i++)
		{
			Color color = array[i].main.startColor.color;
			DemoToonVFX.SVA item = default(DemoToonVFX.SVA);
			Color.RGBToHSV(color, out this.H, out item.S, out item.V);
			item.A = color.a;
			this.svList.Add(item);
		}
		if (this.useAnimation)
		{
			this.animObject.SetInteger("toDo", this.Prefab);
		}
	}

	// Token: 0x06000942 RID: 2370 RVA: 0x00044289 File Offset: 0x00042489
	private void Activate()
	{
		this.Instance.SetActive(true);
	}

	// Token: 0x06000943 RID: 2371 RVA: 0x00044298 File Offset: 0x00042498
	private void LateUpdate()
	{
		if (this.currDistance < 2f)
		{
			this.currDistance = 2f;
		}
		this.currDistance -= Input.GetAxis("Mouse ScrollWheel") * 2f;
		if (this.Holder && (Input.GetMouseButton(0) || Input.GetMouseButton(1)))
		{
			Vector3 mousePosition = Input.mousePosition;
			if (Screen.dpi < 1f)
			{
			}
			float num;
			if (Screen.dpi < 200f)
			{
				num = 1f;
			}
			else
			{
				num = Screen.dpi / 200f;
			}
			if (mousePosition.x < 380f * num && (float)Screen.height - mousePosition.y < 250f * num)
			{
				return;
			}
			Cursor.visible = false;
			Cursor.lockState = CursorLockMode.Locked;
			this.x += (float)((double)(Input.GetAxis("Mouse X") * this.xRotate) * 0.02);
			this.y -= (float)((double)(Input.GetAxis("Mouse Y") * this.yRotate) * 0.02);
			this.y = DemoToonVFX.ClampAngle(this.y, this.yMinLimit, this.yMaxLimit);
			Quaternion rotation = Quaternion.Euler(this.y, this.x, 0f);
			Vector3 position = rotation * new Vector3(0f, 0f, -this.currDistance) + this.Holder.position;
			base.transform.rotation = rotation;
			base.transform.position = position;
		}
		else
		{
			Cursor.visible = true;
			Cursor.lockState = CursorLockMode.None;
		}
		if (this.prevDistance != this.currDistance)
		{
			this.prevDistance = this.currDistance;
			Quaternion rotation2 = Quaternion.Euler(this.y, this.x, 0f);
			Vector3 position2 = rotation2 * new Vector3(0f, 0f, -this.currDistance) + this.Holder.position;
			base.transform.rotation = rotation2;
			base.transform.position = position2;
		}
	}

	// Token: 0x06000944 RID: 2372 RVA: 0x000444C3 File Offset: 0x000426C3
	private static float ClampAngle(float angle, float min, float max)
	{
		if (angle < -360f)
		{
			angle += 360f;
		}
		if (angle > 360f)
		{
			angle -= 360f;
		}
		return Mathf.Clamp(angle, min, max);
	}

	// Token: 0x04001163 RID: 4451
	public Transform Holder;

	// Token: 0x04001164 RID: 4452
	public float currDistance = 5f;

	// Token: 0x04001165 RID: 4453
	public float xRotate = 250f;

	// Token: 0x04001166 RID: 4454
	public float yRotate = 120f;

	// Token: 0x04001167 RID: 4455
	public float yMinLimit = -20f;

	// Token: 0x04001168 RID: 4456
	public float yMaxLimit = 80f;

	// Token: 0x04001169 RID: 4457
	public float prevDistance;

	// Token: 0x0400116A RID: 4458
	private float x;

	// Token: 0x0400116B RID: 4459
	private float y;

	// Token: 0x0400116C RID: 4460
	[Header("GUI")]
	private float windowDpi;

	// Token: 0x0400116D RID: 4461
	public GameObject[] Prefabs;

	// Token: 0x0400116E RID: 4462
	private int Prefab;

	// Token: 0x0400116F RID: 4463
	private GameObject Instance;

	// Token: 0x04001170 RID: 4464
	private float StartColor;

	// Token: 0x04001171 RID: 4465
	private float HueColor;

	// Token: 0x04001172 RID: 4466
	public Texture HueTexture;

	// Token: 0x04001173 RID: 4467
	public float[] activationTime;

	// Token: 0x04001174 RID: 4468
	public Animator animObject;

	// Token: 0x04001175 RID: 4469
	private ParticleSystem[] particleSystems = new ParticleSystem[0];

	// Token: 0x04001176 RID: 4470
	private List<DemoToonVFX.SVA> svList = new List<DemoToonVFX.SVA>();

	// Token: 0x04001177 RID: 4471
	private float H;

	// Token: 0x04001178 RID: 4472
	public bool useAnimation;

	// Token: 0x0200023B RID: 571
	public struct SVA
	{
		// Token: 0x040015F9 RID: 5625
		public float S;

		// Token: 0x040015FA RID: 5626
		public float V;

		// Token: 0x040015FB RID: 5627
		public float A;
	}
}
