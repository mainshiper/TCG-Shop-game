﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000106 RID: 262
public class ImageFadeInOut : MonoBehaviour
{
	// Token: 0x060007B5 RID: 1973 RVA: 0x0003A950 File Offset: 0x00038B50
	private void Awake()
	{
		this.m_DefaultFadeAlpha = this.m_Image.color.a;
		this.m_Color = this.m_Image.color;
		if (this.m_FadeOutOnStart)
		{
			this.m_Color.a = 0f;
			this.m_Image.color = this.m_Color;
		}
		this.m_Image.enabled = true;
	}

	// Token: 0x060007B6 RID: 1974 RVA: 0x0003A9B9 File Offset: 0x00038BB9
	public void SetFadeIn(float fadeSpeed = 1f, float delay = 0f)
	{
		this.m_IsFadingIn = true;
		this.m_IsFadingOut = false;
		this.m_FadeSpeed = fadeSpeed;
		this.m_Delay = delay;
	}

	// Token: 0x060007B7 RID: 1975 RVA: 0x0003A9D7 File Offset: 0x00038BD7
	public void SetFadeOut(float fadeSpeed = 1f, float delay = 0f)
	{
		this.m_IsFadingIn = false;
		this.m_IsFadingOut = true;
		this.m_FadeSpeed = fadeSpeed;
		this.m_Delay = delay;
	}

	// Token: 0x060007B8 RID: 1976 RVA: 0x0003A9F8 File Offset: 0x00038BF8
	private void Update()
	{
		if (this.m_Delay > 0f)
		{
			this.m_Delay -= Time.deltaTime;
			return;
		}
		if (this.m_IsFadingIn)
		{
			this.m_Timer += Time.deltaTime * this.m_FadeSpeed;
			if (this.m_Timer >= 1f)
			{
				this.m_Timer = 1f;
				this.m_IsFadingIn = false;
			}
			this.m_Color.a = Mathf.Lerp(0f, this.m_DefaultFadeAlpha, this.m_Timer);
			this.m_Image.color = this.m_Color;
			return;
		}
		if (this.m_IsFadingOut)
		{
			this.m_Timer -= Time.deltaTime * this.m_FadeSpeed;
			if (this.m_Timer <= 0f)
			{
				this.m_Timer = 0f;
				this.m_IsFadingOut = false;
			}
			this.m_Color.a = Mathf.Lerp(0f, this.m_DefaultFadeAlpha, this.m_Timer);
			this.m_Image.color = this.m_Color;
		}
	}

	// Token: 0x04000EF9 RID: 3833
	public Image m_Image;

	// Token: 0x04000EFA RID: 3834
	public bool m_FadeOutOnStart = true;

	// Token: 0x04000EFB RID: 3835
	private bool m_IsFadingIn;

	// Token: 0x04000EFC RID: 3836
	private bool m_IsFadingOut;

	// Token: 0x04000EFD RID: 3837
	private float m_DefaultFadeAlpha;

	// Token: 0x04000EFE RID: 3838
	private float m_Timer;

	// Token: 0x04000EFF RID: 3839
	private float m_FadeSpeed = 1f;

	// Token: 0x04000F00 RID: 3840
	private float m_Delay;

	// Token: 0x04000F01 RID: 3841
	private Color m_Color;
}
