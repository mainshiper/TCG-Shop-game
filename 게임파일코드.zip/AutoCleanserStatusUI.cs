﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000057 RID: 87
public class AutoCleanserStatusUI : CSingleton<AutoCleanserStatusUI>
{
	// Token: 0x060003F5 RID: 1013 RVA: 0x000239D9 File Offset: 0x00021BD9
	private void Start()
	{
		this.m_TurnOnText.SetActive(false);
		this.m_TurnOffText.SetActive(false);
		this.m_NeedRefillText.SetActive(false);
		AutoCleanserStatusUI.SetVisibility(false);
		AutoCleanserStatusUI.SetRangeVisibility(false);
	}

	// Token: 0x060003F6 RID: 1014 RVA: 0x00023A0C File Offset: 0x00021C0C
	private void Update()
	{
		if (this.m_FollowTargetCleanser)
		{
			if (CSingleton<InteractionPlayerController>.Instance.m_CurrentGameState != EGameState.DefaultState && CSingleton<InteractionPlayerController>.Instance.m_CurrentGameState != EGameState.HoldingBoxState && CSingleton<InteractionPlayerController>.Instance.m_CurrentGameState != EGameState.HoldingItemState && CSingleton<InteractionPlayerController>.Instance.m_CurrentGameState != EGameState.MovingObjectState)
			{
				AutoCleanserStatusUI.SetVisibility(false);
			}
			base.transform.position = this.m_FollowTargetCleanser.transform.position + Vector3.up * this.m_PosYOffset;
			base.transform.LookAt(new Vector3(this.m_Cam.position.x, this.m_Cam.position.y, this.m_Cam.position.z));
			if (this.m_CurrentAutoCleanser)
			{
				this.m_TimerFillBar.fillAmount = this.m_CurrentAutoCleanser.GetTimer() / this.m_CooldownTime;
				if (this.m_CurrentAutoCleanser.IsTurnedOn() && !this.m_CurrentAutoCleanser.IsNeedRefill() && !this.m_TurnOnText.activeSelf)
				{
					this.m_TurnOnText.SetActive(true);
					this.m_TurnOffText.SetActive(false);
					this.m_NeedRefillText.SetActive(false);
				}
				else if (this.m_CurrentAutoCleanser.IsTurnedOn() && this.m_CurrentAutoCleanser.IsNeedRefill() && !this.m_NeedRefillText.activeSelf)
				{
					this.m_TurnOnText.SetActive(false);
					this.m_TurnOffText.SetActive(false);
					this.m_NeedRefillText.SetActive(true);
				}
				else if (!this.m_CurrentAutoCleanser.IsTurnedOn() && !this.m_TurnOffText.activeSelf)
				{
					this.m_TurnOnText.SetActive(false);
					this.m_TurnOffText.SetActive(true);
					this.m_NeedRefillText.SetActive(false);
				}
				for (int i = 0; i < this.m_CurrentAutoCleanser.GetStoredItemList().Count; i++)
				{
					this.m_FillBarList[i].fillAmount = this.m_CurrentAutoCleanser.GetStoredItemList()[i].GetContentFill();
				}
			}
		}
	}

	// Token: 0x060003F7 RID: 1015 RVA: 0x00023C1C File Offset: 0x00021E1C
	public void UpdateAutoCleanserData(int maxSlot, int potency, int dispenseMethod, float cleanserRange, float cooldownTime)
	{
		this.m_CooldownTime = cooldownTime;
		this.m_RangeImage.localScale = Vector3.one * cleanserRange;
		for (int i = 0; i < this.m_FillBarGrpList.Count; i++)
		{
			this.m_FillBarGrpList[i].SetActive(false);
		}
		for (int j = 0; j < maxSlot; j++)
		{
			this.m_FillBarGrpList[j].SetActive(true);
		}
		this.UpdateItemSlotAmountFilled(this.m_CurrentItemAmount);
	}

	// Token: 0x060003F8 RID: 1016 RVA: 0x00023C9C File Offset: 0x00021E9C
	public void UpdateItemSlotAmountFilled(int itemAmount)
	{
		this.m_CurrentItemAmount = itemAmount;
		for (int i = 0; i < this.m_FillBarList.Count; i++)
		{
			this.m_FillBarList[i].enabled = false;
			this.m_BarNoItemList[i].enabled = true;
		}
		for (int j = 0; j < this.m_CurrentItemAmount; j++)
		{
			this.m_FillBarList[j].enabled = true;
			this.m_BarNoItemList[j].enabled = false;
		}
	}

	// Token: 0x060003F9 RID: 1017 RVA: 0x00023D20 File Offset: 0x00021F20
	public static void SetTargetCleanser(InteractableAutoCleanser target, float posYOffset = 0f)
	{
		CSingleton<AutoCleanserStatusUI>.Instance.m_PosYOffset = posYOffset;
		if (CSingleton<AutoCleanserStatusUI>.Instance.m_CurrentAutoCleanser != target)
		{
			AutoCleanserStatusUI.SetVisibility(false);
			AutoCleanserStatusUI.SetRangeVisibility(false);
			CSingleton<AutoCleanserStatusUI>.Instance.m_CurrentAutoCleanser = target;
			if (target != null)
			{
				CSingleton<AutoCleanserStatusUI>.Instance.m_CurrentItemAmount = CSingleton<AutoCleanserStatusUI>.Instance.m_CurrentAutoCleanser.GetStoredItemList().Count;
				CSingleton<AutoCleanserStatusUI>.Instance.UpdateAutoCleanserData(CSingleton<AutoCleanserStatusUI>.Instance.m_CurrentAutoCleanser.m_PosList.Count, CSingleton<AutoCleanserStatusUI>.Instance.m_CurrentAutoCleanser.m_Potency, CSingleton<AutoCleanserStatusUI>.Instance.m_CurrentAutoCleanser.m_DispenseMethod, CSingleton<AutoCleanserStatusUI>.Instance.m_CurrentAutoCleanser.m_CleanserRange, CSingleton<AutoCleanserStatusUI>.Instance.m_CurrentAutoCleanser.m_CooldownTime);
				CSingleton<AutoCleanserStatusUI>.Instance.m_FollowTargetCleanser = target.transform;
				CSingleton<AutoCleanserStatusUI>.Instance.transform.position = CSingleton<AutoCleanserStatusUI>.Instance.m_FollowTargetCleanser.transform.position + Vector3.up * CSingleton<AutoCleanserStatusUI>.Instance.m_PosYOffset;
				AutoCleanserStatusUI.SetVisibility(true);
				AutoCleanserStatusUI.SetRangeVisibility(true);
				return;
			}
			CSingleton<AutoCleanserStatusUI>.Instance.m_FollowTargetCleanser = null;
		}
	}

	// Token: 0x060003FA RID: 1018 RVA: 0x00023E4C File Offset: 0x0002204C
	public static void SetVisibility(bool isVisible)
	{
		CSingleton<AutoCleanserStatusUI>.Instance.m_ScreenGrp.gameObject.SetActive(isVisible);
	}

	// Token: 0x060003FB RID: 1019 RVA: 0x00023E63 File Offset: 0x00022063
	public static void SetRangeVisibility(bool isVisible)
	{
		CSingleton<AutoCleanserStatusUI>.Instance.m_RangeGrp.gameObject.SetActive(isVisible);
	}

	// Token: 0x040004C1 RID: 1217
	public GameObject m_ScreenGrp;

	// Token: 0x040004C2 RID: 1218
	public GameObject m_RangeGrp;

	// Token: 0x040004C3 RID: 1219
	public GameObject m_TurnOnText;

	// Token: 0x040004C4 RID: 1220
	public GameObject m_TurnOffText;

	// Token: 0x040004C5 RID: 1221
	public GameObject m_NeedRefillText;

	// Token: 0x040004C6 RID: 1222
	public Image m_TimerFillBar;

	// Token: 0x040004C7 RID: 1223
	public List<Image> m_FillBarList;

	// Token: 0x040004C8 RID: 1224
	public List<Image> m_BarNoItemList;

	// Token: 0x040004C9 RID: 1225
	public List<GameObject> m_FillBarGrpList;

	// Token: 0x040004CA RID: 1226
	public Transform m_RangeImage;

	// Token: 0x040004CB RID: 1227
	public Transform m_Cam;

	// Token: 0x040004CC RID: 1228
	private int m_CurrentItemAmount;

	// Token: 0x040004CD RID: 1229
	private float m_CooldownTime;

	// Token: 0x040004CE RID: 1230
	private float m_PosYOffset;

	// Token: 0x040004CF RID: 1231
	private Transform m_FollowTargetCleanser;

	// Token: 0x040004D0 RID: 1232
	private InteractableAutoCleanser m_CurrentAutoCleanser;
}
