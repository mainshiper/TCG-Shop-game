﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace CC
{
	// Token: 0x020001CA RID: 458
	public class Option_Color_Picker : MonoBehaviour, ICustomizerUI
	{
		// Token: 0x06000CDE RID: 3294 RVA: 0x0005AB0C File Offset: 0x00058D0C
		public void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util ParentUI)
		{
			this.customizer = customizerScript;
			this.parentUI = ParentUI;
			this.RefreshUIElement();
		}

		// Token: 0x06000CDF RID: 3295 RVA: 0x0005AB24 File Offset: 0x00058D24
		public void RefreshUIElement()
		{
			int num = this.customizer.StoredCharacterData.ColorProperties.FindIndex((CC_Property t) => t.propertyName == this.Property.propertyName && t.materialIndex == this.Property.materialIndex && t.meshTag == this.Property.meshTag);
			Color color;
			if (this.Hair)
			{
				if (ColorUtility.TryParseHtmlString("#" + this.customizer.StoredCharacterData.HairColor[(this.HairSlot == -1) ? 0 : this.HairSlot].stringValue, out color))
				{
					this.color = color;
					this.ColorPreview.color = this.color;
					Color.RGBToHSV(this.color, out this.hue, out this.sat, out this.val);
					this.HueSlider.SetValueWithoutNotify(this.hue);
					this.SatSlider.SetValueWithoutNotify(this.sat);
					this.ValSlider.SetValueWithoutNotify(this.val);
				}
			}
			else if (num != -1 && ColorUtility.TryParseHtmlString("#" + this.customizer.StoredCharacterData.ColorProperties[num].stringValue, out color))
			{
				this.color = color;
				this.ColorPreview.color = this.color;
				Color.RGBToHSV(this.color, out this.hue, out this.sat, out this.val);
				this.HueSlider.SetValueWithoutNotify(this.hue);
				this.SatSlider.SetValueWithoutNotify(this.sat);
				this.ValSlider.SetValueWithoutNotify(this.val);
			}
			num = this.customizer.StoredCharacterData.FloatProperties.FindIndex((CC_Property t) => t.propertyName == this.OpacityProperty.propertyName && t.materialIndex == this.OpacityProperty.materialIndex && t.meshTag == this.OpacityProperty.meshTag);
			if (num != -1 && this.OpacitySlider != null)
			{
				this.OpacitySlider.SetValueWithoutNotify(this.customizer.StoredCharacterData.FloatProperties[num].floatValue);
			}
		}

		// Token: 0x06000CE0 RID: 3296 RVA: 0x0005AD04 File Offset: 0x00058F04
		public void setColor()
		{
			this.color = Color.HSVToRGB(this.hue, this.sat, this.val);
			this.ColorPreview.color = this.color;
			if (this.Hair)
			{
				this.customizer.setHairColor(this.Property, this.color, this.HairSlot, true);
				return;
			}
			this.customizer.setColorProperty(this.Property, this.color, true);
		}

		// Token: 0x06000CE1 RID: 3297 RVA: 0x0005AD7E File Offset: 0x00058F7E
		public void setHue(float value)
		{
			this.hue = value;
			this.setColor();
		}

		// Token: 0x06000CE2 RID: 3298 RVA: 0x0005AD8D File Offset: 0x00058F8D
		public void setSat(float value)
		{
			this.sat = value;
			this.setColor();
		}

		// Token: 0x06000CE3 RID: 3299 RVA: 0x0005AD9C File Offset: 0x00058F9C
		public void setVal(float value)
		{
			this.val = value;
			this.setColor();
		}

		// Token: 0x06000CE4 RID: 3300 RVA: 0x0005ADAB File Offset: 0x00058FAB
		public void setOpacity(float value)
		{
			this.OpacityProperty.floatValue = value;
			this.customizer.setFloatProperty(this.OpacityProperty, true);
		}

		// Token: 0x06000CE5 RID: 3301 RVA: 0x0005ADCC File Offset: 0x00058FCC
		public void randomize(bool RandomizeOpacity)
		{
			this.hue = Random.Range(0f, 1f);
			this.val = Random.Range(0f, 1f);
			this.sat = Random.Range(0f, 1f);
			this.setColor();
			this.HueSlider.value = this.hue;
			this.SatSlider.value = this.sat;
			this.ValSlider.value = this.val;
			if (RandomizeOpacity)
			{
				float num = Random.Range(0f, 1f);
				this.setOpacity(num);
				this.OpacitySlider.value = num;
			}
		}

		// Token: 0x040013D6 RID: 5078
		private CharacterCustomization customizer;

		// Token: 0x040013D7 RID: 5079
		private CC_UI_Util parentUI;

		// Token: 0x040013D8 RID: 5080
		public CC_Property Property;

		// Token: 0x040013D9 RID: 5081
		public CC_Property OpacityProperty;

		// Token: 0x040013DA RID: 5082
		public bool Hair;

		// Token: 0x040013DB RID: 5083
		public int HairSlot;

		// Token: 0x040013DC RID: 5084
		public Image ColorPreview;

		// Token: 0x040013DD RID: 5085
		public Slider HueSlider;

		// Token: 0x040013DE RID: 5086
		public Slider SatSlider;

		// Token: 0x040013DF RID: 5087
		public Slider ValSlider;

		// Token: 0x040013E0 RID: 5088
		public Slider OpacitySlider;

		// Token: 0x040013E1 RID: 5089
		private Color color;

		// Token: 0x040013E2 RID: 5090
		private float hue;

		// Token: 0x040013E3 RID: 5091
		private float sat = 0.5f;

		// Token: 0x040013E4 RID: 5092
		private float val = 0.5f;
	}
}
