﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;

namespace CC
{
	// Token: 0x020001AE RID: 430
	public class CameraController : MonoBehaviour
	{
		// Token: 0x06000C72 RID: 3186 RVA: 0x00057FBB File Offset: 0x000561BB
		private void Awake()
		{
			if (CameraController.instance == null)
			{
				CameraController.instance = this;
				return;
			}
			Object.Destroy(base.gameObject);
		}

		// Token: 0x06000C73 RID: 3187 RVA: 0x00057FDC File Offset: 0x000561DC
		private void Start()
		{
			this._camera = Camera.main;
			this.cameraRoot = base.gameObject.transform;
			this.hotSpot = new Vector2((float)(this.cursorTexture.width / 2), (float)(this.cursorTexture.height / 2));
			this.setDefaultCursor();
			this.cameraOffsetDefault = this._camera.transform.localPosition;
			this.cameraOffset = this.cameraOffsetDefault;
			this.cameraRotationDefault = this.cameraRoot.localRotation.eulerAngles;
			this.cameraRotationTarget = this.cameraRotationDefault;
		}

		// Token: 0x06000C74 RID: 3188 RVA: 0x00058079 File Offset: 0x00056279
		public void setCursor(Texture2D texture)
		{
			Cursor.SetCursor(texture, this.hotSpot, CursorMode.Auto);
		}

		// Token: 0x06000C75 RID: 3189 RVA: 0x00058088 File Offset: 0x00056288
		public void setDefaultCursor()
		{
			Cursor.SetCursor(this.cursorTexture, this.hotSpot, CursorMode.Auto);
		}

		// Token: 0x06000C76 RID: 3190 RVA: 0x0005809C File Offset: 0x0005629C
		private void Update()
		{
			if (!EventSystem.current.IsPointerOverGameObject())
			{
				Vector3 a = Camera.main.ScreenToViewportPoint(Input.mousePosition) - new Vector3(0.5f, 0.5f, 0f);
				this.cameraOffset += a * Mathf.Abs(Input.mouseScrollDelta.y) * this.ZoomPanScale * Mathf.Lerp(0.2f, 1f, this.zoomTarget);
				this.zoomTarget = Mathf.Clamp(this.zoomTarget * (1f - Input.mouseScrollDelta.y / 10f), 0f, 1f);
				if (Input.GetMouseButtonDown(1))
				{
					this.mouseOldPos = Input.mousePosition;
					this.dragging = true;
				}
				if (Input.GetMouseButtonDown(2))
				{
					this.mouseOldPos = Input.mousePosition;
					this.panning = true;
				}
			}
			if (Input.GetMouseButton(1) && this.dragging)
			{
				this.mouseDelta = this.mouseOldPos - Input.mousePosition;
				this.cameraRotationTarget.x = this.cameraRotationTarget.x + this.mouseDelta.y / 5f;
				this.cameraRotationTarget.y = this.cameraRotationTarget.y - this.mouseDelta.x / 5f;
				this.mouseOldPos = Input.mousePosition;
			}
			if (Input.GetMouseButtonUp(1))
			{
				this.dragging = false;
			}
			if (Input.GetMouseButton(2) && this.panning)
			{
				this.mouseDelta = this.mouseOldPos - Input.mousePosition;
				this.cameraOffset -= this.mouseDelta / 500f;
				this.mouseOldPos = Input.mousePosition;
			}
			if (Input.GetMouseButtonUp(2))
			{
				this.panning = false;
			}
			if (Input.GetKeyDown(KeyCode.F))
			{
				this.cameraRotationTarget = this.cameraRotationDefault;
				this.cameraOffset = this.cameraOffsetDefault;
				this.zoomTarget = 1f;
			}
			this.cameraOffset.z = Mathf.Lerp(this.ZoomMin, this.ZoomMax, this.zoomTarget);
			this._camera.transform.localPosition = Vector3.Lerp(this._camera.transform.localPosition, this.cameraOffset, Time.deltaTime * this.panSpeed);
			this.cameraRoot.transform.localRotation = Quaternion.Slerp(this.cameraRoot.transform.localRotation, Quaternion.Euler(this.cameraRotationTarget), Time.deltaTime * this.rotateSpeed);
		}

		// Token: 0x04001352 RID: 4946
		public static CameraController instance;

		// Token: 0x04001353 RID: 4947
		public float ZoomMin = -0.6f;

		// Token: 0x04001354 RID: 4948
		public float ZoomMax = -3.1f;

		// Token: 0x04001355 RID: 4949
		public float ZoomPanScale = 0.5f;

		// Token: 0x04001356 RID: 4950
		private Camera _camera;

		// Token: 0x04001357 RID: 4951
		private Transform cameraRoot;

		// Token: 0x04001358 RID: 4952
		private float zoomTarget = 1f;

		// Token: 0x04001359 RID: 4953
		private Vector3 mouseOldPos;

		// Token: 0x0400135A RID: 4954
		private Vector3 mouseDelta;

		// Token: 0x0400135B RID: 4955
		private Vector3 cameraRotationTarget = new Vector3(10f, -5f, 0f);

		// Token: 0x0400135C RID: 4956
		private Vector3 cameraRotationDefault;

		// Token: 0x0400135D RID: 4957
		private float rotateSpeed = 5f;

		// Token: 0x0400135E RID: 4958
		private bool dragging;

		// Token: 0x0400135F RID: 4959
		private Vector3 cameraOffset;

		// Token: 0x04001360 RID: 4960
		private Vector3 cameraOffsetDefault;

		// Token: 0x04001361 RID: 4961
		private float panSpeed = 3f;

		// Token: 0x04001362 RID: 4962
		private bool panning;

		// Token: 0x04001363 RID: 4963
		public Texture2D cursorTexture;

		// Token: 0x04001364 RID: 4964
		private Vector2 hotSpot;
	}
}
