﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace CC
{
	// Token: 0x020001AF RID: 431
	public class BlendshapeManager : MonoBehaviour
	{
		// Token: 0x06000C78 RID: 3192 RVA: 0x000583A4 File Offset: 0x000565A4
		public void parseBlendshapes()
		{
			this.mesh = base.gameObject.GetComponent<SkinnedMeshRenderer>();
			if (this.mesh.sharedMesh != null)
			{
				for (int i = 0; i < this.mesh.sharedMesh.blendShapeCount; i++)
				{
					this.blendshapeNames.Add(this.mesh.sharedMesh.GetBlendShapeName(i));
				}
			}
		}

		// Token: 0x06000C79 RID: 3193 RVA: 0x0005840C File Offset: 0x0005660C
		public void setBlendshape(string name, float value)
		{
			int num = this.blendshapeNames.FindIndex((string t) => t == name);
			if (num != -1)
			{
				this.mesh.SetBlendShapeWeight(num, value * 100f);
			}
		}

		// Token: 0x04001365 RID: 4965
		private List<string> blendshapeNames = new List<string>();

		// Token: 0x04001366 RID: 4966
		private SkinnedMeshRenderer mesh;
	}
}
