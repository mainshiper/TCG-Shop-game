﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CC
{
	// Token: 0x020001CD RID: 461
	public class Option_Picker : MonoBehaviour, ICustomizerUI
	{
		// Token: 0x06000CF3 RID: 3315 RVA: 0x0005B15F File Offset: 0x0005935F
		public void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util ParentUI)
		{
			this.customizer = customizerScript;
			this.RefreshUIElement();
		}

		// Token: 0x06000CF4 RID: 3316 RVA: 0x0005B170 File Offset: 0x00059370
		public void RefreshUIElement()
		{
			switch (this.CustomizationType)
			{
			case Option_Picker.Type.Blendshape:
			{
				this.optionsCount = this.Options.Count;
				this.updateOptionText();
				int j;
				int i;
				for (i = 0; i < this.customizer.StoredCharacterData.Blendshapes.Count; i = j + 1)
				{
					int num = this.Options.FindIndex((CC_Property t) => t.propertyName == this.customizer.StoredCharacterData.Blendshapes[i].propertyName);
					if (num != -1)
					{
						this.navIndex = num;
						this.updateOptionText();
						return;
					}
					j = i;
				}
				return;
			}
			case Option_Picker.Type.Texture:
			{
				this.optionsCount = this.Options.Count;
				int savedIndex = this.customizer.StoredCharacterData.TextureProperties.FindIndex((CC_Property t) => t.propertyName == this.Property.propertyName && t.materialIndex == this.Property.materialIndex && t.meshTag == this.Property.meshTag);
				if (savedIndex != -1)
				{
					this.navIndex = this.Options.FindIndex((CC_Property t) => t.stringValue == this.customizer.StoredCharacterData.TextureProperties[savedIndex].stringValue);
				}
				else
				{
					this.navIndex = 0;
				}
				this.updateOptionText();
				return;
			}
			case Option_Picker.Type.Hair:
				this.optionsCount = this.customizer.HairTables[this.Slot].Hairstyles.Count;
				this.navIndex = this.customizer.HairTables[this.Slot].Hairstyles.FindIndex((scrObj_Hair.Hairstyle t) => t.Name == this.customizer.StoredCharacterData.HairNames[this.Slot]);
				if (this.navIndex == -1)
				{
					this.navIndex = 0;
				}
				this.updateOptionText();
				return;
			default:
				return;
			}
		}

		// Token: 0x06000CF5 RID: 3317 RVA: 0x0005B30C File Offset: 0x0005950C
		public void updateOptionText()
		{
			this.OptionText.SetText((this.navIndex + 1).ToString() + "/" + this.optionsCount.ToString(), true);
		}

		// Token: 0x06000CF6 RID: 3318 RVA: 0x0005B34C File Offset: 0x0005954C
		public void setOption(int i)
		{
			this.navIndex = i;
			this.updateOptionText();
			switch (this.CustomizationType)
			{
			case Option_Picker.Type.Blendshape:
				foreach (CC_Property cc_Property in this.Options)
				{
					this.customizer.setBlendshapeByName(base.name, 0f, true);
				}
				this.customizer.setBlendshapeByName(this.Options[i].propertyName, 1f, true);
				return;
			case Option_Picker.Type.Texture:
				this.customizer.setTextureProperty(this.Options[i], true, null);
				return;
			case Option_Picker.Type.Hair:
				this.customizer.setHair(i, this.Slot);
				return;
			default:
				return;
			}
		}

		// Token: 0x06000CF7 RID: 3319 RVA: 0x0005B428 File Offset: 0x00059628
		public void navLeft()
		{
			this.setOption((this.navIndex == 0) ? (this.optionsCount - 1) : (this.navIndex - 1));
		}

		// Token: 0x06000CF8 RID: 3320 RVA: 0x0005B44A File Offset: 0x0005964A
		public void navRight()
		{
			this.setOption((this.navIndex == this.optionsCount - 1) ? 0 : (this.navIndex + 1));
		}

		// Token: 0x06000CF9 RID: 3321 RVA: 0x0005B46D File Offset: 0x0005966D
		public void randomize()
		{
			this.setOption(Random.Range(0, this.optionsCount));
		}

		// Token: 0x040013EF RID: 5103
		private CharacterCustomization customizer;

		// Token: 0x040013F0 RID: 5104
		public Option_Picker.Type CustomizationType;

		// Token: 0x040013F1 RID: 5105
		public CC_Property Property;

		// Token: 0x040013F2 RID: 5106
		public List<CC_Property> Options = new List<CC_Property>();

		// Token: 0x040013F3 RID: 5107
		public int Slot;

		// Token: 0x040013F4 RID: 5108
		public TextMeshProUGUI OptionText;

		// Token: 0x040013F5 RID: 5109
		private int navIndex;

		// Token: 0x040013F6 RID: 5110
		private int optionsCount;

		// Token: 0x02000279 RID: 633
		public enum Type
		{
			// Token: 0x040016B8 RID: 5816
			Blendshape,
			// Token: 0x040016B9 RID: 5817
			Texture,
			// Token: 0x040016BA RID: 5818
			Hair
		}
	}
}
