﻿using System;
using System.Collections.Generic;

namespace CC
{
	// Token: 0x020001B0 RID: 432
	[Serializable]
	public class CC_Apparel_Material_Collection
	{
		// Token: 0x04001367 RID: 4967
		public string Label;

		// Token: 0x04001368 RID: 4968
		public List<CC_Apparel_Material_Definition> MaterialDefinitions = new List<CC_Apparel_Material_Definition>();
	}
}
