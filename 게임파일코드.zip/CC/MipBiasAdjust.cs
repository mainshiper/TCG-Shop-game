﻿using System;
using UnityEngine;

namespace CC
{
	// Token: 0x020001BB RID: 443
	public class MipBiasAdjust : MonoBehaviour
	{
		// Token: 0x06000CA1 RID: 3233 RVA: 0x000599DC File Offset: 0x00057BDC
		public void Start()
		{
			for (int i = 0; i < this.Textures.Length; i++)
			{
				this.Textures[i].mipMapBias = this.MipBias[i];
			}
		}

		// Token: 0x04001398 RID: 5016
		public float[] MipBias;

		// Token: 0x04001399 RID: 5017
		public Texture[] Textures;
	}
}
