﻿using System;
using UnityEngine;

namespace CC
{
	// Token: 0x020001C0 RID: 448
	public class CC_UI_Util : MonoBehaviour
	{
		// Token: 0x06000CB7 RID: 3255 RVA: 0x0005A0F0 File Offset: 0x000582F0
		public void Initialize(CharacterCustomization customizerScript)
		{
			this.customizer = customizerScript;
			ICustomizerUI[] componentsInChildren = base.gameObject.GetComponentsInChildren<ICustomizerUI>(true);
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].InitializeUIElement(customizerScript, this);
			}
		}

		// Token: 0x06000CB8 RID: 3256 RVA: 0x0005A12C File Offset: 0x0005832C
		public void refreshUI()
		{
			ICustomizerUI[] componentsInChildren = base.gameObject.GetComponentsInChildren<ICustomizerUI>(true);
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].RefreshUIElement();
			}
		}

		// Token: 0x06000CB9 RID: 3257 RVA: 0x0005A15C File Offset: 0x0005835C
		public void characterNext()
		{
			CC_UI_Manager.instance.characterNext();
		}

		// Token: 0x06000CBA RID: 3258 RVA: 0x0005A168 File Offset: 0x00058368
		public void characterPrev()
		{
			CC_UI_Manager.instance.characterPrev();
		}

		// Token: 0x06000CBB RID: 3259 RVA: 0x0005A174 File Offset: 0x00058374
		public void saveCharacter()
		{
			this.customizer.SaveToJSON();
		}

		// Token: 0x06000CBC RID: 3260 RVA: 0x0005A181 File Offset: 0x00058381
		public void loadCharacter()
		{
			this.customizer.LoadFromJSON();
			this.refreshUI();
		}

		// Token: 0x06000CBD RID: 3261 RVA: 0x0005A194 File Offset: 0x00058394
		public void setCharacterName(string newName)
		{
			this.customizer.setCharacterName(newName);
		}

		// Token: 0x040013AC RID: 5036
		private CharacterCustomization customizer;
	}
}
