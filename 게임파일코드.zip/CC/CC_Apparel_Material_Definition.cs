﻿using System;
using UnityEngine;

namespace CC
{
	// Token: 0x020001B1 RID: 433
	[Serializable]
	public class CC_Apparel_Material_Definition
	{
		// Token: 0x04001369 RID: 4969
		public Color MainTint;

		// Token: 0x0400136A RID: 4970
		public Color TintR;

		// Token: 0x0400136B RID: 4971
		public Color TintG;

		// Token: 0x0400136C RID: 4972
		public Color TintB;

		// Token: 0x0400136D RID: 4973
		public Texture2D Print;
	}
}
