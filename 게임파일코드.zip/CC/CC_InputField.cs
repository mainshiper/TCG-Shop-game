﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;

namespace CC
{
	// Token: 0x020001C9 RID: 457
	public class CC_InputField : MonoBehaviour, ICustomizerUI
	{
		// Token: 0x06000CDB RID: 3291 RVA: 0x0005AAB2 File Offset: 0x00058CB2
		public void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util parentUI)
		{
			this.customizer = customizerScript;
			this.RefreshUIElement();
			base.gameObject.GetComponent<TMP_InputField>().onValueChanged.AddListener(new UnityAction<string>(this.customizer.setCharacterName));
		}

		// Token: 0x06000CDC RID: 3292 RVA: 0x0005AAE7 File Offset: 0x00058CE7
		public void RefreshUIElement()
		{
			base.gameObject.GetComponent<TMP_InputField>().text = this.customizer.CharacterName;
		}

		// Token: 0x040013D5 RID: 5077
		private CharacterCustomization customizer;
	}
}
