﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace CC
{
	// Token: 0x020001B8 RID: 440
	[CreateAssetMenu(fileName = "Presets", menuName = "ScriptableObjects/Presets")]
	public class scrObj_Presets : ScriptableObject
	{
		// Token: 0x04001390 RID: 5008
		public List<CC_CharacterData> Presets = new List<CC_CharacterData>();
	}
}
