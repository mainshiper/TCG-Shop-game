﻿using System;
using UnityEngine;
using UnityEngine.Events;

namespace CC
{
	// Token: 0x020001C5 RID: 453
	[Serializable]
	public class OnPickerDrag : UnityEvent<Vector2>
	{
	}
}
