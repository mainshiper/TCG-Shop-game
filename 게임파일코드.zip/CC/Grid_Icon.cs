﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace CC
{
	// Token: 0x020001C3 RID: 451
	public class Grid_Icon : MonoBehaviour
	{
		// Token: 0x06000CC7 RID: 3271 RVA: 0x0005A30A File Offset: 0x0005850A
		public void setIcon(Sprite icon)
		{
			if (icon != null)
			{
				this.Icon.SetActive(true);
				this.Icon.GetComponent<Image>().sprite = icon;
				return;
			}
			this.Icon.SetActive(false);
		}

		// Token: 0x06000CC8 RID: 3272 RVA: 0x0005A33F File Offset: 0x0005853F
		public void setSelected(bool selected)
		{
			base.gameObject.GetComponent<Image>().color = (selected ? this.ColorSelected : this.ColorUnselected);
			this.SelectedIcon.SetActive(selected);
		}

		// Token: 0x040013B6 RID: 5046
		public string Name;

		// Token: 0x040013B7 RID: 5047
		public int Slot;

		// Token: 0x040013B8 RID: 5048
		public GameObject Icon;

		// Token: 0x040013B9 RID: 5049
		public GameObject SelectedIcon;

		// Token: 0x040013BA RID: 5050
		public Color ColorSelected;

		// Token: 0x040013BB RID: 5051
		public Color ColorUnselected;
	}
}
