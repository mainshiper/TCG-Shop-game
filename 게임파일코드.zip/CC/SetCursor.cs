﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;

namespace CC
{
	// Token: 0x020001D0 RID: 464
	public class SetCursor : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler
	{
		// Token: 0x06000D09 RID: 3337 RVA: 0x0005BA00 File Offset: 0x00059C00
		public void OnPointerEnter(PointerEventData eventData)
		{
			CameraController.instance.setCursor(this.cursorTexture);
		}

		// Token: 0x06000D0A RID: 3338 RVA: 0x0005BA12 File Offset: 0x00059C12
		public void OnPointerExit(PointerEventData eventData)
		{
			CameraController.instance.setDefaultCursor();
		}

		// Token: 0x04001409 RID: 5129
		public Texture2D cursorTexture;
	}
}
