﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;

namespace CC
{
	// Token: 0x020001C1 RID: 449
	public class DragHandle : MonoBehaviour, IDragHandler, IEventSystemHandler, IPointerDownHandler
	{
		// Token: 0x06000CBF RID: 3263 RVA: 0x0005A1AA File Offset: 0x000583AA
		public void OnDrag(PointerEventData eventData)
		{
			this.rectTransform.anchoredPosition += eventData.delta / this.canvas.scaleFactor;
		}

		// Token: 0x06000CC0 RID: 3264 RVA: 0x0005A1D8 File Offset: 0x000583D8
		public void OnPointerDown(PointerEventData eventData)
		{
			this.rectTransform.SetAsLastSibling();
		}

		// Token: 0x06000CC1 RID: 3265 RVA: 0x0005A1E8 File Offset: 0x000583E8
		private void Start()
		{
			this.rectTransform = this.WindowToDrag.GetComponent<RectTransform>();
			Canvas[] componentsInParent = base.GetComponentsInParent<Canvas>();
			this.canvas = componentsInParent[componentsInParent.Length - 1];
		}

		// Token: 0x040013AD RID: 5037
		public GameObject WindowToDrag;

		// Token: 0x040013AE RID: 5038
		private RectTransform rectTransform;

		// Token: 0x040013AF RID: 5039
		private Canvas canvas;
	}
}
