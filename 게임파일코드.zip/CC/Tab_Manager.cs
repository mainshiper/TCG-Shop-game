﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace CC
{
	// Token: 0x020001D1 RID: 465
	public class Tab_Manager : MonoBehaviour
	{
		// Token: 0x06000D0C RID: 3340 RVA: 0x0005BA28 File Offset: 0x00059C28
		private void Start()
		{
			for (int i = 0; i < base.transform.childCount; i++)
			{
				GameObject gameObject = base.transform.GetChild(i).gameObject;
				int index = i;
				this.tabs.Add(gameObject);
				gameObject.GetComponentInChildren<Button>().onClick.AddListener(delegate()
				{
					this.switchTab(index);
				});
			}
			foreach (object obj in this.TabParent.transform)
			{
				Transform transform = (Transform)obj;
				this.tabMenus.Add(transform.gameObject);
			}
			this.switchTab(0);
		}

		// Token: 0x06000D0D RID: 3341 RVA: 0x0005BB00 File Offset: 0x00059D00
		public void switchTab(int tab)
		{
			for (int i = 0; i < this.tabs.Count; i++)
			{
				this.tabs[i].GetComponentInChildren<Button>().colors = ((tab == i) ? this.TabColorActive : this.TabColorInactive);
				if (this.tabMenus.Count > i)
				{
					this.tabMenus[i].SetActive(tab == i);
				}
			}
		}

		// Token: 0x0400140A RID: 5130
		[Header("Button Active Colors")]
		public ColorBlock TabColorActive;

		// Token: 0x0400140B RID: 5131
		[Header("Button Inactive Colors")]
		public ColorBlock TabColorInactive;

		// Token: 0x0400140C RID: 5132
		public GameObject TabParent;

		// Token: 0x0400140D RID: 5133
		private List<GameObject> tabs = new List<GameObject>();

		// Token: 0x0400140E RID: 5134
		private List<GameObject> tabMenus = new List<GameObject>();
	}
}
