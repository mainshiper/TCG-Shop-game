﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;

namespace CC
{
	// Token: 0x020001C6 RID: 454
	public class Grid_Picker : MonoBehaviour, IDragHandler, IEventSystemHandler, IBeginDragHandler
	{
		// Token: 0x06000CCF RID: 3279 RVA: 0x0005A6BC File Offset: 0x000588BC
		public void Start()
		{
			this.rectTransform = base.gameObject.GetComponent<RectTransform>();
			this.rectTransformPicker = this.Picker.GetComponent<RectTransform>();
			this.rectSize = this.rectTransform.sizeDelta;
			if (this._camera == null && this.UseCamera)
			{
				this._camera = Camera.main;
			}
		}

		// Token: 0x06000CD0 RID: 3280 RVA: 0x0005A720 File Offset: 0x00058920
		public void UpdatePosition(PointerEventData eventData)
		{
			Vector2 vector;
			RectTransformUtility.ScreenPointToLocalPointInRectangle(this.rectTransform, eventData.position, this._camera, ref vector);
			vector.x = Mathf.Clamp(vector.x, 0f, this.rectSize.x);
			vector.y = Mathf.Clamp(vector.y, 0f, this.rectSize.y);
			this.rectTransformPicker.anchoredPosition = new Vector2(Mathf.Clamp(vector.x, 10f, this.rectSize.x - 10f), Mathf.Clamp(vector.y, 10f, this.rectSize.y - 10f));
			vector /= this.rectSize;
			this.m_onPickerDrag.Invoke(vector);
		}

		// Token: 0x06000CD1 RID: 3281 RVA: 0x0005A7F6 File Offset: 0x000589F6
		public void OnDrag(PointerEventData eventData)
		{
			this.UpdatePosition(eventData);
		}

		// Token: 0x06000CD2 RID: 3282 RVA: 0x0005A7FF File Offset: 0x000589FF
		public void OnBeginDrag(PointerEventData eventData)
		{
			this.rectSize = this.rectTransform.sizeDelta;
			this.UpdatePosition(eventData);
		}

		// Token: 0x06000CD3 RID: 3283 RVA: 0x0005A81C File Offset: 0x00058A1C
		public void randomize()
		{
			float num = Random.Range(0f, 1f);
			float num2 = Random.Range(0f, 1f);
			this.m_onPickerDrag.Invoke(new Vector2(num, num2));
			this.rectTransformPicker.anchoredPosition = new Vector2(Mathf.Clamp(num * this.rectSize.x, 10f, this.rectSize.x - 10f), Mathf.Clamp(num2 * this.rectSize.y, 10f, this.rectSize.y - 10f));
		}

		// Token: 0x040013C3 RID: 5059
		private RectTransform rectTransform;

		// Token: 0x040013C4 RID: 5060
		private RectTransform rectTransformPicker;

		// Token: 0x040013C5 RID: 5061
		private Vector2 rectSize;

		// Token: 0x040013C6 RID: 5062
		public Vector2 imageSize;

		// Token: 0x040013C7 RID: 5063
		public Camera _camera;

		// Token: 0x040013C8 RID: 5064
		public bool UseCamera;

		// Token: 0x040013C9 RID: 5065
		public GameObject Picker;

		// Token: 0x040013CA RID: 5066
		public GameObject Background;

		// Token: 0x040013CB RID: 5067
		public OnPickerDrag m_onPickerDrag = new OnPickerDrag();
	}
}
