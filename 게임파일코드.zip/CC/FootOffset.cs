﻿using System;

namespace CC
{
	// Token: 0x020001BA RID: 442
	[Serializable]
	public class FootOffset
	{
		// Token: 0x04001395 RID: 5013
		public float HeightOffset = -1f;

		// Token: 0x04001396 RID: 5014
		public float FootRotation;

		// Token: 0x04001397 RID: 5015
		public float BallRotation;
	}
}
