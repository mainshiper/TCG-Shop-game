﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace CC
{
	// Token: 0x020001CF RID: 463
	public class Option_Slider : MonoBehaviour, ICustomizerUI
	{
		// Token: 0x06000D02 RID: 3330 RVA: 0x0005B7F8 File Offset: 0x000599F8
		public void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util ParentUI)
		{
			this.defaultValue = this.slider.value;
			this.customizer = customizerScript;
			this.parentUI = ParentUI;
			this.slider = base.GetComponentInChildren<Slider>();
			this.RefreshUIElement();
		}

		// Token: 0x06000D03 RID: 3331 RVA: 0x0005B82C File Offset: 0x00059A2C
		public void RefreshUIElement()
		{
			Option_Slider.Type customizationType = this.CustomizationType;
			if (customizationType != Option_Slider.Type.Blendshape)
			{
				if (customizationType != Option_Slider.Type.Scalar)
				{
					return;
				}
				int num = this.customizer.StoredCharacterData.FloatProperties.FindIndex((CC_Property t) => t.propertyName == this.Property.propertyName && t.materialIndex == this.Property.materialIndex && t.meshTag == this.Property.meshTag);
				if (num != -1)
				{
					this.slider.SetValueWithoutNotify(this.customizer.StoredCharacterData.FloatProperties[num].floatValue);
					return;
				}
				this.slider.SetValueWithoutNotify(this.defaultValue);
				return;
			}
			else
			{
				int num2 = this.customizer.StoredCharacterData.Blendshapes.FindIndex((CC_Property t) => t.propertyName == this.Property.propertyName);
				if (num2 != -1)
				{
					this.slider.SetValueWithoutNotify(this.customizer.StoredCharacterData.Blendshapes[num2].floatValue);
					return;
				}
				this.slider.SetValueWithoutNotify(this.defaultValue);
				return;
			}
		}

		// Token: 0x06000D04 RID: 3332 RVA: 0x0005B908 File Offset: 0x00059B08
		public void setProperty(float value)
		{
			this.Property.floatValue = value;
			Option_Slider.Type customizationType = this.CustomizationType;
			if (customizationType == Option_Slider.Type.Blendshape)
			{
				this.customizer.setBlendshapeByName(this.Property.propertyName, value, true);
				return;
			}
			if (customizationType != Option_Slider.Type.Scalar)
			{
				return;
			}
			Debug.Log(value);
			this.customizer.setFloatProperty(this.Property, true);
		}

		// Token: 0x06000D05 RID: 3333 RVA: 0x0005B966 File Offset: 0x00059B66
		public void randomize()
		{
			this.slider.value = Random.Range(this.slider.minValue, this.slider.maxValue);
		}

		// Token: 0x04001403 RID: 5123
		public Option_Slider.Type CustomizationType;

		// Token: 0x04001404 RID: 5124
		public CC_Property Property;

		// Token: 0x04001405 RID: 5125
		public Slider slider;

		// Token: 0x04001406 RID: 5126
		private float defaultValue;

		// Token: 0x04001407 RID: 5127
		private CharacterCustomization customizer;

		// Token: 0x04001408 RID: 5128
		private CC_UI_Util parentUI;

		// Token: 0x0200027D RID: 637
		public enum Type
		{
			// Token: 0x040016C2 RID: 5826
			Blendshape,
			// Token: 0x040016C3 RID: 5827
			Scalar
		}
	}
}
