﻿using System;
using System.Collections.Generic;

namespace CC
{
	// Token: 0x020001B4 RID: 436
	[Serializable]
	public class CC_SaveData
	{
		// Token: 0x0400137D RID: 4989
		public List<CC_CharacterData> SavedCharacters = new List<CC_CharacterData>();
	}
}
