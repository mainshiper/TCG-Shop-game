﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CC
{
	// Token: 0x020001CC RID: 460
	public class Option_MultiPicker : MonoBehaviour, ICustomizerUI
	{
		// Token: 0x06000CEA RID: 3306 RVA: 0x0005AF4B File Offset: 0x0005914B
		public void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util ParentUI)
		{
			this.customizer = customizerScript;
			this.parentUI = ParentUI;
			this.RefreshUIElement();
		}

		// Token: 0x06000CEB RID: 3307 RVA: 0x0005AF61 File Offset: 0x00059161
		public void RefreshUIElement()
		{
			if (this.CustomizationType == Option_MultiPicker.Type.Texture)
			{
				this.optionsCount = this.Properties[0].Objects.Count;
				this.getSavedOption(this.customizer.StoredCharacterData.TextureProperties);
			}
		}

		// Token: 0x06000CEC RID: 3308 RVA: 0x0005AFA0 File Offset: 0x000591A0
		public void getSavedOption(List<CC_Property> savedProps)
		{
			CC_Property property0 = this.Properties[0].Property;
			int savedIndex = savedProps.FindIndex((CC_Property t) => t.propertyName == property0.propertyName && t.materialIndex == property0.materialIndex && t.meshTag == property0.meshTag);
			if (savedIndex != -1)
			{
				this.navIndex = this.Properties[0].Objects.FindIndex((string t) => t == savedProps[savedIndex].stringValue);
			}
			else
			{
				this.navIndex = 0;
			}
			this.updateOptionText();
		}

		// Token: 0x06000CED RID: 3309 RVA: 0x0005B030 File Offset: 0x00059230
		public void updateOptionText()
		{
			this.OptionText.SetText((this.navIndex + 1).ToString() + "/" + this.optionsCount.ToString(), true);
		}

		// Token: 0x06000CEE RID: 3310 RVA: 0x0005B070 File Offset: 0x00059270
		public void setOption(int j)
		{
			this.navIndex = j;
			this.updateOptionText();
			if (this.CustomizationType == Option_MultiPicker.Type.Texture)
			{
				for (int i = 0; i < this.Properties.Count; i++)
				{
					this.Properties[i].Property.stringValue = this.Properties[i].Objects[j];
					this.customizer.setTextureProperty(this.Properties[i].Property, true, null);
				}
			}
		}

		// Token: 0x06000CEF RID: 3311 RVA: 0x0005B0F3 File Offset: 0x000592F3
		public void navLeft()
		{
			this.setOption((this.navIndex == 0) ? (this.optionsCount - 1) : (this.navIndex - 1));
		}

		// Token: 0x06000CF0 RID: 3312 RVA: 0x0005B115 File Offset: 0x00059315
		public void navRight()
		{
			this.setOption((this.navIndex == this.optionsCount - 1) ? 0 : (this.navIndex + 1));
		}

		// Token: 0x06000CF1 RID: 3313 RVA: 0x0005B138 File Offset: 0x00059338
		public void randomize()
		{
			this.setOption(Random.Range(0, this.optionsCount));
		}

		// Token: 0x040013E7 RID: 5095
		private CharacterCustomization customizer;

		// Token: 0x040013E8 RID: 5096
		private CC_UI_Util parentUI;

		// Token: 0x040013E9 RID: 5097
		public List<MultiPicker> Properties = new List<MultiPicker>();

		// Token: 0x040013EA RID: 5098
		public Option_MultiPicker.Type CustomizationType;

		// Token: 0x040013EB RID: 5099
		public int Slot;

		// Token: 0x040013EC RID: 5100
		public TextMeshProUGUI OptionText;

		// Token: 0x040013ED RID: 5101
		private int navIndex;

		// Token: 0x040013EE RID: 5102
		private int optionsCount;

		// Token: 0x02000277 RID: 631
		public enum Type
		{
			// Token: 0x040016B3 RID: 5811
			Texture
		}
	}
}
