﻿using System;
using UnityEngine;

namespace CC
{
	// Token: 0x020001C2 RID: 450
	public class ExpandableWindow : MonoBehaviour
	{
		// Token: 0x06000CC3 RID: 3267 RVA: 0x0005A224 File Offset: 0x00058424
		private void Start()
		{
			this.rT = base.gameObject.GetComponent<RectTransform>();
			this.TargetHeight = (this.CurrentHeight = (this.Expanded ? this.ExpandedHeight : this.ClosedHeight));
			this.rT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, this.CurrentHeight);
		}

		// Token: 0x06000CC4 RID: 3268 RVA: 0x0005A279 File Offset: 0x00058479
		public void setExpandedState()
		{
			this.Expanded = !this.Expanded;
			this.TargetHeight = (this.Expanded ? this.ExpandedHeight : this.ClosedHeight);
		}

		// Token: 0x06000CC5 RID: 3269 RVA: 0x0005A2A8 File Offset: 0x000584A8
		private void Update()
		{
			if (Mathf.Abs(this.CurrentHeight - this.TargetHeight) > 1f)
			{
				this.CurrentHeight = Mathf.Lerp(this.CurrentHeight, this.TargetHeight, Time.deltaTime * 5f);
				this.rT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, this.CurrentHeight);
			}
		}

		// Token: 0x040013B0 RID: 5040
		public float ExpandedHeight;

		// Token: 0x040013B1 RID: 5041
		public float ClosedHeight;

		// Token: 0x040013B2 RID: 5042
		public bool Expanded;

		// Token: 0x040013B3 RID: 5043
		private float TargetHeight;

		// Token: 0x040013B4 RID: 5044
		private float CurrentHeight;

		// Token: 0x040013B5 RID: 5045
		private RectTransform rT;
	}
}
