﻿using System;
using UnityEngine;

namespace CC
{
	// Token: 0x020001BD RID: 445
	public class TransformBone : MonoBehaviour
	{
		// Token: 0x06000CA7 RID: 3239 RVA: 0x00059B9C File Offset: 0x00057D9C
		public void SetOffset(FootOffset footOffset)
		{
			float num;
			switch (this.Mode)
			{
			case TransformBone.mode.Height:
				num = footOffset.HeightOffset;
				break;
			case TransformBone.mode.FootRotation:
				num = footOffset.FootRotation;
				break;
			case TransformBone.mode.BallRotation:
				num = footOffset.BallRotation;
				break;
			default:
				num = 0f;
				break;
			}
			switch (this.Axis)
			{
			case TransformBone.axis.X:
				this.offset = new Vector3(num, 0f, 0f);
				return;
			case TransformBone.axis.Y:
				this.offset = new Vector3(0f, num, 0f);
				return;
			case TransformBone.axis.Z:
				this.offset = new Vector3(0f, 0f, num);
				return;
			default:
				return;
			}
		}

		// Token: 0x06000CA8 RID: 3240 RVA: 0x00059C44 File Offset: 0x00057E44
		private void LateUpdate()
		{
			switch (this.Mode)
			{
			case TransformBone.mode.Height:
				base.transform.position = base.transform.position + this.offset / 100f;
				return;
			case TransformBone.mode.FootRotation:
				base.transform.eulerAngles = base.transform.eulerAngles + this.offset;
				return;
			case TransformBone.mode.BallRotation:
				base.transform.eulerAngles = base.transform.eulerAngles + this.offset;
				return;
			default:
				return;
			}
		}

		// Token: 0x0400139F RID: 5023
		public Vector3 offset = new Vector3(0f, 0f, 0f);

		// Token: 0x040013A0 RID: 5024
		public TransformBone.axis Axis;

		// Token: 0x040013A1 RID: 5025
		public TransformBone.mode Mode;

		// Token: 0x0200026E RID: 622
		public enum mode
		{
			// Token: 0x04001698 RID: 5784
			Height,
			// Token: 0x04001699 RID: 5785
			FootRotation,
			// Token: 0x0400169A RID: 5786
			BallRotation
		}

		// Token: 0x0200026F RID: 623
		public enum axis
		{
			// Token: 0x0400169C RID: 5788
			X,
			// Token: 0x0400169D RID: 5789
			Y,
			// Token: 0x0400169E RID: 5790
			Z
		}
	}
}
