﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace CC
{
	// Token: 0x020001B9 RID: 441
	public class CopyPose : MonoBehaviour
	{
		// Token: 0x06000C9C RID: 3228 RVA: 0x00059834 File Offset: 0x00057A34
		private void Start()
		{
			this.sourceRoot = base.transform.parent.GetComponentInChildren<SkinnedMeshRenderer>().rootBone;
			this.targetRoot = this.getRootBone(base.transform.GetComponentInChildren<SkinnedMeshRenderer>().rootBone);
			Transform[] componentsInChildren = this.targetRoot.GetComponentsInChildren<Transform>();
			Transform[] componentsInChildren2 = this.sourceRoot.GetComponentsInChildren<Transform>();
			for (int i = 0; i < componentsInChildren2.Length; i++)
			{
				Transform sourceBone = componentsInChildren2[i];
				Transform transform = componentsInChildren.FirstOrDefault((Transform t) => t.name == sourceBone.name);
				if (transform != null)
				{
					this.sourceBones.Add(sourceBone);
					this.targetBones.Add(transform);
				}
			}
		}

		// Token: 0x06000C9D RID: 3229 RVA: 0x000598E9 File Offset: 0x00057AE9
		private Transform getRootBone(Transform bone)
		{
			if (bone.parent == null || bone.parent == base.gameObject.transform)
			{
				return bone;
			}
			return this.getRootBone(bone.parent);
		}

		// Token: 0x06000C9E RID: 3230 RVA: 0x00059920 File Offset: 0x00057B20
		private void LateUpdate()
		{
			for (int i = 0; i < this.sourceBones.Count; i++)
			{
				this.targetBones[i].localPosition = this.sourceBones[i].localPosition;
				this.targetBones[i].localRotation = this.sourceBones[i].localRotation;
				this.targetBones[i].localScale = this.sourceBones[i].localScale;
			}
		}

		// Token: 0x04001391 RID: 5009
		private Transform sourceRoot;

		// Token: 0x04001392 RID: 5010
		private Transform targetRoot;

		// Token: 0x04001393 RID: 5011
		private List<Transform> sourceBones = new List<Transform>();

		// Token: 0x04001394 RID: 5012
		private List<Transform> targetBones = new List<Transform>();
	}
}
