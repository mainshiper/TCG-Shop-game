﻿using System;
using System.Collections.Generic;

namespace CC
{
	// Token: 0x020001CB RID: 459
	[Serializable]
	public class MultiPicker
	{
		// Token: 0x040013E5 RID: 5093
		public CC_Property Property;

		// Token: 0x040013E6 RID: 5094
		public List<string> Objects = new List<string>();
	}
}
