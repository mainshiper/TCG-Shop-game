﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace CC
{
	// Token: 0x020001B7 RID: 439
	[CreateAssetMenu(fileName = "Hair", menuName = "ScriptableObjects/Hair")]
	public class scrObj_Hair : ScriptableObject
	{
		// Token: 0x0400138D RID: 5005
		public List<scrObj_Hair.Hairstyle> Hairstyles = new List<scrObj_Hair.Hairstyle>();

		// Token: 0x0400138E RID: 5006
		public string ShadowMapProperty;

		// Token: 0x0400138F RID: 5007
		public string TintProperty;

		// Token: 0x0200026B RID: 619
		[Serializable]
		public struct Hairstyle
		{
			// Token: 0x0400168E RID: 5774
			public GameObject Mesh;

			// Token: 0x0400168F RID: 5775
			public string Name;

			// Token: 0x04001690 RID: 5776
			public Texture2D ShadowMap;

			// Token: 0x04001691 RID: 5777
			public bool AddCopyPoseScript;

			// Token: 0x04001692 RID: 5778
			public Sprite Icon;
		}
	}
}
