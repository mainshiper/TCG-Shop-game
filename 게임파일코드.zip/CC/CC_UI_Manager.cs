﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace CC
{
	// Token: 0x020001BF RID: 447
	public class CC_UI_Manager : MonoBehaviour
	{
		// Token: 0x06000CB0 RID: 3248 RVA: 0x00059F9C File Offset: 0x0005819C
		private void Awake()
		{
			if (CC_UI_Manager.instance == null)
			{
				CC_UI_Manager.instance = this;
				return;
			}
			Object.Destroy(base.gameObject);
		}

		// Token: 0x06000CB1 RID: 3249 RVA: 0x00059FBD File Offset: 0x000581BD
		public void Start()
		{
			this.SetActiveCharacter(0);
		}

		// Token: 0x06000CB2 RID: 3250 RVA: 0x00059FC8 File Offset: 0x000581C8
		public void playUIAudio(int Index)
		{
			AudioSource component = base.gameObject.GetComponent<AudioSource>();
			if (component && this.UISounds.Count > Index)
			{
				component.clip = this.UISounds[Index];
			}
			component.Play();
		}

		// Token: 0x06000CB3 RID: 3251 RVA: 0x0005A010 File Offset: 0x00058210
		public void SetActiveCharacter(int i)
		{
			this.characterIndex = i;
			for (int j = 0; j < this.CharacterParent.transform.childCount; j++)
			{
				this.CharacterParent.transform.GetChild(j).gameObject.SetActive(i == j);
				this.CharacterParent.transform.GetChild(j).GetComponent<CharacterCustomization>().UI.SetActive(i == j);
			}
		}

		// Token: 0x06000CB4 RID: 3252 RVA: 0x0005A082 File Offset: 0x00058282
		public void characterNext()
		{
			this.SetActiveCharacter((this.characterIndex == this.CharacterParent.transform.childCount - 1) ? 0 : (this.characterIndex + 1));
		}

		// Token: 0x06000CB5 RID: 3253 RVA: 0x0005A0AF File Offset: 0x000582AF
		public void characterPrev()
		{
			this.SetActiveCharacter((this.characterIndex == 0) ? (this.CharacterParent.transform.childCount - 1) : (this.characterIndex - 1));
		}

		// Token: 0x040013A8 RID: 5032
		public static CC_UI_Manager instance;

		// Token: 0x040013A9 RID: 5033
		[Tooltip("The parent object of your customizable characters")]
		public GameObject CharacterParent;

		// Token: 0x040013AA RID: 5034
		public List<AudioClip> UISounds = new List<AudioClip>();

		// Token: 0x040013AB RID: 5035
		private int characterIndex;
	}
}
