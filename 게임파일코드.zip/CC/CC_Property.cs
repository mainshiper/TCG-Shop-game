﻿using System;

namespace CC
{
	// Token: 0x020001B3 RID: 435
	[Serializable]
	public class CC_Property
	{
		// Token: 0x04001378 RID: 4984
		public string propertyName = "";

		// Token: 0x04001379 RID: 4985
		public string stringValue = "";

		// Token: 0x0400137A RID: 4986
		public float floatValue;

		// Token: 0x0400137B RID: 4987
		public int materialIndex = -1;

		// Token: 0x0400137C RID: 4988
		public string meshTag = "";
	}
}
