﻿using System;
using System.Collections.Generic;

namespace CC
{
	// Token: 0x020001B2 RID: 434
	[Serializable]
	public class CC_CharacterData
	{
		// Token: 0x0400136E RID: 4974
		public string CharacterName;

		// Token: 0x0400136F RID: 4975
		public string CharacterPrefab;

		// Token: 0x04001370 RID: 4976
		public List<CC_Property> Blendshapes;

		// Token: 0x04001371 RID: 4977
		public List<string> HairNames;

		// Token: 0x04001372 RID: 4978
		public List<string> ApparelNames;

		// Token: 0x04001373 RID: 4979
		public List<int> ApparelMaterials;

		// Token: 0x04001374 RID: 4980
		public List<CC_Property> HairColor;

		// Token: 0x04001375 RID: 4981
		public List<CC_Property> FloatProperties;

		// Token: 0x04001376 RID: 4982
		public List<CC_Property> TextureProperties;

		// Token: 0x04001377 RID: 4983
		public List<CC_Property> ColorProperties;
	}
}
