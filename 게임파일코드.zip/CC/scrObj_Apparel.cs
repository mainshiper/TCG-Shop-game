﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace CC
{
	// Token: 0x020001B6 RID: 438
	[CreateAssetMenu(fileName = "Apparel", menuName = "ScriptableObjects/Apparel")]
	public class scrObj_Apparel : ScriptableObject
	{
		// Token: 0x0400138A RID: 5002
		public List<scrObj_Apparel.Apparel> Items = new List<scrObj_Apparel.Apparel>();

		// Token: 0x0400138B RID: 5003
		public string MaskProperty;

		// Token: 0x0400138C RID: 5004
		public string Label;

		// Token: 0x0200026A RID: 618
		[Serializable]
		public struct Apparel
		{
			// Token: 0x04001686 RID: 5766
			public GameObject Mesh;

			// Token: 0x04001687 RID: 5767
			public string Name;

			// Token: 0x04001688 RID: 5768
			public string DisplayName;

			// Token: 0x04001689 RID: 5769
			public bool AddCopyPoseScript;

			// Token: 0x0400168A RID: 5770
			public Texture2D Mask;

			// Token: 0x0400168B RID: 5771
			public FootOffset FootOffset;

			// Token: 0x0400168C RID: 5772
			public List<CC_Apparel_Material_Collection> Materials;

			// Token: 0x0400168D RID: 5773
			public Sprite Icon;
		}
	}
}
