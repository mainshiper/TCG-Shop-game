﻿using System;
using UnityEngine;

namespace CC
{
	// Token: 0x020001C7 RID: 455
	public class Option_Grid_Picker : MonoBehaviour, ICustomizerUI
	{
		// Token: 0x06000CD5 RID: 3285 RVA: 0x0005A8D0 File Offset: 0x00058AD0
		public void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util parentUI)
		{
			this.customizer = customizerScript;
			Option_Grid_Picker.Type customizationType = this.CustomizationType;
			if (customizationType != Option_Grid_Picker.Type.Blendshape)
			{
			}
		}

		// Token: 0x06000CD6 RID: 3286 RVA: 0x0005A8F2 File Offset: 0x00058AF2
		public void RefreshUIElement()
		{
		}

		// Token: 0x06000CD7 RID: 3287 RVA: 0x0005A8F4 File Offset: 0x00058AF4
		public void updateValue(Vector2 coords)
		{
			Option_Grid_Picker.Type customizationType = this.CustomizationType;
			if (customizationType == Option_Grid_Picker.Type.Blendshape)
			{
				Vector2 vector = new Vector2(coords.x * 2f - 1f, coords.y * 2f - 1f);
				foreach (string name in this.ShapesYNeg)
				{
					this.customizer.setBlendshapeByName(name, Mathf.Abs(Mathf.Clamp(vector.y, -1f, 0f)), this.save);
				}
				foreach (string name2 in this.ShapesYPos)
				{
					this.customizer.setBlendshapeByName(name2, Mathf.Clamp(vector.y, 0f, 1f), this.save);
				}
				foreach (string name3 in this.ShapesXPos)
				{
					this.customizer.setBlendshapeByName(name3, Mathf.Clamp(vector.x, 0f, 1f), this.save);
				}
				foreach (string name4 in this.ShapesXNeg)
				{
					this.customizer.setBlendshapeByName(name4, Mathf.Abs(Mathf.Clamp(vector.x, -1f, 0f)), this.save);
				}
				return;
			}
			if (customizationType != Option_Grid_Picker.Type.Color)
			{
				return;
			}
			int x = Mathf.RoundToInt((float)this.colorTexture.width * coords.x);
			int y = Mathf.RoundToInt((float)this.colorTexture.height * coords.y);
			Color pixel = this.colorTexture.GetPixel(x, y);
			this.customizer.setColorProperty(this.ColorProperty, pixel, true);
		}

		// Token: 0x040013CC RID: 5068
		private CharacterCustomization customizer;

		// Token: 0x040013CD RID: 5069
		public string[] ShapesYNeg;

		// Token: 0x040013CE RID: 5070
		public string[] ShapesYPos;

		// Token: 0x040013CF RID: 5071
		public string[] ShapesXNeg;

		// Token: 0x040013D0 RID: 5072
		public string[] ShapesXPos;

		// Token: 0x040013D1 RID: 5073
		public bool save;

		// Token: 0x040013D2 RID: 5074
		public Texture2D colorTexture;

		// Token: 0x040013D3 RID: 5075
		public Option_Grid_Picker.Type CustomizationType;

		// Token: 0x040013D4 RID: 5076
		public CC_Property ColorProperty;

		// Token: 0x02000276 RID: 630
		public enum Type
		{
			// Token: 0x040016B0 RID: 5808
			Blendshape,
			// Token: 0x040016B1 RID: 5809
			Color
		}
	}
}
