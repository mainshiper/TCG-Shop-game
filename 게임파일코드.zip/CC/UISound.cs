﻿using System;
using UnityEngine;

namespace CC
{
	// Token: 0x020001D2 RID: 466
	public class UISound : MonoBehaviour
	{
		// Token: 0x06000D0F RID: 3343 RVA: 0x0005BB8C File Offset: 0x00059D8C
		public void playUISound(int index)
		{
			CC_UI_Manager.instance.playUIAudio(index);
		}
	}
}
