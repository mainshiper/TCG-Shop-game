﻿using System;
using UnityEngine;

namespace CC
{
	// Token: 0x020001BC RID: 444
	public class ScaleCharacter : MonoBehaviour
	{
		// Token: 0x06000CA3 RID: 3235 RVA: 0x00059A19 File Offset: 0x00057C19
		public void SetHeight(float _Height)
		{
			this.Height = _Height;
			this.TargetScale = new Vector3(this.Height * this.Width, this.Height * this.Width, this.Height);
		}

		// Token: 0x06000CA4 RID: 3236 RVA: 0x00059A4D File Offset: 0x00057C4D
		public void SetWidth(float _Width)
		{
			this.Width = _Width;
			this.TargetScale = new Vector3(this.Height * this.Width, this.Height * this.Width, this.Height);
		}

		// Token: 0x06000CA5 RID: 3237 RVA: 0x00059A84 File Offset: 0x00057C84
		private void LateUpdate()
		{
			ScaleCharacter.mode mode = this.Mode;
			if (mode == ScaleCharacter.mode.Scale)
			{
				base.transform.localScale = this.TargetScale;
				return;
			}
			if (mode != ScaleCharacter.mode.CounterScale)
			{
				return;
			}
			base.transform.localScale = new Vector3(1f / this.TargetScale.z * Mathf.Lerp(this.TargetScale.z, 1f, this.CounterScaleLerp), 1f / this.TargetScale.y * Mathf.Lerp(this.TargetScale.z, 1f, this.CounterScaleLerp), 1f / this.TargetScale.x * Mathf.Lerp(this.TargetScale.z, 1f, this.CounterScaleLerp));
		}

		// Token: 0x0400139A RID: 5018
		public Vector3 TargetScale = new Vector3(1f, 1f, 1f);

		// Token: 0x0400139B RID: 5019
		public float Height = 1f;

		// Token: 0x0400139C RID: 5020
		public float Width = 1f;

		// Token: 0x0400139D RID: 5021
		public float CounterScaleLerp = 0.5f;

		// Token: 0x0400139E RID: 5022
		public ScaleCharacter.mode Mode;

		// Token: 0x0200026D RID: 621
		public enum mode
		{
			// Token: 0x04001695 RID: 5781
			Scale,
			// Token: 0x04001696 RID: 5782
			CounterScale
		}
	}
}
