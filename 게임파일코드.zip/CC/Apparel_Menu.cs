﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace CC
{
	// Token: 0x020001BE RID: 446
	public class Apparel_Menu : MonoBehaviour, ICustomizerUI
	{
		// Token: 0x06000CAA RID: 3242 RVA: 0x00059CFC File Offset: 0x00057EFC
		public void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util parentUI)
		{
			this.customizer = customizerScript;
			this.RefreshUIElement();
		}

		// Token: 0x06000CAB RID: 3243 RVA: 0x00059D0C File Offset: 0x00057F0C
		public void setOption(int i)
		{
			this.navIndex = i;
			this.OptionText.text = this.customizer.ApparelTables[i].Label;
			foreach (object obj in this.Container.transform)
			{
				Object.Destroy(((Transform)obj).gameObject);
			}
			foreach (scrObj_Apparel.Apparel apparel in this.customizer.ApparelTables[i].Items)
			{
				int Slot = i;
				for (int j = 0; j < apparel.Materials.Count; j++)
				{
					string name = apparel.Name;
					int matIndex = j;
					GameObject gameObject = Object.Instantiate<GameObject>(this.ButtonPrefab, this.Container.transform).gameObject;
					gameObject.GetComponentInChildren<Button>().onClick.AddListener(delegate()
					{
						this.customizer.setApparelByName(name, Slot, matIndex);
					});
					gameObject.GetComponentInChildren<TextMeshProUGUI>().text = apparel.Materials[j].Label + " " + apparel.DisplayName;
				}
				if (apparel.Materials.Count == 0)
				{
					string name = apparel.Name;
					GameObject gameObject2 = Object.Instantiate<GameObject>(this.ButtonPrefab, this.Container.transform).gameObject;
					gameObject2.GetComponentInChildren<Button>().onClick.AddListener(delegate()
					{
						this.customizer.setApparelByName(name, Slot, 0);
					});
					gameObject2.GetComponentInChildren<TextMeshProUGUI>().text = apparel.DisplayName;
				}
			}
		}

		// Token: 0x06000CAC RID: 3244 RVA: 0x00059F30 File Offset: 0x00058130
		public void navLeft()
		{
			this.setOption((this.navIndex == 0) ? (this.optionsCount - 1) : (this.navIndex - 1));
		}

		// Token: 0x06000CAD RID: 3245 RVA: 0x00059F52 File Offset: 0x00058152
		public void navRight()
		{
			this.setOption((this.navIndex == this.optionsCount - 1) ? 0 : (this.navIndex + 1));
		}

		// Token: 0x06000CAE RID: 3246 RVA: 0x00059F75 File Offset: 0x00058175
		public void RefreshUIElement()
		{
			this.optionsCount = this.customizer.ApparelTables.Count;
			this.setOption(0);
		}

		// Token: 0x040013A2 RID: 5026
		public GameObject ButtonPrefab;

		// Token: 0x040013A3 RID: 5027
		public GameObject Container;

		// Token: 0x040013A4 RID: 5028
		public TextMeshProUGUI OptionText;

		// Token: 0x040013A5 RID: 5029
		private CharacterCustomization customizer;

		// Token: 0x040013A6 RID: 5030
		private int navIndex;

		// Token: 0x040013A7 RID: 5031
		private int optionsCount;
	}
}
