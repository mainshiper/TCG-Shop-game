﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace CC
{
	// Token: 0x020001C4 RID: 452
	public class Grid_Icon_Generator : MonoBehaviour, ICustomizerUI
	{
		// Token: 0x06000CCA RID: 3274 RVA: 0x0005A378 File Offset: 0x00058578
		public void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util parentUI)
		{
			this.customizer = customizerScript;
			Grid_Icon_Generator.Type customizationType = this.CustomizationType;
			if (customizationType != Grid_Icon_Generator.Type.Apparel)
			{
				if (customizationType == Grid_Icon_Generator.Type.Hair)
				{
					List<scrObj_Hair.Hairstyle> hairstyles = this.customizer.HairTables[this.Slot].Hairstyles;
					for (int i = 0; i < hairstyles.Count; i++)
					{
						string name = hairstyles[i].Name;
						int index = i;
						Grid_Icon component = Object.Instantiate<GameObject>(this.Prefab, base.transform).GetComponent<Grid_Icon>();
						component.GetComponent<Button>().onClick.AddListener(delegate()
						{
							this.customizer.setHairByName(name, this.Slot);
						});
						component.GetComponent<Button>().onClick.AddListener(delegate()
						{
							this.updateSelectedState(index);
						});
						component.name = name;
						this.gridIcons.Add(component);
						component.setIcon(hairstyles[i].Icon);
					}
				}
			}
			else
			{
				List<scrObj_Apparel.Apparel> items = this.customizer.ApparelTables[this.Slot].Items;
				for (int j = 0; j < items.Count; j++)
				{
					string name = items[j].Name;
					int index = j;
					Grid_Icon component2 = Object.Instantiate<GameObject>(this.Prefab, base.transform).GetComponent<Grid_Icon>();
					component2.GetComponent<Button>().onClick.AddListener(delegate()
					{
						this.customizer.setApparelByName(name, this.Slot, 0);
					});
					component2.GetComponent<Button>().onClick.AddListener(delegate()
					{
						this.updateSelectedState(index);
					});
					component2.name = name;
					this.gridIcons.Add(component2);
					component2.setIcon(items[j].Icon);
				}
			}
			this.RefreshUIElement();
			while (base.transform.childCount < 9)
			{
				Object.Instantiate<GameObject>(this.Prefab, base.transform).GetComponent<Grid_Icon>().GetComponent<Button>().interactable = false;
			}
		}

		// Token: 0x06000CCB RID: 3275 RVA: 0x0005A5A4 File Offset: 0x000587A4
		public void RefreshUIElement()
		{
			string a = "";
			Grid_Icon_Generator.Type customizationType = this.CustomizationType;
			if (customizationType != Grid_Icon_Generator.Type.Apparel)
			{
				if (customizationType == Grid_Icon_Generator.Type.Hair)
				{
					a = this.customizer.StoredCharacterData.HairNames[this.Slot];
				}
			}
			else
			{
				a = this.customizer.StoredCharacterData.ApparelNames[this.Slot];
			}
			foreach (Grid_Icon grid_Icon in this.gridIcons)
			{
				grid_Icon.setSelected(a == grid_Icon.name);
			}
		}

		// Token: 0x06000CCC RID: 3276 RVA: 0x0005A654 File Offset: 0x00058854
		public void updateSelectedState(int index)
		{
			for (int i = 0; i < this.gridIcons.Count; i++)
			{
				this.gridIcons[i].setSelected(i == index);
			}
		}

		// Token: 0x040013BC RID: 5052
		public Grid_Icon_Generator.Type CustomizationType;

		// Token: 0x040013BD RID: 5053
		public int Slot;

		// Token: 0x040013BE RID: 5054
		public int MinIcons = 9;

		// Token: 0x040013BF RID: 5055
		public GameObject Prefab;

		// Token: 0x040013C0 RID: 5056
		public List<string> Objects = new List<string>();

		// Token: 0x040013C1 RID: 5057
		private CharacterCustomization customizer;

		// Token: 0x040013C2 RID: 5058
		private List<Grid_Icon> gridIcons = new List<Grid_Icon>();

		// Token: 0x02000273 RID: 627
		public enum Type
		{
			// Token: 0x040016A7 RID: 5799
			Apparel,
			// Token: 0x040016A8 RID: 5800
			Hair
		}
	}
}
