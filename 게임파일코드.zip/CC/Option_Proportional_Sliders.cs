﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace CC
{
	// Token: 0x020001CE RID: 462
	public class Option_Proportional_Sliders : MonoBehaviour, ICustomizerUI
	{
		// Token: 0x06000CFD RID: 3325 RVA: 0x0005B50C File Offset: 0x0005970C
		public void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util ParentUI)
		{
			this.customizer = customizerScript;
			this.parentUI = ParentUI;
			for (int i = 0; i < this.Objects.Count; i++)
			{
				Option_Slider component = Object.Instantiate<GameObject>(this.SliderObject, base.transform).GetComponent<Option_Slider>();
				this.sliderObjects.Add(component);
				component.Property.propertyName = this.Objects[i];
				component.CustomizationType = Option_Slider.Type.Blendshape;
				component.InitializeUIElement(customizerScript, ParentUI);
				Slider slider = component.GetComponentInChildren<Slider>();
				this.sliders.Add(slider);
				slider.onValueChanged.AddListener(delegate(float <p0>)
				{
					this.checkExcess(slider);
				});
				component.GetComponentInChildren<TextMeshProUGUI>().text = this.TextPrefix + (i + 1).ToString();
				component.GetComponent<RectTransform>().SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, this.SliderHeight);
				if (this.RemoveText)
				{
					Object.Destroy(component.GetComponentInChildren<TextMeshProUGUI>().gameObject);
				}
			}
			base.gameObject.GetComponent<RectTransform>().SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, base.gameObject.GetComponent<RectTransform>().rect.height + (this.SliderHeight + base.gameObject.GetComponent<VerticalLayoutGroup>().spacing) * (float)this.sliderObjects.Count);
		}

		// Token: 0x06000CFE RID: 3326 RVA: 0x0005B66C File Offset: 0x0005986C
		public void RefreshUIElement()
		{
		}

		// Token: 0x06000CFF RID: 3327 RVA: 0x0005B670 File Offset: 0x00059870
		public void checkExcess(Slider mainSlider)
		{
			this.sliderSum = 0f;
			foreach (Slider slider in this.sliders)
			{
				this.sliderSum = slider.value + this.sliderSum;
			}
			if (this.sliderSum > 1f)
			{
				for (int i = 0; i < this.sliders.Count; i++)
				{
					if (mainSlider != this.sliders[i])
					{
						this.distributeExcess(this.sliderSum - mainSlider.value, this.sliderSum - 1f, i);
					}
				}
			}
		}

		// Token: 0x06000D00 RID: 3328 RVA: 0x0005B734 File Offset: 0x00059934
		public void distributeExcess(float sum, float excess, int index)
		{
			this.sliders[index].SetValueWithoutNotify(this.sliders[index].value - this.sliders[index].value / sum * excess);
			this.sliderObjects[index].setProperty(this.sliders[index].value);
		}

		// Token: 0x040013F7 RID: 5111
		private CharacterCustomization customizer;

		// Token: 0x040013F8 RID: 5112
		private CC_UI_Util parentUI;

		// Token: 0x040013F9 RID: 5113
		public List<string> Objects = new List<string>();

		// Token: 0x040013FA RID: 5114
		public string MeshTag = "";

		// Token: 0x040013FB RID: 5115
		public int MaterialIndex = -1;

		// Token: 0x040013FC RID: 5116
		public float SliderHeight = 60f;

		// Token: 0x040013FD RID: 5117
		public string TextPrefix = "";

		// Token: 0x040013FE RID: 5118
		public bool RemoveText;

		// Token: 0x040013FF RID: 5119
		private float sliderSum;

		// Token: 0x04001400 RID: 5120
		public GameObject SliderObject;

		// Token: 0x04001401 RID: 5121
		private List<Slider> sliders = new List<Slider>();

		// Token: 0x04001402 RID: 5122
		private List<Option_Slider> sliderObjects = new List<Option_Slider>();
	}
}
