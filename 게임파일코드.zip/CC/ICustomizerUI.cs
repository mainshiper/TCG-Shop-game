﻿using System;

namespace CC
{
	// Token: 0x020001C8 RID: 456
	public interface ICustomizerUI
	{
		// Token: 0x06000CD9 RID: 3289
		void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util parentUI);

		// Token: 0x06000CDA RID: 3290
		void RefreshUIElement();
	}
}
