﻿using System;

// Token: 0x020000F6 RID: 246
public enum EScreenFeature
{
	// Token: 0x04000D9C RID: 3484
	None,
	// Token: 0x04000D9D RID: 3485
	OpenScreen,
	// Token: 0x04000D9E RID: 3486
	CloseScreen,
	// Token: 0x04000D9F RID: 3487
	MainFeature1,
	// Token: 0x04000DA0 RID: 3488
	MainFeature2,
	// Token: 0x04000DA1 RID: 3489
	SideFeature1,
	// Token: 0x04000DA2 RID: 3490
	SideFeature2,
	// Token: 0x04000DA3 RID: 3491
	SideFeature3
}
