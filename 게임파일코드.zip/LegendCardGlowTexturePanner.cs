﻿using System;
using UnityEngine;

// Token: 0x02000098 RID: 152
public class LegendCardGlowTexturePanner : MonoBehaviour
{
	// Token: 0x060005F9 RID: 1529 RVA: 0x00031FF9 File Offset: 0x000301F9
	private void Start()
	{
	}

	// Token: 0x060005FA RID: 1530 RVA: 0x00031FFC File Offset: 0x000301FC
	private void Update()
	{
		this.m_X1 += Time.deltaTime * this.m_SpeedX1;
		this.m_X2 += Time.deltaTime * this.m_SpeedX2;
		this.m_Y1 += Time.deltaTime * this.m_SpeedY1;
		this.m_Y2 += Time.deltaTime * this.m_SpeedY2;
		this.m_Offset1.x = this.m_X1;
		this.m_Offset2.x = this.m_X2;
		this.m_Offset1.y = this.m_Y1;
		this.m_Offset2.y = this.m_Y2;
		this.m_Material1.SetFloat("_OffsetX", this.m_X1);
		this.m_Material2.SetFloat("_OffsetX", this.m_X2);
		this.m_Material1.SetTextureOffset("_Texture", this.m_Offset1);
		this.m_Material2.SetTextureOffset("_Texture", this.m_Offset2);
	}

	// Token: 0x060005FB RID: 1531 RVA: 0x0003210C File Offset: 0x0003030C
	private void OnApplicationQuit()
	{
		this.m_Material1.SetTextureOffset("_Texture", Vector2.zero);
		this.m_Material2.SetTextureOffset("_Texture", Vector2.zero);
		this.m_Material1.SetFloat("_OffsetX", 0f);
		this.m_Material2.SetFloat("_OffsetX", 0f);
	}

	// Token: 0x040007C2 RID: 1986
	public Material m_Material1;

	// Token: 0x040007C3 RID: 1987
	public Material m_Material2;

	// Token: 0x040007C4 RID: 1988
	public float m_SpeedX1 = 1f;

	// Token: 0x040007C5 RID: 1989
	public float m_SpeedX2 = 1f;

	// Token: 0x040007C6 RID: 1990
	public float m_SpeedY1 = 1f;

	// Token: 0x040007C7 RID: 1991
	public float m_SpeedY2 = 1f;

	// Token: 0x040007C8 RID: 1992
	private float m_X1;

	// Token: 0x040007C9 RID: 1993
	private float m_X2;

	// Token: 0x040007CA RID: 1994
	private float m_Y1;

	// Token: 0x040007CB RID: 1995
	private float m_Y2;

	// Token: 0x040007CC RID: 1996
	private Vector2 m_Offset1;

	// Token: 0x040007CD RID: 1997
	private Vector2 m_Offset2;
}
