﻿using System;

// Token: 0x0200000F RID: 15
public enum ECollectionSortingType
{
	// Token: 0x040000B3 RID: 179
	Default,
	// Token: 0x040000B4 RID: 180
	Amount,
	// Token: 0x040000B5 RID: 181
	Price,
	// Token: 0x040000B6 RID: 182
	Type,
	// Token: 0x040000B7 RID: 183
	Rarity,
	// Token: 0x040000B8 RID: 184
	DuplicatePrice,
	// Token: 0x040000B9 RID: 185
	TotalValue,
	// Token: 0x040000BA RID: 186
	MAX
}
