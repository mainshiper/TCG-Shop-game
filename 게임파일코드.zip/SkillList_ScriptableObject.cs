﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000134 RID: 308
[CreateAssetMenu(fileName = "Data", menuName = "Inventory/List", order = 7)]
public class SkillList_ScriptableObject : ScriptableObject
{
	// Token: 0x04001103 RID: 4355
	public List<Color> m_ElementColorList;
}
