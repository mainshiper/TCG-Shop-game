﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200010E RID: 270
public class ControllerScreenUIExtension : MonoBehaviour
{
	// Token: 0x060007E9 RID: 2025 RVA: 0x0003B664 File Offset: 0x00039864
	public void OnOpenScreen()
	{
		if (this.m_CurrentControllerButton)
		{
			this.m_CurrentControllerButton.OnSelectionDeactivate();
		}
		if (this.m_StartControllerButton)
		{
			this.m_CurrentControllerButton = this.m_StartControllerButton;
			Vector2 controllerButtonIndex = this.GetControllerButtonIndex(this.m_CurrentControllerButton);
			this.m_CurrentCtrlBtnXIndex = Mathf.RoundToInt(controllerButtonIndex.x);
			this.m_CurrentCtrlBtnYIndex = Mathf.RoundToInt(controllerButtonIndex.y);
		}
		else
		{
			this.m_CurrentCtrlBtnXIndex = 0;
			this.m_CurrentCtrlBtnYIndex = 0;
			this.m_CurrentControllerButton = this.GetControllerButton(0, 0);
		}
		this.m_CurrentControllerButton.OnSelectionActive();
		if (this.GetCtrlBtnXChangeMethod(this.m_CurrentCtrlBtnYIndex) == ECtrlBtnXChangeMethod.RememberIndexX)
		{
			this.m_LastChangeMethodCtrlBtnXIndex = this.m_CurrentCtrlBtnXIndex;
		}
	}

	// Token: 0x060007EA RID: 2026 RVA: 0x0003B715 File Offset: 0x00039915
	public void OnCloseChildScreen()
	{
		if (this.m_CurrentControllerButton)
		{
			this.m_CurrentControllerButton.OnSelectionDeactivate();
			this.m_CurrentControllerButton.OnSelectionActive();
		}
	}

	// Token: 0x060007EB RID: 2027 RVA: 0x0003B73A File Offset: 0x0003993A
	private ControllerButton GetControllerButton(int indexX, int indexY)
	{
		return this.m_ControllerBtnColumnList[indexY].rowList[indexX];
	}

	// Token: 0x060007EC RID: 2028 RVA: 0x0003B754 File Offset: 0x00039954
	private Vector2 GetControllerButtonIndex(ControllerButton ctrlBtn)
	{
		Vector2 result = default(Vector2);
		int num = -1;
		int num2 = -1;
		for (int i = 0; i < this.m_ControllerBtnColumnList.Count; i++)
		{
			for (int j = 0; j < this.m_ControllerBtnColumnList[i].rowList.Count; j++)
			{
				if (this.m_ControllerBtnColumnList[i].rowList[j] == ctrlBtn)
				{
					num = j;
					num2 = i;
					break;
				}
			}
		}
		result.x = (float)num;
		result.y = (float)num2;
		return result;
	}

	// Token: 0x060007ED RID: 2029 RVA: 0x0003B7E4 File Offset: 0x000399E4
	public void RunUpdate()
	{
		if (CSingleton<CGameManager>.Instance.m_IsPrologue || !CSingleton<InputManager>.Instance.m_IsControllerActive || CSingleton<CGameManager>.Instance.m_DisableController)
		{
			return;
		}
		if (InputManager.GetKeyDownAction(EGameAction.MenuConfirm))
		{
			if (this.m_CanRapidFireConfirmBtn)
			{
				this.m_IsHoldingConfirmBtn = true;
			}
			this.OnPressConfirm();
		}
		else if (InputManager.GetKeyUpAction(EGameAction.MenuConfirm))
		{
			if (this.m_CanRapidFireConfirmBtn)
			{
				this.m_IsHoldingConfirmBtn = false;
				this.m_JoystickRapidFireStartTimer = 0f;
				this.m_IsJoystickRapidFire = false;
			}
		}
		else if (InputManager.GetKeyDownAction(EGameAction.MenuBack))
		{
			this.OnPressCancel();
		}
		if (InputManager.GetLeftAnalogDown(0, true))
		{
			this.m_IsHoldingLeftJoystickRight = true;
			this.OnPressRight();
			return;
		}
		if (InputManager.GetLeftAnalogUp(0, true))
		{
			this.m_IsHoldingLeftJoystickRight = false;
			this.m_JoystickRapidFireStartTimer = 0f;
			this.m_IsJoystickRapidFire = false;
		}
		if (InputManager.GetLeftAnalogDown(0, false))
		{
			this.m_IsHoldingLeftJoystickLeft = true;
			this.OnPressLeft();
			return;
		}
		if (InputManager.GetLeftAnalogUp(0, false))
		{
			this.m_IsHoldingLeftJoystickLeft = false;
			this.m_JoystickRapidFireStartTimer = 0f;
			this.m_IsJoystickRapidFire = false;
		}
		if (InputManager.GetLeftAnalogDown(1, true))
		{
			this.m_IsHoldingLeftJoystickUp = true;
			this.OnPressUp();
			return;
		}
		if (InputManager.GetLeftAnalogUp(1, true))
		{
			this.m_IsHoldingLeftJoystickUp = false;
			this.m_JoystickRapidFireStartTimer = 0f;
			this.m_IsJoystickRapidFire = false;
		}
		if (InputManager.GetLeftAnalogDown(1, false))
		{
			this.m_IsHoldingLeftJoystickDown = true;
			this.OnPressDown();
			return;
		}
		if (InputManager.GetLeftAnalogUp(1, false))
		{
			this.m_IsHoldingLeftJoystickDown = false;
			this.m_JoystickRapidFireStartTimer = 0f;
			this.m_IsJoystickRapidFire = false;
		}
		if (!this.m_IsJoystickRapidFire)
		{
			if (this.m_IsHoldingLeftJoystickRight || this.m_IsHoldingLeftJoystickLeft || this.m_IsHoldingLeftJoystickUp || this.m_IsHoldingLeftJoystickDown || (this.m_CanRapidFireConfirmBtn && this.m_IsHoldingConfirmBtn))
			{
				this.m_JoystickRapidFireStartTimer += Time.unscaledDeltaTime;
				if (this.m_JoystickRapidFireStartTimer >= this.m_JoystickRapidFireStartTime)
				{
					this.m_JoystickRapidFireStartTimer = 0f;
					this.m_JoystickRapidFireTimer = 0f;
					this.m_IsJoystickRapidFire = true;
					return;
				}
			}
		}
		else if (this.m_IsJoystickRapidFire)
		{
			this.m_JoystickRapidFireTimer += Time.unscaledDeltaTime;
			if (this.m_JoystickRapidFireTimer >= this.m_JoystickRapidFireTime)
			{
				this.m_JoystickRapidFireTimer = 0f;
				if (this.m_IsHoldingLeftJoystickLeft)
				{
					this.OnPressLeft();
					return;
				}
				if (this.m_IsHoldingLeftJoystickRight)
				{
					this.OnPressRight();
					return;
				}
				if (this.m_IsHoldingLeftJoystickUp)
				{
					this.OnPressUp();
					return;
				}
				if (this.m_IsHoldingLeftJoystickDown)
				{
					this.OnPressDown();
					return;
				}
				if (this.m_IsHoldingConfirmBtn)
				{
					this.OnPressConfirm();
				}
			}
		}
	}

	// Token: 0x060007EE RID: 2030 RVA: 0x0003BA54 File Offset: 0x00039C54
	public void UpdateControllerBtnIndex_X(int addX)
	{
		this.m_CurrentCtrlBtnXIndex += addX;
		if (this.m_CurrentCtrlBtnXIndex < 0)
		{
			if (this.m_LoopWithinRowOnly)
			{
				for (int i = this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count - 1; i >= 0; i--)
				{
					if (this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList[i].IsActive())
					{
						this.m_CurrentCtrlBtnXIndex = i;
						break;
					}
				}
			}
			else if (this.m_SettingScreenLoopSpecial)
			{
				this.EvaluateSpecialLoopCaseForSettingScreen();
			}
			else
			{
				this.UpdateControllerBtnIndex_Y(-1, true);
				for (int j = this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count - 1; j >= 0; j--)
				{
					if (this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList[j].IsActive())
					{
						this.m_CurrentCtrlBtnXIndex = j;
						break;
					}
				}
			}
		}
		else if (this.m_CurrentCtrlBtnXIndex >= this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count)
		{
			if (this.m_LoopWithinRowOnly)
			{
				this.m_CurrentCtrlBtnXIndex = 0;
			}
			else if (this.m_SettingScreenLoopSpecial)
			{
				this.EvaluateSpecialLoopCaseForSettingScreen();
			}
			else
			{
				int currentCtrlBtnYIndex = this.m_CurrentCtrlBtnYIndex;
				this.UpdateControllerBtnIndex_Y(1, true);
				if (currentCtrlBtnYIndex != this.m_CurrentCtrlBtnYIndex)
				{
					this.m_CurrentCtrlBtnXIndex = 0;
				}
			}
		}
		else
		{
			bool flag = true;
			if (addX > 0)
			{
				for (int k = this.m_CurrentCtrlBtnXIndex; k < this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count; k++)
				{
					if (this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList[k].IsActive())
					{
						flag = false;
						this.m_CurrentCtrlBtnXIndex = k;
						break;
					}
				}
			}
			else
			{
				for (int l = this.m_CurrentCtrlBtnXIndex; l >= 0; l--)
				{
					if (this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList[l].IsActive())
					{
						flag = false;
						this.m_CurrentCtrlBtnXIndex = l;
						break;
					}
				}
			}
			if (flag)
			{
				if (addX > 0)
				{
					if (this.m_LoopWithinRowOnly)
					{
						this.m_CurrentCtrlBtnXIndex = 0;
					}
					else if (this.m_SettingScreenLoopSpecial)
					{
						this.EvaluateSpecialLoopCaseForSettingScreen();
					}
					else
					{
						this.UpdateControllerBtnIndex_Y(1, true);
						this.m_CurrentCtrlBtnXIndex = 0;
					}
				}
				else if (addX < 0)
				{
					if (this.m_LoopWithinRowOnly)
					{
						for (int m = this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count - 1; m >= 0; m--)
						{
							if (this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList[m].IsActive())
							{
								this.m_CurrentCtrlBtnXIndex = m;
								break;
							}
						}
					}
					else if (this.m_SettingScreenLoopSpecial)
					{
						this.EvaluateSpecialLoopCaseForSettingScreen();
					}
					else
					{
						this.m_CurrentCtrlBtnXIndex = 1000;
						this.UpdateControllerBtnIndex_Y(-1, true);
					}
				}
			}
		}
		if (this.m_CurrentControllerButton)
		{
			this.m_CurrentControllerButton.OnSelectionDeactivate();
		}
		this.m_CurrentControllerButton = this.GetControllerButton(this.m_CurrentCtrlBtnXIndex, this.m_CurrentCtrlBtnYIndex);
		this.m_CurrentControllerButton.OnSelectionActive();
		if (this.m_SliderScreen && this.m_CurrentControllerButton.m_CanScrollerSlide)
		{
			this.m_SliderScreen.ScrollToUI(this.m_CurrentControllerButton.gameObject, false, this.m_SliderOffsetY);
		}
	}

	// Token: 0x060007EF RID: 2031 RVA: 0x0003BDB0 File Offset: 0x00039FB0
	private void EvaluateSpecialLoopCaseForSettingScreen()
	{
		if (this.GetCtrlBtnXChangeMethod(this.m_CurrentCtrlBtnYIndex) == ECtrlBtnXChangeMethod.SettingScreenSkipSideButtonIndexY)
		{
			this.m_CurrentCtrlBtnXIndex = 0;
			this.m_CurrentCtrlBtnYIndex = CSingleton<SettingScreen>.Instance.m_SubSettingBtnHighlight.Count;
			bool flag = false;
			for (int i = this.m_CurrentCtrlBtnYIndex; i < this.m_ControllerBtnColumnList.Count; i++)
			{
				for (int j = 0; j < this.m_ControllerBtnColumnList[i].rowList.Count; j++)
				{
					if (this.m_ControllerBtnColumnList[i].rowList[j].IsActive())
					{
						flag = true;
						this.m_CurrentCtrlBtnXIndex = j;
						this.m_CurrentCtrlBtnYIndex = i;
						break;
					}
				}
				if (flag)
				{
					return;
				}
			}
			return;
		}
		this.m_CurrentCtrlBtnXIndex = 0;
		this.m_CurrentCtrlBtnYIndex = this.m_IndexYWhenLoopXEnd;
	}

	// Token: 0x060007F0 RID: 2032 RVA: 0x0003BE70 File Offset: 0x0003A070
	public void UpdateControllerBtnIndex_Y(int addY, bool ignoreUpdateControllerBtn = false)
	{
		ECtrlBtnXChangeMethod ctrlBtnXChangeMethod = this.GetCtrlBtnXChangeMethod(this.m_CurrentCtrlBtnYIndex);
		if (ctrlBtnXChangeMethod == ECtrlBtnXChangeMethod.RememberIndexX)
		{
			this.m_LastChangeMethodCtrlBtnXIndex = this.m_CurrentCtrlBtnXIndex;
		}
		this.m_CurrentCtrlBtnYIndex += addY;
		if (this.m_CurrentCtrlBtnYIndex < 0)
		{
			if (this.m_CanLoopY)
			{
				bool flag = false;
				for (int i = this.m_ControllerBtnColumnList.Count - 1; i >= 0; i--)
				{
					for (int j = this.m_ControllerBtnColumnList[i].rowList.Count - 1; j >= 0; j--)
					{
						if (this.m_ControllerBtnColumnList[i].rowList[j].IsActive())
						{
							flag = true;
							this.m_CurrentCtrlBtnYIndex = i;
							break;
						}
					}
					if (flag)
					{
						break;
					}
				}
			}
			else
			{
				this.m_CurrentCtrlBtnYIndex = 0;
			}
		}
		else if (this.m_CurrentCtrlBtnYIndex >= this.m_ControllerBtnColumnList.Count)
		{
			if (this.m_CanLoopY)
			{
				this.m_CurrentCtrlBtnYIndex = 0;
			}
			else
			{
				this.m_CurrentCtrlBtnYIndex = this.m_ControllerBtnColumnList.Count - 1;
			}
		}
		else
		{
			bool flag2 = true;
			if (addY > 0)
			{
				for (int k = this.m_CurrentCtrlBtnYIndex; k < this.m_ControllerBtnColumnList.Count; k++)
				{
					int l = this.m_ControllerBtnColumnList[k].rowList.Count - 1;
					while (l >= 0)
					{
						if (this.m_ControllerBtnColumnList[k].rowList[l].IsActive())
						{
							flag2 = false;
							this.m_CurrentCtrlBtnYIndex = k;
							if (this.m_CurrentCtrlBtnXIndex > l)
							{
								this.m_CurrentCtrlBtnXIndex = l;
								break;
							}
							break;
						}
						else
						{
							l--;
						}
					}
					if (!flag2)
					{
						break;
					}
				}
			}
			else
			{
				for (int m = this.m_CurrentCtrlBtnYIndex; m >= 0; m--)
				{
					int n = this.m_ControllerBtnColumnList[m].rowList.Count - 1;
					while (n >= 0)
					{
						if (this.m_ControllerBtnColumnList[m].rowList[n].IsActive())
						{
							flag2 = false;
							this.m_CurrentCtrlBtnYIndex = m;
							if (this.m_CurrentCtrlBtnXIndex > n)
							{
								this.m_CurrentCtrlBtnXIndex = n;
								break;
							}
							break;
						}
						else
						{
							n--;
						}
					}
					if (!flag2)
					{
						break;
					}
				}
			}
			if (flag2)
			{
				if (this.m_CanLoopY)
				{
					this.m_CurrentCtrlBtnYIndex = 0;
				}
				else
				{
					this.m_CurrentCtrlBtnYIndex--;
				}
			}
		}
		if (this.m_CurrentCtrlBtnXIndex >= this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count)
		{
			this.m_CurrentCtrlBtnXIndex = this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count - 1;
		}
		if (this.m_CurrentCtrlBtnXIndex > this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count - this.m_CurrentCtrlBtnXIndex)
		{
			for (int num = this.m_CurrentCtrlBtnXIndex; num < this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count; num++)
			{
				if (this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList[num].IsActive())
				{
					this.m_CurrentCtrlBtnXIndex = num;
					break;
				}
			}
		}
		else
		{
			for (int num2 = this.m_CurrentCtrlBtnXIndex; num2 >= 0; num2--)
			{
				if (this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList[num2].IsActive())
				{
					this.m_CurrentCtrlBtnXIndex = num2;
					break;
				}
			}
		}
		ctrlBtnXChangeMethod = this.GetCtrlBtnXChangeMethod(this.m_CurrentCtrlBtnYIndex);
		if (ctrlBtnXChangeMethod == ECtrlBtnXChangeMethod.RememberIndexX)
		{
			this.m_CurrentCtrlBtnXIndex = this.m_LastChangeMethodCtrlBtnXIndex;
		}
		else if (ctrlBtnXChangeMethod == ECtrlBtnXChangeMethod.AlwaysZeroifGoDown && addY > 0)
		{
			this.m_CurrentCtrlBtnXIndex = 0;
		}
		else if (ctrlBtnXChangeMethod == ECtrlBtnXChangeMethod.AlwaysGoIndexYOne)
		{
			this.m_CurrentCtrlBtnYIndex = 1;
		}
		if (ignoreUpdateControllerBtn)
		{
			return;
		}
		if (this.m_CurrentControllerButton)
		{
			this.m_CurrentControllerButton.OnSelectionDeactivate();
		}
		this.m_CurrentControllerButton = this.GetControllerButton(this.m_CurrentCtrlBtnXIndex, this.m_CurrentCtrlBtnYIndex);
		this.m_CurrentControllerButton.OnSelectionActive();
		if (this.m_SliderScreen && this.m_CurrentControllerButton.m_CanScrollerSlide)
		{
			this.m_SliderScreen.ScrollToUI(this.m_CurrentControllerButton.gameObject, false, this.m_SliderOffsetY);
		}
	}

	// Token: 0x060007F1 RID: 2033 RVA: 0x0003C27D File Offset: 0x0003A47D
	public void EvaluateCtrlBtnActiveChanged()
	{
		this.UpdateControllerBtnIndex_Y(-1, false);
	}

	// Token: 0x060007F2 RID: 2034 RVA: 0x0003C287 File Offset: 0x0003A487
	public void OnPressLeft()
	{
		if (CSingleton<ControllerScreenUIExtManager>.Instance.m_LockLJoystickHorizontal)
		{
			return;
		}
		SoundManager.GenericPop(0.5f, 1f);
		this.UpdateControllerBtnIndex_X(-1);
	}

	// Token: 0x060007F3 RID: 2035 RVA: 0x0003C2AC File Offset: 0x0003A4AC
	public void OnPressRight()
	{
		if (CSingleton<ControllerScreenUIExtManager>.Instance.m_LockLJoystickHorizontal)
		{
			return;
		}
		SoundManager.GenericPop(0.5f, 1f);
		this.UpdateControllerBtnIndex_X(1);
	}

	// Token: 0x060007F4 RID: 2036 RVA: 0x0003C2D1 File Offset: 0x0003A4D1
	public void OnPressUp()
	{
		if (CSingleton<ControllerScreenUIExtManager>.Instance.m_LockLJoystickVertical)
		{
			return;
		}
		SoundManager.GenericPop(0.5f, 1f);
		this.UpdateControllerBtnIndex_Y(-1, false);
	}

	// Token: 0x060007F5 RID: 2037 RVA: 0x0003C2F7 File Offset: 0x0003A4F7
	public void OnPressDown()
	{
		if (CSingleton<ControllerScreenUIExtManager>.Instance.m_LockLJoystickVertical)
		{
			return;
		}
		SoundManager.GenericPop(0.5f, 1f);
		this.UpdateControllerBtnIndex_Y(1, false);
	}

	// Token: 0x060007F6 RID: 2038 RVA: 0x0003C31D File Offset: 0x0003A51D
	public void OnPressConfirm()
	{
		SoundManager.GenericConfirm(0.5f, 1f);
		this.m_CurrentControllerButton.OnPressConfirm();
	}

	// Token: 0x060007F7 RID: 2039 RVA: 0x0003C339 File Offset: 0x0003A539
	public void OnPressCancel()
	{
		if (!this.m_CloseScreenBtn)
		{
			return;
		}
		SoundManager.GenericCancel(0.5f, 1f);
		if (!this.m_CurrentControllerButton.OnPressCancel())
		{
			this.m_CloseScreenBtn.onClick.Invoke();
		}
	}

	// Token: 0x060007F8 RID: 2040 RVA: 0x0003C375 File Offset: 0x0003A575
	private ECtrlBtnXChangeMethod GetCtrlBtnXChangeMethod(int columnIndex)
	{
		if (columnIndex >= this.m_CtrlBtnXChangeMethodList.Count)
		{
			return ECtrlBtnXChangeMethod.Normal;
		}
		return this.m_CtrlBtnXChangeMethodList[columnIndex];
	}

	// Token: 0x04000F2F RID: 3887
	public List<ControllerBtnList> m_ControllerBtnColumnList;

	// Token: 0x04000F30 RID: 3888
	public List<ECtrlBtnXChangeMethod> m_CtrlBtnXChangeMethodList;

	// Token: 0x04000F31 RID: 3889
	public Button m_CloseScreenBtn;

	// Token: 0x04000F32 RID: 3890
	public ControllerButton m_StartControllerButton;

	// Token: 0x04000F33 RID: 3891
	public bool m_LoopWithinRowOnly;

	// Token: 0x04000F34 RID: 3892
	public bool m_CanLoopY = true;

	// Token: 0x04000F35 RID: 3893
	public bool m_CanRapidFireConfirmBtn;

	// Token: 0x04000F36 RID: 3894
	public bool m_SettingScreenLoopSpecial;

	// Token: 0x04000F37 RID: 3895
	public int m_IndexYWhenLoopXEnd;

	// Token: 0x04000F38 RID: 3896
	public GenericSliderScreen m_SliderScreen;

	// Token: 0x04000F39 RID: 3897
	public float m_SliderOffsetY;

	// Token: 0x04000F3A RID: 3898
	public ControllerButton m_CurrentControllerButton;

	// Token: 0x04000F3B RID: 3899
	public int m_CurrentCtrlBtnXIndex;

	// Token: 0x04000F3C RID: 3900
	public int m_CurrentCtrlBtnYIndex;

	// Token: 0x04000F3D RID: 3901
	public int m_LastChangeMethodCtrlBtnXIndex;

	// Token: 0x04000F3E RID: 3902
	private bool m_IsHoldingConfirmBtn;

	// Token: 0x04000F3F RID: 3903
	private bool m_IsHoldingLeftJoystickRight;

	// Token: 0x04000F40 RID: 3904
	private bool m_IsHoldingLeftJoystickLeft;

	// Token: 0x04000F41 RID: 3905
	private bool m_IsHoldingLeftJoystickUp;

	// Token: 0x04000F42 RID: 3906
	private bool m_IsHoldingLeftJoystickDown;

	// Token: 0x04000F43 RID: 3907
	private bool m_IsJoystickRapidFire;

	// Token: 0x04000F44 RID: 3908
	private float m_JoystickRapidFireStartTimer;

	// Token: 0x04000F45 RID: 3909
	private float m_JoystickRapidFireStartTime = 0.5f;

	// Token: 0x04000F46 RID: 3910
	private float m_JoystickRapidFireTimer;

	// Token: 0x04000F47 RID: 3911
	private float m_JoystickRapidFireTime = 0.08f;
}
