﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000034 RID: 52
[Serializable]
public class MarketPrice
{
	// Token: 0x060002A9 RID: 681 RVA: 0x0001A10E File Offset: 0x0001830E
	public float GetMarketPrice()
	{
		return (float)Mathf.RoundToInt(this.generatedMarketPrice * (1f + this.pricePercentChangeList / 100f) * 100f) / 100f;
	}

	// Token: 0x060002AA RID: 682 RVA: 0x0001A13B File Offset: 0x0001833B
	public float GetMarketPriceCustomPercent(float percent)
	{
		return (float)Mathf.RoundToInt(this.generatedMarketPrice * (1f + percent / 100f) * 100f) / 100f;
	}

	// Token: 0x04000320 RID: 800
	public float generatedMarketPrice;

	// Token: 0x04000321 RID: 801
	public float pricePercentChangeList;

	// Token: 0x04000322 RID: 802
	public List<float> pastPricePercentChangeList;
}
