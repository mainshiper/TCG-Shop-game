﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;

// Token: 0x0200003A RID: 58
public class LightManager : CSingleton<LightManager>
{
	// Token: 0x060002DD RID: 733 RVA: 0x0001B148 File Offset: 0x00019348
	private void Awake()
	{
		for (int i = 0; i < this.m_SunlightList.Count; i++)
		{
			this.m_OriginalSunlightGrpLightIntensityList.Add(this.m_SunlightList[i].intensity);
		}
		for (int j = 0; j < this.m_ItemLightList.Count; j++)
		{
			this.m_OriginalItemLightIntensityList.Add(this.m_ItemLightList[j].intensity);
		}
		for (int k = 0; k < this.m_AmbientLightList.Count; k++)
		{
			this.m_OriginalAmbientLightIntensityList.Add(this.m_AmbientLightList[k].intensity);
		}
		if (this.m_LoadMaterialOriginalColor)
		{
			for (int l = 0; l < this.m_ItemMatList.Count; l++)
			{
				if (this.m_ItemMatList[l])
				{
					this.m_ItemMatOriginalColorList.Add(this.m_ItemMatList[l].GetColor("_Color"));
				}
				else
				{
					this.m_ItemMatOriginalColorList.Add(Color.white);
				}
			}
		}
		this.m_BillboardTextOriginalColor = this.m_BillboardText.color;
		this.m_LightTimeData = new LightTimeData();
	}

	// Token: 0x060002DE RID: 734 RVA: 0x0001B26C File Offset: 0x0001946C
	private void Init()
	{
		if (this.m_FinishLoading)
		{
			return;
		}
		this.m_FinishLoading = true;
		if (CPlayerData.m_LightTimeData == null)
		{
			this.ResetSunlightIntensity();
			this.UpdateLightTimeData();
			CPlayerData.m_LightTimeData = this.m_LightTimeData;
			return;
		}
		this.m_LightTimeData = CPlayerData.m_LightTimeData;
		this.m_IsLerpingSunIntensity = this.m_LightTimeData.m_IsLerpingSunIntensity;
		this.m_IsBlendingSkybox = this.m_LightTimeData.m_IsBlendingSkybox;
		this.m_IsStopBlendingSkybox = this.m_LightTimeData.m_IsStopBlendingSkybox;
		this.m_HasDayEnded = this.m_LightTimeData.m_HasDayEnded;
		this.m_TImeOfDayIndex = this.m_LightTimeData.m_TImeOfDayIndex;
		this.m_SkyboxIndex = this.m_LightTimeData.m_SkyboxIndex;
		this.m_TimeHour = this.m_LightTimeData.m_TimeHour;
		this.m_TimeMin = this.m_LightTimeData.m_TimeMin;
		this.m_TimeMinFloat = this.m_LightTimeData.m_TimeMinFloat;
		this.m_Timer = this.m_LightTimeData.m_Timer;
		this.m_SunlightLerpTimer = this.m_LightTimeData.m_SunlightLerpTimer;
		this.m_SunlightRotationLerpTimer = this.m_LightTimeData.m_SunlightRotationLerpTimer;
		this.m_GlobalBrightness = this.m_LightTimeData.m_GlobalBrightness;
		this.m_LerpStartBrightness = this.m_LightTimeData.m_LerpStartBrightness;
		this.m_NightlightGrp.SetActive(this.m_LightTimeData.m_IsNightLightOn);
		this.m_ShoplightGrp.SetActive(this.m_LightTimeData.m_IsShopLightOn);
		this.m_SunlightGrp.SetActive(this.m_LightTimeData.m_IsSunlightOn);
		this.m_Sunlight.rotation = Quaternion.Lerp(this.m_SunlightLerpStartPos.rotation, this.m_SunlightLerpEndPos.rotation, this.m_SunlightRotationLerpTimer);
		this.m_ShopLightOnTimer = this.m_LightTimeData.m_ShopLightOnTimer;
		if (this.m_HasDayEnded)
		{
			CEventManager.QueueEvent(new CEventPlayer_OnDayEnded());
		}
		if (this.m_TImeOfDayIndex >= 2)
		{
			SoundManager.BlendToMusic("BGM_ShopNight", 1f, true);
		}
		else
		{
			SoundManager.BlendToMusic("BGM_ShopDay", 1f, true);
		}
		if (!this.m_IsLerpingSunIntensity)
		{
			for (int i = 0; i < this.m_AmbientLightList.Count; i++)
			{
				this.m_AmbientLightList[i].intensity = this.m_GlobalBrightness;
			}
			if (this.m_TImeOfDayIndex >= 3)
			{
				for (int j = 0; j < this.m_SunlightList.Count; j++)
				{
					float num = this.m_OriginalSunlightGrpLightIntensityList[j] * this.m_TargetSunlightIntensityPercentList[0];
					float b = num * this.m_TargetSunlightIntensityPercentList[1];
					this.m_SunlightList[j].intensity = Mathf.Lerp(num, b, 1f);
				}
				if (this.m_BlendoutSunShadow)
				{
					this.m_SunlightList[0].shadowStrength = 0f;
					this.m_SunlightList[0].shadows = LightShadows.None;
				}
			}
			else if (this.m_TImeOfDayIndex == 2)
			{
				for (int k = 0; k < this.m_SunlightList.Count; k++)
				{
					float num2 = this.m_OriginalSunlightGrpLightIntensityList[k];
					float b2 = num2 * this.m_TargetSunlightIntensityPercentList[0];
					this.m_SunlightList[k].intensity = Mathf.Lerp(num2, b2, 1f);
				}
				if (this.m_BlendoutSunShadow)
				{
					this.m_SunlightList[0].shadowStrength = 0f;
					this.m_SunlightList[0].shadows = LightShadows.None;
				}
			}
		}
		base.StartCoroutine(this.DelayUpdateSkyBox());
		this.EvaluateTimeClock();
		this.EvaluateWorldUIBrightness();
		CPlayerData.m_LightTimeData = this.m_LightTimeData;
	}

	// Token: 0x060002DF RID: 735 RVA: 0x0001B5EF File Offset: 0x000197EF
	private IEnumerator DelayUpdateSkyBox()
	{
		this.m_IsLoadingSkyboxBlend = true;
		if (this.m_IsBlendingSkybox)
		{
			this.m_SkyboxBlender.Blend(this.m_SkyboxIndex, true);
			this.m_SkyboxBlender.blendValue = 1f;
			yield return new WaitForSeconds(0.01f);
			this.m_SkyboxBlender.blendValue = this.m_LightTimeData.m_SkyboxBlendValue;
			this.m_SkyboxBlender.blendSpeed = this.m_LightTimeData.m_SkyboxBlendSpeed;
			this.m_SkyboxBlender.Blend(this.m_SkyboxIndex + 1, true);
		}
		else
		{
			this.m_SkyboxBlender.Blend(this.m_SkyboxIndex, true);
			this.m_SkyboxBlender.blendValue = 1f;
			yield return new WaitForSeconds(0.01f);
			this.m_SkyboxBlender.blendValue = this.m_LightTimeData.m_SkyboxBlendValue;
			this.m_SkyboxBlender.blendSpeed = this.m_LightTimeData.m_SkyboxBlendSpeed;
		}
		this.m_IsLoadingSkyboxBlend = false;
		DynamicGI.UpdateEnvironment();
		yield break;
	}

	// Token: 0x060002E0 RID: 736 RVA: 0x0001B600 File Offset: 0x00019800
	private void UpdateLightTimeData()
	{
		this.m_LightTimeData.m_IsLerpingSunIntensity = this.m_IsLerpingSunIntensity;
		this.m_LightTimeData.m_IsBlendingSkybox = this.m_IsBlendingSkybox;
		this.m_LightTimeData.m_IsStopBlendingSkybox = this.m_IsStopBlendingSkybox;
		this.m_LightTimeData.m_HasDayEnded = this.m_HasDayEnded;
		this.m_LightTimeData.m_TImeOfDayIndex = this.m_TImeOfDayIndex;
		this.m_LightTimeData.m_SkyboxIndex = this.m_SkyboxIndex;
		this.m_LightTimeData.m_TimeHour = this.m_TimeHour;
		this.m_LightTimeData.m_TimeMin = this.m_TimeMin;
		this.m_LightTimeData.m_TimeMinFloat = this.m_TimeMinFloat;
		this.m_LightTimeData.m_Timer = this.m_Timer;
		this.m_LightTimeData.m_SunlightLerpTimer = this.m_SunlightLerpTimer;
		this.m_LightTimeData.m_SunlightRotationLerpTimer = this.m_SunlightRotationLerpTimer;
		this.m_LightTimeData.m_GlobalBrightness = this.m_GlobalBrightness;
		this.m_LightTimeData.m_LerpStartBrightness = this.m_LerpStartBrightness;
		this.m_LightTimeData.m_IsNightLightOn = this.m_NightlightGrp.activeSelf;
		this.m_LightTimeData.m_IsShopLightOn = this.m_ShoplightGrp.activeSelf;
		this.m_LightTimeData.m_IsSunlightOn = this.m_SunlightGrp.activeSelf;
		this.m_LightTimeData.m_ShopLightOnTimer = this.m_ShopLightOnTimer;
		if (!this.m_IsLoadingSkyboxBlend)
		{
			this.m_LightTimeData.m_SkyboxBlendValue = this.m_SkyboxBlender.blendValue;
			this.m_LightTimeData.m_SkyboxBlendSpeed = this.m_SkyboxBlender.blendSpeed;
		}
		CPlayerData.m_LightTimeData = this.m_LightTimeData;
	}

	// Token: 0x060002E1 RID: 737 RVA: 0x0001B790 File Offset: 0x00019990
	private void Update()
	{
		if (!this.m_FinishLoading)
		{
			return;
		}
		this.UpdateLightTimeData();
		if (this.m_IsShopLightOn)
		{
			this.m_ShopLightOnTimer += Time.deltaTime;
		}
		if (!CPlayerData.m_IsShopOnceOpen)
		{
			return;
		}
		if (!this.m_HasDayEnded)
		{
			this.m_TimeMinFloat += Time.deltaTime * this.m_TimerLerpSpeed;
			this.m_TimeMin = Mathf.FloorToInt(this.m_TimeMinFloat);
			this.EvaluateTimeClock();
			this.EvaluateLerpSunIntensity();
			this.m_SunlightRotationLerpTimer += Time.deltaTime * 0.0013888889f * this.m_TimerLerpSpeed;
			this.m_Sunlight.rotation = Quaternion.Lerp(this.m_SunlightLerpStartPos.rotation, this.m_SunlightLerpEndPos.rotation, this.m_SunlightRotationLerpTimer);
			this.m_SkyboxBlender.rotationSpeed = this.m_SkyboxRotateSpeed * this.m_TimerLerpSpeed;
			if (!this.m_IsBlendingSkybox && !this.m_IsStopBlendingSkybox)
			{
				this.m_Timer += Time.deltaTime * this.m_TimerLerpSpeed;
				if (this.m_Timer > this.m_TimeTillNextSkybox[this.m_SkyboxIndex])
				{
					this.m_Timer = 0f;
					this.m_IsBlendingSkybox = true;
					this.m_SkyboxBlender.blendSpeed = 1f / this.m_SkyboxBlendDuration[this.m_SkyboxIndex] * this.m_TimerLerpSpeed;
					this.m_SkyboxBlender.Blend(this.m_SkyboxIndex + 1, true);
					return;
				}
			}
			else if (this.m_IsBlendingSkybox && !this.m_IsStopBlendingSkybox)
			{
				this.m_Timer += Time.deltaTime * this.m_TimerLerpSpeed;
				if (this.m_Timer >= this.m_SkyboxBlendDuration[this.m_SkyboxIndex])
				{
					this.m_Timer = 0f;
					this.m_SkyboxIndex++;
					this.m_IsBlendingSkybox = false;
					if (this.m_SkyboxIndex >= 2)
					{
						this.m_IsStopBlendingSkybox = true;
						this.m_SkyboxBlender.Stop(true);
					}
				}
			}
		}
	}

	// Token: 0x060002E2 RID: 738 RVA: 0x0001B98B File Offset: 0x00019B8B
	public static void GoNextDay()
	{
		CPlayerData.m_CurrentDay++;
		CSingleton<LightManager>.Instance.ResetSunlightIntensity();
	}

	// Token: 0x060002E3 RID: 739 RVA: 0x0001B9A4 File Offset: 0x00019BA4
	private void ResetSunlightIntensity()
	{
		for (int i = 0; i < this.m_SunlightList.Count; i++)
		{
			this.m_SunlightList[i].intensity = this.m_OriginalSunlightGrpLightIntensityList[i];
		}
		for (int j = 0; j < this.m_ItemLightList.Count; j++)
		{
			this.m_ItemLightList[j].intensity = this.m_OriginalItemLightIntensityList[j];
		}
		for (int k = 0; k < this.m_AmbientLightList.Count; k++)
		{
			this.m_AmbientLightList[k].intensity = this.m_OriginalAmbientLightIntensityList[k];
		}
		this.m_SunlightList[0].shadowStrength = 1f;
		this.m_SunlightList[0].shadows = LightShadows.Soft;
		this.m_IsLerpingSunIntensity = false;
		this.m_IsBlendingSkybox = false;
		this.m_IsStopBlendingSkybox = false;
		this.m_SkyboxIndex = 0;
		this.m_Timer = 0f;
		this.m_SunlightLerpTimer = 0f;
		this.m_SunlightRotationLerpTimer = 0f;
		this.m_Sunlight.rotation = Quaternion.Lerp(this.m_SunlightLerpStartPos.rotation, this.m_SunlightLerpEndPos.rotation, 0f);
		this.m_SkyboxBlender.Blend(0, true);
		this.m_SkyboxBlender.blendValue = 1f;
		this.m_SunlightRotationLerpTimer = 0f;
		this.m_IsShopLightOn = false;
		this.m_IsSunLightOn = true;
		this.m_SunlightGrp.SetActive(true);
		this.m_ShoplightGrp.SetActive(false);
		this.m_NightlightGrp.SetActive(false);
		this.EvaluateWorldUIBrightness();
		base.StartCoroutine(this.DelayUpdateEnv());
	}

	// Token: 0x060002E4 RID: 740 RVA: 0x0001BB47 File Offset: 0x00019D47
	private IEnumerator DelayUpdateEnv()
	{
		yield return new WaitForSeconds(0.01f);
		this.m_SkyboxBlender.Blend(0, true);
		this.m_SkyboxBlender.blendValue = 1f;
		yield return new WaitForSeconds(0.01f);
		DynamicGI.UpdateEnvironment();
		this.m_SkyboxBlender.blendValue = 0f;
		this.m_HasDayEnded = false;
		this.m_TimeHour = 8;
		this.m_TimeMin = 0;
		this.m_TimeMinFloat = 0f;
		this.EvaluateTimeClock();
		CEventManager.QueueEvent(new CEventPlayer_OnDayStarted());
		SoundManager.BlendToMusic("BGM_ShopDay", 1f, true);
		yield break;
	}

	// Token: 0x060002E5 RID: 741 RVA: 0x0001BB58 File Offset: 0x00019D58
	private void EvaluateLerpSunIntensity()
	{
		if (this.m_IsLerpingSunIntensity)
		{
			if (this.m_TImeOfDayIndex >= 3)
			{
				this.m_SunlightLerpTimer += Time.deltaTime * (1f / this.m_SkyboxBlendDuration[1]) * this.m_TimerLerpSpeed;
				for (int i = 0; i < this.m_SunlightList.Count; i++)
				{
					float num = this.m_OriginalSunlightGrpLightIntensityList[i] * this.m_TargetSunlightIntensityPercentList[0];
					float b = num * this.m_TargetSunlightIntensityPercentList[1];
					this.m_SunlightList[i].intensity = Mathf.Lerp(num, b, this.m_SunlightLerpTimer);
				}
				this.m_WorldUIEvaluateTimer += Time.deltaTime;
				if (this.m_WorldUIEvaluateTimer > 0.1f)
				{
					this.EvaluateWorldUIBrightness();
					this.m_WorldUIEvaluateTimer = 0f;
				}
				if (this.m_SunlightLerpTimer >= 1f)
				{
					this.m_SunlightLerpTimer = 0f;
					this.m_SunlightGrp.SetActive(false);
					this.m_NightlightGrp.gameObject.SetActive(true);
					this.m_IsLerpingSunIntensity = false;
					return;
				}
			}
			else if (this.m_TImeOfDayIndex == 2)
			{
				this.m_SunlightLerpTimer += Time.deltaTime * (1f / this.m_SkyboxBlendDuration[0]) * this.m_TimerLerpSpeed;
				for (int j = 0; j < this.m_SunlightList.Count; j++)
				{
					float num2 = this.m_OriginalSunlightGrpLightIntensityList[j];
					float b2 = num2 * this.m_TargetSunlightIntensityPercentList[0];
					this.m_SunlightList[j].intensity = Mathf.Lerp(num2, b2, this.m_SunlightLerpTimer);
				}
				if (this.m_BlendoutSunShadow)
				{
					this.m_SunlightList[0].shadowStrength = Mathf.Lerp(1f, 0f, this.m_SunlightLerpTimer * 1.25f);
					if (this.m_SunlightList[0].shadowStrength <= 0f)
					{
						this.m_SunlightList[0].shadows = LightShadows.None;
					}
				}
				this.m_WorldUIEvaluateTimer += Time.deltaTime;
				if (this.m_WorldUIEvaluateTimer > 0.1f)
				{
					this.EvaluateWorldUIBrightness();
					this.m_WorldUIEvaluateTimer = 0f;
				}
				if (this.m_SunlightLerpTimer >= 1f)
				{
					this.m_SunlightLerpTimer = 0f;
					this.m_IsLerpingSunIntensity = false;
				}
			}
		}
	}

	// Token: 0x060002E6 RID: 742 RVA: 0x0001BDB0 File Offset: 0x00019FB0
	private void EvaluateTimeClock()
	{
		if (this.m_TimeMin >= 60)
		{
			this.m_TimeMinFloat = 0f;
			this.m_TimeMin = 0;
			this.m_TimeHour++;
		}
		if (this.m_TimeHour >= 21 && this.m_TimeMin >= 0)
		{
			this.m_TimeHour = 21;
			this.m_TimeMin = 0;
		}
		string str = "AM";
		if (this.m_TimeHour >= 12)
		{
			str = "PM";
		}
		string str2 = this.m_TimeMin.ToString();
		if (this.m_TimeMin < 10)
		{
			str2 = "0" + this.m_TimeMin.ToString();
		}
		int num = this.m_TimeHour;
		if (this.m_TimeHour > 12)
		{
			num = this.m_TimeHour - 12;
		}
		string str3 = num.ToString();
		if (num < 10)
		{
			str3 = "0" + num.ToString();
		}
		this.m_TimeString = str3 + ":" + str2 + str;
		if (this.m_TimeHour == 18 && this.m_TimeMin == 30)
		{
			this.m_TimeOfDayString = "Night";
			this.m_TImeOfDayIndex = 3;
			this.m_IsLerpingSunIntensity = true;
			this.m_LerpStartBrightness = this.m_GlobalBrightness;
			return;
		}
		if (this.m_TimeHour == 16 && this.m_TimeMin == 0)
		{
			this.m_TimeOfDayString = "Evening";
			this.m_TImeOfDayIndex = 2;
			this.m_IsLerpingSunIntensity = true;
			this.m_LerpStartBrightness = this.m_GlobalBrightness;
			SoundManager.BlendToMusic("BGM_ShopNight", 0.1f, true);
			return;
		}
		if (this.m_TimeHour == 12 && this.m_TimeMin == 0)
		{
			this.m_TimeOfDayString = "Afternoon";
			this.m_TImeOfDayIndex = 1;
			this.m_IsLerpingSunIntensity = false;
			return;
		}
		if (this.m_TimeHour == 8 && this.m_TimeMin == 0)
		{
			this.m_TimeOfDayString = "Morning";
			this.m_TImeOfDayIndex = 0;
			this.m_IsLerpingSunIntensity = false;
			this.m_HasDayEnded = false;
			return;
		}
		if (this.m_TimeHour == 21 && this.m_TimeMin == 0)
		{
			this.m_TimeOfDayString = "Day End";
			this.m_HasDayEnded = true;
			this.m_TImeOfDayIndex = 4;
			this.m_IsLerpingSunIntensity = false;
			this.m_SkyboxBlender.rotationSpeed = 0f;
			CEventManager.QueueEvent(new CEventPlayer_OnDayEnded());
		}
	}

	// Token: 0x060002E7 RID: 743 RVA: 0x0001BFC4 File Offset: 0x0001A1C4
	public float GetPercentTillDayEnd()
	{
		float num = 780f;
		return (float)((this.m_TimeHour - 8) * 60 + this.m_TimeMin) / num;
	}

	// Token: 0x060002E8 RID: 744 RVA: 0x0001BFEC File Offset: 0x0001A1EC
	private void EvaluateWorldUIBrightness()
	{
		this.m_IsShopLightOn = this.m_ShoplightGrp.activeSelf;
		this.m_IsSunLightOn = this.m_SunlightGrp.activeSelf;
		if (this.m_IsSunLightOn)
		{
			if (this.m_TImeOfDayIndex == 3)
			{
				if (this.m_IsLerpingSunIntensity)
				{
					this.m_GlobalBrightness = Mathf.Lerp(this.m_LerpStartBrightness, 0.05f, this.m_SunlightLerpTimer);
				}
				else
				{
					this.m_GlobalBrightness = 0.05f;
				}
			}
			else if (this.m_TImeOfDayIndex == 2)
			{
				if (this.m_IsLerpingSunIntensity)
				{
					this.m_GlobalBrightness = Mathf.Lerp(this.m_LerpStartBrightness, 0.55f, this.m_SunlightLerpTimer);
				}
				else
				{
					this.m_GlobalBrightness = 0.55f;
				}
			}
			else
			{
				this.m_GlobalBrightness = 0.95f;
			}
		}
		else
		{
			this.m_GlobalBrightness = 0.05f;
		}
		if (this.m_IsShopLightOn)
		{
			this.m_GlobalBrightness += 0.9f;
		}
		this.m_GlobalBrightness = Mathf.Clamp(this.m_GlobalBrightness, 0f, 1f);
		for (int i = 0; i < this.m_ItemLightList.Count; i++)
		{
			this.m_ItemLightList[i].intensity = this.m_GlobalBrightness * this.m_OriginalItemLightIntensityList[i];
		}
		for (int j = 0; j < this.m_AmbientLightList.Count; j++)
		{
			this.m_AmbientLightList[j].intensity = this.m_GlobalBrightness * this.m_OriginalAmbientLightIntensityList[j];
		}
		PriceTagUISpawner.SetAllPriceTagUIBrightness(this.m_GlobalBrightness);
		Card3dUISpawner.SetAllCardUIBrightness(this.m_GlobalBrightness);
		this.m_BillboardTargetLerpColor = this.m_BillboardTextOriginalColor * this.m_GlobalBrightness;
		this.m_BillboardTargetLerpColor.a = 1f;
		this.m_BillboardText.color = this.m_BillboardTargetLerpColor;
		this.m_CardBackMat.SetColor("_EmissionColor", this.m_CardBackMatOriginalEmissionColor * Mathf.Lerp(0.2f, 1f, this.m_GlobalBrightness));
		for (int k = 0; k < this.m_ItemMatList.Count; k++)
		{
			if (this.m_ItemMatList[k])
			{
				this.m_ItemMatList[k].SetColor("_Color", this.m_ItemMatOriginalColorList[k] * Mathf.Lerp(0.2f, 1f, this.m_GlobalBrightness));
			}
		}
	}

	// Token: 0x060002E9 RID: 745 RVA: 0x0001C242 File Offset: 0x0001A442
	public void ToggleShopLight()
	{
		this.m_ShoplightGrp.SetActive(!this.m_ShoplightGrp.activeSelf);
		this.EvaluateWorldUIBrightness();
	}

	// Token: 0x060002EA RID: 746 RVA: 0x0001C263 File Offset: 0x0001A463
	public float GetBrightness()
	{
		return this.m_GlobalBrightness;
	}

	// Token: 0x060002EB RID: 747 RVA: 0x0001C26B File Offset: 0x0001A46B
	public static bool GetHasDayEnded()
	{
		return CSingleton<LightManager>.Instance.m_HasDayEnded;
	}

	// Token: 0x060002EC RID: 748 RVA: 0x0001C278 File Offset: 0x0001A478
	public override void OnApplicationQuit()
	{
		if (this.m_LoadMaterialOriginalColor)
		{
			for (int i = 0; i < this.m_ItemMatList.Count; i++)
			{
				if (this.m_ItemMatList[i])
				{
					this.m_ItemMatList[i].SetColor("_Color", this.m_ItemMatOriginalColorList[i]);
				}
			}
		}
	}

	// Token: 0x060002ED RID: 749 RVA: 0x0001C2D8 File Offset: 0x0001A4D8
	public static bool IsMorning()
	{
		return CSingleton<LightManager>.Instance.m_TImeOfDayIndex == 0;
	}

	// Token: 0x060002EE RID: 750 RVA: 0x0001C2E7 File Offset: 0x0001A4E7
	public static bool IsAfternoon()
	{
		return CSingleton<LightManager>.Instance.m_TImeOfDayIndex == 1;
	}

	// Token: 0x060002EF RID: 751 RVA: 0x0001C2F6 File Offset: 0x0001A4F6
	public static bool IsEvening()
	{
		return CSingleton<LightManager>.Instance.m_TImeOfDayIndex == 2;
	}

	// Token: 0x060002F0 RID: 752 RVA: 0x0001C305 File Offset: 0x0001A505
	public static bool IsNight()
	{
		return CSingleton<LightManager>.Instance.m_TImeOfDayIndex == 3;
	}

	// Token: 0x060002F1 RID: 753 RVA: 0x0001C314 File Offset: 0x0001A514
	public static float GetShopLightOnTime()
	{
		return CSingleton<LightManager>.Instance.m_ShopLightOnTimer;
	}

	// Token: 0x060002F2 RID: 754 RVA: 0x0001C320 File Offset: 0x0001A520
	public static void ResetShopLightOnTime()
	{
		CSingleton<LightManager>.Instance.m_ShopLightOnTimer = 0f;
	}

	// Token: 0x060002F3 RID: 755 RVA: 0x0001C331 File Offset: 0x0001A531
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.AddListener<CEventPlayer_OnSettingUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnSettingUpdated>(this.OnSettingUpdated));
		}
	}

	// Token: 0x060002F4 RID: 756 RVA: 0x0001C363 File Offset: 0x0001A563
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.RemoveListener<CEventPlayer_OnSettingUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnSettingUpdated>(this.OnSettingUpdated));
		}
	}

	// Token: 0x060002F5 RID: 757 RVA: 0x0001C395 File Offset: 0x0001A595
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.Init();
		this.EvaluateQualitySetting();
	}

	// Token: 0x060002F6 RID: 758 RVA: 0x0001C3A3 File Offset: 0x0001A5A3
	protected void OnSettingUpdated(CEventPlayer_OnSettingUpdated evt)
	{
		this.EvaluateQualitySetting();
	}

	// Token: 0x060002F7 RID: 759 RVA: 0x0001C3AC File Offset: 0x0001A5AC
	private void EvaluateQualitySetting()
	{
		if (this.m_CurrentQualitySettingIndex != CSingleton<CGameManager>.Instance.m_QualitySettingIndex)
		{
			this.m_CurrentQualitySettingIndex = CSingleton<CGameManager>.Instance.m_QualitySettingIndex;
			if (this.m_CurrentQualitySettingIndex == 2)
			{
				this.m_PostProcessVolume.enabled = false;
				this.m_SunlightList[0].shadows = LightShadows.Hard;
				for (int i = 0; i < this.m_SoftShadowLightList.Count; i++)
				{
					this.m_SoftShadowLightList[i].shadows = LightShadows.None;
				}
				return;
			}
			if (this.m_CurrentQualitySettingIndex == 1)
			{
				this.m_PostProcessVolume.enabled = false;
				this.m_SunlightList[0].shadows = LightShadows.Soft;
				for (int j = 0; j < this.m_SoftShadowLightList.Count; j++)
				{
					this.m_SoftShadowLightList[j].shadows = LightShadows.None;
				}
				return;
			}
			this.m_PostProcessVolume.enabled = true;
			this.m_SunlightList[0].shadows = LightShadows.Soft;
			for (int k = 0; k < this.m_SoftShadowLightList.Count; k++)
			{
				this.m_SoftShadowLightList[k].shadows = LightShadows.Soft;
			}
		}
	}

	// Token: 0x04000364 RID: 868
	public bool m_LoadMaterialOriginalColor;

	// Token: 0x04000365 RID: 869
	public static LightManager m_Instance;

	// Token: 0x04000366 RID: 870
	public bool m_BlendoutSunShadow = true;

	// Token: 0x04000367 RID: 871
	public float m_TimerLerpSpeed = 1f;

	// Token: 0x04000368 RID: 872
	public float m_SkyboxRotateSpeed = 0.2f;

	// Token: 0x04000369 RID: 873
	public TextMeshProUGUI m_BillboardText;

	// Token: 0x0400036A RID: 874
	public GameObject m_SunlightGrp;

	// Token: 0x0400036B RID: 875
	public GameObject m_ShoplightGrp;

	// Token: 0x0400036C RID: 876
	public GameObject m_NightlightGrp;

	// Token: 0x0400036D RID: 877
	public ReflectionProbe m_ReflectionProbe;

	// Token: 0x0400036E RID: 878
	public PostProcessVolume m_PostProcessVolume;

	// Token: 0x0400036F RID: 879
	public SkyboxBlender m_SkyboxBlender;

	// Token: 0x04000370 RID: 880
	public Material m_CardBackMat;

	// Token: 0x04000371 RID: 881
	public Color m_CardBackMatOriginalEmissionColor;

	// Token: 0x04000372 RID: 882
	public List<Material> m_ItemMatList;

	// Token: 0x04000373 RID: 883
	public List<Color> m_ItemMatOriginalColorList;

	// Token: 0x04000374 RID: 884
	public List<float> m_TimeTillNextSkybox;

	// Token: 0x04000375 RID: 885
	public List<float> m_SkyboxBlendDuration;

	// Token: 0x04000376 RID: 886
	public Transform m_Sunlight;

	// Token: 0x04000377 RID: 887
	public Transform m_SunlightLerpStartPos;

	// Token: 0x04000378 RID: 888
	public Transform m_SunlightLerpEndPos;

	// Token: 0x04000379 RID: 889
	public List<Light> m_ItemLightList = new List<Light>();

	// Token: 0x0400037A RID: 890
	public List<Light> m_SunlightList = new List<Light>();

	// Token: 0x0400037B RID: 891
	public List<Light> m_AmbientLightList = new List<Light>();

	// Token: 0x0400037C RID: 892
	public List<float> m_TargetSunlightIntensityPercentList = new List<float>();

	// Token: 0x0400037D RID: 893
	public List<Light> m_SoftShadowLightList = new List<Light>();

	// Token: 0x0400037E RID: 894
	public string m_TimeString = "";

	// Token: 0x0400037F RID: 895
	public string m_TimeOfDayString = "";

	// Token: 0x04000380 RID: 896
	private bool m_FinishLoading;

	// Token: 0x04000381 RID: 897
	private bool m_IsLoadingSkyboxBlend;

	// Token: 0x04000382 RID: 898
	private bool m_IsLerpingSunIntensity;

	// Token: 0x04000383 RID: 899
	private bool m_IsBlendingSkybox;

	// Token: 0x04000384 RID: 900
	private bool m_IsStopBlendingSkybox;

	// Token: 0x04000385 RID: 901
	private bool m_HasDayEnded;

	// Token: 0x04000386 RID: 902
	private bool m_IsShopLightOn;

	// Token: 0x04000387 RID: 903
	private bool m_IsSunLightOn = true;

	// Token: 0x04000388 RID: 904
	private int m_TImeOfDayIndex;

	// Token: 0x04000389 RID: 905
	private int m_SkyboxIndex;

	// Token: 0x0400038A RID: 906
	private int m_TimeHour = 8;

	// Token: 0x0400038B RID: 907
	private int m_TimeMin;

	// Token: 0x0400038C RID: 908
	private int m_CurrentQualitySettingIndex;

	// Token: 0x0400038D RID: 909
	private float m_TimeMinFloat;

	// Token: 0x0400038E RID: 910
	private float m_Timer;

	// Token: 0x0400038F RID: 911
	private float m_SunlightLerpTimer;

	// Token: 0x04000390 RID: 912
	private float m_SunlightRotationLerpTimer;

	// Token: 0x04000391 RID: 913
	private float m_WorldUIEvaluateTimer;

	// Token: 0x04000392 RID: 914
	private float m_GlobalBrightness = 1f;

	// Token: 0x04000393 RID: 915
	private float m_LerpStartBrightness;

	// Token: 0x04000394 RID: 916
	private float m_ShopLightOnTimer;

	// Token: 0x04000395 RID: 917
	private Color m_BillboardTextOriginalColor;

	// Token: 0x04000396 RID: 918
	private Color m_BillboardTargetLerpColor;

	// Token: 0x04000397 RID: 919
	private List<float> m_OriginalSunlightGrpLightIntensityList = new List<float>();

	// Token: 0x04000398 RID: 920
	private List<float> m_OriginalShoplightGrpLightIntensityList = new List<float>();

	// Token: 0x04000399 RID: 921
	private List<float> m_OriginalItemLightIntensityList = new List<float>();

	// Token: 0x0400039A RID: 922
	private List<float> m_OriginalAmbientLightIntensityList = new List<float>();

	// Token: 0x0400039B RID: 923
	private LightTimeData m_LightTimeData;
}
