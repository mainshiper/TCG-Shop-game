﻿using System;
using System.Collections.Generic;
using I2.Loc;
using UnityEngine;

// Token: 0x020000A3 RID: 163
public class CPlayerData : CSingleton<CPlayerData>
{
	// Token: 0x0600065F RID: 1631 RVA: 0x00035455 File Offset: 0x00033655
	protected CPlayerData()
	{
	}

	// Token: 0x17000003 RID: 3
	// (get) Token: 0x06000660 RID: 1632 RVA: 0x0003545D File Offset: 0x0003365D
	// (set) Token: 0x06000661 RID: 1633 RVA: 0x00035464 File Offset: 0x00033664
	public static string PlayerName
	{
		get
		{
			return CPlayerData.m_PlayerName;
		}
		set
		{
			CPlayerData.m_PlayerName = value;
			CPlayerData.m_PlayerName == "";
		}
	}

	// Token: 0x06000662 RID: 1634 RVA: 0x0003547C File Offset: 0x0003367C
	public static string GetPlayerName()
	{
		if (CPlayerData.m_PlayerName == null)
		{
			return "";
		}
		return CPlayerData.m_PlayerName;
	}

	// Token: 0x06000663 RID: 1635 RVA: 0x00035490 File Offset: 0x00033690
	private void Awake()
	{
		CEventManager.AddListener<CEventPlayer_SetCoin>(new CEventManager.EventDelegate<CEventPlayer_SetCoin>(this.CPlayer_OnSetCoin));
		CPlayerData.CreateDefaultData(false);
	}

	// Token: 0x06000664 RID: 1636 RVA: 0x000354A9 File Offset: 0x000336A9
	public static void ResetData()
	{
		GameInstance.m_IsRestartingGameDeleteAll = true;
		CPlayerData.CreateDefaultData(false);
		CEventManager.QueueEvent(new CEventPlayer_ChangeScene(ELevelName.Start));
	}

	// Token: 0x06000665 RID: 1637 RVA: 0x000354C4 File Offset: 0x000336C4
	public static void CreateDefaultData(bool isRebornReset = false)
	{
		if (!isRebornReset)
		{
			CPlayerData.m_PlayerName = "";
			CPlayerData.m_CanCloudLoad = true;
			CPlayerData.m_CollectionSortingMethodIndexList.Clear();
		}
		CPlayerData.m_TutorialIndex = 0;
		CPlayerData.m_TutorialSubgroupIndex = 0;
		CPlayerData.m_TutorialDataList.Clear();
		CPlayerData.m_HasFinishedTutorial = false;
		CPlayerData.m_HasGetGhostCard = false;
		CPlayerData.m_CoinAmount = 1000f;
		CPlayerData.m_FamePoint = 0;
		CPlayerData.m_UnlockRoomCount = 0;
		CPlayerData.m_UnlockWarehouseRoomCount = 0;
		CPlayerData.m_IsWarehouseRoomUnlocked = false;
		CPlayerData.m_GameReportDataCollect.ResetData();
		CEventManager.QueueEvent(new CEventPlayer_SetCoin(CPlayerData.m_CoinAmount));
		CEventManager.QueueEvent(new CEventPlayer_SetFame(0));
		CPlayerData.m_SkyboxBlendValue = 0f;
		CPlayerData.m_LightTimeData = null;
		CPlayerData.m_GameEventFormat = EGameEventFormat.Standard;
		CPlayerData.m_PendingGameEventFormat = EGameEventFormat.None;
		CPlayerData.m_GameEventExpansionType = ECardExpansionType.Tetramon;
		CPlayerData.m_PendingGameEventExpansionType = ECardExpansionType.Tetramon;
		CPlayerData.m_LastLocalExitTime = DateTime.UtcNow;
		CPlayerData.m_TotalFameAdd = 0;
		CPlayerData.m_CurrentDay = 0;
		CPlayerData.m_ShopExpPoint = 0;
		CPlayerData.m_ShopLevel = 0;
		CPlayerData.m_IsShopOpen = false;
		CPlayerData.m_IsShopOnceOpen = false;
		CPlayerData.m_IsWarehouseDoorClosed = false;
		CPlayerData.m_IsItemPriceGenerated = false;
		CPlayerData.m_IsCardPriceGenerated = false;
		CPlayerData.m_GameReportDataCollectPermanent = default(GameReportDataCollect);
		CPlayerData.m_GameReportDataCollect = default(GameReportDataCollect);
		CPlayerData.m_GameReportDataCollectPastList.Clear();
		CPlayerData.m_ShelfSaveDataList.Clear();
		CPlayerData.m_WarehouseShelfSaveDataList.Clear();
		CPlayerData.m_PackageBoxItemSaveDataList.Clear();
		CPlayerData.m_InteractableObjectSaveDataList.Clear();
		CPlayerData.m_CardShelfSaveDataList.Clear();
		CPlayerData.m_PlayTableSaveDataList.Clear();
		CPlayerData.m_AutoCleanserSaveDataList.Clear();
		CPlayerData.m_WorkbenchSaveDataList.Clear();
		CPlayerData.m_CustomerSaveDataList.Clear();
		CPlayerData.m_WorkerSaveDataList.Clear();
		CPlayerData.m_BillList.Clear();
		CPlayerData.m_HoldCardDataList.Clear();
		CPlayerData.m_HoldItemTypeList.Clear();
		for (int i = 0; i < 6; i++)
		{
			CPlayerData.m_CollectionSortingMethodIndexList.Add(2);
		}
		CPlayerData.m_CardCollectedList.Clear();
		CPlayerData.m_CardCollectedListDestiny.Clear();
		CPlayerData.m_CardCollectedListGhost.Clear();
		CPlayerData.m_CardCollectedListGhostBlack.Clear();
		CPlayerData.m_CardCollectedListMegabot.Clear();
		CPlayerData.m_CardCollectedListFantasyRPG.Clear();
		CPlayerData.m_CardCollectedListCatJob.Clear();
		CPlayerData.m_IsCardCollectedList.Clear();
		CPlayerData.m_IsCardCollectedListDestiny.Clear();
		CPlayerData.m_IsCardCollectedListGhost.Clear();
		CPlayerData.m_IsCardCollectedListGhostBlack.Clear();
		CPlayerData.m_IsCardCollectedListMegabot.Clear();
		CPlayerData.m_IsCardCollectedListFantasyRPG.Clear();
		CPlayerData.m_IsCardCollectedListCatJob.Clear();
		CPlayerData.m_CardPriceSetList.Clear();
		CPlayerData.m_CardPriceSetListDestiny.Clear();
		CPlayerData.m_CardPriceSetListGhost.Clear();
		CPlayerData.m_CardPriceSetListGhostBlack.Clear();
		CPlayerData.m_CardPriceSetListMegabot.Clear();
		CPlayerData.m_CardPriceSetListFantasyRPG.Clear();
		CPlayerData.m_CardPriceSetListCatJob.Clear();
		CPlayerData.m_GenCardMarketPriceList.Clear();
		CPlayerData.m_GenCardMarketPriceListDestiny.Clear();
		CPlayerData.m_GenCardMarketPriceListGhost.Clear();
		CPlayerData.m_GenCardMarketPriceListGhostBlack.Clear();
		CPlayerData.m_GenCardMarketPriceListMegabot.Clear();
		CPlayerData.m_GenCardMarketPriceListFantasyRPG.Clear();
		CPlayerData.m_GenCardMarketPriceListCatJob.Clear();
		for (int j = 0; j < CPlayerData.GetCardCollectionDataCount() + 100; j++)
		{
			CPlayerData.m_CardCollectedList.Add(0);
			CPlayerData.m_CardCollectedListDestiny.Add(0);
			CPlayerData.m_CardCollectedListGhost.Add(0);
			CPlayerData.m_CardCollectedListGhostBlack.Add(0);
			CPlayerData.m_CardCollectedListMegabot.Add(0);
			CPlayerData.m_CardCollectedListFantasyRPG.Add(0);
			CPlayerData.m_CardCollectedListCatJob.Add(0);
			CPlayerData.m_IsCardCollectedList.Add(false);
			CPlayerData.m_IsCardCollectedListDestiny.Add(false);
			CPlayerData.m_IsCardCollectedListGhost.Add(false);
			CPlayerData.m_IsCardCollectedListGhostBlack.Add(false);
			CPlayerData.m_IsCardCollectedListMegabot.Add(false);
			CPlayerData.m_IsCardCollectedListFantasyRPG.Add(false);
			CPlayerData.m_IsCardCollectedListCatJob.Add(false);
			CPlayerData.m_CardPriceSetList.Add(0f);
			CPlayerData.m_CardPriceSetListDestiny.Add(0f);
			CPlayerData.m_CardPriceSetListGhost.Add(0f);
			CPlayerData.m_CardPriceSetListGhostBlack.Add(0f);
			CPlayerData.m_CardPriceSetListMegabot.Add(0f);
			CPlayerData.m_CardPriceSetListFantasyRPG.Add(0f);
			CPlayerData.m_CardPriceSetListCatJob.Add(0f);
			MarketPrice marketPrice = new MarketPrice();
			marketPrice.pastPricePercentChangeList = new List<float>();
			CPlayerData.m_GenCardMarketPriceList.Add(marketPrice);
			marketPrice = new MarketPrice();
			marketPrice.pastPricePercentChangeList = new List<float>();
			CPlayerData.m_GenCardMarketPriceListDestiny.Add(marketPrice);
			marketPrice = new MarketPrice();
			marketPrice.pastPricePercentChangeList = new List<float>();
			CPlayerData.m_GenCardMarketPriceListGhost.Add(marketPrice);
			marketPrice = new MarketPrice();
			marketPrice.pastPricePercentChangeList = new List<float>();
			CPlayerData.m_GenCardMarketPriceListGhostBlack.Add(marketPrice);
			marketPrice = new MarketPrice();
			marketPrice.pastPricePercentChangeList = new List<float>();
			CPlayerData.m_GenCardMarketPriceListMegabot.Add(marketPrice);
			marketPrice = new MarketPrice();
			marketPrice.pastPricePercentChangeList = new List<float>();
			CPlayerData.m_GenCardMarketPriceListFantasyRPG.Add(marketPrice);
			marketPrice = new MarketPrice();
			marketPrice.pastPricePercentChangeList = new List<float>();
			CPlayerData.m_GenCardMarketPriceListCatJob.Add(marketPrice);
		}
		CPlayerData.m_IsItemLicenseUnlocked.Clear();
		CPlayerData.m_StockSoldList.Clear();
		CPlayerData.m_CurrentTotalItemCountList.Clear();
		CPlayerData.m_SetItemPriceList.Clear();
		CPlayerData.m_AverageItemCostList.Clear();
		CPlayerData.m_GeneratedCostPriceList.Clear();
		CPlayerData.m_GeneratedMarketPriceList.Clear();
		CPlayerData.m_ItemPricePercentChangeList.Clear();
		CPlayerData.m_ItemPricePercentPastChangeList.Clear();
		CPlayerData.m_SetGameEventPriceList.Clear();
		CPlayerData.m_GeneratedGameEventPriceList.Clear();
		CPlayerData.m_GameEventPricePercentChangeList.Clear();
		CPlayerData.m_CollectionCardPackCountList.Clear();
		CPlayerData.m_IsItemLicenseUnlocked.Add(true);
		CPlayerData.m_IsWorkerHired.Clear();
		CPlayerData.m_IsAchievementUnlocked.Clear();
		for (int k = 0; k < 100; k++)
		{
			CPlayerData.m_CollectionCardPackCountList.Add(0);
			CPlayerData.m_SetGameEventPriceList.Add(0f);
			CPlayerData.m_GeneratedGameEventPriceList.Add(0f);
			CPlayerData.m_GameEventPricePercentChangeList.Add(0f);
			CPlayerData.m_IsWorkerHired.Add(false);
			CPlayerData.m_IsAchievementUnlocked.Add(false);
		}
		for (int l = 0; l < 500; l++)
		{
			CPlayerData.m_IsItemLicenseUnlocked.Add(false);
			CPlayerData.m_CurrentTotalItemCountList.Add(0);
			CPlayerData.m_SetItemPriceList.Add(0f);
			CPlayerData.m_AverageItemCostList.Add(0f);
			CPlayerData.m_GeneratedCostPriceList.Add(0f);
			CPlayerData.m_GeneratedMarketPriceList.Add(0f);
			CPlayerData.m_ItemPricePercentChangeList.Add(0f);
			FloatList floatList = new FloatList();
			floatList.floatDataList = new List<float>();
			CPlayerData.m_ItemPricePercentPastChangeList.Add(floatList);
			CPlayerData.m_StockSoldList.Add(0);
		}
		CPlayerData.m_WorkbenchMinimumCardLimit = 4;
		CPlayerData.m_WorkbenchPriceLimit = 0.5f;
		CPlayerData.m_WorkbenchRarityLimit = ERarity.None;
		CPlayerData.m_WorkbenchCardExpansionType = ECardExpansionType.Tetramon;
		CPlayerData.m_ChampionCardCollectedList.Clear();
		CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(true);
	}

	// Token: 0x06000666 RID: 1638 RVA: 0x00035B41 File Offset: 0x00033D41
	public static int GetSellAmountRequiredToCollectPack()
	{
		return 100;
	}

	// Token: 0x06000667 RID: 1639 RVA: 0x00035B45 File Offset: 0x00033D45
	public static int GetCardCollectionDataCount()
	{
		return 2000;
	}

	// Token: 0x06000668 RID: 1640 RVA: 0x00035B4C File Offset: 0x00033D4C
	public static int GetExpRequiredToLevelUp()
	{
		return 250 + CPlayerData.m_ShopLevel * 200 + CPlayerData.m_ShopLevel * CPlayerData.m_ShopLevel * 10;
	}

	// Token: 0x06000669 RID: 1641 RVA: 0x00035B6E File Offset: 0x00033D6E
	public static int GetExpRequiredToLevelUpAtLevel(int shopLevel)
	{
		return 250 + shopLevel * 200 + shopLevel * shopLevel * 10;
	}

	// Token: 0x0600066A RID: 1642 RVA: 0x00035B84 File Offset: 0x00033D84
	public static int GetCardAmountPerMonsterType(ECardExpansionType expansionType, bool includeFoilCount = true)
	{
		int num = 6;
		if (expansionType == ECardExpansionType.Tetramon)
		{
			num = 6;
		}
		else if (expansionType == ECardExpansionType.Destiny)
		{
			num = 6;
		}
		else if (expansionType == ECardExpansionType.Ghost)
		{
			num = 1;
		}
		else if (expansionType == ECardExpansionType.Megabot)
		{
			num = 6;
		}
		else if (expansionType == ECardExpansionType.FantasyRPG)
		{
			num = 6;
		}
		else if (expansionType == ECardExpansionType.CatJob)
		{
			num = 6;
		}
		if (includeFoilCount)
		{
			return num * 2;
		}
		return num;
	}

	// Token: 0x0600066B RID: 1643 RVA: 0x00035BC8 File Offset: 0x00033DC8
	public static ECardBorderType GetCardBorderType(int borderTypeIndex, ECardExpansionType expansionType)
	{
		List<ECardBorderType> list = new List<ECardBorderType>();
		list.Add(ECardBorderType.Base);
		list.Add(ECardBorderType.FirstEdition);
		list.Add(ECardBorderType.Silver);
		list.Add(ECardBorderType.Gold);
		list.Add(ECardBorderType.EX);
		list.Add(ECardBorderType.FullArt);
		if (expansionType == ECardExpansionType.Ghost)
		{
			list.Clear();
			list.Add(ECardBorderType.FullArt);
		}
		return list[borderTypeIndex % CPlayerData.GetCardAmountPerMonsterType(expansionType, false)];
	}

	// Token: 0x0600066C RID: 1644 RVA: 0x00035C28 File Offset: 0x00033E28
	public static List<int> GetCardCollectedList(ECardExpansionType expansionType, bool isDimension)
	{
		if (expansionType == ECardExpansionType.Tetramon)
		{
			return CPlayerData.m_CardCollectedList;
		}
		if (expansionType == ECardExpansionType.Destiny)
		{
			return CPlayerData.m_CardCollectedListDestiny;
		}
		if (expansionType == ECardExpansionType.Ghost)
		{
			if (isDimension)
			{
				return CPlayerData.m_CardCollectedListGhostBlack;
			}
			return CPlayerData.m_CardCollectedListGhost;
		}
		else
		{
			if (expansionType == ECardExpansionType.Megabot)
			{
				return CPlayerData.m_CardCollectedListMegabot;
			}
			if (expansionType == ECardExpansionType.FantasyRPG)
			{
				return CPlayerData.m_CardCollectedListFantasyRPG;
			}
			if (expansionType == ECardExpansionType.CatJob)
			{
				return CPlayerData.m_CardCollectedListCatJob;
			}
			return null;
		}
	}

	// Token: 0x0600066D RID: 1645 RVA: 0x00035C7C File Offset: 0x00033E7C
	public static List<bool> GetIsCardCollectedList(ECardExpansionType expansionType, bool isDimension)
	{
		if (expansionType == ECardExpansionType.Tetramon)
		{
			return CPlayerData.m_IsCardCollectedList;
		}
		if (expansionType == ECardExpansionType.Destiny)
		{
			return CPlayerData.m_IsCardCollectedListDestiny;
		}
		if (expansionType == ECardExpansionType.Ghost)
		{
			if (isDimension)
			{
				return CPlayerData.m_IsCardCollectedListGhostBlack;
			}
			return CPlayerData.m_IsCardCollectedListGhost;
		}
		else
		{
			if (expansionType == ECardExpansionType.Megabot)
			{
				return CPlayerData.m_IsCardCollectedListMegabot;
			}
			if (expansionType == ECardExpansionType.FantasyRPG)
			{
				return CPlayerData.m_IsCardCollectedListFantasyRPG;
			}
			if (expansionType == ECardExpansionType.CatJob)
			{
				return CPlayerData.m_IsCardCollectedListCatJob;
			}
			return null;
		}
	}

	// Token: 0x0600066E RID: 1646 RVA: 0x00035CCE File Offset: 0x00033ECE
	public static EMonsterType GetMonsterTypeFromCardSaveIndex(int index, ECardExpansionType cardExpansionType)
	{
		return InventoryBase.GetShownMonsterList(cardExpansionType)[index / CPlayerData.GetCardAmountPerMonsterType(cardExpansionType, true)];
	}

	// Token: 0x0600066F RID: 1647 RVA: 0x00035CE4 File Offset: 0x00033EE4
	public static int GetCardSaveIndex(CardData cardData)
	{
		int num = 0;
		for (int i = 0; i < InventoryBase.GetShownMonsterList(cardData.expansionType).Count; i++)
		{
			if (InventoryBase.GetShownMonsterList(cardData.expansionType)[i] == cardData.monsterType)
			{
				num = (int)(i * CPlayerData.GetCardAmountPerMonsterType(cardData.expansionType, true) + cardData.borderType);
				break;
			}
		}
		if (cardData.isFoil)
		{
			num += CPlayerData.GetCardAmountPerMonsterType(cardData.expansionType, false);
		}
		return num;
	}

	// Token: 0x06000670 RID: 1648 RVA: 0x00035D58 File Offset: 0x00033F58
	public static float GetUnlockShopRoomCost(int level)
	{
		int num = 100 + level / 4 * 50;
		return (float)(300 + num * level);
	}

	// Token: 0x06000671 RID: 1649 RVA: 0x00035D7C File Offset: 0x00033F7C
	public static float GetUnlockWarehouseRoomCost(int level)
	{
		int num = 500 + level / 2 * 200;
		return (float)(1000 + num * level);
	}

	// Token: 0x06000672 RID: 1650 RVA: 0x00035DA4 File Offset: 0x00033FA4
	public static void AddCurrentTotalItemCount(EItemType itemType, int amount)
	{
		List<int> currentTotalItemCountList = CPlayerData.m_CurrentTotalItemCountList;
		currentTotalItemCountList[(int)itemType] = currentTotalItemCountList[(int)itemType] + amount;
		if (CPlayerData.m_CurrentTotalItemCountList[(int)itemType] < 0)
		{
			CPlayerData.m_CurrentTotalItemCountList[(int)itemType] = 0;
		}
	}

	// Token: 0x06000673 RID: 1651 RVA: 0x00035DE3 File Offset: 0x00033FE3
	public static int GetCurrentTotalItemCount(EItemType itemType)
	{
		if (itemType == EItemType.None)
		{
			return 0;
		}
		if (CPlayerData.m_CurrentTotalItemCountList[(int)itemType] < 0)
		{
			CPlayerData.m_CurrentTotalItemCountList[(int)itemType] = 0;
		}
		return CPlayerData.m_CurrentTotalItemCountList[(int)itemType];
	}

	// Token: 0x06000674 RID: 1652 RVA: 0x00035E10 File Offset: 0x00034010
	public static void AddItemPricePercentChange(EItemType itemType, float percentChange)
	{
		List<float> itemPricePercentChangeList = CPlayerData.m_ItemPricePercentChangeList;
		itemPricePercentChangeList[(int)itemType] = itemPricePercentChangeList[(int)itemType] + percentChange;
		if (CPlayerData.m_ItemPricePercentChangeList[(int)itemType] < -80f)
		{
			CPlayerData.m_ItemPricePercentChangeList[(int)itemType] = -80f;
		}
		if (CPlayerData.m_ItemPricePercentChangeList[(int)itemType] > 200f)
		{
			CPlayerData.m_ItemPricePercentChangeList[(int)itemType] = 200f;
		}
	}

	// Token: 0x06000675 RID: 1653 RVA: 0x00035E7C File Offset: 0x0003407C
	public static void UpdateItemPricePercentChange()
	{
		for (int i = 0; i < CPlayerData.m_ItemPricePercentChangeList.Count; i++)
		{
			if (CPlayerData.m_ItemPricePercentPastChangeList[i].floatDataList == null)
			{
				CPlayerData.m_ItemPricePercentPastChangeList[i].floatDataList = new List<float>();
			}
			CPlayerData.m_ItemPricePercentPastChangeList[i].floatDataList.Add(CPlayerData.m_ItemPricePercentChangeList[i]);
			if (CPlayerData.m_ItemPricePercentPastChangeList[i].floatDataList.Count > 30)
			{
				CPlayerData.m_ItemPricePercentPastChangeList[i].floatDataList.RemoveAt(0);
			}
		}
	}

	// Token: 0x06000676 RID: 1654 RVA: 0x00035F17 File Offset: 0x00034117
	public static void SetItemPrice(EItemType itemType, float price)
	{
		CPlayerData.m_SetItemPriceList[(int)itemType] = price;
		CEventManager.QueueEvent(new CEventPlayer_ItemPriceChanged(itemType, price));
	}

	// Token: 0x06000677 RID: 1655 RVA: 0x00035F34 File Offset: 0x00034134
	public static float GetItemPrice(EItemType itemType, bool preventZero = true)
	{
		if (itemType == EItemType.None)
		{
			return 0f;
		}
		float num = CPlayerData.m_SetItemPriceList[(int)itemType];
		if (preventZero && num <= 0f)
		{
			num = CPlayerData.GetAverageItemCost(itemType);
			if (num <= 0f)
			{
				num = CPlayerData.GetItemMarketPrice(itemType);
			}
		}
		return num;
	}

	// Token: 0x06000678 RID: 1656 RVA: 0x00035F79 File Offset: 0x00034179
	public static float GetItemCost(EItemType itemType)
	{
		if (itemType == EItemType.None)
		{
			return 0f;
		}
		return RestockManager.GetItemCost(itemType);
	}

	// Token: 0x06000679 RID: 1657 RVA: 0x00035F8C File Offset: 0x0003418C
	public static void UpdateAverageItemCost(EItemType itemType, int addItemCount, float unitCost)
	{
		if (itemType == EItemType.None)
		{
			return;
		}
		int num = CPlayerData.GetCurrentTotalItemCount(itemType);
		float averageItemCost = CPlayerData.GetAverageItemCost(itemType);
		if (num < 0)
		{
			num = 0;
		}
		float num2 = ((float)num * averageItemCost + (float)addItemCount * unitCost) / (float)(num + addItemCount);
		if (num2 < 0f || num2 > CPlayerData.GetItemMarketPrice(itemType) * 5f || float.IsNaN(num2))
		{
			num2 = CPlayerData.GetItemCost(itemType);
		}
		CPlayerData.m_AverageItemCostList[(int)itemType] = num2;
		CPlayerData.AddCurrentTotalItemCount(itemType, addItemCount);
	}

	// Token: 0x0600067A RID: 1658 RVA: 0x00035FFA File Offset: 0x000341FA
	public static void SetAverageItemCost(EItemType itemType, float cost)
	{
		if (itemType == EItemType.None)
		{
			return;
		}
		CPlayerData.m_AverageItemCostList[(int)itemType] = cost;
	}

	// Token: 0x0600067B RID: 1659 RVA: 0x00036010 File Offset: 0x00034210
	public static float GetAverageItemCost(EItemType itemType)
	{
		if (itemType == EItemType.None)
		{
			return 0f;
		}
		float num = CPlayerData.m_AverageItemCostList[(int)itemType];
		if (num < 0f || num > CPlayerData.GetItemMarketPrice(itemType) * 5f || float.IsNaN(num))
		{
			num = CPlayerData.GetItemCost(itemType);
		}
		return num;
	}

	// Token: 0x0600067C RID: 1660 RVA: 0x0003605A File Offset: 0x0003425A
	public static float GetItemMarketPrice(EItemType itemType)
	{
		if (itemType == EItemType.None)
		{
			return 0f;
		}
		return RestockManager.GetItemMarketPrice(itemType);
	}

	// Token: 0x0600067D RID: 1661 RVA: 0x0003606C File Offset: 0x0003426C
	public static float GetItemMarketPriceCustomPercent(EItemType itemType, float percent)
	{
		if (itemType == EItemType.None)
		{
			return 0f;
		}
		return RestockManager.GetItemMarketPriceCustomPercent(itemType, percent);
	}

	// Token: 0x0600067E RID: 1662 RVA: 0x0003607F File Offset: 0x0003427F
	public static bool GetIsItemLicenseUnlocked(int index)
	{
		return CPlayerData.m_IsItemLicenseUnlocked[index];
	}

	// Token: 0x0600067F RID: 1663 RVA: 0x0003608C File Offset: 0x0003428C
	public static void SetUnlockItemLicense(int index)
	{
		CPlayerData.m_IsItemLicenseUnlocked[index] = true;
	}

	// Token: 0x06000680 RID: 1664 RVA: 0x0003609A File Offset: 0x0003429A
	public static bool GetIsWorkerHired(int index)
	{
		return CPlayerData.m_IsWorkerHired[index];
	}

	// Token: 0x06000681 RID: 1665 RVA: 0x000360A7 File Offset: 0x000342A7
	public static void SetIsWorkerHired(int index, bool isHired)
	{
		CPlayerData.m_IsWorkerHired[index] = isHired;
	}

	// Token: 0x06000682 RID: 1666 RVA: 0x000360B8 File Offset: 0x000342B8
	public static float GetCardPrice(CardData cardData)
	{
		int cardSaveIndex = CPlayerData.GetCardSaveIndex(cardData);
		if (cardData.expansionType == ECardExpansionType.Tetramon)
		{
			return CPlayerData.m_CardPriceSetList[cardSaveIndex];
		}
		if (cardData.expansionType == ECardExpansionType.Destiny)
		{
			return CPlayerData.m_CardPriceSetListDestiny[cardSaveIndex];
		}
		if (cardData.expansionType == ECardExpansionType.Ghost)
		{
			if (cardData.isDestiny)
			{
				return CPlayerData.m_CardPriceSetListGhostBlack[cardSaveIndex];
			}
			return CPlayerData.m_CardPriceSetListGhost[cardSaveIndex];
		}
		else
		{
			if (cardData.expansionType == ECardExpansionType.Megabot)
			{
				return CPlayerData.m_CardPriceSetListMegabot[cardSaveIndex];
			}
			if (cardData.expansionType == ECardExpansionType.FantasyRPG)
			{
				return CPlayerData.m_CardPriceSetListFantasyRPG[cardSaveIndex];
			}
			if (cardData.expansionType == ECardExpansionType.CatJob)
			{
				return CPlayerData.m_CardPriceSetListCatJob[cardSaveIndex];
			}
			return 0f;
		}
	}

	// Token: 0x06000683 RID: 1667 RVA: 0x00036164 File Offset: 0x00034364
	public static float GetCardPriceUsingIndex(int index, ECardExpansionType expansionType, bool isDestiny)
	{
		if (expansionType == ECardExpansionType.Tetramon)
		{
			return CPlayerData.m_CardPriceSetList[index];
		}
		if (expansionType == ECardExpansionType.Destiny)
		{
			return CPlayerData.m_CardPriceSetListDestiny[index];
		}
		if (expansionType == ECardExpansionType.Ghost)
		{
			if (isDestiny)
			{
				return CPlayerData.m_CardPriceSetListGhostBlack[index];
			}
			return CPlayerData.m_CardPriceSetListGhost[index];
		}
		else
		{
			if (expansionType == ECardExpansionType.Megabot)
			{
				return CPlayerData.m_CardPriceSetListMegabot[index];
			}
			if (expansionType == ECardExpansionType.FantasyRPG)
			{
				return CPlayerData.m_CardPriceSetListFantasyRPG[index];
			}
			if (expansionType == ECardExpansionType.CatJob)
			{
				return CPlayerData.m_CardPriceSetListCatJob[index];
			}
			return 0f;
		}
	}

	// Token: 0x06000684 RID: 1668 RVA: 0x000361E4 File Offset: 0x000343E4
	public static void SetCardPrice(CardData cardData, float priceSet)
	{
		int cardSaveIndex = CPlayerData.GetCardSaveIndex(cardData);
		if (cardData.expansionType == ECardExpansionType.Tetramon)
		{
			CPlayerData.m_CardPriceSetList[cardSaveIndex] = priceSet;
		}
		else if (cardData.expansionType == ECardExpansionType.Destiny)
		{
			CPlayerData.m_CardPriceSetListDestiny[cardSaveIndex] = priceSet;
		}
		else if (cardData.expansionType == ECardExpansionType.Ghost)
		{
			if (cardData.isDestiny)
			{
				CPlayerData.m_CardPriceSetListGhostBlack[cardSaveIndex] = priceSet;
			}
			else
			{
				CPlayerData.m_CardPriceSetListGhost[cardSaveIndex] = priceSet;
			}
		}
		else if (cardData.expansionType == ECardExpansionType.Megabot)
		{
			CPlayerData.m_CardPriceSetListMegabot[cardSaveIndex] = priceSet;
		}
		else if (cardData.expansionType == ECardExpansionType.FantasyRPG)
		{
			CPlayerData.m_CardPriceSetListFantasyRPG[cardSaveIndex] = priceSet;
		}
		else if (cardData.expansionType == ECardExpansionType.CatJob)
		{
			CPlayerData.m_CardPriceSetListCatJob[cardSaveIndex] = priceSet;
		}
		CEventManager.QueueEvent(new CEventPlayer_CardPriceChanged(cardData, priceSet));
	}

	// Token: 0x06000685 RID: 1669 RVA: 0x000362A4 File Offset: 0x000344A4
	public static void SetCardGeneratedMarketPrice(int cardIndex, ECardExpansionType expansionType, bool isDestiny, float price)
	{
		if (expansionType == ECardExpansionType.Tetramon)
		{
			CPlayerData.m_GenCardMarketPriceList[cardIndex].generatedMarketPrice = price;
			return;
		}
		if (expansionType == ECardExpansionType.Destiny)
		{
			CPlayerData.m_GenCardMarketPriceListDestiny[cardIndex].generatedMarketPrice = price;
			return;
		}
		if (expansionType == ECardExpansionType.Ghost)
		{
			if (isDestiny)
			{
				CPlayerData.m_GenCardMarketPriceListGhost[cardIndex].generatedMarketPrice = price;
				return;
			}
			CPlayerData.m_GenCardMarketPriceListGhostBlack[cardIndex].generatedMarketPrice = price;
			return;
		}
		else
		{
			if (expansionType == ECardExpansionType.Megabot)
			{
				CPlayerData.m_GenCardMarketPriceListMegabot[cardIndex].generatedMarketPrice = price;
				return;
			}
			if (expansionType == ECardExpansionType.FantasyRPG)
			{
				CPlayerData.m_GenCardMarketPriceListFantasyRPG[cardIndex].generatedMarketPrice = price;
				return;
			}
			if (expansionType == ECardExpansionType.CatJob)
			{
				CPlayerData.m_GenCardMarketPriceListCatJob[cardIndex].generatedMarketPrice = price;
			}
			return;
		}
	}

	// Token: 0x06000686 RID: 1670 RVA: 0x00036348 File Offset: 0x00034548
	public static void AddCardPricePercentChange(int cardIndex, ECardExpansionType expansionType, bool isDestiny, float percentChange)
	{
		if (expansionType == ECardExpansionType.Tetramon)
		{
			CPlayerData.m_GenCardMarketPriceList[cardIndex].pricePercentChangeList += percentChange;
			if (CPlayerData.m_GenCardMarketPriceList[cardIndex].pricePercentChangeList < -80f)
			{
				CPlayerData.m_GenCardMarketPriceList[cardIndex].pricePercentChangeList = -80f;
			}
			if (CPlayerData.m_GenCardMarketPriceList[cardIndex].pricePercentChangeList > 200f)
			{
				CPlayerData.m_GenCardMarketPriceList[cardIndex].pricePercentChangeList = 200f;
				return;
			}
		}
		else if (expansionType == ECardExpansionType.Destiny)
		{
			CPlayerData.m_GenCardMarketPriceListDestiny[cardIndex].pricePercentChangeList += percentChange;
			if (CPlayerData.m_GenCardMarketPriceListDestiny[cardIndex].pricePercentChangeList < -80f)
			{
				CPlayerData.m_GenCardMarketPriceListDestiny[cardIndex].pricePercentChangeList = -80f;
			}
			if (CPlayerData.m_GenCardMarketPriceListDestiny[cardIndex].pricePercentChangeList > 200f)
			{
				CPlayerData.m_GenCardMarketPriceListDestiny[cardIndex].pricePercentChangeList = 200f;
				return;
			}
		}
		else if (expansionType == ECardExpansionType.Ghost)
		{
			if (isDestiny)
			{
				CPlayerData.m_GenCardMarketPriceListGhost[cardIndex].pricePercentChangeList += percentChange;
				if (CPlayerData.m_GenCardMarketPriceListGhost[cardIndex].pricePercentChangeList < -80f)
				{
					CPlayerData.m_GenCardMarketPriceListGhost[cardIndex].pricePercentChangeList = -80f;
				}
				if (CPlayerData.m_GenCardMarketPriceListGhost[cardIndex].pricePercentChangeList > 200f)
				{
					CPlayerData.m_GenCardMarketPriceListGhost[cardIndex].pricePercentChangeList = 200f;
					return;
				}
			}
			else
			{
				CPlayerData.m_GenCardMarketPriceListGhostBlack[cardIndex].pricePercentChangeList += percentChange;
				if (CPlayerData.m_GenCardMarketPriceListGhostBlack[cardIndex].pricePercentChangeList < -80f)
				{
					CPlayerData.m_GenCardMarketPriceListGhostBlack[cardIndex].pricePercentChangeList = -80f;
				}
				if (CPlayerData.m_GenCardMarketPriceListGhostBlack[cardIndex].pricePercentChangeList > 200f)
				{
					CPlayerData.m_GenCardMarketPriceListGhostBlack[cardIndex].pricePercentChangeList = 200f;
					return;
				}
			}
		}
		else if (expansionType == ECardExpansionType.Megabot)
		{
			CPlayerData.m_GenCardMarketPriceListMegabot[cardIndex].pricePercentChangeList += percentChange;
			if (CPlayerData.m_GenCardMarketPriceListMegabot[cardIndex].pricePercentChangeList < -80f)
			{
				CPlayerData.m_GenCardMarketPriceListMegabot[cardIndex].pricePercentChangeList = -80f;
			}
			if (CPlayerData.m_GenCardMarketPriceListMegabot[cardIndex].pricePercentChangeList > 200f)
			{
				CPlayerData.m_GenCardMarketPriceListMegabot[cardIndex].pricePercentChangeList = 200f;
				return;
			}
		}
		else if (expansionType == ECardExpansionType.FantasyRPG)
		{
			CPlayerData.m_GenCardMarketPriceListFantasyRPG[cardIndex].pricePercentChangeList += percentChange;
			if (CPlayerData.m_GenCardMarketPriceListFantasyRPG[cardIndex].pricePercentChangeList < -80f)
			{
				CPlayerData.m_GenCardMarketPriceListFantasyRPG[cardIndex].pricePercentChangeList = -80f;
			}
			if (CPlayerData.m_GenCardMarketPriceListFantasyRPG[cardIndex].pricePercentChangeList > 200f)
			{
				CPlayerData.m_GenCardMarketPriceListFantasyRPG[cardIndex].pricePercentChangeList = 200f;
				return;
			}
		}
		else if (expansionType == ECardExpansionType.CatJob)
		{
			CPlayerData.m_GenCardMarketPriceListCatJob[cardIndex].pricePercentChangeList += percentChange;
			if (CPlayerData.m_GenCardMarketPriceListCatJob[cardIndex].pricePercentChangeList < -80f)
			{
				CPlayerData.m_GenCardMarketPriceListCatJob[cardIndex].pricePercentChangeList = -80f;
			}
			if (CPlayerData.m_GenCardMarketPriceListCatJob[cardIndex].pricePercentChangeList > 200f)
			{
				CPlayerData.m_GenCardMarketPriceListCatJob[cardIndex].pricePercentChangeList = 200f;
			}
		}
	}

	// Token: 0x06000687 RID: 1671 RVA: 0x0003669C File Offset: 0x0003489C
	public static float GetCardPricePercentChange(int cardIndex, ECardExpansionType expansionType, bool isDestiny)
	{
		if (expansionType == ECardExpansionType.Tetramon)
		{
			return CPlayerData.m_GenCardMarketPriceList[cardIndex].pricePercentChangeList;
		}
		if (expansionType == ECardExpansionType.Destiny)
		{
			return CPlayerData.m_GenCardMarketPriceListDestiny[cardIndex].pricePercentChangeList;
		}
		if (expansionType == ECardExpansionType.Ghost)
		{
			if (isDestiny)
			{
				return CPlayerData.m_GenCardMarketPriceListGhost[cardIndex].pricePercentChangeList;
			}
			return CPlayerData.m_GenCardMarketPriceListGhostBlack[cardIndex].pricePercentChangeList;
		}
		else
		{
			if (expansionType == ECardExpansionType.Megabot)
			{
				return CPlayerData.m_GenCardMarketPriceListMegabot[cardIndex].pricePercentChangeList;
			}
			if (expansionType == ECardExpansionType.FantasyRPG)
			{
				return CPlayerData.m_GenCardMarketPriceListFantasyRPG[cardIndex].pricePercentChangeList;
			}
			if (expansionType == ECardExpansionType.CatJob)
			{
				return CPlayerData.m_GenCardMarketPriceListCatJob[cardIndex].pricePercentChangeList;
			}
			return 0f;
		}
	}

	// Token: 0x06000688 RID: 1672 RVA: 0x00036740 File Offset: 0x00034940
	public static void UpdatePastCardPricePercentChange()
	{
		for (int i = 0; i < CPlayerData.m_GenCardMarketPriceList.Count; i++)
		{
			if (CPlayerData.m_GenCardMarketPriceList[i].pastPricePercentChangeList == null)
			{
				CPlayerData.m_GenCardMarketPriceList[i].pastPricePercentChangeList = new List<float>();
			}
			CPlayerData.m_GenCardMarketPriceList[i].pastPricePercentChangeList.Add(CPlayerData.m_GenCardMarketPriceList[i].pricePercentChangeList);
			if (CPlayerData.m_GenCardMarketPriceList[i].pastPricePercentChangeList.Count > 30)
			{
				CPlayerData.m_GenCardMarketPriceList[i].pastPricePercentChangeList.RemoveAt(0);
			}
		}
		for (int j = 0; j < CPlayerData.m_GenCardMarketPriceListDestiny.Count; j++)
		{
			if (CPlayerData.m_GenCardMarketPriceListDestiny[j].pastPricePercentChangeList == null)
			{
				CPlayerData.m_GenCardMarketPriceListDestiny[j].pastPricePercentChangeList = new List<float>();
			}
			CPlayerData.m_GenCardMarketPriceListDestiny[j].pastPricePercentChangeList.Add(CPlayerData.m_GenCardMarketPriceListDestiny[j].pricePercentChangeList);
			if (CPlayerData.m_GenCardMarketPriceListDestiny[j].pastPricePercentChangeList.Count > 30)
			{
				CPlayerData.m_GenCardMarketPriceListDestiny[j].pastPricePercentChangeList.RemoveAt(0);
			}
		}
		for (int k = 0; k < CPlayerData.m_GenCardMarketPriceListGhost.Count; k++)
		{
			if (CPlayerData.m_GenCardMarketPriceListGhost[k].pastPricePercentChangeList == null)
			{
				CPlayerData.m_GenCardMarketPriceListGhost[k].pastPricePercentChangeList = new List<float>();
			}
			CPlayerData.m_GenCardMarketPriceListGhost[k].pastPricePercentChangeList.Add(CPlayerData.m_GenCardMarketPriceListGhost[k].pricePercentChangeList);
			if (CPlayerData.m_GenCardMarketPriceListGhost[k].pastPricePercentChangeList.Count > 30)
			{
				CPlayerData.m_GenCardMarketPriceListGhost[k].pastPricePercentChangeList.RemoveAt(0);
			}
		}
		for (int l = 0; l < CPlayerData.m_GenCardMarketPriceListGhostBlack.Count; l++)
		{
			if (CPlayerData.m_GenCardMarketPriceListGhostBlack[l].pastPricePercentChangeList == null)
			{
				CPlayerData.m_GenCardMarketPriceListGhostBlack[l].pastPricePercentChangeList = new List<float>();
			}
			CPlayerData.m_GenCardMarketPriceListGhostBlack[l].pastPricePercentChangeList.Add(CPlayerData.m_GenCardMarketPriceListGhostBlack[l].pricePercentChangeList);
			if (CPlayerData.m_GenCardMarketPriceListGhostBlack[l].pastPricePercentChangeList.Count > 30)
			{
				CPlayerData.m_GenCardMarketPriceListGhostBlack[l].pastPricePercentChangeList.RemoveAt(0);
			}
		}
		for (int m = 0; m < CPlayerData.m_GenCardMarketPriceListMegabot.Count; m++)
		{
			if (CPlayerData.m_GenCardMarketPriceListMegabot[m].pastPricePercentChangeList == null)
			{
				CPlayerData.m_GenCardMarketPriceListMegabot[m].pastPricePercentChangeList = new List<float>();
			}
			CPlayerData.m_GenCardMarketPriceListMegabot[m].pastPricePercentChangeList.Add(CPlayerData.m_GenCardMarketPriceListMegabot[m].pricePercentChangeList);
			if (CPlayerData.m_GenCardMarketPriceListMegabot[m].pastPricePercentChangeList.Count > 30)
			{
				CPlayerData.m_GenCardMarketPriceListMegabot[m].pastPricePercentChangeList.RemoveAt(0);
			}
		}
		for (int n = 0; n < CPlayerData.m_GenCardMarketPriceListFantasyRPG.Count; n++)
		{
			if (CPlayerData.m_GenCardMarketPriceListFantasyRPG[n].pastPricePercentChangeList == null)
			{
				CPlayerData.m_GenCardMarketPriceListFantasyRPG[n].pastPricePercentChangeList = new List<float>();
			}
			CPlayerData.m_GenCardMarketPriceListFantasyRPG[n].pastPricePercentChangeList.Add(CPlayerData.m_GenCardMarketPriceListFantasyRPG[n].pricePercentChangeList);
			if (CPlayerData.m_GenCardMarketPriceListFantasyRPG[n].pastPricePercentChangeList.Count > 30)
			{
				CPlayerData.m_GenCardMarketPriceListFantasyRPG[n].pastPricePercentChangeList.RemoveAt(0);
			}
		}
		for (int num = 0; num < CPlayerData.m_GenCardMarketPriceListCatJob.Count; num++)
		{
			if (CPlayerData.m_GenCardMarketPriceListCatJob[num].pastPricePercentChangeList == null)
			{
				CPlayerData.m_GenCardMarketPriceListCatJob[num].pastPricePercentChangeList = new List<float>();
			}
			CPlayerData.m_GenCardMarketPriceListCatJob[num].pastPricePercentChangeList.Add(CPlayerData.m_GenCardMarketPriceListCatJob[num].pricePercentChangeList);
			if (CPlayerData.m_GenCardMarketPriceListCatJob[num].pastPricePercentChangeList.Count > 30)
			{
				CPlayerData.m_GenCardMarketPriceListCatJob[num].pastPricePercentChangeList.RemoveAt(0);
			}
		}
	}

	// Token: 0x06000689 RID: 1673 RVA: 0x00036B7C File Offset: 0x00034D7C
	public static List<float> GetPastCardPricePercentChange(int cardIndex, ECardExpansionType expansionType, bool isDestiny)
	{
		if (expansionType == ECardExpansionType.Tetramon)
		{
			return CPlayerData.m_GenCardMarketPriceList[cardIndex].pastPricePercentChangeList;
		}
		if (expansionType == ECardExpansionType.Destiny)
		{
			return CPlayerData.m_GenCardMarketPriceListDestiny[cardIndex].pastPricePercentChangeList;
		}
		if (expansionType == ECardExpansionType.Ghost)
		{
			if (isDestiny)
			{
				return CPlayerData.m_GenCardMarketPriceListGhost[cardIndex].pastPricePercentChangeList;
			}
			return CPlayerData.m_GenCardMarketPriceListGhostBlack[cardIndex].pastPricePercentChangeList;
		}
		else
		{
			if (expansionType == ECardExpansionType.Megabot)
			{
				return CPlayerData.m_GenCardMarketPriceListMegabot[cardIndex].pastPricePercentChangeList;
			}
			if (expansionType == ECardExpansionType.FantasyRPG)
			{
				return CPlayerData.m_GenCardMarketPriceListFantasyRPG[cardIndex].pastPricePercentChangeList;
			}
			if (expansionType == ECardExpansionType.CatJob)
			{
				return CPlayerData.m_GenCardMarketPriceListCatJob[cardIndex].pastPricePercentChangeList;
			}
			return null;
		}
	}

	// Token: 0x0600068A RID: 1674 RVA: 0x00036C1C File Offset: 0x00034E1C
	public static float GetCardMarketPrice(CardData cardData)
	{
		int cardSaveIndex = CPlayerData.GetCardSaveIndex(cardData);
		if (cardData.expansionType == ECardExpansionType.Tetramon)
		{
			return CPlayerData.m_GenCardMarketPriceList[cardSaveIndex].GetMarketPrice();
		}
		if (cardData.expansionType == ECardExpansionType.Destiny)
		{
			return CPlayerData.m_GenCardMarketPriceListDestiny[cardSaveIndex].GetMarketPrice();
		}
		if (cardData.expansionType == ECardExpansionType.Ghost)
		{
			if (cardData.isDestiny)
			{
				return CPlayerData.m_GenCardMarketPriceListGhost[cardSaveIndex].GetMarketPrice();
			}
			return CPlayerData.m_GenCardMarketPriceListGhostBlack[cardSaveIndex].GetMarketPrice();
		}
		else
		{
			if (cardData.expansionType == ECardExpansionType.Megabot)
			{
				return CPlayerData.m_GenCardMarketPriceListMegabot[cardSaveIndex].GetMarketPrice();
			}
			if (cardData.expansionType == ECardExpansionType.FantasyRPG)
			{
				return CPlayerData.m_GenCardMarketPriceListFantasyRPG[cardSaveIndex].GetMarketPrice();
			}
			if (cardData.expansionType == ECardExpansionType.CatJob)
			{
				return CPlayerData.m_GenCardMarketPriceListCatJob[cardSaveIndex].GetMarketPrice();
			}
			return 0f;
		}
	}

	// Token: 0x0600068B RID: 1675 RVA: 0x00036CEC File Offset: 0x00034EEC
	public static float GetCardMarketPrice(int index, ECardExpansionType expansionType, bool isDestiny)
	{
		if (expansionType == ECardExpansionType.Tetramon)
		{
			return CPlayerData.m_GenCardMarketPriceList[index].GetMarketPrice();
		}
		if (expansionType == ECardExpansionType.Destiny)
		{
			return CPlayerData.m_GenCardMarketPriceListDestiny[index].GetMarketPrice();
		}
		if (expansionType == ECardExpansionType.Ghost)
		{
			if (isDestiny)
			{
				return CPlayerData.m_GenCardMarketPriceListGhost[index].GetMarketPrice();
			}
			return CPlayerData.m_GenCardMarketPriceListGhostBlack[index].GetMarketPrice();
		}
		else
		{
			if (expansionType == ECardExpansionType.Megabot)
			{
				return CPlayerData.m_GenCardMarketPriceListMegabot[index].GetMarketPrice();
			}
			if (expansionType == ECardExpansionType.FantasyRPG)
			{
				return CPlayerData.m_GenCardMarketPriceListFantasyRPG[index].GetMarketPrice();
			}
			if (expansionType == ECardExpansionType.CatJob)
			{
				return CPlayerData.m_GenCardMarketPriceListCatJob[index].GetMarketPrice();
			}
			return 0f;
		}
	}

	// Token: 0x0600068C RID: 1676 RVA: 0x00036D90 File Offset: 0x00034F90
	public static float GetCardMarketPriceCustomPercent(int index, ECardExpansionType expansionType, bool isDestiny, float percent)
	{
		if (expansionType == ECardExpansionType.Tetramon)
		{
			return CPlayerData.m_GenCardMarketPriceList[index].GetMarketPriceCustomPercent(percent);
		}
		if (expansionType == ECardExpansionType.Destiny)
		{
			return CPlayerData.m_GenCardMarketPriceListDestiny[index].GetMarketPriceCustomPercent(percent);
		}
		if (expansionType == ECardExpansionType.Ghost)
		{
			if (isDestiny)
			{
				return CPlayerData.m_GenCardMarketPriceListGhost[index].GetMarketPriceCustomPercent(percent);
			}
			return CPlayerData.m_GenCardMarketPriceListGhostBlack[index].GetMarketPriceCustomPercent(percent);
		}
		else
		{
			if (expansionType == ECardExpansionType.Megabot)
			{
				return CPlayerData.m_GenCardMarketPriceListMegabot[index].GetMarketPriceCustomPercent(percent);
			}
			if (expansionType == ECardExpansionType.FantasyRPG)
			{
				return CPlayerData.m_GenCardMarketPriceListFantasyRPG[index].GetMarketPriceCustomPercent(percent);
			}
			if (expansionType == ECardExpansionType.CatJob)
			{
				return CPlayerData.m_GenCardMarketPriceListCatJob[index].GetMarketPriceCustomPercent(percent);
			}
			return 0f;
		}
	}

	// Token: 0x0600068D RID: 1677 RVA: 0x00036E3C File Offset: 0x0003503C
	public static void AddCard(CardData cardData, int addAmount)
	{
		int cardSaveIndex = CPlayerData.GetCardSaveIndex(cardData);
		if (cardData.expansionType == ECardExpansionType.Tetramon)
		{
			List<int> list = CPlayerData.m_CardCollectedList;
			int index = cardSaveIndex;
			list[index] += addAmount;
			CPlayerData.m_IsCardCollectedList[cardSaveIndex] = true;
			return;
		}
		if (cardData.expansionType == ECardExpansionType.Destiny)
		{
			List<int> list = CPlayerData.m_CardCollectedListDestiny;
			int index = cardSaveIndex;
			list[index] += addAmount;
			CPlayerData.m_IsCardCollectedListDestiny[cardSaveIndex] = true;
			return;
		}
		if (cardData.expansionType == ECardExpansionType.Ghost)
		{
			List<int> list;
			int index;
			if (cardData.isDestiny)
			{
				list = CPlayerData.m_CardCollectedListGhostBlack;
				index = cardSaveIndex;
				list[index] += addAmount;
				CPlayerData.m_IsCardCollectedListGhostBlack[cardSaveIndex] = true;
				return;
			}
			list = CPlayerData.m_CardCollectedListGhost;
			index = cardSaveIndex;
			list[index] += addAmount;
			CPlayerData.m_IsCardCollectedListGhost[cardSaveIndex] = true;
			return;
		}
		else
		{
			if (cardData.expansionType == ECardExpansionType.Megabot)
			{
				List<int> list = CPlayerData.m_CardCollectedListMegabot;
				int index = cardSaveIndex;
				list[index] += addAmount;
				CPlayerData.m_IsCardCollectedListMegabot[cardSaveIndex] = true;
				return;
			}
			if (cardData.expansionType == ECardExpansionType.FantasyRPG)
			{
				List<int> list = CPlayerData.m_CardCollectedListFantasyRPG;
				int index = cardSaveIndex;
				list[index] += addAmount;
				CPlayerData.m_IsCardCollectedListFantasyRPG[cardSaveIndex] = true;
				return;
			}
			if (cardData.expansionType == ECardExpansionType.CatJob)
			{
				List<int> list = CPlayerData.m_CardCollectedListCatJob;
				int index = cardSaveIndex;
				list[index] += addAmount;
				CPlayerData.m_IsCardCollectedListCatJob[cardSaveIndex] = true;
			}
			return;
		}
	}

	// Token: 0x0600068E RID: 1678 RVA: 0x00036F90 File Offset: 0x00035190
	public static void ReduceCard(CardData cardData, int reduceAmount)
	{
		int cardSaveIndex = CPlayerData.GetCardSaveIndex(cardData);
		if (cardData.expansionType == ECardExpansionType.Tetramon)
		{
			List<int> list = CPlayerData.m_CardCollectedList;
			int index = cardSaveIndex;
			list[index] -= reduceAmount;
			return;
		}
		if (cardData.expansionType == ECardExpansionType.Destiny)
		{
			List<int> list = CPlayerData.m_CardCollectedListDestiny;
			int index = cardSaveIndex;
			list[index] -= reduceAmount;
			return;
		}
		if (cardData.expansionType == ECardExpansionType.Ghost)
		{
			List<int> list;
			int index;
			if (cardData.isDestiny)
			{
				list = CPlayerData.m_CardCollectedListGhostBlack;
				index = cardSaveIndex;
				list[index] -= reduceAmount;
				return;
			}
			list = CPlayerData.m_CardCollectedListGhost;
			index = cardSaveIndex;
			list[index] -= reduceAmount;
			return;
		}
		else
		{
			if (cardData.expansionType == ECardExpansionType.Megabot)
			{
				List<int> list = CPlayerData.m_CardCollectedListMegabot;
				int index = cardSaveIndex;
				list[index] -= reduceAmount;
				return;
			}
			if (cardData.expansionType == ECardExpansionType.FantasyRPG)
			{
				List<int> list = CPlayerData.m_CardCollectedListFantasyRPG;
				int index = cardSaveIndex;
				list[index] -= reduceAmount;
				return;
			}
			if (cardData.expansionType == ECardExpansionType.CatJob)
			{
				List<int> list = CPlayerData.m_CardCollectedListCatJob;
				int index = cardSaveIndex;
				list[index] -= reduceAmount;
			}
			return;
		}
	}

	// Token: 0x0600068F RID: 1679 RVA: 0x00037090 File Offset: 0x00035290
	public static void ReduceCardUsingIndex(int index, ECardExpansionType expansionType, bool isDestiny, int reduceAmount)
	{
		if (expansionType == ECardExpansionType.Tetramon)
		{
			List<int> list = CPlayerData.m_CardCollectedList;
			list[index] -= reduceAmount;
			return;
		}
		if (expansionType == ECardExpansionType.Destiny)
		{
			List<int> list = CPlayerData.m_CardCollectedListDestiny;
			list[index] -= reduceAmount;
			return;
		}
		if (expansionType == ECardExpansionType.Ghost)
		{
			List<int> list;
			if (isDestiny)
			{
				list = CPlayerData.m_CardCollectedListGhostBlack;
				list[index] -= reduceAmount;
				return;
			}
			list = CPlayerData.m_CardCollectedListGhost;
			list[index] -= reduceAmount;
			return;
		}
		else
		{
			if (expansionType == ECardExpansionType.Megabot)
			{
				List<int> list = CPlayerData.m_CardCollectedListMegabot;
				list[index] -= reduceAmount;
				return;
			}
			if (expansionType == ECardExpansionType.FantasyRPG)
			{
				List<int> list = CPlayerData.m_CardCollectedListFantasyRPG;
				list[index] -= reduceAmount;
				return;
			}
			if (expansionType == ECardExpansionType.CatJob)
			{
				List<int> list = CPlayerData.m_CardCollectedListCatJob;
				list[index] -= reduceAmount;
			}
			return;
		}
	}

	// Token: 0x06000690 RID: 1680 RVA: 0x00037168 File Offset: 0x00035368
	public static void SetCard(CardData cardData, int amount)
	{
		int cardSaveIndex = CPlayerData.GetCardSaveIndex(cardData);
		if (cardData.expansionType == ECardExpansionType.Tetramon)
		{
			CPlayerData.m_CardCollectedList[cardSaveIndex] = amount;
			return;
		}
		if (cardData.expansionType == ECardExpansionType.Destiny)
		{
			CPlayerData.m_CardCollectedListDestiny[cardSaveIndex] = amount;
			return;
		}
		if (cardData.expansionType == ECardExpansionType.Ghost)
		{
			if (cardData.isDestiny)
			{
				CPlayerData.m_CardCollectedListGhostBlack[cardSaveIndex] = amount;
				return;
			}
			CPlayerData.m_CardCollectedListGhost[cardSaveIndex] = amount;
			return;
		}
		else
		{
			if (cardData.expansionType == ECardExpansionType.Megabot)
			{
				CPlayerData.m_CardCollectedListMegabot[cardSaveIndex] = amount;
				return;
			}
			if (cardData.expansionType == ECardExpansionType.FantasyRPG)
			{
				CPlayerData.m_CardCollectedListFantasyRPG[cardSaveIndex] = amount;
				return;
			}
			if (cardData.expansionType == ECardExpansionType.CatJob)
			{
				CPlayerData.m_CardCollectedListCatJob[cardSaveIndex] = amount;
			}
			return;
		}
	}

	// Token: 0x06000691 RID: 1681 RVA: 0x00037214 File Offset: 0x00035414
	public static CardData GetCardData(int cardIndex, ECardExpansionType expansionType, bool isDestiny)
	{
		return new CardData
		{
			monsterType = CPlayerData.GetMonsterTypeFromCardSaveIndex(cardIndex, expansionType),
			isFoil = (cardIndex % CPlayerData.GetCardAmountPerMonsterType(expansionType, true) >= CPlayerData.GetCardAmountPerMonsterType(expansionType, false)),
			borderType = (ECardBorderType)(cardIndex % CPlayerData.GetCardAmountPerMonsterType(expansionType, false)),
			isDestiny = isDestiny,
			expansionType = expansionType
		};
	}

	// Token: 0x06000692 RID: 1682 RVA: 0x0003726B File Offset: 0x0003546B
	public static void AddChampionCard(EMonsterType monsterType)
	{
		CPlayerData.m_ChampionCardCollectedList.Add((int)monsterType);
	}

	// Token: 0x06000693 RID: 1683 RVA: 0x00037278 File Offset: 0x00035478
	public static void AddSpecialEventCard(EMonsterType monsterType)
	{
		if (monsterType >= EMonsterType.None)
		{
			Debug.LogError("monstertype should be negative for special event");
			return;
		}
		CPlayerData.m_ChampionCardCollectedList.Add((int)monsterType);
	}

	// Token: 0x06000694 RID: 1684 RVA: 0x00037294 File Offset: 0x00035494
	public static string GetCardBorderName(ECardBorderType cardBorder)
	{
		string result = LocalizationManager.GetTranslation("Basic", true, 0, true, false, null, null, true);
		if (cardBorder == ECardBorderType.FirstEdition)
		{
			result = LocalizationManager.GetTranslation("First Edition", true, 0, true, false, null, null, true);
		}
		else if (cardBorder == ECardBorderType.Silver)
		{
			result = LocalizationManager.GetTranslation("Silver Edition", true, 0, true, false, null, null, true);
		}
		else if (cardBorder == ECardBorderType.Gold)
		{
			result = LocalizationManager.GetTranslation("Gold Edition", true, 0, true, false, null, null, true);
		}
		else if (cardBorder == ECardBorderType.EX)
		{
			result = "EX";
		}
		else if (cardBorder == ECardBorderType.FullArt)
		{
			result = LocalizationManager.GetTranslation("Full Art", true, 0, true, false, null, null, true);
		}
		return result;
	}

	// Token: 0x06000695 RID: 1685 RVA: 0x00037320 File Offset: 0x00035520
	public static string GetFullCardTypeName(CardData cardData, bool ignoreRarity = false)
	{
		string rarityName = InventoryBase.GetMonsterData(cardData.monsterType).GetRarityName();
		if (cardData.isFoil)
		{
			if (ignoreRarity)
			{
				return CPlayerData.GetCardBorderName(cardData.GetCardBorderType()) + " " + LocalizationManager.GetTranslation("Foil", true, 0, true, false, null, null, true);
			}
			return string.Concat(new string[]
			{
				CPlayerData.GetCardBorderName(cardData.GetCardBorderType()),
				" ",
				rarityName,
				" ",
				LocalizationManager.GetTranslation("Foil", true, 0, true, false, null, null, true)
			});
		}
		else
		{
			if (ignoreRarity)
			{
				return CPlayerData.GetCardBorderName(cardData.GetCardBorderType());
			}
			return CPlayerData.GetCardBorderName(cardData.GetCardBorderType()) + " " + rarityName;
		}
	}

	// Token: 0x06000696 RID: 1686 RVA: 0x000373D8 File Offset: 0x000355D8
	public static int GetCardAmount(CardData cardData)
	{
		int cardSaveIndex = CPlayerData.GetCardSaveIndex(cardData);
		return CPlayerData.GetCardCollectedList(cardData.expansionType, cardData.isDestiny)[cardSaveIndex];
	}

	// Token: 0x06000697 RID: 1687 RVA: 0x00037403 File Offset: 0x00035603
	public static int GetCardAmountByIndex(int index, ECardExpansionType cardExpansionType, bool isDimensionCard)
	{
		return CPlayerData.GetCardCollectedList(cardExpansionType, isDimensionCard)[index];
	}

	// Token: 0x06000698 RID: 1688 RVA: 0x00037414 File Offset: 0x00035614
	public static int GetCardFameAmount(CardData cardData)
	{
		int num = 1;
		ERarity rarity = InventoryBase.GetMonsterData(cardData.monsterType).Rarity;
		if (cardData.GetCardBorderType() == ECardBorderType.Base)
		{
			num = 1;
		}
		else if (cardData.GetCardBorderType() == ECardBorderType.FirstEdition)
		{
			num = 5;
		}
		else if (cardData.GetCardBorderType() == ECardBorderType.Silver)
		{
			num = 10;
		}
		else if (cardData.GetCardBorderType() == ECardBorderType.Gold)
		{
			num = 20;
		}
		else if (cardData.GetCardBorderType() == ECardBorderType.EX)
		{
			num = 50;
		}
		else if (cardData.GetCardBorderType() == ECardBorderType.FullArt)
		{
			num = 200;
		}
		if (rarity == ERarity.Common)
		{
			num = num;
		}
		else if (rarity == ERarity.Rare)
		{
			num += 5;
		}
		else if (rarity == ERarity.Epic)
		{
			num += 15;
		}
		else if (rarity == ERarity.Legendary)
		{
			num += 40;
		}
		if (cardData.expansionType == ECardExpansionType.Tetramon)
		{
			num = num;
		}
		else if (cardData.expansionType == ECardExpansionType.Destiny)
		{
			num = 9 + Mathf.RoundToInt((float)num * 1.25f);
		}
		else if (cardData.expansionType == ECardExpansionType.Ghost)
		{
			num = 18 + Mathf.RoundToInt((float)num * 2f);
		}
		else if (cardData.expansionType == ECardExpansionType.Megabot)
		{
			num = 13 + Mathf.RoundToInt((float)num * 1.4f);
		}
		else if (cardData.expansionType == ECardExpansionType.FantasyRPG)
		{
			num = 13 + Mathf.RoundToInt((float)num * 1.1f);
		}
		else if (cardData.expansionType == ECardExpansionType.CatJob)
		{
			num = 1 + Mathf.RoundToInt((float)num * 1.02f);
		}
		num = Mathf.RoundToInt((float)num * (1f + (float)cardData.GetCardBorderType() * 0.25f));
		if (cardData.isFoil)
		{
			num = (int)(num + ((cardData.GetCardBorderType() + 1) * ECardBorderType.FullArt * (cardData.GetCardBorderType() + 1) + (int)cardData.GetCardBorderType()));
			num = Mathf.RoundToInt((float)num * 2.5f);
		}
		return num;
	}

	// Token: 0x06000699 RID: 1689 RVA: 0x00037593 File Offset: 0x00035793
	public static bool IsCardUnlocked(ECardExpansionType cardExpansionType, int index, bool isDimensionCard)
	{
		return CPlayerData.GetCardCollectedList(cardExpansionType, isDimensionCard)[index] >= 1;
	}

	// Token: 0x0600069A RID: 1690 RVA: 0x000375A8 File Offset: 0x000357A8
	public static bool HasEnoughCardAmount(ECardExpansionType cardExpansionType, int index, int amount, bool isDimensionCard)
	{
		return CPlayerData.GetCardCollectedList(cardExpansionType, isDimensionCard)[index] >= amount;
	}

	// Token: 0x0600069B RID: 1691 RVA: 0x000375BD File Offset: 0x000357BD
	public static int GetTotalCardCollectedAmount()
	{
		return 0 + CPlayerData.GetCardCollectedAmount(ECardExpansionType.Tetramon, false) + CPlayerData.GetCardCollectedAmount(ECardExpansionType.Destiny, true) + CPlayerData.GetCardCollectedAmount(ECardExpansionType.Ghost, false) + CPlayerData.GetCardCollectedAmount(ECardExpansionType.Ghost, true) + CPlayerData.GetCardCollectedAmount(ECardExpansionType.Megabot, false) + CPlayerData.GetCardCollectedAmount(ECardExpansionType.FantasyRPG, false) + CPlayerData.GetCardCollectedAmount(ECardExpansionType.CatJob, false);
	}

	// Token: 0x0600069C RID: 1692 RVA: 0x000375F8 File Offset: 0x000357F8
	public static int GetCardCollectedAmount(ECardExpansionType cardExpansionType, bool isDimensionCard)
	{
		int num = 0;
		for (int i = 0; i < CPlayerData.GetCardCollectedList(cardExpansionType, isDimensionCard).Count; i++)
		{
			if (CPlayerData.GetCardCollectedList(cardExpansionType, isDimensionCard)[i] >= 1)
			{
				num++;
			}
		}
		return num;
	}

	// Token: 0x0600069D RID: 1693 RVA: 0x00037634 File Offset: 0x00035834
	public static float GetCardAlbumTotalValue(ECardExpansionType cardExpansionType, bool isDimensionCard)
	{
		float num = 0f;
		for (int i = 0; i < CPlayerData.GetCardCollectedList(cardExpansionType, isDimensionCard).Count; i++)
		{
			num += CPlayerData.GetCardMarketPrice(i, cardExpansionType, isDimensionCard) * (float)CPlayerData.GetCardCollectedList(cardExpansionType, isDimensionCard)[i];
		}
		return num;
	}

	// Token: 0x0600069E RID: 1694 RVA: 0x0003767C File Offset: 0x0003587C
	public static BillData GetBill(EBillType billType)
	{
		for (int i = 0; i < CPlayerData.m_BillList.Count; i++)
		{
			if (CPlayerData.m_BillList[i].billType == billType)
			{
				return CPlayerData.m_BillList[i];
			}
		}
		BillData billData = new BillData();
		billData.billType = billType;
		CPlayerData.m_BillList.Add(billData);
		return billData;
	}

	// Token: 0x0600069F RID: 1695 RVA: 0x000376D8 File Offset: 0x000358D8
	public static void UpdateBill(EBillType billType, int dueDayChange, float amountToPayChange)
	{
		int i = 0;
		while (i < CPlayerData.m_BillList.Count)
		{
			if (CPlayerData.m_BillList[i].billType == billType)
			{
				if (amountToPayChange > 0f || CPlayerData.m_BillList[i].billDayPassed > 0)
				{
					CPlayerData.m_BillList[i].billDayPassed += dueDayChange;
					CPlayerData.m_BillList[i].amountToPay += amountToPayChange;
					return;
				}
				break;
			}
			else
			{
				i++;
			}
		}
	}

	// Token: 0x060006A0 RID: 1696 RVA: 0x0003775C File Offset: 0x0003595C
	public static void SetBill(EBillType billType, int dayPassed, float amountToPay)
	{
		for (int i = 0; i < CPlayerData.m_BillList.Count; i++)
		{
			if (CPlayerData.m_BillList[i].billType == billType)
			{
				CPlayerData.m_BillList[i].billDayPassed = dayPassed;
				CPlayerData.m_BillList[i].amountToPay = amountToPay;
				return;
			}
		}
	}

	// Token: 0x060006A1 RID: 1697 RVA: 0x000377B4 File Offset: 0x000359B4
	private void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_SetCoin>(new CEventManager.EventDelegate<CEventPlayer_SetCoin>(this.CPlayer_OnSetCoin));
			CEventManager.AddListener<CEventPlayer_AddCoin>(new CEventManager.EventDelegate<CEventPlayer_AddCoin>(this.CPlayer_OnAddCoin));
			CEventManager.AddListener<CEventPlayer_ReduceCoin>(new CEventManager.EventDelegate<CEventPlayer_ReduceCoin>(this.CPlayer_OnReduceCoin));
			CEventManager.AddListener<CEventPlayer_AddFame>(new CEventManager.EventDelegate<CEventPlayer_AddFame>(this.CPlayer_OnAddFame));
			CEventManager.AddListener<CEventPlayer_SetFame>(new CEventManager.EventDelegate<CEventPlayer_SetFame>(this.CPlayer_OnSetFame));
			CEventManager.AddListener<CEventPlayer_AddShopExp>(new CEventManager.EventDelegate<CEventPlayer_AddShopExp>(this.CPlayer_OnAddShopExp));
			CEventManager.AddListener<CEventPlayer_SetShopExp>(new CEventManager.EventDelegate<CEventPlayer_SetShopExp>(this.CPlayer_OnSetShopExp));
			CEventManager.AddListener<CEventPlayer_ChangeScene>(new CEventManager.EventDelegate<CEventPlayer_ChangeScene>(this.CPlayer_OnChangeScene));
		}
	}

	// Token: 0x060006A2 RID: 1698 RVA: 0x0003785C File Offset: 0x00035A5C
	private void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_SetCoin>(new CEventManager.EventDelegate<CEventPlayer_SetCoin>(this.CPlayer_OnSetCoin));
			CEventManager.RemoveListener<CEventPlayer_AddCoin>(new CEventManager.EventDelegate<CEventPlayer_AddCoin>(this.CPlayer_OnAddCoin));
			CEventManager.RemoveListener<CEventPlayer_ReduceCoin>(new CEventManager.EventDelegate<CEventPlayer_ReduceCoin>(this.CPlayer_OnReduceCoin));
			CEventManager.RemoveListener<CEventPlayer_AddFame>(new CEventManager.EventDelegate<CEventPlayer_AddFame>(this.CPlayer_OnAddFame));
			CEventManager.RemoveListener<CEventPlayer_SetFame>(new CEventManager.EventDelegate<CEventPlayer_SetFame>(this.CPlayer_OnSetFame));
			CEventManager.RemoveListener<CEventPlayer_AddShopExp>(new CEventManager.EventDelegate<CEventPlayer_AddShopExp>(this.CPlayer_OnAddShopExp));
			CEventManager.RemoveListener<CEventPlayer_SetShopExp>(new CEventManager.EventDelegate<CEventPlayer_SetShopExp>(this.CPlayer_OnSetShopExp));
			CEventManager.RemoveListener<CEventPlayer_ChangeScene>(new CEventManager.EventDelegate<CEventPlayer_ChangeScene>(this.CPlayer_OnChangeScene));
		}
	}

	// Token: 0x060006A3 RID: 1699 RVA: 0x00037902 File Offset: 0x00035B02
	private void CPlayer_OnChangeScene(CEventPlayer_ChangeScene evt)
	{
		CPlayerData.m_CurrentLevelName = evt.m_SceneName;
	}

	// Token: 0x060006A4 RID: 1700 RVA: 0x0003790F File Offset: 0x00035B0F
	private void CPlayer_OnAddCoin(CEventPlayer_AddCoin evt)
	{
		CPlayerData.m_CoinAmount += evt.m_CoinValue;
		if (CPlayerData.m_CoinAmount < -100000000f)
		{
			CPlayerData.m_CoinAmount = 0f;
			CEventManager.QueueEvent(new CEventPlayer_SetCoin(0f));
		}
	}

	// Token: 0x060006A5 RID: 1701 RVA: 0x00037947 File Offset: 0x00035B47
	private void CPlayer_OnReduceCoin(CEventPlayer_ReduceCoin evt)
	{
		CPlayerData.m_CoinAmount -= evt.m_CoinValue;
	}

	// Token: 0x060006A6 RID: 1702 RVA: 0x0003795A File Offset: 0x00035B5A
	private void CPlayer_OnSetCoin(CEventPlayer_SetCoin evt)
	{
		CPlayerData.m_CoinAmount = evt.m_CoinValue;
	}

	// Token: 0x060006A7 RID: 1703 RVA: 0x00037967 File Offset: 0x00035B67
	private void CPlayer_OnAddFame(CEventPlayer_AddFame evt)
	{
		CPlayerData.m_FamePoint += evt.m_FameValue;
		CPlayerData.m_FamePoint = Mathf.Clamp(CPlayerData.m_FamePoint, 0, 99999999);
		CPlayerData.m_TotalFameAdd += evt.m_FameValue;
	}

	// Token: 0x060006A8 RID: 1704 RVA: 0x000379A0 File Offset: 0x00035BA0
	private void CPlayer_OnSetFame(CEventPlayer_SetFame evt)
	{
		CPlayerData.m_FamePoint = evt.m_FameValue;
		CPlayerData.m_FamePoint = Mathf.Clamp(CPlayerData.m_FamePoint, 0, 99999999);
	}

	// Token: 0x060006A9 RID: 1705 RVA: 0x000379C4 File Offset: 0x00035BC4
	private void CPlayer_OnAddShopExp(CEventPlayer_AddShopExp evt)
	{
		CPlayerData.m_ShopExpPoint += evt.m_ExpValue;
		CPlayerData.m_GameReportDataCollect.storeExpGained = CPlayerData.m_GameReportDataCollect.storeExpGained + evt.m_ExpValue;
		CPlayerData.m_GameReportDataCollectPermanent.storeExpGained = CPlayerData.m_GameReportDataCollectPermanent.storeExpGained + evt.m_ExpValue;
		bool flag = false;
		while (CPlayerData.m_ShopExpPoint >= CPlayerData.GetExpRequiredToLevelUp())
		{
			CPlayerData.m_ShopExpPoint -= CPlayerData.GetExpRequiredToLevelUp();
			CPlayerData.m_ShopLevel++;
			CPlayerData.m_GameReportDataCollect.storeLevelGained = CPlayerData.m_GameReportDataCollect.storeLevelGained + 1;
			CPlayerData.m_GameReportDataCollectPermanent.storeLevelGained = CPlayerData.m_GameReportDataCollectPermanent.storeLevelGained + 1;
			flag = true;
			TutorialManager.AddTaskValue(ETutorialTaskCondition.ShopLevel, 1f);
			UnityAnalytic.ShopLevelUp(CPlayerData.m_ShopLevel);
		}
		if (flag)
		{
			CEventManager.QueueEvent(new CEventPlayer_ShopLeveledUp(CPlayerData.m_ShopLevel));
		}
	}

	// Token: 0x060006AA RID: 1706 RVA: 0x00037A80 File Offset: 0x00035C80
	private void CPlayer_OnSetShopExp(CEventPlayer_SetShopExp evt)
	{
		CPlayerData.m_ShopExpPoint = evt.m_ExpValue;
		bool flag = false;
		while (CPlayerData.m_ShopExpPoint >= CPlayerData.GetExpRequiredToLevelUp())
		{
			CPlayerData.m_ShopExpPoint -= CPlayerData.GetExpRequiredToLevelUp();
			CPlayerData.m_ShopLevel++;
			flag = true;
		}
		if (flag)
		{
			CEventManager.QueueEvent(new CEventPlayer_ShopLeveledUp(CPlayerData.m_ShopLevel));
		}
	}

	// Token: 0x060006AB RID: 1707 RVA: 0x00037AD8 File Offset: 0x00035CD8
	public static bool CheckAuthGameID()
	{
		return CPlayerData.m_AuthGameID == "AS394nGOA@laen083KAWmp439-24905we#*%&^jawr84jiR#(JIOI#TRQ*(#)TR*(Q#INTRHereaaerea";
	}

	// Token: 0x04000876 RID: 2166
	public static CPlayerData m_Instance = null;

	// Token: 0x04000877 RID: 2167
	public static ELevelName m_CurrentLevelName = ELevelName.Start;

	// Token: 0x04000878 RID: 2168
	public static int m_SaveIndex = 0;

	// Token: 0x04000879 RID: 2169
	public static int m_SaveCycle = 0;

	// Token: 0x0400087A RID: 2170
	public static string m_LastLoginPlayfabID = "";

	// Token: 0x0400087B RID: 2171
	public static bool m_CanCloudLoad = true;

	// Token: 0x0400087C RID: 2172
	public static float m_SkyboxBlendValue = 0f;

	// Token: 0x0400087D RID: 2173
	public static LightTimeData m_LightTimeData;

	// Token: 0x0400087E RID: 2174
	public static EGameEventFormat m_GameEventFormat = EGameEventFormat.Standard;

	// Token: 0x0400087F RID: 2175
	public static EGameEventFormat m_PendingGameEventFormat = EGameEventFormat.None;

	// Token: 0x04000880 RID: 2176
	public static ECardExpansionType m_GameEventExpansionType = ECardExpansionType.Tetramon;

	// Token: 0x04000881 RID: 2177
	public static ECardExpansionType m_PendingGameEventExpansionType = ECardExpansionType.Tetramon;

	// Token: 0x04000882 RID: 2178
	public static GameReportDataCollect m_GameReportDataCollectPermanent = default(GameReportDataCollect);

	// Token: 0x04000883 RID: 2179
	public static GameReportDataCollect m_GameReportDataCollect = default(GameReportDataCollect);

	// Token: 0x04000884 RID: 2180
	public static List<GameReportDataCollect> m_GameReportDataCollectPastList = new List<GameReportDataCollect>();

	// Token: 0x04000885 RID: 2181
	public static List<ShelfSaveData> m_ShelfSaveDataList = new List<ShelfSaveData>();

	// Token: 0x04000886 RID: 2182
	public static List<WarehouseShelfSaveData> m_WarehouseShelfSaveDataList = new List<WarehouseShelfSaveData>();

	// Token: 0x04000887 RID: 2183
	public static List<PackageBoxItemaveData> m_PackageBoxItemSaveDataList = new List<PackageBoxItemaveData>();

	// Token: 0x04000888 RID: 2184
	public static List<InteractableObjectSaveData> m_InteractableObjectSaveDataList = new List<InteractableObjectSaveData>();

	// Token: 0x04000889 RID: 2185
	public static List<CardShelfSaveData> m_CardShelfSaveDataList = new List<CardShelfSaveData>();

	// Token: 0x0400088A RID: 2186
	public static List<PlayTableSaveData> m_PlayTableSaveDataList = new List<PlayTableSaveData>();

	// Token: 0x0400088B RID: 2187
	public static List<AutoCleanserSaveData> m_AutoCleanserSaveDataList = new List<AutoCleanserSaveData>();

	// Token: 0x0400088C RID: 2188
	public static List<WorkbenchSaveData> m_WorkbenchSaveDataList = new List<WorkbenchSaveData>();

	// Token: 0x0400088D RID: 2189
	public static List<CustomerSaveData> m_CustomerSaveDataList = new List<CustomerSaveData>();

	// Token: 0x0400088E RID: 2190
	public static List<WorkerSaveData> m_WorkerSaveDataList = new List<WorkerSaveData>();

	// Token: 0x0400088F RID: 2191
	public static List<TutorialData> m_TutorialDataList = new List<TutorialData>();

	// Token: 0x04000890 RID: 2192
	public static List<BillData> m_BillList = new List<BillData>();

	// Token: 0x04000891 RID: 2193
	public static List<CardData> m_HoldCardDataList = new List<CardData>();

	// Token: 0x04000892 RID: 2194
	public static List<EItemType> m_HoldItemTypeList = new List<EItemType>();

	// Token: 0x04000893 RID: 2195
	public static bool m_IsShopOpen = false;

	// Token: 0x04000894 RID: 2196
	public static bool m_IsShopOnceOpen = false;

	// Token: 0x04000895 RID: 2197
	public static bool m_IsWarehouseDoorClosed = false;

	// Token: 0x04000896 RID: 2198
	public static bool m_IsItemPriceGenerated = false;

	// Token: 0x04000897 RID: 2199
	public static bool m_IsCardPriceGenerated = false;

	// Token: 0x04000898 RID: 2200
	public static List<int> m_CurrentTotalItemCountList = new List<int>();

	// Token: 0x04000899 RID: 2201
	public static List<float> m_SetItemPriceList = new List<float>();

	// Token: 0x0400089A RID: 2202
	public static List<float> m_AverageItemCostList = new List<float>();

	// Token: 0x0400089B RID: 2203
	public static List<float> m_GeneratedCostPriceList = new List<float>();

	// Token: 0x0400089C RID: 2204
	public static List<float> m_GeneratedMarketPriceList = new List<float>();

	// Token: 0x0400089D RID: 2205
	public static List<float> m_ItemPricePercentChangeList = new List<float>();

	// Token: 0x0400089E RID: 2206
	public static List<FloatList> m_ItemPricePercentPastChangeList = new List<FloatList>();

	// Token: 0x0400089F RID: 2207
	public static List<float> m_SetGameEventPriceList = new List<float>();

	// Token: 0x040008A0 RID: 2208
	public static List<float> m_GeneratedGameEventPriceList = new List<float>();

	// Token: 0x040008A1 RID: 2209
	public static List<float> m_GameEventPricePercentChangeList = new List<float>();

	// Token: 0x040008A2 RID: 2210
	public static List<int> m_StockSoldList = new List<int>();

	// Token: 0x040008A3 RID: 2211
	public static List<int> m_CollectionCardPackCountList = new List<int>();

	// Token: 0x040008A4 RID: 2212
	public static List<int> m_CardCollectedList = new List<int>();

	// Token: 0x040008A5 RID: 2213
	public static List<int> m_CardCollectedListDestiny = new List<int>();

	// Token: 0x040008A6 RID: 2214
	public static List<int> m_CardCollectedListGhost = new List<int>();

	// Token: 0x040008A7 RID: 2215
	public static List<int> m_CardCollectedListGhostBlack = new List<int>();

	// Token: 0x040008A8 RID: 2216
	public static List<int> m_CardCollectedListMegabot = new List<int>();

	// Token: 0x040008A9 RID: 2217
	public static List<int> m_CardCollectedListFantasyRPG = new List<int>();

	// Token: 0x040008AA RID: 2218
	public static List<int> m_CardCollectedListCatJob = new List<int>();

	// Token: 0x040008AB RID: 2219
	public static List<bool> m_IsCardCollectedList = new List<bool>();

	// Token: 0x040008AC RID: 2220
	public static List<bool> m_IsCardCollectedListDestiny = new List<bool>();

	// Token: 0x040008AD RID: 2221
	public static List<bool> m_IsCardCollectedListGhost = new List<bool>();

	// Token: 0x040008AE RID: 2222
	public static List<bool> m_IsCardCollectedListGhostBlack = new List<bool>();

	// Token: 0x040008AF RID: 2223
	public static List<bool> m_IsCardCollectedListMegabot = new List<bool>();

	// Token: 0x040008B0 RID: 2224
	public static List<bool> m_IsCardCollectedListFantasyRPG = new List<bool>();

	// Token: 0x040008B1 RID: 2225
	public static List<bool> m_IsCardCollectedListCatJob = new List<bool>();

	// Token: 0x040008B2 RID: 2226
	public static List<float> m_CardPriceSetList = new List<float>();

	// Token: 0x040008B3 RID: 2227
	public static List<float> m_CardPriceSetListDestiny = new List<float>();

	// Token: 0x040008B4 RID: 2228
	public static List<float> m_CardPriceSetListGhost = new List<float>();

	// Token: 0x040008B5 RID: 2229
	public static List<float> m_CardPriceSetListGhostBlack = new List<float>();

	// Token: 0x040008B6 RID: 2230
	public static List<float> m_CardPriceSetListMegabot = new List<float>();

	// Token: 0x040008B7 RID: 2231
	public static List<float> m_CardPriceSetListFantasyRPG = new List<float>();

	// Token: 0x040008B8 RID: 2232
	public static List<float> m_CardPriceSetListCatJob = new List<float>();

	// Token: 0x040008B9 RID: 2233
	public static List<MarketPrice> m_GenCardMarketPriceList = new List<MarketPrice>();

	// Token: 0x040008BA RID: 2234
	public static List<MarketPrice> m_GenCardMarketPriceListDestiny = new List<MarketPrice>();

	// Token: 0x040008BB RID: 2235
	public static List<MarketPrice> m_GenCardMarketPriceListGhost = new List<MarketPrice>();

	// Token: 0x040008BC RID: 2236
	public static List<MarketPrice> m_GenCardMarketPriceListGhostBlack = new List<MarketPrice>();

	// Token: 0x040008BD RID: 2237
	public static List<MarketPrice> m_GenCardMarketPriceListMegabot = new List<MarketPrice>();

	// Token: 0x040008BE RID: 2238
	public static List<MarketPrice> m_GenCardMarketPriceListFantasyRPG = new List<MarketPrice>();

	// Token: 0x040008BF RID: 2239
	public static List<MarketPrice> m_GenCardMarketPriceListCatJob = new List<MarketPrice>();

	// Token: 0x040008C0 RID: 2240
	public static List<int> m_CollectionSortingMethodIndexList = new List<int>();

	// Token: 0x040008C1 RID: 2241
	public static List<int> m_ChampionCardCollectedList = new List<int>();

	// Token: 0x040008C2 RID: 2242
	public static List<bool> m_IsItemLicenseUnlocked = new List<bool>();

	// Token: 0x040008C3 RID: 2243
	public static List<bool> m_IsWorkerHired = new List<bool>();

	// Token: 0x040008C4 RID: 2244
	public static List<bool> m_IsAchievementUnlocked = new List<bool>();

	// Token: 0x040008C5 RID: 2245
	public static bool m_IsWarehouseRoomUnlocked = false;

	// Token: 0x040008C6 RID: 2246
	public static int m_UnlockRoomCount = 0;

	// Token: 0x040008C7 RID: 2247
	public static int m_UnlockWarehouseRoomCount = 0;

	// Token: 0x040008C8 RID: 2248
	public static int m_TotalFameAdd = 0;

	// Token: 0x040008C9 RID: 2249
	public static int m_CurrentDay = 0;

	// Token: 0x040008CA RID: 2250
	public static int m_ShopExpPoint = 0;

	// Token: 0x040008CB RID: 2251
	public static int m_ShopLevel = 0;

	// Token: 0x040008CC RID: 2252
	public static int m_WorkbenchMinimumCardLimit = 4;

	// Token: 0x040008CD RID: 2253
	public static float m_WorkbenchPriceLimit = 0.5f;

	// Token: 0x040008CE RID: 2254
	public static ERarity m_WorkbenchRarityLimit = ERarity.None;

	// Token: 0x040008CF RID: 2255
	public static ECardExpansionType m_WorkbenchCardExpansionType = ECardExpansionType.Tetramon;

	// Token: 0x040008D0 RID: 2256
	public static DateTime m_LastLocalExitTime;

	// Token: 0x040008D1 RID: 2257
	public static DateTime m_StarterOfferStartTime;

	// Token: 0x040008D2 RID: 2258
	public static int m_TotalCoinAmount = 0;

	// Token: 0x040008D3 RID: 2259
	public static string m_DebugString = "";

	// Token: 0x040008D4 RID: 2260
	public static string m_DebugString2 = "";

	// Token: 0x040008D5 RID: 2261
	private static string m_PlayerName;

	// Token: 0x040008D6 RID: 2262
	public static float m_CoinAmount = 0f;

	// Token: 0x040008D7 RID: 2263
	public static int m_FamePoint = 0;

	// Token: 0x040008D8 RID: 2264
	public static int m_CloudSaveCountdown = 0;

	// Token: 0x040008D9 RID: 2265
	public static DateTime m_LoginServerTime;

	// Token: 0x040008DA RID: 2266
	public static float m_MusicVolumeDecrease;

	// Token: 0x040008DB RID: 2267
	public static float m_SoundVolumeDecrease;

	// Token: 0x040008DC RID: 2268
	public static int m_TutorialIndex = 0;

	// Token: 0x040008DD RID: 2269
	public static int m_TutorialSubgroupIndex = 0;

	// Token: 0x040008DE RID: 2270
	public static bool m_HasFinishedTutorial = false;

	// Token: 0x040008DF RID: 2271
	public static bool m_IsMainGame = true;

	// Token: 0x040008E0 RID: 2272
	public static int m_UserSegmentIndex = 0;

	// Token: 0x040008E1 RID: 2273
	public static bool m_HasGetGhostCard = false;

	// Token: 0x040008E2 RID: 2274
	public static string m_AuthGameID = "AS394nGOA@laen083KAWmp439-24905we#*%&^jawr84jiR#(JIOI#TRQ*(#)TR*(Q#INTRHereaaerea";
}
