﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x0200011E RID: 286
public class DebugTextTest : CSingleton<DebugTextTest>
{
	// Token: 0x06000865 RID: 2149 RVA: 0x0003FA98 File Offset: 0x0003DC98
	private void Awake()
	{
		if (DebugTextTest.m_Instance == null)
		{
			DebugTextTest.m_Instance = this;
		}
		else if (DebugTextTest.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		if (base.transform.root == base.transform)
		{
			Object.DontDestroyOnLoad(this);
		}
	}

	// Token: 0x06000866 RID: 2150 RVA: 0x0003FAF0 File Offset: 0x0003DCF0
	public static void PrintText2(string text)
	{
	}

	// Token: 0x06000867 RID: 2151 RVA: 0x0003FAF2 File Offset: 0x0003DCF2
	public static void PrintText(string text)
	{
	}

	// Token: 0x0400103B RID: 4155
	public static DebugTextTest m_Instance;

	// Token: 0x0400103C RID: 4156
	public TextMeshProUGUI m_Text;

	// Token: 0x0400103D RID: 4157
	public TextMeshProUGUI m_Text2;

	// Token: 0x0400103E RID: 4158
	private static string m_CurrentString;

	// Token: 0x0400103F RID: 4159
	private static int m_StringCount;
}
