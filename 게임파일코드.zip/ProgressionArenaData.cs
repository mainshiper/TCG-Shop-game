﻿using System;
using I2.Loc;
using UnityEngine;

// Token: 0x0200012F RID: 303
[Serializable]
public struct ProgressionArenaData
{
	// Token: 0x060008EC RID: 2284 RVA: 0x000426A2 File Offset: 0x000408A2
	public string GetArenaName()
	{
		return LocalizationManager.GetTranslation(this.m_ArenaTitle, true, 0, true, false, null, null, true);
	}

	// Token: 0x060008ED RID: 2285 RVA: 0x000426B8 File Offset: 0x000408B8
	public string GetArenaNumberText(int index)
	{
		string result;
		if (index == -1)
		{
			result = LocalizationManager.GetTranslation("Beginner Arena", true, 0, true, false, null, null, true);
		}
		else
		{
			result = LocalizationManager.GetTranslation("Arena", true, 0, true, false, null, null, true) + " " + (index + 1).ToString();
		}
		return result;
	}

	// Token: 0x040010F0 RID: 4336
	public int m_UnlockMMR;

	// Token: 0x040010F1 RID: 4337
	public Sprite m_ArenaImage;

	// Token: 0x040010F2 RID: 4338
	public string m_ArenaTitle;
}
