﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000A9 RID: 169
public class CEventManager : CSingleton<CEventManager>
{
	// Token: 0x060006C4 RID: 1732 RVA: 0x000388A1 File Offset: 0x00036AA1
	protected CEventManager()
	{
	}

	// Token: 0x060006C5 RID: 1733 RVA: 0x000388CC File Offset: 0x00036ACC
	private void Update()
	{
		float num = 0f;
		while (this.m_queueEvent.Count > 0)
		{
			if (this.m_limitQueueProcessing && num > this.m_queueProcessTime)
			{
				return;
			}
			CEvent evt = this.m_queueEvent.Dequeue() as CEvent;
			this.OnNotify(evt);
			if (this.m_limitQueueProcessing)
			{
				num += Time.deltaTime;
			}
		}
	}

	// Token: 0x060006C6 RID: 1734 RVA: 0x00038929 File Offset: 0x00036B29
	public static void QueueEvent(CEvent evt)
	{
		if ((Application.isPlaying || Application.isMobilePlatform) && !CSingleton<CEventManager>.IsQuitting)
		{
			CSingleton<CEventManager>.Instance.QueueEventPrivate(evt);
		}
	}

	// Token: 0x060006C7 RID: 1735 RVA: 0x0003894C File Offset: 0x00036B4C
	public static void AddListener<T>(CEventManager.EventDelegate<T> listener) where T : CEvent
	{
		if ((Application.isPlaying || Application.isMobilePlatform) && !CSingleton<CEventManager>.IsQuitting)
		{
			CSingleton<CEventManager>.Instance.AddListenerPrivate<T>(listener);
		}
	}

	// Token: 0x060006C8 RID: 1736 RVA: 0x0003896E File Offset: 0x00036B6E
	public static void RemoveListener<T>(CEventManager.EventDelegate<T> listener) where T : CEvent
	{
		if ((Application.isPlaying || Application.isMobilePlatform) && !CSingleton<CEventManager>.IsQuitting)
		{
			CSingleton<CEventManager>.Instance.RemoveListenerPrivate<T>(listener);
		}
	}

	// Token: 0x060006C9 RID: 1737 RVA: 0x00038990 File Offset: 0x00036B90
	private void AddListenerPrivate<T>(CEventManager.EventDelegate<T> listener) where T : CEvent
	{
		if (this.m_listenerLookup.ContainsKey(listener))
		{
			return;
		}
		CEventManager.EventDelegate eventDelegate = delegate(CEvent e)
		{
			listener((T)((object)e));
		};
		this.m_listenerLookup[listener] = eventDelegate;
		CEventManager.EventDelegate a;
		if (this.m_listeners.TryGetValue(typeof(T), out a))
		{
			a = (this.m_listeners[typeof(T)] = (CEventManager.EventDelegate)Delegate.Combine(a, eventDelegate));
			return;
		}
		this.m_listeners[typeof(T)] = eventDelegate;
	}

	// Token: 0x060006CA RID: 1738 RVA: 0x00038A30 File Offset: 0x00036C30
	public void RemoveListenerPrivate<T>(CEventManager.EventDelegate<T> listener) where T : CEvent
	{
		CEventManager.EventDelegate value;
		if (this.m_listenerLookup.TryGetValue(listener, out value))
		{
			CEventManager.EventDelegate eventDelegate;
			if (this.m_listeners.TryGetValue(typeof(T), out eventDelegate))
			{
				eventDelegate = (CEventManager.EventDelegate)Delegate.Remove(eventDelegate, value);
				if (eventDelegate == null)
				{
					this.m_listeners.Remove(typeof(T));
				}
				else
				{
					this.m_listeners[typeof(T)] = eventDelegate;
				}
			}
			this.m_listenerLookup.Remove(listener);
		}
	}

	// Token: 0x060006CB RID: 1739 RVA: 0x00038AB1 File Offset: 0x00036CB1
	public bool HasListener<T>(CEventManager.EventDelegate<T> listener) where T : CEvent
	{
		return this.m_listenerLookup.ContainsKey(listener);
	}

	// Token: 0x060006CC RID: 1740 RVA: 0x00038AC0 File Offset: 0x00036CC0
	private void OnNotify(CEvent evt)
	{
		CEventManager.EventDelegate eventDelegate;
		if (this.m_listeners.TryGetValue(evt.GetType(), out eventDelegate) && eventDelegate != null)
		{
			eventDelegate(evt);
		}
	}

	// Token: 0x060006CD RID: 1741 RVA: 0x00038AEC File Offset: 0x00036CEC
	private bool QueueEventPrivate(CEvent evt)
	{
		if (!this.m_listeners.ContainsKey(evt.GetType()))
		{
			return false;
		}
		this.m_queueEvent.Enqueue(evt);
		return true;
	}

	// Token: 0x060006CE RID: 1742 RVA: 0x00038B10 File Offset: 0x00036D10
	private void RemoveAll()
	{
		this.m_listeners.Clear();
		this.m_listenerLookup.Clear();
	}

	// Token: 0x04000902 RID: 2306
	public bool m_limitQueueProcessing;

	// Token: 0x04000903 RID: 2307
	public float m_queueProcessTime;

	// Token: 0x04000904 RID: 2308
	private Queue m_queueEvent = new Queue();

	// Token: 0x04000905 RID: 2309
	private Dictionary<Type, CEventManager.EventDelegate> m_listeners = new Dictionary<Type, CEventManager.EventDelegate>();

	// Token: 0x04000906 RID: 2310
	private Dictionary<Delegate, CEventManager.EventDelegate> m_listenerLookup = new Dictionary<Delegate, CEventManager.EventDelegate>();

	// Token: 0x0200022A RID: 554
	// (Invoke) Token: 0x06000F1A RID: 3866
	public delegate void EventDelegate<T>(T e) where T : CEvent;

	// Token: 0x0200022B RID: 555
	// (Invoke) Token: 0x06000F1E RID: 3870
	private delegate void EventDelegate(CEvent e);
}
