﻿using System;
using UnityEngine;

// Token: 0x020000A4 RID: 164
[Serializable]
public struct Vector3Serializer
{
	// Token: 0x060006AD RID: 1709 RVA: 0x00037E77 File Offset: 0x00036077
	public void SetData(Vector3 v3)
	{
		this.x = v3.x;
		this.y = v3.y;
		this.z = v3.z;
	}

	// Token: 0x17000004 RID: 4
	// (get) Token: 0x060006AE RID: 1710 RVA: 0x00037E9D File Offset: 0x0003609D
	public Vector3 Data
	{
		get
		{
			return new Vector3(this.x, this.y, this.z);
		}
	}

	// Token: 0x040008E3 RID: 2275
	public float x;

	// Token: 0x040008E4 RID: 2276
	public float y;

	// Token: 0x040008E5 RID: 2277
	public float z;
}
