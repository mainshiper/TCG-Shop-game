﻿using System;

// Token: 0x02000029 RID: 41
public class InteractableStorageCompartment : InteractableObject
{
	// Token: 0x06000227 RID: 551 RVA: 0x00015431 File Offset: 0x00013631
	public void InitWarehouseShelf(WarehouseShelf warehouseShelf, ShelfCompartment shelfCompartment, int index)
	{
		this.m_WarehouseShelf = warehouseShelf;
		this.m_ShelfCompartment = shelfCompartment;
		this.m_ShelfCompartment.SetIndex(index);
		this.m_ShelfCompartment.SetWarehouseShelf(this.m_WarehouseShelf);
	}

	// Token: 0x06000228 RID: 552 RVA: 0x00015460 File Offset: 0x00013660
	public override void OnMouseButtonUp()
	{
		if (this.m_ShelfCompartment.GetInteractablePackagingBoxList().Count > 0)
		{
			InteractablePackagingBox_Item lastInteractablePackagingBox = this.m_ShelfCompartment.GetLastInteractablePackagingBox();
			if (lastInteractablePackagingBox.CanPickup())
			{
				lastInteractablePackagingBox.StartHoldBox(true, CSingleton<InteractionPlayerController>.Instance.m_HoldItemPos);
				this.m_ShelfCompartment.RemoveBox(lastInteractablePackagingBox);
			}
		}
	}

	// Token: 0x06000229 RID: 553 RVA: 0x000154B4 File Offset: 0x000136B4
	public void DisableAllItem()
	{
		for (int i = 0; i < this.m_ShelfCompartment.GetInteractablePackagingBoxList().Count; i++)
		{
			if (this.m_ShelfCompartment.GetInteractablePackagingBoxList()[i])
			{
				this.m_ShelfCompartment.GetInteractablePackagingBoxList()[i].m_ItemCompartment.DisableAllItem();
			}
			RestockManager.RemoveItemPackageBox(this.m_ShelfCompartment.GetInteractablePackagingBoxList()[i]);
		}
	}

	// Token: 0x0600022A RID: 554 RVA: 0x00015525 File Offset: 0x00013725
	public ShelfCompartment GetShelfCompartment()
	{
		return this.m_ShelfCompartment;
	}

	// Token: 0x0400026C RID: 620
	private WarehouseShelf m_WarehouseShelf;

	// Token: 0x0400026D RID: 621
	private ShelfCompartment m_ShelfCompartment;
}
