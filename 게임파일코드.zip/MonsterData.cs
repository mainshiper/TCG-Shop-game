﻿using System;
using System.Collections.Generic;
using I2.Loc;
using UnityEngine;

// Token: 0x0200003C RID: 60
[Serializable]
public class MonsterData
{
	// Token: 0x060002FF RID: 767 RVA: 0x0001C7EC File Offset: 0x0001A9EC
	public string GetName()
	{
		return LocalizationManager.GetTranslation(this.Name, true, 0, true, false, null, null, true);
	}

	// Token: 0x06000300 RID: 768 RVA: 0x0001C800 File Offset: 0x0001AA00
	public string GetArtistName()
	{
		return "Illus. " + this.ArtistName;
	}

	// Token: 0x06000301 RID: 769 RVA: 0x0001C814 File Offset: 0x0001AA14
	public string GetDescription()
	{
		if (this.Description == "")
		{
			return LocalizationManager.GetTranslation("No effect", true, 0, true, false, null, null, true);
		}
		return LocalizationManager.GetTranslation(this.Description, true, 0, true, false, null, null, true).Replace("XXX", this.EffectAmount.x.ToString()).Replace("YYY", this.EffectAmount.y.ToString()).Replace("ZZZ", this.EffectAmount.z.ToString());
	}

	// Token: 0x06000302 RID: 770 RVA: 0x0001C8A5 File Offset: 0x0001AAA5
	public string GetRarityName()
	{
		return LocalizationManager.GetTranslation(this.Rarity.ToString(), true, 0, true, false, null, null, true);
	}

	// Token: 0x06000303 RID: 771 RVA: 0x0001C8C4 File Offset: 0x0001AAC4
	public string GetElementName()
	{
		return LocalizationManager.GetTranslation(this.ElementIndex.ToString(), true, 0, true, false, null, null, true);
	}

	// Token: 0x06000304 RID: 772 RVA: 0x0001C8E4 File Offset: 0x0001AAE4
	public string GetRoleName()
	{
		string text = "";
		string result = "";
		for (int i = 0; i < this.Roles.Count; i++)
		{
			if (i > 0)
			{
				text += ", ";
			}
			string translation = LocalizationManager.GetTranslation(this.Roles[i].ToString(), true, 0, true, false, null, null, true);
			if (this.Roles[i] == EMonsterRole.AllRounder)
			{
				translation = LocalizationManager.GetTranslation("All Rounder", true, 0, true, false, null, null, true);
			}
			else if (this.Roles[i] == EMonsterRole.MagicalAttacker)
			{
				translation = LocalizationManager.GetTranslation("Magical Attacker", true, 0, true, false, null, null, true);
			}
			else if (this.Roles[i] == EMonsterRole.PhysicalAttacker)
			{
				translation = LocalizationManager.GetTranslation("Physical Attacker", true, 0, true, false, null, null, true);
			}
			text += translation;
			if (i == 0)
			{
				result = translation;
			}
		}
		if (text.Length > 27)
		{
			return result;
		}
		return text;
	}

	// Token: 0x06000305 RID: 773 RVA: 0x0001C9D4 File Offset: 0x0001ABD4
	public Sprite GetIcon(ECardExpansionType cardExpansionType)
	{
		if (cardExpansionType == ECardExpansionType.Ghost)
		{
			return this.GhostIcon;
		}
		if (!(this.Icon == null))
		{
			return this.Icon;
		}
		if (cardExpansionType == ECardExpansionType.None)
		{
			return LoadStreamTexture.GetImage("Special_" + this.MonsterType.ToString());
		}
		return LoadStreamTexture.GetImage(cardExpansionType.ToString() + "_" + this.MonsterType.ToString());
	}

	// Token: 0x040003A8 RID: 936
	public string Name;

	// Token: 0x040003A9 RID: 937
	public string ArtistName;

	// Token: 0x040003AA RID: 938
	public string Description;

	// Token: 0x040003AB RID: 939
	public Vector3 EffectAmount;

	// Token: 0x040003AC RID: 940
	public EElementIndex ElementIndex;

	// Token: 0x040003AD RID: 941
	public ERarity Rarity;

	// Token: 0x040003AE RID: 942
	public EMonsterType MonsterType;

	// Token: 0x040003AF RID: 943
	public EMonsterType NextEvolution;

	// Token: 0x040003B0 RID: 944
	public EMonsterType PreviousEvolution;

	// Token: 0x040003B1 RID: 945
	public List<EMonsterRole> Roles;

	// Token: 0x040003B2 RID: 946
	public Stats BaseStats;

	// Token: 0x040003B3 RID: 947
	public List<ESkill> SkillList;

	// Token: 0x040003B4 RID: 948
	public Sprite Icon;

	// Token: 0x040003B5 RID: 949
	public Sprite GhostIcon;
}
