﻿using System;

// Token: 0x020000CC RID: 204
public class CEventPlayer_ParticleSpawnerReachedDestination : CEvent
{
	// Token: 0x17000026 RID: 38
	// (get) Token: 0x0600074B RID: 1867 RVA: 0x000395CB File Offset: 0x000377CB
	// (set) Token: 0x0600074C RID: 1868 RVA: 0x000395D3 File Offset: 0x000377D3
	public ECurrencyType m_CurrencyType { get; private set; }

	// Token: 0x0600074D RID: 1869 RVA: 0x000395DC File Offset: 0x000377DC
	public CEventPlayer_ParticleSpawnerReachedDestination(ECurrencyType CurrencyType)
	{
		this.m_CurrencyType = CurrencyType;
	}
}
