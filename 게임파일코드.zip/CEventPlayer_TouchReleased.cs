﻿using System;
using UnityEngine;

// Token: 0x020000C9 RID: 201
public class CEventPlayer_TouchReleased : CEvent
{
	// Token: 0x17000024 RID: 36
	// (get) Token: 0x06000744 RID: 1860 RVA: 0x00039583 File Offset: 0x00037783
	// (set) Token: 0x06000745 RID: 1861 RVA: 0x0003958B File Offset: 0x0003778B
	public Vector3 m_ReleaseVector { get; private set; }

	// Token: 0x06000746 RID: 1862 RVA: 0x00039594 File Offset: 0x00037794
	public CEventPlayer_TouchReleased(Vector3 releaseVector)
	{
		this.m_ReleaseVector = releaseVector;
	}
}
