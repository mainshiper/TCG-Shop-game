﻿using System;
using UnityEngine;

namespace EpicToonFX
{
	// Token: 0x020001F7 RID: 503
	public class ETFXMouseOrbit : MonoBehaviour
	{
		// Token: 0x06000DFC RID: 3580 RVA: 0x00060518 File Offset: 0x0005E718
		private void Start()
		{
			Vector3 eulerAngles = base.transform.eulerAngles;
			this.rotationYAxis = eulerAngles.y;
			this.rotationXAxis = eulerAngles.x;
			if (base.GetComponent<Rigidbody>())
			{
				base.GetComponent<Rigidbody>().freezeRotation = true;
			}
		}

		// Token: 0x06000DFD RID: 3581 RVA: 0x00060564 File Offset: 0x0005E764
		private void LateUpdate()
		{
			if (this.target)
			{
				if (Input.GetMouseButton(1))
				{
					this.velocityX += this.xSpeed * Input.GetAxis("Mouse X") * this.distance * 0.02f;
					this.velocityY += this.ySpeed * Input.GetAxis("Mouse Y") * 0.02f;
				}
				this.rotationYAxis += this.velocityX;
				this.rotationXAxis -= this.velocityY;
				this.rotationXAxis = ETFXMouseOrbit.ClampAngle(this.rotationXAxis, this.yMinLimit, this.yMaxLimit);
				Quaternion rotation = Quaternion.Euler(this.rotationXAxis, this.rotationYAxis, 0f);
				this.distance = Mathf.Clamp(this.distance - Input.GetAxis("Mouse ScrollWheel") * 5f, this.distanceMin, this.distanceMax);
				RaycastHit raycastHit;
				if (Physics.Linecast(this.target.position, base.transform.position, ref raycastHit))
				{
					this.distance -= raycastHit.distance;
				}
				Vector3 point = new Vector3(0f, 0f, -this.distance);
				Vector3 position = rotation * point + this.target.position;
				base.transform.rotation = rotation;
				base.transform.position = position;
				this.velocityX = Mathf.Lerp(this.velocityX, 0f, Time.deltaTime * this.smoothTime);
				this.velocityY = Mathf.Lerp(this.velocityY, 0f, Time.deltaTime * this.smoothTime);
			}
		}

		// Token: 0x06000DFE RID: 3582 RVA: 0x0006071F File Offset: 0x0005E91F
		public static float ClampAngle(float angle, float min, float max)
		{
			if (angle < -360f)
			{
				angle += 360f;
			}
			if (angle > 360f)
			{
				angle -= 360f;
			}
			return Mathf.Clamp(angle, min, max);
		}

		// Token: 0x04001511 RID: 5393
		public Transform target;

		// Token: 0x04001512 RID: 5394
		public float distance = 5f;

		// Token: 0x04001513 RID: 5395
		public float xSpeed = 120f;

		// Token: 0x04001514 RID: 5396
		public float ySpeed = 120f;

		// Token: 0x04001515 RID: 5397
		public float yMinLimit = -20f;

		// Token: 0x04001516 RID: 5398
		public float yMaxLimit = 80f;

		// Token: 0x04001517 RID: 5399
		public float distanceMin = 0.5f;

		// Token: 0x04001518 RID: 5400
		public float distanceMax = 15f;

		// Token: 0x04001519 RID: 5401
		public float smoothTime = 2f;

		// Token: 0x0400151A RID: 5402
		private float rotationYAxis;

		// Token: 0x0400151B RID: 5403
		private float rotationXAxis;

		// Token: 0x0400151C RID: 5404
		private float velocityX;

		// Token: 0x0400151D RID: 5405
		private float velocityY;
	}
}
