﻿using System;
using System.Collections;
using UnityEngine;

namespace EpicToonFX
{
	// Token: 0x020001F6 RID: 502
	public class ETFXLoopScript : MonoBehaviour
	{
		// Token: 0x06000DF8 RID: 3576 RVA: 0x000604D2 File Offset: 0x0005E6D2
		private void Start()
		{
			this.PlayEffect();
		}

		// Token: 0x06000DF9 RID: 3577 RVA: 0x000604DA File Offset: 0x0005E6DA
		public void PlayEffect()
		{
			base.StartCoroutine("EffectLoop");
		}

		// Token: 0x06000DFA RID: 3578 RVA: 0x000604E8 File Offset: 0x0005E6E8
		private IEnumerator EffectLoop()
		{
			GameObject effectPlayer = Object.Instantiate<GameObject>(this.chosenEffect, base.transform.position, base.transform.rotation);
			if (this.spawnWithoutLight = effectPlayer.GetComponent<Light>())
			{
				effectPlayer.GetComponent<Light>().enabled = false;
			}
			if (this.spawnWithoutSound = effectPlayer.GetComponent<AudioSource>())
			{
				effectPlayer.GetComponent<AudioSource>().enabled = false;
			}
			yield return new WaitForSeconds(this.loopTimeLimit);
			Object.Destroy(effectPlayer);
			this.PlayEffect();
			yield break;
		}

		// Token: 0x0400150D RID: 5389
		public GameObject chosenEffect;

		// Token: 0x0400150E RID: 5390
		public float loopTimeLimit = 2f;

		// Token: 0x0400150F RID: 5391
		[Header("Spawn without")]
		public bool spawnWithoutLight = true;

		// Token: 0x04001510 RID: 5392
		public bool spawnWithoutSound = true;
	}
}
