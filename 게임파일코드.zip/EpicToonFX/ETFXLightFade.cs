﻿using System;
using UnityEngine;

namespace EpicToonFX
{
	// Token: 0x020001F8 RID: 504
	public class ETFXLightFade : MonoBehaviour
	{
		// Token: 0x06000E00 RID: 3584 RVA: 0x000607B8 File Offset: 0x0005E9B8
		private void Start()
		{
			if (base.gameObject.GetComponent<Light>())
			{
				this.li = base.gameObject.GetComponent<Light>();
				this.initIntensity = this.li.intensity;
				return;
			}
			MonoBehaviour.print("No light object found on " + base.gameObject.name);
		}

		// Token: 0x06000E01 RID: 3585 RVA: 0x00060814 File Offset: 0x0005EA14
		private void Update()
		{
			if (base.gameObject.GetComponent<Light>())
			{
				this.li.intensity -= this.initIntensity * (Time.deltaTime / this.life);
				if (this.killAfterLife && this.li.intensity <= 0f)
				{
					Object.Destroy(base.gameObject.GetComponent<Light>());
				}
			}
		}

		// Token: 0x0400151E RID: 5406
		[Header("Seconds to dim the light")]
		public float life = 0.2f;

		// Token: 0x0400151F RID: 5407
		public bool killAfterLife = true;

		// Token: 0x04001520 RID: 5408
		private Light li;

		// Token: 0x04001521 RID: 5409
		private float initIntensity;
	}
}
