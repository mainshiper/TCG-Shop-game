﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;

namespace EpicToonFX
{
	// Token: 0x020001F5 RID: 501
	public class ETFXFireProjectile : MonoBehaviour
	{
		// Token: 0x06000DF2 RID: 3570 RVA: 0x000602EF File Offset: 0x0005E4EF
		private void Start()
		{
			this.selectedProjectileButton = GameObject.Find("Button").GetComponent<ETFXButtonScript>();
		}

		// Token: 0x06000DF3 RID: 3571 RVA: 0x00060308 File Offset: 0x0005E508
		private void Update()
		{
			if (Input.GetKeyDown(KeyCode.RightArrow))
			{
				this.nextEffect();
			}
			if (Input.GetKeyDown(KeyCode.D))
			{
				this.nextEffect();
			}
			if (Input.GetKeyDown(KeyCode.A))
			{
				this.previousEffect();
			}
			else if (Input.GetKeyDown(KeyCode.LeftArrow))
			{
				this.previousEffect();
			}
			if (Input.GetKeyDown(KeyCode.Mouse0) && !EventSystem.current.IsPointerOverGameObject() && Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), ref this.hit, 100f))
			{
				GameObject gameObject = Object.Instantiate<GameObject>(this.projectiles[this.currentProjectile], this.spawnPosition.position, Quaternion.identity);
				gameObject.transform.LookAt(this.hit.point);
				gameObject.GetComponent<Rigidbody>().AddForce(gameObject.transform.forward * this.speed);
				gameObject.GetComponent<ETFXProjectileScript>().impactNormal = this.hit.normal;
			}
			Debug.DrawRay(Camera.main.ScreenPointToRay(Input.mousePosition).origin, Camera.main.ScreenPointToRay(Input.mousePosition).direction * 100f, Color.yellow);
		}

		// Token: 0x06000DF4 RID: 3572 RVA: 0x0006044A File Offset: 0x0005E64A
		public void nextEffect()
		{
			if (this.currentProjectile < this.projectiles.Length - 1)
			{
				this.currentProjectile++;
			}
			else
			{
				this.currentProjectile = 0;
			}
			this.selectedProjectileButton.getProjectileNames();
		}

		// Token: 0x06000DF5 RID: 3573 RVA: 0x00060480 File Offset: 0x0005E680
		public void previousEffect()
		{
			if (this.currentProjectile > 0)
			{
				this.currentProjectile--;
			}
			else
			{
				this.currentProjectile = this.projectiles.Length - 1;
			}
			this.selectedProjectileButton.getProjectileNames();
		}

		// Token: 0x06000DF6 RID: 3574 RVA: 0x000604B6 File Offset: 0x0005E6B6
		public void AdjustSpeed(float newSpeed)
		{
			this.speed = newSpeed;
		}

		// Token: 0x04001507 RID: 5383
		private RaycastHit hit;

		// Token: 0x04001508 RID: 5384
		public GameObject[] projectiles;

		// Token: 0x04001509 RID: 5385
		public Transform spawnPosition;

		// Token: 0x0400150A RID: 5386
		[HideInInspector]
		public int currentProjectile;

		// Token: 0x0400150B RID: 5387
		public float speed = 1000f;

		// Token: 0x0400150C RID: 5388
		private ETFXButtonScript selectedProjectileButton;
	}
}
