﻿using System;
using UnityEngine;

namespace EpicToonFX
{
	// Token: 0x020001F9 RID: 505
	public class ETFXPitchRandomizer : MonoBehaviour
	{
		// Token: 0x06000E03 RID: 3587 RVA: 0x0006089C File Offset: 0x0005EA9C
		private void Start()
		{
			base.transform.GetComponent<AudioSource>().pitch *= 1f + Random.Range(-this.randomPercent / 100f, this.randomPercent / 100f);
		}

		// Token: 0x04001522 RID: 5410
		public float randomPercent = 10f;
	}
}
