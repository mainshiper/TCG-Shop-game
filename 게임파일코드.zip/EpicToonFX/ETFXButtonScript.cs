﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace EpicToonFX
{
	// Token: 0x020001F4 RID: 500
	public class ETFXButtonScript : MonoBehaviour
	{
		// Token: 0x06000DED RID: 3565 RVA: 0x00060198 File Offset: 0x0005E398
		private void Start()
		{
			this.effectScript = GameObject.Find("ETFXFireProjectile").GetComponent<ETFXFireProjectile>();
			this.getProjectileNames();
			this.MyButtonText = this.Button.transform.Find("Text").GetComponent<Text>();
			this.MyButtonText.text = this.projectileParticleName;
		}

		// Token: 0x06000DEE RID: 3566 RVA: 0x000601F1 File Offset: 0x0005E3F1
		private void Update()
		{
			this.MyButtonText.text = this.projectileParticleName;
		}

		// Token: 0x06000DEF RID: 3567 RVA: 0x00060204 File Offset: 0x0005E404
		public void getProjectileNames()
		{
			this.projectileScript = this.effectScript.projectiles[this.effectScript.currentProjectile].GetComponent<ETFXProjectileScript>();
			this.projectileParticleName = this.projectileScript.projectileParticle.name;
		}

		// Token: 0x06000DF0 RID: 3568 RVA: 0x00060240 File Offset: 0x0005E440
		public bool overButton()
		{
			Rect rect = new Rect(this.buttonsX, this.buttonsY, this.buttonsSizeX, this.buttonsSizeY);
			Rect rect2 = new Rect(this.buttonsX + this.buttonsDistance, this.buttonsY, this.buttonsSizeX, this.buttonsSizeY);
			return rect.Contains(new Vector2(Input.mousePosition.x, (float)Screen.height - Input.mousePosition.y)) || rect2.Contains(new Vector2(Input.mousePosition.x, (float)Screen.height - Input.mousePosition.y));
		}

		// Token: 0x040014FD RID: 5373
		public GameObject Button;

		// Token: 0x040014FE RID: 5374
		private Text MyButtonText;

		// Token: 0x040014FF RID: 5375
		private string projectileParticleName;

		// Token: 0x04001500 RID: 5376
		private ETFXFireProjectile effectScript;

		// Token: 0x04001501 RID: 5377
		private ETFXProjectileScript projectileScript;

		// Token: 0x04001502 RID: 5378
		public float buttonsX;

		// Token: 0x04001503 RID: 5379
		public float buttonsY;

		// Token: 0x04001504 RID: 5380
		public float buttonsSizeX;

		// Token: 0x04001505 RID: 5381
		public float buttonsSizeY;

		// Token: 0x04001506 RID: 5382
		public float buttonsDistance;
	}
}
