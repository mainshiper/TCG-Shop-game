﻿using System;
using UnityEngine;

namespace EpicToonFX
{
	// Token: 0x020001FA RID: 506
	public class ETFXRotation : MonoBehaviour
	{
		// Token: 0x06000E05 RID: 3589 RVA: 0x000608EC File Offset: 0x0005EAEC
		private void Start()
		{
		}

		// Token: 0x06000E06 RID: 3590 RVA: 0x000608F0 File Offset: 0x0005EAF0
		private void Update()
		{
			if (this.rotateSpace == ETFXRotation.spaceEnum.Local)
			{
				base.transform.Rotate(this.rotateVector * Time.deltaTime);
			}
			if (this.rotateSpace == ETFXRotation.spaceEnum.World)
			{
				base.transform.Rotate(this.rotateVector * Time.deltaTime, Space.World);
			}
		}

		// Token: 0x04001523 RID: 5411
		[Header("Rotate axises by degrees per second")]
		public Vector3 rotateVector = Vector3.zero;

		// Token: 0x04001524 RID: 5412
		public ETFXRotation.spaceEnum rotateSpace;

		// Token: 0x0200028A RID: 650
		public enum spaceEnum
		{
			// Token: 0x040016F0 RID: 5872
			Local,
			// Token: 0x040016F1 RID: 5873
			World
		}
	}
}
