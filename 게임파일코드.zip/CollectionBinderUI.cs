﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x0200005D RID: 93
public class CollectionBinderUI : MonoBehaviour
{
	// Token: 0x06000421 RID: 1057 RVA: 0x00024FD2 File Offset: 0x000231D2
	private void Awake()
	{
		this.m_ScreenGrp.SetActive(false);
		this.m_SortAlbumScreen.SetActive(false);
		this.m_CardNameText.gameObject.SetActive(false);
		this.m_CardFullRarityNameText.gameObject.SetActive(false);
	}

	// Token: 0x06000422 RID: 1058 RVA: 0x0002500E File Offset: 0x0002320E
	public void OpenScreen()
	{
		this.m_ScreenGrp.SetActive(true);
	}

	// Token: 0x06000423 RID: 1059 RVA: 0x0002501C File Offset: 0x0002321C
	public void CloseScreen()
	{
		this.m_ScreenGrp.SetActive(false);
	}

	// Token: 0x06000424 RID: 1060 RVA: 0x0002502A File Offset: 0x0002322A
	public void SetMaxPage(int maxPage)
	{
		this.m_MaxPage = maxPage;
	}

	// Token: 0x06000425 RID: 1061 RVA: 0x00025033 File Offset: 0x00023233
	public void SetCardCollected(int current, ECardExpansionType expansionType)
	{
		this.m_CardCollectedText.text = current.ToString() + " / " + this.m_MaxCardCollectionCount.ToString();
	}

	// Token: 0x06000426 RID: 1062 RVA: 0x0002505C File Offset: 0x0002325C
	public void SetMaxCardCollectCount(int maxCardCollectionCount)
	{
		this.m_MaxCardCollectionCount = maxCardCollectionCount;
	}

	// Token: 0x06000427 RID: 1063 RVA: 0x00025065 File Offset: 0x00023265
	public void SetTotalValue(float totalValue)
	{
		this.m_TotalValueText.text = GameInstance.GetPriceString(totalValue, false, true, false, "F2");
	}

	// Token: 0x06000428 RID: 1064 RVA: 0x00025080 File Offset: 0x00023280
	public void SetCurrentPage(int pageIndex)
	{
		this.m_PageText.text = pageIndex.ToString() + " / " + this.m_MaxPage.ToString();
	}

	// Token: 0x06000429 RID: 1065 RVA: 0x000250AC File Offset: 0x000232AC
	public void OpenExpansionSelectScreen(int currentExpansionIndex)
	{
		if (this.m_ExpansionSelectScreen.activeSelf)
		{
			this.CloseExpansionSelectScreen();
			return;
		}
		InteractionPlayerController.TempHideToolTip();
		InteractionPlayerController.AddToolTip(EGameAction.CloseCardAlbum, false, false);
		InteractionPlayerController.AddToolTip(EGameAction.BackF, false, false);
		CSingleton<InteractionPlayerController>.Instance.ShowCursor();
		SoundManager.GenericMenuOpen(1f, 1f);
		this.m_ExpansionSelectHighlightBtn.transform.position = this.m_ExpansionBtnList[currentExpansionIndex].position;
		this.m_ExpansionSelectScreen.SetActive(true);
	}

	// Token: 0x0600042A RID: 1066 RVA: 0x0002512A File Offset: 0x0002332A
	public void CloseExpansionSelectScreen()
	{
		InteractionPlayerController.RestoreHiddenToolTip();
		CSingleton<InteractionPlayerController>.Instance.HideCursor();
		SoundManager.GenericMenuClose(1f, 1f);
		this.m_ExpansionSelectScreen.SetActive(false);
	}

	// Token: 0x0600042B RID: 1067 RVA: 0x00025158 File Offset: 0x00023358
	public void OpenSortAlbumScreen(int sortingMethodIndex, int currentExpansionIndex)
	{
		if (this.m_SortAlbumScreen.activeSelf)
		{
			this.CloseSortAlbumScreen();
			return;
		}
		InteractionPlayerController.TempHideToolTip();
		InteractionPlayerController.AddToolTip(EGameAction.CloseCardAlbum, false, false);
		InteractionPlayerController.AddToolTip(EGameAction.BackF, false, false);
		CSingleton<InteractionPlayerController>.Instance.ShowCursor();
		SoundManager.GenericMenuOpen(1f, 1f);
		this.m_SortAlbumHighlightBtn.transform.position = this.m_SortAlbumBtnList[sortingMethodIndex].position;
		this.m_ExpansionSelectHighlightBtn.transform.position = this.m_ExpansionBtnList[currentExpansionIndex].position;
		this.m_SortAlbumScreen.SetActive(true);
		ControllerScreenUIExtManager.OnOpenScreen(this.m_SortAlbumScreenUIExtension);
	}

	// Token: 0x0600042C RID: 1068 RVA: 0x00025202 File Offset: 0x00023402
	public void CloseSortAlbumScreen()
	{
		InteractionPlayerController.RestoreHiddenToolTip();
		CSingleton<InteractionPlayerController>.Instance.HideCursor();
		SoundManager.GenericMenuClose(1f, 1f);
		this.m_SortAlbumScreen.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_SortAlbumScreenUIExtension);
	}

	// Token: 0x0600042D RID: 1069 RVA: 0x00025239 File Offset: 0x00023439
	public void OnPressSwitchSortingMethod(int sortingMethodIndex)
	{
		CSingleton<InteractionPlayerController>.Instance.HideCursor();
		SoundManager.GenericConfirm(1f, 1f);
		this.m_CollectionAlbum.OnPressSwitchSortingMethod(sortingMethodIndex);
		this.m_SortAlbumScreen.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_SortAlbumScreenUIExtension);
	}

	// Token: 0x0600042E RID: 1070 RVA: 0x00025277 File Offset: 0x00023477
	public void OnPressSwitchExpansion(int expansionIndex)
	{
		CSingleton<InteractionPlayerController>.Instance.HideCursor();
		SoundManager.GenericConfirm(1f, 1f);
		this.m_CollectionAlbum.OnPressSwitchExpansion(expansionIndex);
		this.m_SortAlbumScreen.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_SortAlbumScreenUIExtension);
	}

	// Token: 0x0600042F RID: 1071 RVA: 0x000252B5 File Offset: 0x000234B5
	public void OpenGhostCardTutorialScreen()
	{
		SoundManager.GenericMenuOpen(1f, 1f);
		CSingleton<InteractionPlayerController>.Instance.EnterUIMode();
		this.m_GhostCardTutorialScreen.SetActive(true);
		ControllerScreenUIExtManager.OnOpenScreen(this.m_GhostCardTutorialScreenUIExtension);
	}

	// Token: 0x06000430 RID: 1072 RVA: 0x000252E7 File Offset: 0x000234E7
	public void CloseGhostCardTutorialScreen()
	{
		SoundManager.GenericConfirm(1f, 1f);
		CSingleton<InteractionPlayerController>.Instance.ExitUIMode();
		this.m_GhostCardTutorialScreen.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_GhostCardTutorialScreenUIExtension);
		CPlayerData.m_HasGetGhostCard = true;
	}

	// Token: 0x040004FF RID: 1279
	public ControllerScreenUIExtension m_SortAlbumScreenUIExtension;

	// Token: 0x04000500 RID: 1280
	public ControllerScreenUIExtension m_GhostCardTutorialScreenUIExtension;

	// Token: 0x04000501 RID: 1281
	public CollectionBinderFlipAnimCtrl m_CollectionAlbum;

	// Token: 0x04000502 RID: 1282
	public GameObject m_ScreenGrp;

	// Token: 0x04000503 RID: 1283
	public GameObject m_SortAlbumScreen;

	// Token: 0x04000504 RID: 1284
	public GameObject m_SortAlbumHighlightBtn;

	// Token: 0x04000505 RID: 1285
	public GameObject m_ExpansionSelectScreen;

	// Token: 0x04000506 RID: 1286
	public GameObject m_ExpansionSelectHighlightBtn;

	// Token: 0x04000507 RID: 1287
	public GameObject m_GhostCardTutorialScreen;

	// Token: 0x04000508 RID: 1288
	public List<Transform> m_SortAlbumBtnList;

	// Token: 0x04000509 RID: 1289
	public List<Transform> m_ExpansionBtnList;

	// Token: 0x0400050A RID: 1290
	public TextMeshProUGUI m_CardCollectedText;

	// Token: 0x0400050B RID: 1291
	public TextMeshProUGUI m_PageText;

	// Token: 0x0400050C RID: 1292
	public TextMeshProUGUI m_CardNameText;

	// Token: 0x0400050D RID: 1293
	public TextMeshProUGUI m_CardFullRarityNameText;

	// Token: 0x0400050E RID: 1294
	public TextMeshProUGUI m_TotalValueText;

	// Token: 0x0400050F RID: 1295
	public Animation m_CardNameFoilAnim;

	// Token: 0x04000510 RID: 1296
	public Animation m_CardFullRarityNameFoilAnim;

	// Token: 0x04000511 RID: 1297
	private int m_MaxPage;

	// Token: 0x04000512 RID: 1298
	private int m_MaxCardCollectionCount;
}
