﻿using System;
using UnityEngine;

// Token: 0x02000143 RID: 323
public class ButtonAnimation : MonoBehaviour
{
	// Token: 0x06000936 RID: 2358 RVA: 0x0004391C File Offset: 0x00041B1C
	private void Awake()
	{
		this.initial_size_x = base.transform.localScale.x;
		this.initial_size_y = base.transform.localScale.y;
	}

	// Token: 0x06000937 RID: 2359 RVA: 0x0004394C File Offset: 0x00041B4C
	private void FixedUpdate()
	{
		if (this.GO)
		{
			float num = base.transform.localScale.x;
			float num2 = base.transform.localScale.y;
			if (base.transform.localScale.y < this.initial_size_y)
			{
				num *= this.speed;
				num2 *= this.speed;
				base.transform.localScale = new Vector3(num, num2, 1f);
				return;
			}
			num = this.initial_size_x;
			num2 = this.initial_size_y;
			base.transform.localScale = new Vector3(num, num2, 1f);
			this.GO = false;
		}
	}

	// Token: 0x06000938 RID: 2360 RVA: 0x000439F4 File Offset: 0x00041BF4
	private void Go()
	{
		this.GO = true;
		base.transform.localScale = new Vector3(this.initial_size_x * this.factor, this.initial_size_y * this.factor, 1f);
	}

	// Token: 0x04001158 RID: 4440
	private float initial_size_x;

	// Token: 0x04001159 RID: 4441
	private float initial_size_y;

	// Token: 0x0400115A RID: 4442
	public float factor = 0.5f;

	// Token: 0x0400115B RID: 4443
	public float speed = 1.15f;

	// Token: 0x0400115C RID: 4444
	private bool GO;
}
