﻿using System;
using I2.Loc;
using TMPro;

// Token: 0x0200005F RID: 95
public class ConfirmSellShelfScreen : UIScreenBase
{
	// Token: 0x06000439 RID: 1081 RVA: 0x0002540A File Offset: 0x0002360A
	protected override void OnOpenScreen()
	{
		SoundManager.GenericMenuOpen(1f, 1f);
		CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.SetStopMovement(true);
		CSingleton<InteractionPlayerController>.Instance.EnterUIMode();
		base.OnOpenScreen();
	}

	// Token: 0x0600043A RID: 1082 RVA: 0x0002543B File Offset: 0x0002363B
	protected override void OnCloseScreen()
	{
		CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.SetStopMovement(false);
		CSingleton<InteractionPlayerController>.Instance.ExitUIMode();
		SoundManager.GenericMenuClose(1f, 1f);
		base.OnCloseScreen();
	}

	// Token: 0x0600043B RID: 1083 RVA: 0x0002546C File Offset: 0x0002366C
	public void SetFurnitureData(FurniturePurchaseData data)
	{
		string text = LocalizationManager.GetTranslation(this.m_Text, true, 0, true, false, null, null, true).Replace("XXX", data.GetName());
		text = text.Replace("YYY", GameInstance.GetPriceString(data.price / 2f, false, true, false, "F2"));
		this.m_DisplayText.text = text;
	}

	// Token: 0x0600043C RID: 1084 RVA: 0x000254CD File Offset: 0x000236CD
	public void OnPressConfirmBtn()
	{
		SoundManager.GenericConfirm(1f, 1f);
		CSingleton<InteractionPlayerController>.Instance.ConfirmSellFurniture();
		base.CloseScreen();
	}

	// Token: 0x0600043D RID: 1085 RVA: 0x000254EE File Offset: 0x000236EE
	public void OnPressCancelBtn()
	{
		SoundManager.GenericCancel(1f, 1f);
		base.CloseScreen();
	}

	// Token: 0x04000514 RID: 1300
	public TextMeshProUGUI m_DisplayText;

	// Token: 0x04000515 RID: 1301
	public string m_Text = "Are you sure about selling XXX for YYY?";
}
