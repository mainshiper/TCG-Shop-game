﻿using System;
using System.Collections.Generic;

// Token: 0x0200004F RID: 79
[Serializable]
public class WorkbenchSaveData
{
	// Token: 0x0400046A RID: 1130
	public List<EItemType> itemTypeList;

	// Token: 0x0400046B RID: 1131
	public Vector3Serializer pos;

	// Token: 0x0400046C RID: 1132
	public QuaternionSerializer rot;

	// Token: 0x0400046D RID: 1133
	public bool isBoxed;

	// Token: 0x0400046E RID: 1134
	public Vector3Serializer boxedPackagePos;

	// Token: 0x0400046F RID: 1135
	public QuaternionSerializer boxedPackageRot;

	// Token: 0x04000470 RID: 1136
	public EObjectType objectType;
}
