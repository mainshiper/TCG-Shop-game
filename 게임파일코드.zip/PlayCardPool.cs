﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000004 RID: 4
public class PlayCardPool : CSingleton<PlayCardPool>
{
	// Token: 0x06000009 RID: 9 RVA: 0x000021D8 File Offset: 0x000003D8
	private void Awake()
	{
		if (PlayCardPool.m_Instance == null)
		{
			PlayCardPool.m_Instance = this;
		}
		else if (PlayCardPool.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
		for (int i = 0; i < this.m_PlayCardPoolList.Count; i++)
		{
			this.m_PlayCardPoolList[i].Init();
		}
	}

	// Token: 0x0600000A RID: 10 RVA: 0x00002240 File Offset: 0x00000440
	public PlayCard FindPlayCard()
	{
		for (int i = 0; i < this.m_PlayCardPoolList.Count; i++)
		{
			if (!this.m_PlayCardPoolList[i].gameObject.activeSelf)
			{
				this.m_PlayCardPoolList[i].gameObject.SetActive(true);
				return this.m_PlayCardPoolList[i];
			}
		}
		return null;
	}

	// Token: 0x04000007 RID: 7
	public static PlayCardPool m_Instance;

	// Token: 0x04000008 RID: 8
	public List<PlayCard> m_PlayCardPoolList;
}
