﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000040 RID: 64
public class PriceChangeManager : CSingleton<PriceChangeManager>
{
	// Token: 0x06000318 RID: 792 RVA: 0x0001CD00 File Offset: 0x0001AF00
	private void Init()
	{
		if (false || CPlayerData.m_GeneratedGameEventPriceList[0] == 0f)
		{
			for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_GameEventDataList.Count; i++)
			{
				CPlayerData.m_GeneratedGameEventPriceList[i] = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_GameEventDataList[i].baseFee * Mathf.Clamp(Random.Range(0.9f, 1.1f), 1f, 1.1f);
				CPlayerData.m_GeneratedGameEventPriceList[i] = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_GameEventDataList[i].baseFee;
				float num = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_GameEventDataList[i].marketPriceMinPercent;
				float maxInclusive = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_GameEventDataList[i].marketPriceMaxPercent;
				if (num == 0f)
				{
				}
				num = 1f;
				maxInclusive = 1f;
				CPlayerData.m_GeneratedGameEventPriceList[i] = CPlayerData.m_GeneratedGameEventPriceList[i] * Random.Range(num, maxInclusive);
			}
			for (int j = 0; j < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_GameEventDataList.Count; j++)
			{
				CPlayerData.m_GameEventPricePercentChangeList[j] = (float)Random.Range(0, 10);
				CPlayerData.m_GameEventPricePercentChangeList[j] = 0f;
				CPlayerData.m_SetGameEventPriceList[j] = PriceChangeManager.GetGameEventMarketPrice((EGameEventFormat)j);
			}
		}
		this.m_SetGameEventPriceList = CPlayerData.m_SetGameEventPriceList;
		this.m_GeneratedGameEventPriceList = CPlayerData.m_GeneratedGameEventPriceList;
		this.m_GameEventPricePercentChangeList = CPlayerData.m_GameEventPricePercentChangeList;
	}

	// Token: 0x06000319 RID: 793 RVA: 0x0001CE9C File Offset: 0x0001B09C
	private void EvaluatePriceChange()
	{
		GameEventData gameEventData = InventoryBase.GetGameEventData(CPlayerData.m_GameEventFormat);
		EPriceChangeType randomPriceChangeType = this.GetRandomPriceChangeType(gameEventData.positivePriceChangeType);
		EPriceChangeType randomPriceChangeType2 = this.GetRandomPriceChangeType(gameEventData.negativePriceChangeType);
		if (randomPriceChangeType != randomPriceChangeType2)
		{
			for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ItemDataList.Count; i++)
			{
				EItemType itemType = (EItemType)i;
				bool flag = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ItemDataList[i].affectedPriceChangeType.Contains(randomPriceChangeType);
				bool flag2 = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ItemDataList[i].affectedPriceChangeType.Contains(randomPriceChangeType2);
				float num = Random.Range(this.m_PriceChangeMin, this.m_PriceChangeMax);
				if (flag)
				{
					CPlayerData.AddItemPricePercentChange(itemType, num);
				}
				else if (flag2)
				{
					CPlayerData.AddItemPricePercentChange(itemType, -num);
				}
				int num2 = Random.Range(0, 100);
				if (num2 < 40)
				{
					if (num2 % 2 == 0)
					{
						CPlayerData.AddItemPricePercentChange(itemType, num / 2.5f);
					}
					else
					{
						CPlayerData.AddItemPricePercentChange(itemType, -num / 2.5f);
					}
				}
			}
			this.UpdateCardMarketPrice(CPlayerData.m_GameEventExpansionType, randomPriceChangeType, true);
			this.UpdateCardMarketPrice(CPlayerData.m_GameEventExpansionType, randomPriceChangeType2, false);
			if (CPlayerData.m_GameEventExpansionType == ECardExpansionType.Tetramon)
			{
				this.UpdateCardMarketPrice(ECardExpansionType.Destiny, randomPriceChangeType, true);
				this.UpdateCardMarketPrice(ECardExpansionType.Destiny, randomPriceChangeType2, false);
				this.UpdateCardMarketPrice(ECardExpansionType.Ghost, randomPriceChangeType, true);
				this.UpdateCardMarketPrice(ECardExpansionType.Ghost, randomPriceChangeType2, false);
			}
		}
	}

	// Token: 0x0600031A RID: 794 RVA: 0x0001CFEC File Offset: 0x0001B1EC
	private EPriceChangeType GetRandomPriceChangeType(EPriceChangeType priceChangeType)
	{
		List<EPriceChangeType> list = new List<EPriceChangeType>();
		if (priceChangeType == EPriceChangeType.RandomRarityPackCard)
		{
			list.Add(EPriceChangeType.CommonPackCard);
			list.Add(EPriceChangeType.RarePackCard);
			list.Add(EPriceChangeType.EpicPackCard);
			list.Add(EPriceChangeType.LegendPackCard);
		}
		else if (priceChangeType == EPriceChangeType.NoneCommonPackCard)
		{
			list.Add(EPriceChangeType.RarePackCard);
			list.Add(EPriceChangeType.EpicPackCard);
			list.Add(EPriceChangeType.LegendPackCard);
		}
		else if (priceChangeType == EPriceChangeType.RandomElement)
		{
			list.Add(EPriceChangeType.FireElement);
			list.Add(EPriceChangeType.EarthElement);
			list.Add(EPriceChangeType.WaterElement);
			list.Add(EPriceChangeType.WindElement);
		}
		else if (priceChangeType == EPriceChangeType.RandomBorder)
		{
			list.Add(EPriceChangeType.FirstEdition);
			list.Add(EPriceChangeType.SilverBorder);
			list.Add(EPriceChangeType.GoldBorder);
			list.Add(EPriceChangeType.ExBorder);
			list.Add(EPriceChangeType.FullArtBorder);
		}
		else
		{
			if (priceChangeType == EPriceChangeType.RandomEffect)
			{
				list.Add(EPriceChangeType.RandomRarityPackCard);
				list.Add(EPriceChangeType.RandomElement);
				list.Add(EPriceChangeType.RandomBorder);
				return this.GetRandomPriceChangeType(list[Random.Range(0, list.Count)]);
			}
			list.Add(priceChangeType);
		}
		return list[Random.Range(0, list.Count)];
	}

	// Token: 0x0600031B RID: 795 RVA: 0x0001D0E4 File Offset: 0x0001B2E4
	private void UpdateCardMarketPrice(ECardExpansionType expansionType, EPriceChangeType priceChangeType, bool isIncrease)
	{
		int num = InventoryBase.GetShownMonsterList(expansionType).Count * CPlayerData.GetCardAmountPerMonsterType(expansionType, true);
		if (expansionType == ECardExpansionType.Ghost)
		{
			num *= 2;
		}
		for (int i = 0; i < num; i++)
		{
			int num2 = i;
			bool isDestiny = false;
			if (expansionType == ECardExpansionType.Ghost && num2 >= InventoryBase.GetShownMonsterList(expansionType).Count * CPlayerData.GetCardAmountPerMonsterType(expansionType, true))
			{
				isDestiny = true;
				num2 -= InventoryBase.GetShownMonsterList(expansionType).Count * CPlayerData.GetCardAmountPerMonsterType(expansionType, true);
			}
			ECardBorderType ecardBorderType = (ECardBorderType)(i % CPlayerData.GetCardAmountPerMonsterType(expansionType, false));
			MonsterData monsterData = InventoryBase.GetMonsterData(CPlayerData.GetMonsterTypeFromCardSaveIndex(num2, expansionType));
			ERarity rarity = monsterData.Rarity;
			bool flag = i % CPlayerData.GetCardAmountPerMonsterType(expansionType, true) >= CPlayerData.GetCardAmountPerMonsterType(expansionType, false);
			bool flag2 = false;
			if (priceChangeType == EPriceChangeType.Foil && flag)
			{
				flag2 = true;
			}
			else if (priceChangeType == EPriceChangeType.NonFoil && !flag)
			{
				flag2 = true;
			}
			else if (priceChangeType == EPriceChangeType.CommonPackCard && rarity == ERarity.Common)
			{
				flag2 = true;
			}
			else if (priceChangeType == EPriceChangeType.RarePackCard && rarity == ERarity.Rare)
			{
				flag2 = true;
			}
			else if (priceChangeType == EPriceChangeType.EpicPackCard && rarity == ERarity.Epic)
			{
				flag2 = true;
			}
			else if (priceChangeType == EPriceChangeType.LegendPackCard && rarity == ERarity.Legendary)
			{
				flag2 = true;
			}
			else if (priceChangeType == EPriceChangeType.FirstEdition && ecardBorderType == ECardBorderType.FirstEdition)
			{
				flag2 = true;
			}
			else if (priceChangeType == EPriceChangeType.SilverBorder && ecardBorderType == ECardBorderType.Silver)
			{
				flag2 = true;
			}
			else if (priceChangeType == EPriceChangeType.GoldBorder && ecardBorderType == ECardBorderType.Gold)
			{
				flag2 = true;
			}
			else if (priceChangeType == EPriceChangeType.ExBorder && ecardBorderType == ECardBorderType.EX)
			{
				flag2 = true;
			}
			else if (priceChangeType == EPriceChangeType.FullArtBorder && ecardBorderType == ECardBorderType.FullArt)
			{
				flag2 = true;
			}
			else if (priceChangeType == EPriceChangeType.FireElement && monsterData.ElementIndex == EElementIndex.Fire)
			{
				flag2 = true;
			}
			else if (priceChangeType == EPriceChangeType.EarthElement && monsterData.ElementIndex == EElementIndex.Earth)
			{
				flag2 = true;
			}
			else if (priceChangeType == EPriceChangeType.WaterElement && monsterData.ElementIndex == EElementIndex.Water)
			{
				flag2 = true;
			}
			else if (priceChangeType == EPriceChangeType.WindElement && monsterData.ElementIndex == EElementIndex.Wind)
			{
				flag2 = true;
			}
			float num3 = Random.Range(this.m_PriceChangeMin, this.m_PriceChangeMax);
			if (flag2)
			{
				if (!isIncrease)
				{
					num3 *= -1f;
				}
				CPlayerData.AddCardPricePercentChange(num2, expansionType, isDestiny, num3);
			}
			int num4 = Random.Range(0, 100);
			if (num4 < 40)
			{
				if (num4 % 2 == 0)
				{
					CPlayerData.AddCardPricePercentChange(num2, expansionType, isDestiny, num3 / 2.5f);
				}
				else
				{
					CPlayerData.AddCardPricePercentChange(num2, expansionType, isDestiny, -num3 / 2.5f);
				}
			}
		}
	}

	// Token: 0x0600031C RID: 796 RVA: 0x0001D2F8 File Offset: 0x0001B4F8
	private void EvaluatePriceCrash()
	{
		for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ItemDataList.Count; i++)
		{
			EItemType eitemType = (EItemType)i;
			float num = CPlayerData.m_ItemPricePercentChangeList[(int)eitemType];
			if (num > 25f)
			{
				if ((float)Random.Range(0, 100) < Mathf.Abs(num))
				{
					float percentChange = Random.Range(this.m_PriceCrashMin, -num / 2.1f);
					CPlayerData.AddItemPricePercentChange(eitemType, percentChange);
				}
			}
			else if (num < -25f && (float)Random.Range(0, 100) < Mathf.Abs(num))
			{
				float percentChange2 = Random.Range(this.m_PriceCrashMin, Mathf.Abs(num) / 2.1f);
				CPlayerData.AddItemPricePercentChange(eitemType, percentChange2);
			}
		}
		this.EvaluateCardPriceCrash(ECardExpansionType.Tetramon);
		this.EvaluateCardPriceCrash(ECardExpansionType.Destiny);
		this.EvaluateCardPriceCrash(ECardExpansionType.Ghost);
		this.EvaluateCardPriceCrash(ECardExpansionType.FantasyRPG);
		this.EvaluateCardPriceCrash(ECardExpansionType.Megabot);
		this.EvaluateCardPriceCrash(ECardExpansionType.CatJob);
	}

	// Token: 0x0600031D RID: 797 RVA: 0x0001D3D4 File Offset: 0x0001B5D4
	private void EvaluateCardPriceCrash(ECardExpansionType expansionType)
	{
		int num = InventoryBase.GetShownMonsterList(expansionType).Count * CPlayerData.GetCardAmountPerMonsterType(expansionType, true);
		if (expansionType == ECardExpansionType.Ghost)
		{
			num *= 2;
		}
		for (int i = 0; i < num; i++)
		{
			int num2 = i;
			bool isDestiny = false;
			if (expansionType == ECardExpansionType.Ghost && num2 >= InventoryBase.GetShownMonsterList(expansionType).Count * CPlayerData.GetCardAmountPerMonsterType(expansionType, true))
			{
				isDestiny = true;
				num2 -= InventoryBase.GetShownMonsterList(expansionType).Count * CPlayerData.GetCardAmountPerMonsterType(expansionType, true);
			}
			float cardPricePercentChange = CPlayerData.GetCardPricePercentChange(num2, expansionType, isDestiny);
			if (cardPricePercentChange > 25f)
			{
				if ((float)Random.Range(0, 100) < Mathf.Abs(cardPricePercentChange))
				{
					float percentChange = Random.Range(this.m_PriceCrashMin, -cardPricePercentChange / 2.1f);
					CPlayerData.AddCardPricePercentChange(num2, expansionType, isDestiny, percentChange);
				}
			}
			else if (cardPricePercentChange < -25f && (float)Random.Range(0, 100) < Mathf.Abs(cardPricePercentChange))
			{
				float percentChange2 = Random.Range(this.m_PriceCrashMin, Mathf.Abs(cardPricePercentChange) / 2.1f);
				CPlayerData.AddCardPricePercentChange(num2, expansionType, isDestiny, percentChange2);
			}
		}
	}

	// Token: 0x0600031E RID: 798 RVA: 0x0001D4CB File Offset: 0x0001B6CB
	public static void SetGameEventPrice(EGameEventFormat gameEventFormat, float price)
	{
		CPlayerData.m_SetGameEventPriceList[(int)gameEventFormat] = price;
	}

	// Token: 0x0600031F RID: 799 RVA: 0x0001D4D9 File Offset: 0x0001B6D9
	public static float GetGameEventPrice(EGameEventFormat gameEventFormat, bool preventZero = true)
	{
		if (gameEventFormat == EGameEventFormat.None)
		{
			return 0f;
		}
		return CPlayerData.m_SetGameEventPriceList[(int)gameEventFormat];
	}

	// Token: 0x06000320 RID: 800 RVA: 0x0001D4F0 File Offset: 0x0001B6F0
	public static float GetGameEventMarketPrice(EGameEventFormat gameEventFormat)
	{
		if (gameEventFormat == EGameEventFormat.None)
		{
			return 0f;
		}
		return (float)Mathf.CeilToInt((float)Mathf.RoundToInt((CPlayerData.m_GeneratedGameEventPriceList[(int)gameEventFormat] + CPlayerData.m_GeneratedGameEventPriceList[(int)gameEventFormat] * (CPlayerData.m_GameEventPricePercentChangeList[(int)gameEventFormat] / 100f)) / 1f));
	}

	// Token: 0x06000321 RID: 801 RVA: 0x0001D542 File Offset: 0x0001B742
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.AddListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
		}
	}

	// Token: 0x06000322 RID: 802 RVA: 0x0001D574 File Offset: 0x0001B774
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.RemoveListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
		}
	}

	// Token: 0x06000323 RID: 803 RVA: 0x0001D5A6 File Offset: 0x0001B7A6
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.Init();
	}

	// Token: 0x06000324 RID: 804 RVA: 0x0001D5AE File Offset: 0x0001B7AE
	protected void OnDayStarted(CEventPlayer_OnDayStarted evt)
	{
		this.EvaluatePriceChange();
		this.EvaluatePriceCrash();
		CPlayerData.UpdateItemPricePercentChange();
		CPlayerData.UpdatePastCardPricePercentChange();
	}

	// Token: 0x040003CC RID: 972
	public List<float> m_SetGameEventPriceList = new List<float>();

	// Token: 0x040003CD RID: 973
	public List<float> m_GeneratedGameEventPriceList = new List<float>();

	// Token: 0x040003CE RID: 974
	public List<float> m_GameEventPricePercentChangeList = new List<float>();

	// Token: 0x040003CF RID: 975
	private float m_PriceChangeMin = 0.2f;

	// Token: 0x040003D0 RID: 976
	private float m_PriceChangeMax = 5f;

	// Token: 0x040003D1 RID: 977
	private float m_PriceCrashMin = 5f;

	// Token: 0x040003D2 RID: 978
	private float m_PriceCrashMax = 50f;

	// Token: 0x040003D3 RID: 979
	public bool m_Debug;
}
