﻿using System;
using UnityEngine;

// Token: 0x02000145 RID: 325
public class SelfDestruct : MonoBehaviour
{
	// Token: 0x0600093D RID: 2365 RVA: 0x00043E11 File Offset: 0x00042011
	private void Start()
	{
		float num = this.selfdestruct_in;
	}

	// Token: 0x04001162 RID: 4450
	public float selfdestruct_in = 4f;
}
