﻿using System;

// Token: 0x020000B3 RID: 179
public class CEventPlayer_SetFame : CEvent
{
	// Token: 0x17000014 RID: 20
	// (get) Token: 0x0600070E RID: 1806 RVA: 0x00039353 File Offset: 0x00037553
	// (set) Token: 0x0600070F RID: 1807 RVA: 0x0003935B File Offset: 0x0003755B
	public int m_FameValue { get; private set; }

	// Token: 0x06000710 RID: 1808 RVA: 0x00039364 File Offset: 0x00037564
	public CEventPlayer_SetFame(int fameValue)
	{
		this.m_FameValue = fameValue;
	}
}
