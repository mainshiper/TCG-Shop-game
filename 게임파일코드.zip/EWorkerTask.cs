﻿using System;

// Token: 0x02000090 RID: 144
public enum EWorkerTask
{
	// Token: 0x0400074F RID: 1871
	Rest,
	// Token: 0x04000750 RID: 1872
	ManCounter,
	// Token: 0x04000751 RID: 1873
	RestockShelf,
	// Token: 0x04000752 RID: 1874
	GoBackHome = 99,
	// Token: 0x04000753 RID: 1875
	Fired
}
