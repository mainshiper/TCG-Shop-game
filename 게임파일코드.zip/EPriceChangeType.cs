﻿using System;

// Token: 0x020000DE RID: 222
public enum EPriceChangeType
{
	// Token: 0x04000A50 RID: 2640
	None = -1,
	// Token: 0x04000A51 RID: 2641
	CommonPackCard,
	// Token: 0x04000A52 RID: 2642
	RarePackCard,
	// Token: 0x04000A53 RID: 2643
	EpicPackCard,
	// Token: 0x04000A54 RID: 2644
	LegendPackCard,
	// Token: 0x04000A55 RID: 2645
	NoneCommonPackCard,
	// Token: 0x04000A56 RID: 2646
	RandomRarityPackCard,
	// Token: 0x04000A57 RID: 2647
	FireElement,
	// Token: 0x04000A58 RID: 2648
	EarthElement,
	// Token: 0x04000A59 RID: 2649
	WaterElement,
	// Token: 0x04000A5A RID: 2650
	WindElement,
	// Token: 0x04000A5B RID: 2651
	RandomElement,
	// Token: 0x04000A5C RID: 2652
	FirstEdition,
	// Token: 0x04000A5D RID: 2653
	SilverBorder,
	// Token: 0x04000A5E RID: 2654
	GoldBorder,
	// Token: 0x04000A5F RID: 2655
	ExBorder,
	// Token: 0x04000A60 RID: 2656
	FullArtBorder,
	// Token: 0x04000A61 RID: 2657
	RandomBorder,
	// Token: 0x04000A62 RID: 2658
	Foil,
	// Token: 0x04000A63 RID: 2659
	NonFoil,
	// Token: 0x04000A64 RID: 2660
	RandomEffect,
	// Token: 0x04000A65 RID: 2661
	Figurine,
	// Token: 0x04000A66 RID: 2662
	ExpansionTetramon
}
