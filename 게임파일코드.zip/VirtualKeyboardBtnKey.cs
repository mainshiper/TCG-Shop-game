﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000114 RID: 276
public class VirtualKeyboardBtnKey : MonoBehaviour
{
	// Token: 0x0600081F RID: 2079 RVA: 0x0003D559 File Offset: 0x0003B759
	public void Init(VirtualKeyboardScreenUI virtualKeyboardScreenUI)
	{
		this.m_VirtualKeyboardScreenUI = virtualKeyboardScreenUI;
		this.EvaluateKey();
	}

	// Token: 0x06000820 RID: 2080 RVA: 0x0003D568 File Offset: 0x0003B768
	public void EvaluateKey()
	{
		if (this.m_IsCapital || this.m_IsBack || this.m_IsSpacebar || this.m_IsDone)
		{
			return;
		}
		if (!this.m_VirtualKeyboardScreenUI.m_IsAltActive)
		{
			this.m_KeyText.text = this.m_String.ToLower();
			return;
		}
		if (this.m_AltString != null && this.m_AltString != "")
		{
			this.m_KeyText.text = this.m_AltString;
			return;
		}
		this.m_KeyText.text = this.m_String.ToUpper();
	}

	// Token: 0x06000821 RID: 2081 RVA: 0x0003D5FC File Offset: 0x0003B7FC
	public void OnPressButton()
	{
		if (this.m_IsCapital)
		{
			this.m_VirtualKeyboardScreenUI.OnPressCapitalKey();
		}
		else if (this.m_IsBack)
		{
			this.m_VirtualKeyboardScreenUI.OnPressBackKey();
		}
		else if (this.m_IsSpacebar)
		{
			this.m_VirtualKeyboardScreenUI.OnPressSpaceKey();
		}
		else if (this.m_IsDone)
		{
			this.m_VirtualKeyboardScreenUI.OnPressDoneKey();
		}
		else
		{
			this.m_VirtualKeyboardScreenUI.OnPressButton(this.m_KeyText.text);
		}
		SoundManager.GenericLightTap(0.4f, 1f);
	}

	// Token: 0x04000F6F RID: 3951
	public TextMeshProUGUI m_KeyText;

	// Token: 0x04000F70 RID: 3952
	public string m_String;

	// Token: 0x04000F71 RID: 3953
	public string m_AltString;

	// Token: 0x04000F72 RID: 3954
	public bool m_IsSpacebar;

	// Token: 0x04000F73 RID: 3955
	public bool m_IsBack;

	// Token: 0x04000F74 RID: 3956
	public bool m_IsCapital;

	// Token: 0x04000F75 RID: 3957
	public bool m_IsDone;

	// Token: 0x04000F76 RID: 3958
	private VirtualKeyboardScreenUI m_VirtualKeyboardScreenUI;
}
