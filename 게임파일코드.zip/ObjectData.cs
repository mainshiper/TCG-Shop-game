﻿using System;
using I2.Loc;

// Token: 0x02000131 RID: 305
[Serializable]
public class ObjectData
{
	// Token: 0x060008F1 RID: 2289 RVA: 0x0004275E File Offset: 0x0004095E
	public string GetName()
	{
		return LocalizationManager.GetTranslation(this.name, true, 0, true, false, null, null, true);
	}

	// Token: 0x040010F8 RID: 4344
	public string name;

	// Token: 0x040010F9 RID: 4345
	public EObjectType objectType;

	// Token: 0x040010FA RID: 4346
	public InteractableObject spawnPrefab;
}
