﻿using System;

// Token: 0x02000072 RID: 114
[Serializable]
public class BillData
{
	// Token: 0x04000623 RID: 1571
	public EBillType billType;

	// Token: 0x04000624 RID: 1572
	public int billDayPassed;

	// Token: 0x04000625 RID: 1573
	public float amountToPay;
}
