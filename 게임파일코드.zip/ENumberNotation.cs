﻿using System;

// Token: 0x020000D9 RID: 217
public enum ENumberNotation
{
	// Token: 0x040009A9 RID: 2473
	None,
	// Token: 0x040009AA RID: 2474
	K,
	// Token: 0x040009AB RID: 2475
	M,
	// Token: 0x040009AC RID: 2476
	B,
	// Token: 0x040009AD RID: 2477
	T,
	// Token: 0x040009AE RID: 2478
	Qa,
	// Token: 0x040009AF RID: 2479
	Qb,
	// Token: 0x040009B0 RID: 2480
	Qc,
	// Token: 0x040009B1 RID: 2481
	Qd,
	// Token: 0x040009B2 RID: 2482
	Qe,
	// Token: 0x040009B3 RID: 2483
	Qf,
	// Token: 0x040009B4 RID: 2484
	Qg,
	// Token: 0x040009B5 RID: 2485
	Qh,
	// Token: 0x040009B6 RID: 2486
	Qi,
	// Token: 0x040009B7 RID: 2487
	Qj,
	// Token: 0x040009B8 RID: 2488
	Qk,
	// Token: 0x040009B9 RID: 2489
	Ql,
	// Token: 0x040009BA RID: 2490
	Qm,
	// Token: 0x040009BB RID: 2491
	Qn,
	// Token: 0x040009BC RID: 2492
	Qo,
	// Token: 0x040009BD RID: 2493
	Qp,
	// Token: 0x040009BE RID: 2494
	Qq,
	// Token: 0x040009BF RID: 2495
	Qr,
	// Token: 0x040009C0 RID: 2496
	Qs,
	// Token: 0x040009C1 RID: 2497
	Qt,
	// Token: 0x040009C2 RID: 2498
	Qu,
	// Token: 0x040009C3 RID: 2499
	Qv,
	// Token: 0x040009C4 RID: 2500
	Qw,
	// Token: 0x040009C5 RID: 2501
	Qx,
	// Token: 0x040009C6 RID: 2502
	Qy,
	// Token: 0x040009C7 RID: 2503
	Qz
}
