﻿using System;
using I2.Loc;
using TMPro;
using UnityEngine;

// Token: 0x02000081 RID: 129
public class SetGameEventScreen : UIScreenBase
{
	// Token: 0x0600050F RID: 1295 RVA: 0x0002BC90 File Offset: 0x00029E90
	protected override void OnOpenScreen()
	{
		this.m_LastSetFee = PriceChangeManager.GetGameEventPrice(CPlayerData.m_GameEventFormat, true);
		base.OnOpenScreen();
		this.m_ShopNameText.text = CPlayerData.PlayerName;
		this.EvaluateText();
	}

	// Token: 0x06000510 RID: 1296 RVA: 0x0002BCBF File Offset: 0x00029EBF
	protected override void OnCloseScreen()
	{
		base.OnCloseScreen();
	}

	// Token: 0x06000511 RID: 1297 RVA: 0x0002BCC7 File Offset: 0x00029EC7
	public void OnPressSetPrice()
	{
		base.OpenChildScreen(this.m_SetPriceScreen);
		SoundManager.GenericConfirm(1f, 1f);
	}

	// Token: 0x06000512 RID: 1298 RVA: 0x0002BCE4 File Offset: 0x00029EE4
	public void OnPressSetFormat()
	{
		base.OpenChildScreen(this.m_SetFormatScreen);
		SoundManager.GenericConfirm(1f, 1f);
	}

	// Token: 0x06000513 RID: 1299 RVA: 0x0002BD01 File Offset: 0x00029F01
	public void OnPressReset()
	{
		CPlayerData.m_PendingGameEventFormat = EGameEventFormat.None;
		CPlayerData.m_PendingGameEventExpansionType = CPlayerData.m_GameEventExpansionType;
		PriceChangeManager.SetGameEventPrice(CPlayerData.m_GameEventFormat, this.m_LastSetFee);
		this.EvaluateText();
		SoundManager.GenericConfirm(1f, 1f);
	}

	// Token: 0x06000514 RID: 1300 RVA: 0x0002BD38 File Offset: 0x00029F38
	protected override void OnChildScreenClosed(UIScreenBase childScreen)
	{
		base.OnChildScreenClosed(childScreen);
		this.EvaluateText();
	}

	// Token: 0x06000515 RID: 1301 RVA: 0x0002BD48 File Offset: 0x00029F48
	private void EvaluateText()
	{
		if (CPlayerData.m_PendingGameEventFormat != EGameEventFormat.None)
		{
			GameEventData gameEventData = InventoryBase.GetGameEventData(CPlayerData.m_PendingGameEventFormat);
			this.m_FormatText.text = LocalizationManager.GetTranslation(this.m_FormatPrefix, true, 0, true, false, null, null, true) + " : " + gameEventData.GetName();
			this.m_CostText.text = string.Concat(new string[]
			{
				LocalizationManager.GetTranslation(this.m_CostPrefix, true, 0, true, false, null, null, true),
				" : ",
				GameInstance.GetPriceString((float)gameEventData.hostEventCost, false, true, false, "F2"),
				"/",
				LocalizationManager.GetTranslation(this.m_CostSuffix, true, 0, true, false, null, null, true)
			});
			this.m_FeeText.text = LocalizationManager.GetTranslation(this.m_FeePrefix, true, 0, true, false, null, null, true) + " : " + GameInstance.GetPriceString(PriceChangeManager.GetGameEventPrice(CPlayerData.m_PendingGameEventFormat, true), false, true, false, "F2") + LocalizationManager.GetTranslation(this.m_FeeSuffix, true, 0, true, false, null, null, true);
			this.m_PositiveEffectText.text = "(+) " + InventoryBase.GetPriceChangeTypeText(gameEventData.positivePriceChangeType, true);
			this.m_NegativeEffectText.text = "(-) " + InventoryBase.GetPriceChangeTypeText(gameEventData.negativePriceChangeType, false);
			this.m_CurrentGameEventText.gameObject.SetActive(false);
			this.m_NextGameEventText.gameObject.SetActive(true);
		}
		else
		{
			GameEventData gameEventData2 = InventoryBase.GetGameEventData(CPlayerData.m_GameEventFormat);
			this.m_FormatText.text = LocalizationManager.GetTranslation(this.m_FormatPrefix, true, 0, true, false, null, null, true) + " : " + gameEventData2.GetName();
			this.m_CostText.text = string.Concat(new string[]
			{
				LocalizationManager.GetTranslation(this.m_CostPrefix, true, 0, true, false, null, null, true),
				" : ",
				GameInstance.GetPriceString((float)gameEventData2.hostEventCost, false, true, false, "F2"),
				"/",
				LocalizationManager.GetTranslation(this.m_CostSuffix, true, 0, true, false, null, null, true)
			});
			this.m_FeeText.text = LocalizationManager.GetTranslation(this.m_FeePrefix, true, 0, true, false, null, null, true) + " : " + GameInstance.GetPriceString(PriceChangeManager.GetGameEventPrice(CPlayerData.m_GameEventFormat, true), false, true, false, "F2") + LocalizationManager.GetTranslation(this.m_FeeSuffix, true, 0, true, false, null, null, true);
			this.m_PositiveEffectText.text = "(+) " + InventoryBase.GetPriceChangeTypeText(gameEventData2.positivePriceChangeType, true);
			this.m_NegativeEffectText.text = "(-) " + InventoryBase.GetPriceChangeTypeText(gameEventData2.negativePriceChangeType, false);
			this.m_CurrentGameEventText.gameObject.SetActive(true);
			this.m_NextGameEventText.gameObject.SetActive(false);
		}
		if (CPlayerData.m_GameEventExpansionType != CPlayerData.m_PendingGameEventExpansionType)
		{
			this.m_CurrentGameEventText.gameObject.SetActive(false);
			this.m_NextGameEventText.gameObject.SetActive(true);
		}
	}

	// Token: 0x040006AD RID: 1709
	public SetGameEventPriceScreen m_SetPriceScreen;

	// Token: 0x040006AE RID: 1710
	public SetGameEventFormatScreen m_SetFormatScreen;

	// Token: 0x040006AF RID: 1711
	public GameObject m_CurrentGameEventText;

	// Token: 0x040006B0 RID: 1712
	public GameObject m_NextGameEventText;

	// Token: 0x040006B1 RID: 1713
	public TextMeshProUGUI m_ShopNameText;

	// Token: 0x040006B2 RID: 1714
	public TextMeshProUGUI m_FeeText;

	// Token: 0x040006B3 RID: 1715
	public TextMeshProUGUI m_FormatText;

	// Token: 0x040006B4 RID: 1716
	public TextMeshProUGUI m_CostText;

	// Token: 0x040006B5 RID: 1717
	public TextMeshProUGUI m_PositiveEffectText;

	// Token: 0x040006B6 RID: 1718
	public TextMeshProUGUI m_NegativeEffectText;

	// Token: 0x040006B7 RID: 1719
	private string m_FeePrefix = "Fee";

	// Token: 0x040006B8 RID: 1720
	private string m_FormatPrefix = "Format";

	// Token: 0x040006B9 RID: 1721
	private string m_CostPrefix = "Cost";

	// Token: 0x040006BA RID: 1722
	private string m_FeeSuffix = "hr";

	// Token: 0x040006BB RID: 1723
	private string m_CostSuffix = "day";

	// Token: 0x040006BC RID: 1724
	private float m_LastSetFee;
}
