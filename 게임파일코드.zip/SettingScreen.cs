﻿using System;
using System.Collections.Generic;
using I2.Loc;
using UnityEngine;
using UniversalSettings;

// Token: 0x0200009C RID: 156
public class SettingScreen : CSingleton<SettingScreen>
{
	// Token: 0x0600060D RID: 1549 RVA: 0x00032644 File Offset: 0x00030844
	public static void OpenScreen(bool isTitleScreen)
	{
		CSingleton<SettingScreen>.Instance.m_IsTitleScreen = isTitleScreen;
		CSingleton<SettingScreen>.Instance.m_GameSettingScreen.SetActive(true);
		CSingleton<SettingScreen>.Instance.m_DisplaySettingScreen.SetActive(false);
		CSingleton<SettingScreen>.Instance.m_LanguageScreen.SetActive(false);
		CSingleton<SettingScreen>.Instance.m_KeybindScreen.SetActive(false);
		CSingleton<SettingScreen>.Instance.ShowSubSettingBtnHighlight(0);
		CSingleton<SettingScreen>.Instance.m_IsChangingKeybind = false;
		CSingleton<SettingScreen>.Instance.m_CurrentCurrencyType = CSingleton<CGameManager>.Instance.m_CurrencyType;
		if (CSingleton<SettingScreen>.Instance.m_ScreenGrp.activeSelf)
		{
			SettingScreen.CloseScreen();
			return;
		}
		CSingleton<SettingScreen>.Instance.m_ScreenGrp.SetActive(true);
		ControllerScreenUIExtManager.OnOpenScreen(CSingleton<SettingScreen>.Instance.m_ControllerScreenUIExtension);
		SoundManager.GenericMenuOpen(1f, 1f);
	}

	// Token: 0x0600060E RID: 1550 RVA: 0x0003270C File Offset: 0x0003090C
	public static void CloseScreen()
	{
		if (CSingleton<SettingScreen>.Instance.m_IsChangingKeybind)
		{
			return;
		}
		if (SettingScreen.CheckKeybindChangesConfirmScreenPopup())
		{
			return;
		}
		CSingleton<SettingScreen>.Instance.m_ScreenGrp.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<SettingScreen>.Instance.m_ControllerScreenUIExtension);
		CSettingData.instance.SaveSettingData();
		SoundManager.GenericMenuClose(1f, 1f);
		if (CSingleton<SettingScreen>.Instance.m_CurrentCurrencyType != CSingleton<CGameManager>.Instance.m_CurrencyType)
		{
			CSingleton<SettingScreen>.Instance.m_CurrentCurrencyType = CSingleton<CGameManager>.Instance.m_CurrencyType;
			CEventManager.QueueEvent(new CEventPlayer_OnMoneyCurrencyUpdated());
		}
	}

	// Token: 0x0600060F RID: 1551 RVA: 0x0003279A File Offset: 0x0003099A
	private static bool CheckKeybindChangesConfirmScreenPopup()
	{
		if (InputManager.HasKeybindChanges())
		{
			ControllerScreenUIExtManager.OnOpenScreen(CSingleton<SettingScreen>.Instance.m_KeybindChangesConfirmScreenUIExtension);
			CSingleton<SettingScreen>.Instance.m_KeybindChangesConfirmScreen.SetActive(true);
			return true;
		}
		return false;
	}

	// Token: 0x06000610 RID: 1552 RVA: 0x000327C5 File Offset: 0x000309C5
	public void OnPressConfirmKeybindChange()
	{
		this.m_KeybindChangesConfirmScreen.SetActive(false);
		this.m_IsChangingKeybind = false;
		this.OnPressSaveKeybind();
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<SettingScreen>.Instance.m_KeybindChangesConfirmScreenUIExtension);
	}

	// Token: 0x06000611 RID: 1553 RVA: 0x000327EF File Offset: 0x000309EF
	public void OnPressCancelKeybindChange()
	{
		this.m_KeybindChangesConfirmScreen.SetActive(false);
		this.m_IsChangingKeybind = false;
		this.OnPressUndoKeybind();
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<SettingScreen>.Instance.m_KeybindChangesConfirmScreenUIExtension);
	}

	// Token: 0x06000612 RID: 1554 RVA: 0x0003281C File Offset: 0x00030A1C
	private void Start()
	{
		UniversalSettingsRunner.Instance.onApplySettings += delegate()
		{
			CSingleton<CGameManager>.Instance.m_EnableTooltip = UniversalSettingsRunner.Instance.GetCustomBoolean(0);
			CSingleton<CGameManager>.Instance.m_InvertedMouse = UniversalSettingsRunner.Instance.GetCustomBoolean(1);
			CSingleton<CGameManager>.Instance.m_InvertedMouse = UniversalSettingsRunner.Instance.GetCustomBoolean(1);
			CSingleton<CGameManager>.Instance.m_CashierLockMovement = UniversalSettingsRunner.Instance.GetCustomBoolean(2);
			CSingleton<CGameManager>.Instance.m_KeyboardTypeIndex = UniversalSettingsRunner.Instance.GetCustomInteger(1);
			InputManager.OnKeyboardTypeUpdated(CSingleton<CGameManager>.Instance.m_KeyboardTypeIndex);
			CSingleton<CGameManager>.Instance.m_QualitySettingIndex = UniversalSettingsRunner.Instance.GetCustomInteger(2);
			CSingleton<CGameManager>.Instance.m_MouseSensitivity = UniversalSettingsRunner.Instance.GetCustomFloat(0);
			SoundManager.MusicVolume = UniversalSettingsRunner.Instance.GetCustomFloat(1);
			SoundManager.SFXVolume = UniversalSettingsRunner.Instance.GetCustomFloat(2);
			CSingleton<CGameManager>.Instance.m_CameraFOVSlider = UniversalSettingsRunner.Instance.GetCustomFloat(3);
			CSingleton<CGameManager>.Instance.m_CenterDotSizeSlider = UniversalSettingsRunner.Instance.GetCustomFloat(4);
			CSingleton<CGameManager>.Instance.m_OpenPackSpeedSlider = UniversalSettingsRunner.Instance.GetCustomFloat(5);
			CSingleton<CGameManager>.Instance.m_CenterDotColorIndex = UniversalSettingsRunner.Instance.GetCustomInteger(3);
			CSingleton<CGameManager>.Instance.m_CenterDotSpriteTypeIndex = UniversalSettingsRunner.Instance.GetCustomInteger(4);
			CSingleton<CGameManager>.Instance.m_CurrencyType = (EMoneyCurrencyType)UniversalSettingsRunner.Instance.GetCustomInteger(5);
			CSingleton<CGameManager>.Instance.m_CenterDotHasOutline = UniversalSettingsRunner.Instance.GetCustomBoolean(3);
			CSingleton<CGameManager>.Instance.m_OpenPackShowNewCard = UniversalSettingsRunner.Instance.GetCustomBoolean(4);
			CSingleton<CGameManager>.Instance.m_OpenPacAutoNextCard = UniversalSettingsRunner.Instance.GetCustomBoolean(5);
			CSingleton<CGameManager>.Instance.m_DisableController = UniversalSettingsRunner.Instance.GetCustomBoolean(6);
			CSingleton<CGameManager>.Instance.m_IsTurnVSyncOff = UniversalSettingsRunner.Instance.GetCustomBoolean(7);
			if (CSingleton<CGameManager>.Instance.m_IsTurnVSyncOff)
			{
				QualitySettings.vSyncCount = 0;
			}
			else
			{
				QualitySettings.vSyncCount = 1;
			}
			CSingleton<InputManager>.Instance.SetIsControllerDisabledSetting(CSingleton<CGameManager>.Instance.m_DisableController);
			CSingleton<SoundManager>.Instance.EvaluateSoundVolume();
			CSingleton<CGameManager>.Instance.m_MouseSensitivityLerp = Mathf.Lerp(0.2f, 1.8f, CSingleton<CGameManager>.Instance.m_MouseSensitivity);
			CEventManager.QueueEvent(new CEventPlayer_OnSettingUpdated());
		};
		CSingleton<CGameManager>.Instance.m_EnableTooltip = UniversalSettingsRunner.Instance.GetCustomBoolean(0);
		CSingleton<CGameManager>.Instance.m_InvertedMouse = UniversalSettingsRunner.Instance.GetCustomBoolean(1);
		CSingleton<CGameManager>.Instance.m_CashierLockMovement = UniversalSettingsRunner.Instance.GetCustomBoolean(2);
		CSingleton<CGameManager>.Instance.m_KeyboardTypeIndex = UniversalSettingsRunner.Instance.GetCustomInteger(1);
		InputManager.OnKeyboardTypeUpdated(CSingleton<CGameManager>.Instance.m_KeyboardTypeIndex);
		CSingleton<CGameManager>.Instance.m_QualitySettingIndex = UniversalSettingsRunner.Instance.GetCustomInteger(2);
		CSingleton<CGameManager>.Instance.m_MouseSensitivity = UniversalSettingsRunner.Instance.GetCustomFloat(0);
		SoundManager.MusicVolume = UniversalSettingsRunner.Instance.GetCustomFloat(1);
		SoundManager.SFXVolume = UniversalSettingsRunner.Instance.GetCustomFloat(2);
		CSingleton<CGameManager>.Instance.m_CameraFOVSlider = UniversalSettingsRunner.Instance.GetCustomFloat(3);
		CSingleton<CGameManager>.Instance.m_CenterDotSizeSlider = UniversalSettingsRunner.Instance.GetCustomFloat(4);
		CSingleton<CGameManager>.Instance.m_OpenPackSpeedSlider = UniversalSettingsRunner.Instance.GetCustomFloat(5);
		CSingleton<CGameManager>.Instance.m_CenterDotColorIndex = UniversalSettingsRunner.Instance.GetCustomInteger(3);
		CSingleton<CGameManager>.Instance.m_CenterDotSpriteTypeIndex = UniversalSettingsRunner.Instance.GetCustomInteger(4);
		CSingleton<CGameManager>.Instance.m_CurrencyType = (EMoneyCurrencyType)UniversalSettingsRunner.Instance.GetCustomInteger(5);
		CSingleton<CGameManager>.Instance.m_CenterDotHasOutline = UniversalSettingsRunner.Instance.GetCustomBoolean(3);
		CSingleton<CGameManager>.Instance.m_OpenPackShowNewCard = UniversalSettingsRunner.Instance.GetCustomBoolean(4);
		CSingleton<CGameManager>.Instance.m_OpenPacAutoNextCard = UniversalSettingsRunner.Instance.GetCustomBoolean(5);
		CSingleton<CGameManager>.Instance.m_DisableController = UniversalSettingsRunner.Instance.GetCustomBoolean(6);
		CSingleton<CGameManager>.Instance.m_IsTurnVSyncOff = UniversalSettingsRunner.Instance.GetCustomBoolean(7);
		if (CSingleton<CGameManager>.Instance.m_IsTurnVSyncOff)
		{
			QualitySettings.vSyncCount = 0;
		}
		else
		{
			QualitySettings.vSyncCount = 1;
		}
		CSingleton<InputManager>.Instance.SetIsControllerDisabledSetting(CSingleton<CGameManager>.Instance.m_DisableController);
		CSingleton<CGameManager>.Instance.m_MouseSensitivityLerp = Mathf.Lerp(0.2f, 1.8f, CSingleton<CGameManager>.Instance.m_MouseSensitivity);
		CEventManager.QueueEvent(new CEventPlayer_OnSettingUpdated());
	}

	// Token: 0x06000613 RID: 1555 RVA: 0x00032A41 File Offset: 0x00030C41
	public void ManualUpdate()
	{
		if (!this.m_IsChangingKeybind && CSingleton<SettingScreen>.Instance.m_ScreenGrp.activeSelf && (Input.GetKeyUp(KeyCode.Escape) || InputManager.GetKeyUpAction(EGameAction.ClosePhone)))
		{
			SettingScreen.CloseScreen();
		}
	}

	// Token: 0x06000614 RID: 1556 RVA: 0x00032A73 File Offset: 0x00030C73
	public void OnSettingUpdated(float amount)
	{
	}

	// Token: 0x06000615 RID: 1557 RVA: 0x00032A78 File Offset: 0x00030C78
	public void OnPressGameSetting()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		if (SettingScreen.CheckKeybindChangesConfirmScreenPopup())
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		this.m_GameSettingScreen.SetActive(true);
		this.m_DisplaySettingScreen.SetActive(false);
		this.m_LanguageScreen.SetActive(false);
		this.m_KeybindScreen.SetActive(false);
		this.ShowSubSettingBtnHighlight(0);
	}

	// Token: 0x06000616 RID: 1558 RVA: 0x00032ADC File Offset: 0x00030CDC
	public void OnPressDisplaySetting()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		if (SettingScreen.CheckKeybindChangesConfirmScreenPopup())
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		this.m_GameSettingScreen.SetActive(false);
		this.m_DisplaySettingScreen.SetActive(true);
		this.m_LanguageScreen.SetActive(false);
		this.m_KeybindScreen.SetActive(false);
		this.ShowSubSettingBtnHighlight(1);
	}

	// Token: 0x06000617 RID: 1559 RVA: 0x00032B40 File Offset: 0x00030D40
	public void OnPressLanguage()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		if (SettingScreen.CheckKeybindChangesConfirmScreenPopup())
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		this.m_GameSettingScreen.SetActive(false);
		this.m_DisplaySettingScreen.SetActive(false);
		this.m_LanguageScreen.SetActive(true);
		this.m_KeybindScreen.SetActive(false);
		this.ShowSubSettingBtnHighlight(2);
	}

	// Token: 0x06000618 RID: 1560 RVA: 0x00032BA4 File Offset: 0x00030DA4
	public void OnPressKeybindSetting()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		this.m_GameSettingScreen.SetActive(false);
		this.m_DisplaySettingScreen.SetActive(false);
		this.m_LanguageScreen.SetActive(false);
		this.m_KeybindScreen.SetActive(true);
		this.m_KeybindKeyboardHighlight.SetActive(true);
		this.m_KeybindControllerHighlight.SetActive(false);
		if (CSingleton<InputManager>.Instance.m_IsControllerActive)
		{
			this.m_KeybindKeyboardScreen.SetActive(false);
			this.m_KeybindControllerScreen.SetActive(true);
			this.m_KeybindKeyboardHighlight.SetActive(false);
			this.m_KeybindControllerHighlight.SetActive(true);
		}
		else
		{
			this.m_KeybindKeyboardScreen.SetActive(true);
			this.m_KeybindControllerScreen.SetActive(false);
			this.m_KeybindKeyboardHighlight.SetActive(true);
			this.m_KeybindControllerHighlight.SetActive(false);
		}
		this.ShowSubSettingBtnHighlight(3);
		this.EvaluateKeybindSettingUI();
	}

	// Token: 0x06000619 RID: 1561 RVA: 0x00032C8C File Offset: 0x00030E8C
	public void OnPressKeybindKeyboard()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		this.m_KeybindKeyboardHighlight.SetActive(true);
		this.m_KeybindControllerHighlight.SetActive(false);
		this.m_KeybindKeyboardScreen.SetActive(true);
		this.m_KeybindControllerScreen.SetActive(false);
		this.EvaluateKeybindSettingUI();
	}

	// Token: 0x0600061A RID: 1562 RVA: 0x00032CE8 File Offset: 0x00030EE8
	public void OnPressKeybindController()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		this.m_KeybindKeyboardHighlight.SetActive(false);
		this.m_KeybindControllerHighlight.SetActive(true);
		this.m_KeybindKeyboardScreen.SetActive(false);
		this.m_KeybindControllerScreen.SetActive(true);
		this.EvaluateKeybindSettingUI();
	}

	// Token: 0x0600061B RID: 1563 RVA: 0x00032D43 File Offset: 0x00030F43
	public void OnPressResetKeybind()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		CSingleton<InputManager>.Instance.ResetToDefaultKeybind();
		CSettingData.instance.SaveSettingData();
		this.EvaluateKeybindSettingUI();
	}

	// Token: 0x0600061C RID: 1564 RVA: 0x00032D77 File Offset: 0x00030F77
	public void OnPressUndoKeybind()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		CSingleton<InputManager>.Instance.UndoKeybind();
		this.EvaluateKeybindSettingUI();
	}

	// Token: 0x0600061D RID: 1565 RVA: 0x00032DA1 File Offset: 0x00030FA1
	public void OnPressSaveKeybind()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		CSettingData.instance.SaveSettingData();
		CEventManager.QueueEvent(new CEventPlayer_OnKeybindChanged());
	}

	// Token: 0x0600061E RID: 1566 RVA: 0x00032DD0 File Offset: 0x00030FD0
	private void EvaluateKeybindSettingUI()
	{
		for (int i = 0; i < this.m_KeybindSettingList.Count; i++)
		{
			this.m_KeybindSettingList[i].UpdateInputUI();
		}
	}

	// Token: 0x0600061F RID: 1567 RVA: 0x00032E04 File Offset: 0x00031004
	public void OnPressLanguageSelect(string language)
	{
		if (language == "English")
		{
			LocalizationManager.CurrentLanguageCode = "en";
		}
		else if (language == "France")
		{
			LocalizationManager.CurrentLanguageCode = "fr";
		}
		else if (language == "Germany")
		{
			LocalizationManager.CurrentLanguageCode = "de";
		}
		else if (language == "Spanish")
		{
			LocalizationManager.CurrentLanguageCode = "es";
		}
		else if (language == "ChineseT")
		{
			LocalizationManager.CurrentLanguageCode = "zh-TW";
		}
		else if (language == "ChineseS")
		{
			LocalizationManager.CurrentLanguageCode = "zh-CN";
		}
		else if (language == "Korean")
		{
			LocalizationManager.CurrentLanguageCode = "ko";
		}
		else if (language == "Japanese")
		{
			LocalizationManager.CurrentLanguageCode = "ja";
		}
		else if (language == "Portuguese")
		{
			LocalizationManager.CurrentLanguageCode = "pt";
		}
		else if (language == "Italian")
		{
			LocalizationManager.CurrentLanguageCode = "it";
		}
		else if (language == "Russian")
		{
			LocalizationManager.CurrentLanguageCode = "ru";
		}
		else if (language == "Hindi")
		{
			LocalizationManager.CurrentLanguageCode = "hi";
		}
		else if (language == "Thai")
		{
			LocalizationManager.CurrentLanguageCode = "th";
		}
		else if (language == "Arabic")
		{
			LocalizationManager.CurrentLanguageCode = "ar";
			LocalizationManager.IsRight2Left = false;
		}
		else if (language == "Dutch")
		{
			LocalizationManager.CurrentLanguageCode = "nl";
		}
		CEventManager.QueueEvent(new CEventPlayer_OnLanguageChanged());
	}

	// Token: 0x06000620 RID: 1568 RVA: 0x00032FB4 File Offset: 0x000311B4
	private void ShowSubSettingBtnHighlight(int index)
	{
		for (int i = 0; i < this.m_SubSettingBtnHighlight.Count; i++)
		{
			this.m_SubSettingBtnHighlight[i].SetActive(false);
		}
		this.m_SubSettingBtnHighlight[index].SetActive(true);
	}

	// Token: 0x06000621 RID: 1569 RVA: 0x00032FFB File Offset: 0x000311FB
	public void SetIsChangingKeybind(bool isChangingKeybind)
	{
		this.m_IsChangingKeybind = isChangingKeybind;
	}

	// Token: 0x06000622 RID: 1570 RVA: 0x00033004 File Offset: 0x00031204
	public static bool IsChangingKeybind()
	{
		return CSingleton<SettingScreen>.Instance.m_IsChangingKeybind;
	}

	// Token: 0x040007E3 RID: 2019
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x040007E4 RID: 2020
	public ControllerScreenUIExtension m_KeybindChangesConfirmScreenUIExtension;

	// Token: 0x040007E5 RID: 2021
	public GameObject m_ScreenGrp;

	// Token: 0x040007E6 RID: 2022
	public GameObject m_GameSettingScreen;

	// Token: 0x040007E7 RID: 2023
	public GameObject m_DisplaySettingScreen;

	// Token: 0x040007E8 RID: 2024
	public GameObject m_LanguageScreen;

	// Token: 0x040007E9 RID: 2025
	public GameObject m_KeybindScreen;

	// Token: 0x040007EA RID: 2026
	public GameObject m_KeybindKeyboardHighlight;

	// Token: 0x040007EB RID: 2027
	public GameObject m_KeybindControllerHighlight;

	// Token: 0x040007EC RID: 2028
	public GameObject m_KeybindKeyboardScreen;

	// Token: 0x040007ED RID: 2029
	public GameObject m_KeybindControllerScreen;

	// Token: 0x040007EE RID: 2030
	public GameObject m_KeybindChangesConfirmScreen;

	// Token: 0x040007EF RID: 2031
	public List<GameObject> m_SubSettingBtnHighlight;

	// Token: 0x040007F0 RID: 2032
	public List<KeybindSetting> m_KeybindSettingList;

	// Token: 0x040007F1 RID: 2033
	private bool m_IsCursorVisible;

	// Token: 0x040007F2 RID: 2034
	private bool m_IsTitleScreen = true;

	// Token: 0x040007F3 RID: 2035
	private bool m_IsChangingKeybind;

	// Token: 0x040007F4 RID: 2036
	private EMoneyCurrencyType m_CurrentCurrencyType;
}
