﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x02000127 RID: 295
public class SliderUI : MonoBehaviour
{
	// Token: 0x060008A8 RID: 2216 RVA: 0x00040C9C File Offset: 0x0003EE9C
	private void Awake()
	{
	}

	// Token: 0x060008A9 RID: 2217 RVA: 0x00040C9E File Offset: 0x0003EE9E
	public void OnSliderPress(int index)
	{
		this.EvaluateSlider();
	}

	// Token: 0x060008AA RID: 2218 RVA: 0x00040CA6 File Offset: 0x0003EEA6
	public void OnSliderDrag(int index)
	{
		this.EvaluateSlider();
	}

	// Token: 0x060008AB RID: 2219 RVA: 0x00040CAE File Offset: 0x0003EEAE
	public void OnRelease()
	{
		this.m_OnReleaseEvent.Invoke();
	}

	// Token: 0x060008AC RID: 2220 RVA: 0x00040CBC File Offset: 0x0003EEBC
	private void EvaluateSlider()
	{
		float num = this.m_EndPoint.position.x - this.m_StartPoint.position.x;
		float num2 = Input.mousePosition.x;
		num2 = Mathf.Clamp(num2, this.m_StartPoint.position.x, this.m_EndPoint.position.x);
		this.m_Percent = (num2 - this.m_StartPoint.position.x) / num;
		this.m_SliderIcon.position = new Vector3(num2, this.m_SliderIcon.position.y, 0f);
		this.m_SliderEvent.Invoke(this.m_Percent);
		this.EvaluateText();
	}

	// Token: 0x060008AD RID: 2221 RVA: 0x00040D74 File Offset: 0x0003EF74
	private void EvaluateText()
	{
		if (this.m_DecimalAmount <= 0f)
		{
			int num = Mathf.FloorToInt(this.m_Percent * 100f * this.m_PercentMultiplier / 100f);
			this.m_PercentText.text = num.ToString();
			return;
		}
		float num2 = (float)Mathf.FloorToInt(this.m_Percent * Mathf.Pow(10f, this.m_DecimalAmount) * this.m_PercentMultiplier) / Mathf.Pow(10f, this.m_DecimalAmount);
		this.m_PercentText.text = num2.ToString();
	}

	// Token: 0x060008AE RID: 2222 RVA: 0x00040E08 File Offset: 0x0003F008
	public void SetSliderPosByPercent(float percent)
	{
		this.m_Percent = percent;
		float num = Mathf.Lerp(this.m_StartPoint.position.x, this.m_EndPoint.position.x, percent);
		num = Mathf.Clamp(num, this.m_StartPoint.position.x, this.m_EndPoint.position.x);
		this.m_SliderIcon.position = new Vector3(num, this.m_SliderIcon.position.y, 0f);
		this.EvaluateText();
	}

	// Token: 0x060008AF RID: 2223 RVA: 0x00040E96 File Offset: 0x0003F096
	private void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.CPlayer_OnStartGame));
			CEventManager.AddListener<CEventPlayer_ChangeScene>(new CEventManager.EventDelegate<CEventPlayer_ChangeScene>(this.OnOpenLoadingScreen));
		}
	}

	// Token: 0x060008B0 RID: 2224 RVA: 0x00040EC8 File Offset: 0x0003F0C8
	private void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.CPlayer_OnStartGame));
			CEventManager.RemoveListener<CEventPlayer_ChangeScene>(new CEventManager.EventDelegate<CEventPlayer_ChangeScene>(this.OnOpenLoadingScreen));
		}
	}

	// Token: 0x060008B1 RID: 2225 RVA: 0x00040EFA File Offset: 0x0003F0FA
	private void CPlayer_OnStartGame(CEventPlayer_GameDataFinishLoaded evt)
	{
	}

	// Token: 0x060008B2 RID: 2226 RVA: 0x00040EFC File Offset: 0x0003F0FC
	private void OnOpenLoadingScreen(CEventPlayer_ChangeScene evt)
	{
	}

	// Token: 0x04001082 RID: 4226
	public TextMeshProUGUI m_PercentText;

	// Token: 0x04001083 RID: 4227
	public float m_PercentMultiplier = 255f;

	// Token: 0x04001084 RID: 4228
	public float m_DecimalAmount;

	// Token: 0x04001085 RID: 4229
	public RectTransform m_SliderIcon;

	// Token: 0x04001086 RID: 4230
	public RectTransform m_StartPoint;

	// Token: 0x04001087 RID: 4231
	public RectTransform m_EndPoint;

	// Token: 0x04001088 RID: 4232
	private float m_Percent;

	// Token: 0x04001089 RID: 4233
	public SliderPercentEvent m_SliderEvent;

	// Token: 0x0400108A RID: 4234
	public UnityEvent m_OnReleaseEvent;
}
