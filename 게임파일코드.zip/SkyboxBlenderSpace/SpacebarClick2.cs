﻿using System;
using UnityEngine;

namespace SkyboxBlenderSpace
{
	// Token: 0x020001A9 RID: 425
	public class SpacebarClick2 : MonoBehaviour
	{
		// Token: 0x06000C59 RID: 3161 RVA: 0x00056FE4 File Offset: 0x000551E4
		private void Update()
		{
			if (Input.GetKeyDown(KeyCode.Space))
			{
				this.skyboxScript.Blend(true, true);
				this.isStopped = false;
			}
			if (Input.GetKeyDown(KeyCode.E))
			{
				if (this.isStopped)
				{
					this.skyboxScript.Blend(true, true);
					this.isStopped = false;
					return;
				}
				this.skyboxScript.Stop(true);
				this.isStopped = true;
			}
		}

		// Token: 0x04001337 RID: 4919
		public SkyboxBlender skyboxScript;

		// Token: 0x04001338 RID: 4920
		private bool isStopped;
	}
}
