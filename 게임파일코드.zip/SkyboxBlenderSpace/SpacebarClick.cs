﻿using System;
using UnityEngine;

namespace SkyboxBlenderSpace
{
	// Token: 0x020001A8 RID: 424
	public class SpacebarClick : MonoBehaviour
	{
		// Token: 0x06000C57 RID: 3159 RVA: 0x00056F78 File Offset: 0x00055178
		private void Update()
		{
			if (Input.GetKeyDown(KeyCode.Space))
			{
				this.skyboxScript.Blend(false, true);
				this.isStopped = false;
			}
			if (Input.GetKeyDown(KeyCode.E))
			{
				if (this.isStopped)
				{
					this.skyboxScript.Resume(true);
					this.isStopped = false;
					return;
				}
				this.skyboxScript.Stop(true);
				this.isStopped = true;
			}
		}

		// Token: 0x04001335 RID: 4917
		public SkyboxBlender skyboxScript;

		// Token: 0x04001336 RID: 4918
		private bool isStopped;
	}
}
