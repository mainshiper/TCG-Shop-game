﻿using System;
using UnityEngine;

namespace SkyboxBlenderSpace
{
	// Token: 0x020001AA RID: 426
	public class SpacebarClick3 : MonoBehaviour
	{
		// Token: 0x06000C5B RID: 3163 RVA: 0x00057050 File Offset: 0x00055250
		private void Update()
		{
			if (Input.GetKeyDown(KeyCode.Space))
			{
				this.skyboxScript.Blend(2, true);
				this.isStopped = false;
			}
			if (Input.GetKeyDown(KeyCode.E))
			{
				if (this.isStopped)
				{
					this.skyboxScript.Blend(2, true);
					this.isStopped = false;
					return;
				}
				this.skyboxScript.Stop(true);
				this.isStopped = true;
			}
		}

		// Token: 0x04001339 RID: 4921
		public SkyboxBlender skyboxScript;

		// Token: 0x0400133A RID: 4922
		private bool isStopped;
	}
}
