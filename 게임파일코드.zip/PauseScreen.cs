﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x0200009B RID: 155
public class PauseScreen : CSingleton<PauseScreen>
{
	// Token: 0x06000602 RID: 1538 RVA: 0x000323C4 File Offset: 0x000305C4
	public static void OpenScreen()
	{
		if (CSingleton<PauseScreen>.Instance.m_ScreenGrp.activeSelf)
		{
			PauseScreen.CloseScreen();
			return;
		}
		CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
		CSingleton<PauseScreen>.Instance.m_IsCursorVisible = Cursor.visible;
		CSingleton<PauseScreen>.Instance.m_CursorLockMode = InputManager.GetCursorLockMode();
		CSingleton<PauseScreen>.Instance.m_IsCameraEnabled = CSingleton<InteractionPlayerController>.Instance.m_CameraController.enabled;
		CSingleton<InteractionPlayerController>.Instance.ShowCursor();
		CSingleton<PauseScreen>.Instance.m_VersionText.text = "v" + Application.version;
		CSingleton<PauseScreen>.Instance.m_ScreenGrp.SetActive(true);
		SoundManager.MuteAllSound();
		ControllerScreenUIExtManager.OnOpenScreen(CSingleton<PauseScreen>.Instance.m_ControllerScreenUIExtension);
		Time.timeScale = 0f;
	}

	// Token: 0x06000603 RID: 1539 RVA: 0x00032480 File Offset: 0x00030680
	public static void CloseScreen()
	{
		if (CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ScreenGrp.activeSelf)
		{
			SaveLoadGameSlotSelectScreen.CloseScreen();
			return;
		}
		if (CSingleton<SettingScreen>.Instance.m_ScreenGrp.activeSelf)
		{
			SettingScreen.CloseScreen();
			return;
		}
		Time.timeScale = 1f;
		SoundManager.UnMuteAllSound();
		CSingleton<PauseScreen>.Instance.m_ScreenGrp.SetActive(false);
		if (InputManager.GetCursorLockMode() == CursorLockMode.Confined && !CSingleton<InputManager>.Instance.m_IsControllerActive)
		{
			Cursor.visible = true;
		}
		else
		{
			Cursor.visible = false;
		}
		if (CSingleton<PauseScreen>.Instance.m_CursorLockMode == CursorLockMode.Locked)
		{
			CenterDot.SetVisibility(true);
		}
		InputManager.SetCursorLockMode(CSingleton<PauseScreen>.Instance.m_CursorLockMode);
		CSingleton<InteractionPlayerController>.Instance.m_CameraController.enabled = CSingleton<PauseScreen>.Instance.m_IsCameraEnabled;
		SoundManager.GenericLightTap(1f, 1f);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<PauseScreen>.Instance.m_ControllerScreenUIExtension);
		CSingleton<InteractionPlayerController>.Instance.ResetMousePress();
	}

	// Token: 0x06000604 RID: 1540 RVA: 0x0003255F File Offset: 0x0003075F
	public void OnPressSetting()
	{
		SoundManager.GenericLightTap(1f, 1f);
		SettingScreen.OpenScreen(false);
	}

	// Token: 0x06000605 RID: 1541 RVA: 0x00032576 File Offset: 0x00030776
	public void OpenLoadGameSlotScreen()
	{
		SoundManager.GenericLightTap(1f, 1f);
		SaveLoadGameSlotSelectScreen.OpenScreen(false);
	}

	// Token: 0x06000606 RID: 1542 RVA: 0x0003258D File Offset: 0x0003078D
	public void OpenSaveGameSlotScreen()
	{
		SoundManager.GenericLightTap(1f, 1f);
		SaveLoadGameSlotSelectScreen.OpenScreen(true);
	}

	// Token: 0x06000607 RID: 1543 RVA: 0x000325A4 File Offset: 0x000307A4
	public void OnPressBackMenu()
	{
		Time.timeScale = 1f;
		SoundManager.GenericLightTap(1f, 1f);
		CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
		CSingleton<CGameManager>.Instance.SaveGameData(0);
		CSingleton<CGameManager>.Instance.LoadMainLevelAsync("Title", -1);
	}

	// Token: 0x06000608 RID: 1544 RVA: 0x000325F0 File Offset: 0x000307F0
	public void OnPressQuit()
	{
		SoundManager.GenericLightTap(1f, 1f);
		Application.Quit();
	}

	// Token: 0x06000609 RID: 1545 RVA: 0x00032606 File Offset: 0x00030806
	public void OnPressWishlistOnSteam()
	{
		Application.OpenURL("https://store.steampowered.com/app/3070070?utm_source=prologue&utm_campaign=prologue1&utm_medium=game");
		UnityAnalytic.PressWishlist(1);
	}

	// Token: 0x0600060A RID: 1546 RVA: 0x00032618 File Offset: 0x00030818
	public void OnPressFeedbackBtn()
	{
		Application.OpenURL("https://steamcommunity.com/app/3070070/discussions/");
		UnityAnalytic.PressFeedback(1);
	}

	// Token: 0x0600060B RID: 1547 RVA: 0x0003262A File Offset: 0x0003082A
	public void OnPressDiscordBtn()
	{
		Application.OpenURL("https://discord.gg/2YaaUZzrRY");
		UnityAnalytic.JoinDiscord();
	}

	// Token: 0x040007DD RID: 2013
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x040007DE RID: 2014
	public GameObject m_ScreenGrp;

	// Token: 0x040007DF RID: 2015
	public TextMeshProUGUI m_VersionText;

	// Token: 0x040007E0 RID: 2016
	private bool m_IsCursorVisible;

	// Token: 0x040007E1 RID: 2017
	private bool m_IsCameraEnabled;

	// Token: 0x040007E2 RID: 2018
	private CursorLockMode m_CursorLockMode;
}
