﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200012D RID: 301
[CreateAssetMenu(fileName = "Data", menuName = "Inventory/List", order = 5)]
public class MonsterData_ScriptableObject : ScriptableObject
{
	// Token: 0x060008E3 RID: 2275 RVA: 0x000425D8 File Offset: 0x000407D8
	public MonsterData GetMonsterData(string monsterType)
	{
		for (int i = 0; i < this.m_DataList.Count; i++)
		{
			if (this.m_DataList[i].MonsterType.ToString() == monsterType)
			{
				return this.m_DataList[i];
			}
		}
		return this.m_DataList[0];
	}

	// Token: 0x060008E4 RID: 2276 RVA: 0x00042638 File Offset: 0x00040838
	public Color GetRarityColor(ERarity rarity)
	{
		return this.m_RarityColor[(int)rarity];
	}

	// Token: 0x060008E5 RID: 2277 RVA: 0x00042646 File Offset: 0x00040846
	public Sprite GetCardBorderSprite(ERarity rarity)
	{
		return this.m_CardBorderList[(int)rarity];
	}

	// Token: 0x060008E6 RID: 2278 RVA: 0x00042654 File Offset: 0x00040854
	public Sprite GetCardBGSprite(EElementIndex element)
	{
		if (element == EElementIndex.None)
		{
			return null;
		}
		return this.m_CardBGList[(int)element];
	}

	// Token: 0x060008E7 RID: 2279 RVA: 0x00042668 File Offset: 0x00040868
	public Sprite GetCardFrontSprite(EElementIndex elementIndex)
	{
		return this.m_CardFrontImageList[(int)elementIndex];
	}

	// Token: 0x060008E8 RID: 2280 RVA: 0x00042676 File Offset: 0x00040876
	public Sprite GetCardBackSprite(ECardExpansionType cardExpansionType)
	{
		return this.m_CardBackImageList[(int)cardExpansionType];
	}

	// Token: 0x060008E9 RID: 2281 RVA: 0x00042684 File Offset: 0x00040884
	public Sprite GetCardFoilMaskSprite(ECardExpansionType cardExpansionType)
	{
		return this.m_CardFoilMaskImageList[(int)cardExpansionType];
	}

	// Token: 0x040010D1 RID: 4305
	public List<EMonsterType> m_ShownMonsterList;

	// Token: 0x040010D2 RID: 4306
	public List<EMonsterType> m_ShownGhostMonsterList;

	// Token: 0x040010D3 RID: 4307
	public List<EMonsterType> m_ShownMegabotList;

	// Token: 0x040010D4 RID: 4308
	public List<EMonsterType> m_ShownFantasyRPGList;

	// Token: 0x040010D5 RID: 4309
	public List<EMonsterType> m_ShownCatJobList;

	// Token: 0x040010D6 RID: 4310
	public List<MonsterData> m_DataList;

	// Token: 0x040010D7 RID: 4311
	public List<MonsterData> m_MegabotDataList;

	// Token: 0x040010D8 RID: 4312
	public List<MonsterData> m_FantasyRPGDataList;

	// Token: 0x040010D9 RID: 4313
	public List<MonsterData> m_CatJobDataList;

	// Token: 0x040010DA RID: 4314
	public List<Color> m_RarityColor;

	// Token: 0x040010DB RID: 4315
	public List<Sprite> m_CardBorderList;

	// Token: 0x040010DC RID: 4316
	public List<Sprite> m_CardBGList;

	// Token: 0x040010DD RID: 4317
	public List<Sprite> m_CardFrontImageList;

	// Token: 0x040010DE RID: 4318
	public List<Sprite> m_CardBackImageList;

	// Token: 0x040010DF RID: 4319
	public List<Sprite> m_CardFoilMaskImageList;

	// Token: 0x040010E0 RID: 4320
	public List<CardUISetting> m_CardUISettingList;

	// Token: 0x040010E1 RID: 4321
	public List<Sprite> m_TetramonImageList;

	// Token: 0x040010E2 RID: 4322
	public List<MonsterData> m_SpecialCardImageList;
}
