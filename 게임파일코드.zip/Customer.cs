﻿using System;
using System.Collections;
using System.Collections.Generic;
using CC;
using I2.Loc;
using Pathfinding;
using UnityEngine;

// Token: 0x02000012 RID: 18
public class Customer : MonoBehaviour
{
	// Token: 0x06000093 RID: 147 RVA: 0x00009879 File Offset: 0x00007A79
	private void Start()
	{
		this.m_DefaultStartEndModifier = this.m_Seeker.startEndModifier;
	}

	// Token: 0x06000094 RID: 148 RVA: 0x0000988C File Offset: 0x00007A8C
	public void RandomizeCharacterMesh()
	{
		if (!this.m_CharacterCustom.m_HasInit)
		{
			if (this.m_IsFemale)
			{
				this.m_CharacterCustom.CharacterName = "Female" + CSingleton<CustomerManager>.Instance.GetCustomerModelIndex(false).ToString();
			}
			else
			{
				this.m_CharacterCustom.CharacterName = "Male" + CSingleton<CustomerManager>.Instance.GetCustomerModelIndex(true).ToString();
			}
			this.m_CharacterCustom.Initialize();
		}
	}

	// Token: 0x06000095 RID: 149 RVA: 0x0000990C File Offset: 0x00007B0C
	public void ActivateCustomer()
	{
		this.m_IsActive = true;
		this.RandomizeCharacterMesh();
		this.m_Timer = 0f;
		this.m_ModifiedSpeed = this.m_Speed + Random.Range(0f, 0.25f);
		this.m_FailFindShelfAttemptCount = 0;
		this.m_FailFindItemAttemptCount = 0;
		this.m_ItemScannedCount = 0;
		this.m_TotalScannedItemCost = 0f;
		this.m_HasTookItemFromShelf = false;
		this.m_IsAtPayingPosition = false;
		this.m_IsWaitingForPathCallback = false;
		this.m_UnableToFindQueue = false;
		this.m_IsChattyCustomer = (Random.Range(0, 100) < 10);
		this.m_CustomerCash.Init(this);
		this.m_TargetTransform = CustomerManager.GetRandomExitPoint();
		base.transform.position = this.m_TargetTransform.position;
		base.transform.rotation = this.m_TargetTransform.rotation;
		this.m_TargetLerpRotation = this.m_TargetTransform.rotation;
		this.m_MaxMoney = CSingleton<CustomerManager>.Instance.GetCustomerMaxMoney();
		this.m_CurrentCostTotal = 0f;
		this.SetState(ECustomerState.Idle);
		this.m_Timer = 10f;
		this.m_ShoppingBagTransform.gameObject.SetActive(false);
		this.m_Anim.SetBool("HoldingBag", false);
		this.m_Anim.SetBool("HandingOverCash", false);
		this.m_CustomerCash.gameObject.SetActive(false);
		this.m_GameCardFanOut.SetActive(false);
		this.m_GameCardSingle.SetActive(false);
		this.m_CleanFX.SetActive(false);
		this.m_IsSmelly = false;
		this.m_SmellyFX.SetActive(false);
		int num = Random.Range(0, 100);
		if (LightManager.IsEvening())
		{
			num -= 3;
		}
		else if (LightManager.IsNight())
		{
			num -= 5;
		}
		if (num < 2 + Mathf.Clamp(CPlayerData.m_ShopLevel / 2, 0, 15) && CSingleton<CustomerManager>.Instance.GetSmellyCustomerList().Count < CPlayerData.m_ShopLevel / 5 + 1)
		{
			this.SetSmelly();
		}
		this.m_TargetBuyItemList.Clear();
		int num2 = Random.Range(0, 100);
		int num3 = 40;
		if (CPlayerData.m_ShopLevel < 3)
		{
			num3 = 5;
		}
		else if (CPlayerData.m_ShopLevel < 5)
		{
			num3 = 12;
		}
		else if (CPlayerData.m_ShopLevel < 10)
		{
			num3 = 25;
		}
		if (num2 < num3)
		{
			Random.Range(0, 100);
			int num4 = 1;
			List<EItemType> unlockableItemTypeAtShopLevel = InventoryBase.GetUnlockableItemTypeAtShopLevel(CPlayerData.m_ShopLevel + num4);
			int num5 = Mathf.Clamp(Random.Range(-unlockableItemTypeAtShopLevel.Count / 2, unlockableItemTypeAtShopLevel.Count), 1, 6);
			if (unlockableItemTypeAtShopLevel.Count > 0)
			{
				for (int i = 0; i < num5; i++)
				{
					this.m_TargetBuyItemList.Add(unlockableItemTypeAtShopLevel[Random.Range(0, unlockableItemTypeAtShopLevel.Count)]);
				}
			}
		}
	}

	// Token: 0x06000096 RID: 150 RVA: 0x00009B96 File Offset: 0x00007D96
	public void SetSmelly()
	{
		this.m_IsSmelly = true;
		this.m_SmellyMeter = 10;
		CSingleton<CustomerManager>.Instance.AddToSmellyCustomerList(this);
		this.m_SmellyFX.SetActive(true);
	}

	// Token: 0x06000097 RID: 151 RVA: 0x00009BC0 File Offset: 0x00007DC0
	public void DeactivateCustomer()
	{
		for (int i = this.m_ItemInBagList.Count - 1; i >= 0; i--)
		{
			CPlayerData.AddCurrentTotalItemCount(this.m_ItemInBagList[i].GetItemType(), -1);
			this.m_ItemInBagList[i].DisableItem();
			this.m_ItemInBagList.RemoveAt(i);
		}
		for (int j = this.m_CardInBagList.Count - 1; j >= 0; j--)
		{
			this.m_CardInBagList[j].OnDestroyed();
			this.m_CardInBagList.RemoveAt(j);
		}
		if (!this.m_HasUpdatedCustomerCount)
		{
			this.m_HasUpdatedCustomerCount = true;
			CSingleton<CustomerManager>.Instance.UpdateCustomerCount(-1);
		}
		this.SetOutOfScreen();
		base.gameObject.SetActive(false);
		this.m_IsActive = false;
		this.m_IsInsideShop = false;
		this.m_HasPlayedGame = false;
		this.m_HasCheckedOut = false;
		this.m_HasUpdatedCustomerCount = false;
		this.m_IsAngry = false;
		if (this.m_IsSmelly)
		{
			this.m_IsSmelly = false;
			CSingleton<CustomerManager>.Instance.RemoveFromSmellyCustomerList(this);
		}
	}

	// Token: 0x06000098 RID: 152 RVA: 0x00009CC0 File Offset: 0x00007EC0
	public void DeodorantSprayCheck(Vector3 sprayPos, float range, int potency)
	{
		sprayPos.y = base.transform.position.y;
		if ((base.transform.position - sprayPos).magnitude < range)
		{
			this.m_IsBeingSprayed = true;
			this.m_BeingSprayedResetTimer = 0f;
			this.m_BeingSprayedResetTimeMax = Random.Range(1.5f, 3.5f);
			this.m_Anim.SetBool("IsBeingSprayed", true);
			if (this.m_IsSmelly)
			{
				this.m_SmellyMeter -= potency;
				if (this.m_SmellyMeter <= 0)
				{
					this.m_SmellyMeter = 0;
					this.m_IsSmelly = false;
					this.m_SmellyFX.SetActive(false);
					this.m_CleanFX.SetActive(true);
					CSingleton<CustomerManager>.Instance.RemoveFromSmellyCustomerList(this);
					CPlayerData.m_GameReportDataCollect.smellyCustomerCleaned = CPlayerData.m_GameReportDataCollect.smellyCustomerCleaned + 1;
					CPlayerData.m_GameReportDataCollectPermanent.smellyCustomerCleaned = CPlayerData.m_GameReportDataCollectPermanent.smellyCustomerCleaned + 1;
					AchievementManager.OnCleanSmellyCustomer(CPlayerData.m_GameReportDataCollectPermanent.smellyCustomerCleaned);
				}
			}
		}
	}

	// Token: 0x06000099 RID: 153 RVA: 0x00009DB8 File Offset: 0x00007FB8
	private bool HasNoItemOrCheckedOut()
	{
		return this.m_ItemInBagList.Count + this.m_CardInBagList.Count <= 0 || this.m_HasCheckedOut;
	}

	// Token: 0x0600009A RID: 154 RVA: 0x00009DDC File Offset: 0x00007FDC
	private bool StenchLeaveCheck()
	{
		if (this.m_IsInsideShop && !this.m_IsSmelly)
		{
			int smellyCustomerInsideShopCount = CSingleton<CustomerManager>.Instance.GetSmellyCustomerInsideShopCount();
			int num = Random.Range(0, 100);
			if (smellyCustomerInsideShopCount > 0 && num < smellyCustomerInsideShopCount * 15)
			{
				if (!CSingleton<CustomerManager>.Instance.IsWithinSmellyCustomerRange(base.transform.position))
				{
					return false;
				}
				this.PopupText(new List<string>
				{
					LocalizationManager.GetTranslation("Ugh, the stench...", true, 0, true, false, null, null, true),
					LocalizationManager.GetTranslation("It's too smelly!", true, 0, true, false, null, null, true),
					LocalizationManager.GetTranslation("Omg this place stinks!", true, 0, true, false, null, null, true)
				}, 100);
				if (this.m_ItemInBagList.Count > 0 || this.m_CardInBagList.Count > 0)
				{
					this.ThinkWantToPay();
				}
				else
				{
					this.ExitShop();
				}
				return true;
			}
		}
		return false;
	}

	// Token: 0x0600009B RID: 155 RVA: 0x00009EC0 File Offset: 0x000080C0
	private void OnCustomerReachInsideShop()
	{
		CPlayerData.m_GameReportDataCollect.customerVisited = CPlayerData.m_GameReportDataCollect.customerVisited + 1;
		CPlayerData.m_GameReportDataCollectPermanent.customerVisited = CPlayerData.m_GameReportDataCollectPermanent.customerVisited + 1;
		this.StenchLeaveCheck();
		if (this.m_CurrentState == ECustomerState.WalkToPlayTable)
		{
			if (this.m_CurrentPlayTable && this.m_CurrentPlayTableSeatIndex != -1)
			{
				this.m_CurrentPlayTable.CustomerUnbookSeatIndex(this.m_CurrentPlayTableSeatIndex);
			}
			this.AttemptFindPlayTable();
		}
		if (this.m_CurrentState == ECustomerState.WalkToShelf)
		{
			this.AttemptFindShelf();
		}
	}

	// Token: 0x0600009C RID: 156 RVA: 0x00009F38 File Offset: 0x00008138
	private void DetermineShopAction()
	{
		this.m_Seeker.startEndModifier = this.m_DefaultStartEndModifier;
		if (EndOfDayReportScreen.IsActive())
		{
			this.ExitShop();
			return;
		}
		if (this.StenchLeaveCheck())
		{
			return;
		}
		ShelfManager.GetShelfToBuyItem(this.m_TargetBuyItemList, 0) != null;
		bool flag = ShelfManager.GetCardShelfToBuyCard() != null;
		bool flag2 = ShelfManager.GetPlayTableToPlay(false) != null;
		bool flag3 = ShelfManager.HasPlayTableWithPlayerWaiting();
		bool flag4 = false;
		if (!this.m_HasPlayedGame && (flag2 || flag3) && this.HasNoItemOrCheckedOut() && !this.m_IsAngry)
		{
			int num = Random.Range(0, 100);
			if (LightManager.IsMorning())
			{
				num += 15;
			}
			if (LightManager.IsEvening())
			{
				num -= 30;
			}
			if (LightManager.IsNight())
			{
				num -= 40;
			}
			if (flag3)
			{
				num -= 25;
			}
			if (num < 33)
			{
				this.ThinkWantToPlayTable();
				flag4 = true;
			}
		}
		if (!flag4 && flag && !this.m_HasCheckedOut)
		{
			int num2 = Random.Range(0, 100);
			if (LightManager.IsAfternoon())
			{
				num2 -= 15;
			}
			if (num2 < 33)
			{
				this.ThinkWantToBuyCard();
				flag4 = true;
			}
		}
		if (!flag4)
		{
			if (!this.m_HasCheckedOut)
			{
				this.ThinkWantToBuyItem();
				return;
			}
			this.ExitShop();
		}
	}

	// Token: 0x0600009D RID: 157 RVA: 0x0000A058 File Offset: 0x00008258
	private void ThinkWantToBuyItem()
	{
		if (this.m_FailFindItemAttemptCount <= Random.Range(1, 5))
		{
			this.SetState(ECustomerState.WantToBuyItem);
			this.AttemptFindShelf();
			return;
		}
		if (this.m_ItemInBagList.Count > 0 || this.m_CardInBagList.Count > 0)
		{
			this.ThinkWantToPay();
			return;
		}
		this.ExitShop();
	}

	// Token: 0x0600009E RID: 158 RVA: 0x0000A0AC File Offset: 0x000082AC
	private void ThinkWantToBuyCard()
	{
		if (this.m_FailFindItemAttemptCount <= Random.Range(1, 5))
		{
			this.SetState(ECustomerState.WantToBuyCard);
			this.AttemptFindCardShelf();
			return;
		}
		if (this.m_ItemInBagList.Count > 0 || this.m_CardInBagList.Count > 0)
		{
			this.ThinkWantToPay();
			return;
		}
		this.ExitShop();
	}

	// Token: 0x0600009F RID: 159 RVA: 0x0000A100 File Offset: 0x00008300
	private void ThinkWantToPlayTable()
	{
		if (this.m_FailFindItemAttemptCount <= Random.Range(1, 5))
		{
			this.SetState(ECustomerState.WantToPlayGame);
			this.AttemptFindPlayTable();
			return;
		}
		if (this.m_ItemInBagList.Count > 0 || this.m_CardInBagList.Count > 0)
		{
			this.ThinkWantToPay();
			return;
		}
		this.ExitShop();
	}

	// Token: 0x060000A0 RID: 160 RVA: 0x0000A154 File Offset: 0x00008354
	private void AttemptFindShelf()
	{
		this.m_ReachedEndOfPath = false;
		this.m_CurrentShelf = ShelfManager.GetShelfToBuyItem(this.m_TargetBuyItemList, 0);
		if (this.m_CurrentShelf)
		{
			this.m_CurrentItemCompartment = this.m_CurrentShelf.GetCustomerTargetItemCompartment(this.m_TargetBuyItemList);
			this.m_TargetTransform = this.m_CurrentItemCompartment.m_CustomerStandLoc;
		}
		else
		{
			this.m_TargetTransform = CustomerManager.GetRandomShopLocationPoint();
		}
		if (this.m_TargetTransform)
		{
			this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
			this.m_IsWaitingForPathCallback = true;
			this.m_UnableToFindQueue = false;
			this.SetState(ECustomerState.WalkToShelf);
			return;
		}
		this.m_UnableToFindQueue = true;
		Debug.Log(base.transform.name + " unable to find shelf");
	}

	// Token: 0x060000A1 RID: 161 RVA: 0x0000A230 File Offset: 0x00008430
	private void TakeItemFromShelf()
	{
		this.m_IsInsideShop = true;
		if (!this.m_CurrentShelf)
		{
			this.SetState(ECustomerState.Idle);
			return;
		}
		float magnitude = (this.m_CurrentShelf.transform.position - base.transform.position).magnitude;
		float magnitude2 = (this.m_CurrentItemCompartment.transform.position - base.transform.position).magnitude;
		if (this.m_CurrentItemCompartment.GetItemCount() > 0 && this.m_CurrentShelf.IsValidObject())
		{
			Item lastItem = this.m_CurrentItemCompartment.GetLastItem();
			ItemData itemData = InventoryBase.GetItemData(lastItem.GetItemType());
			int num = Mathf.RoundToInt((50f - itemData.GetItemVolume()) / 10f);
			if (num < 0)
			{
				num = 0;
			}
			if (this.m_CurrentItemCompartment.GetItemCount() > 3)
			{
				num = 0;
			}
			int num2 = Random.Range(0, Mathf.Clamp(this.m_CurrentItemCompartment.GetItemCount() + 1 + num, 4, 14));
			int num3 = Random.Range(1, 60);
			float num4 = 0f;
			if (itemData.isNotBoosterPack)
			{
				if (num2 > 1)
				{
					num2 /= 2;
				}
				else if (Random.Range(0, 100) < 75)
				{
					num2 = 1;
				}
			}
			if (lastItem.GetItemType() == EItemType.Deodorant)
			{
				if (this.m_IsSmelly)
				{
					num2 = 0;
				}
				else
				{
					num2 = Random.Range(0, 4);
				}
			}
			num2 = Mathf.Clamp(num2, 0, this.m_CurrentItemCompartment.GetItemCount());
			bool flag = false;
			for (int i = 0; i < num2; i++)
			{
				lastItem = this.m_CurrentItemCompartment.GetLastItem();
				if (lastItem)
				{
					float itemPrice = CPlayerData.GetItemPrice(lastItem.GetItemType(), true);
					float itemMarketPrice = CPlayerData.GetItemMarketPrice(lastItem.GetItemType());
					int customerBuyItemChance = CSingleton<CustomerManager>.Instance.GetCustomerBuyItemChance(itemPrice, itemMarketPrice);
					int num5 = Random.Range(0, 100);
					if (!flag)
					{
						flag = this.BuyItemSpeechPopup(customerBuyItemChance, itemPrice, itemData.name);
					}
					if (num5 < customerBuyItemChance)
					{
						this.m_CurrentItemCompartment.RemoveItem(lastItem);
						lastItem.m_Mesh.enabled = true;
						this.m_ItemInBagList.Add(lastItem);
						lastItem.SetCurrentPrice(itemPrice);
						lastItem.LerpToTransform(this.m_ShoppingBagTransform, this.m_ShoppingBagTransform, false);
						lastItem.SetHideItemAfterFinishLerp();
						this.m_CurrentCostTotal += itemPrice;
						num4 += lastItem.GetItemVolume();
						if (num4 >= (float)num3 || this.m_CurrentCostTotal >= this.m_MaxMoney)
						{
							break;
						}
					}
				}
			}
			if (num4 > 0f)
			{
				this.m_ShoppingBagTransform.gameObject.SetActive(true);
				this.m_Anim.SetBool("HoldingBag", true);
				this.m_Anim.SetTrigger("GrabItem");
			}
			else
			{
				this.m_FailFindItemAttemptCount++;
			}
			if (this.m_DecideFinishShopping != null)
			{
				base.StopCoroutine(this.m_DecideFinishShopping);
			}
			this.m_DecideFinishShopping = base.StartCoroutine(this.DecideIfFinishShopping());
			return;
		}
		this.CustomerConfused();
		this.m_HasTookItemFromShelf = false;
		this.m_FailFindItemAttemptCount++;
		this.SetState(ECustomerState.Idle);
	}

	// Token: 0x060000A2 RID: 162 RVA: 0x0000A524 File Offset: 0x00008724
	private bool BuyItemSpeechPopup(int randomBuyItemChance, float currentPrice, string itemName)
	{
		List<string> list = new List<string>();
		if (randomBuyItemChance >= 100)
		{
			list.Add(LocalizationManager.GetTranslation("Buy buy buy!!", true, 0, true, false, null, null, true));
			list.Add(LocalizationManager.GetTranslation("Wow this is the cheapest I've seen!", true, 0, true, false, null, null, true));
			list.Add(LocalizationManager.GetTranslation("What a steal!", true, 0, true, false, null, null, true));
		}
		else if (randomBuyItemChance >= 90)
		{
			list.Add(LocalizationManager.GetTranslation("Cheap XXX. What a bargain!", true, 0, true, false, null, null, true).Replace("XXX", itemName));
			list.Add(LocalizationManager.GetTranslation("This is tempting!", true, 0, true, false, null, null, true));
			list.Add(LocalizationManager.GetTranslation("Wow so cheap!", true, 0, true, false, null, null, true));
		}
		else if (randomBuyItemChance >= 70)
		{
			if (currentPrice >= 2f)
			{
				list.Add(LocalizationManager.GetTranslation("XXX bucks for this is fair.", true, 0, true, false, null, null, true).Replace("XXX", Mathf.RoundToInt(currentPrice).ToString()));
			}
			list.Add(LocalizationManager.GetTranslation("Good price!", true, 0, true, false, null, null, true));
			list.Add(LocalizationManager.GetTranslation("Wow, gotta take one of these.", true, 0, true, false, null, null, true));
		}
		else if (randomBuyItemChance >= 50)
		{
			list.Add(LocalizationManager.GetTranslation("Fair price for a XXX.", true, 0, true, false, null, null, true).Replace("XXX", itemName));
			list.Add(LocalizationManager.GetTranslation("Not a bad price really.", true, 0, true, false, null, null, true));
			list.Add(LocalizationManager.GetTranslation("Fair price I'd say.", true, 0, true, false, null, null, true));
			list.Add(LocalizationManager.GetTranslation("This is fine.", true, 0, true, false, null, null, true));
		}
		else if (randomBuyItemChance >= 30)
		{
			list.Add(LocalizationManager.GetTranslation("XXX is a little expensive, hmm...", true, 0, true, false, null, null, true).Replace("XXX", itemName));
			list.Add(LocalizationManager.GetTranslation("Can't decide if I really want this.", true, 0, true, false, null, null, true));
			list.Add(LocalizationManager.GetTranslation("It's pricey, I need to think a little.", true, 0, true, false, null, null, true));
		}
		else if (randomBuyItemChance >= 1)
		{
			if (currentPrice >= 2f)
			{
				list.Add(LocalizationManager.GetTranslation("This cost XXX bucks!?", true, 0, true, false, null, null, true).Replace("XXX", Mathf.RoundToInt(currentPrice).ToString()));
			}
			list.Add(LocalizationManager.GetTranslation("Man, XXX sure is expensive!", true, 0, true, false, null, null, true).Replace("XXX", itemName));
			list.Add(LocalizationManager.GetTranslation("God, so expensive.", true, 0, true, false, null, null, true));
		}
		else if (randomBuyItemChance <= 0)
		{
			if (currentPrice >= 2f)
			{
				list.Add(LocalizationManager.GetTranslation("Ridiculous. XXX bucks for this!?", true, 0, true, false, null, null, true).Replace("XXX", Mathf.RoundToInt(currentPrice).ToString()));
			}
			list.Add(LocalizationManager.GetTranslation("Crazy. Who's gonna buy XXX at this price!?", true, 0, true, false, null, null, true).Replace("XXX", itemName));
			list.Add(LocalizationManager.GetTranslation("This is a scam!", true, 0, true, false, null, null, true));
		}
		return list.Count > 0 && this.PopupText(list, 15);
	}

	// Token: 0x060000A3 RID: 163 RVA: 0x0000A818 File Offset: 0x00008A18
	private void TakeCardFromShelf()
	{
		this.m_IsInsideShop = true;
		if (!this.m_CurrentCardShelf)
		{
			this.SetState(ECustomerState.Idle);
			return;
		}
		float magnitude = (this.m_CurrentCardShelf.transform.position - base.transform.position).magnitude;
		float magnitude2 = (this.m_CurrentCardCompartment.transform.position - base.transform.position).magnitude;
		if (this.m_CurrentCardCompartment.m_StoredCardList.Count <= 0 || !this.m_CurrentCardShelf.IsValidObject())
		{
			this.CustomerConfused();
			this.m_HasTookItemFromShelf = false;
			this.m_HasTookCardFromShelf = false;
			this.m_FailFindItemAttemptCount++;
			this.SetState(ECustomerState.Idle);
			return;
		}
		InteractableCard3d interactableCard3d = this.m_CurrentCardCompartment.m_StoredCardList[0];
		float cardPrice = CPlayerData.GetCardPrice(interactableCard3d.m_Card3dUI.m_CardUI.GetCardData());
		float cardMarketPrice = CPlayerData.GetCardMarketPrice(interactableCard3d.m_Card3dUI.m_CardUI.GetCardData());
		int customerBuyItemChance = CSingleton<CustomerManager>.Instance.GetCustomerBuyItemChance(cardPrice, cardMarketPrice);
		int num = Random.Range(0, 100);
		bool flag = true;
		if (num >= customerBuyItemChance)
		{
			flag = false;
			this.m_FailFindItemAttemptCount++;
		}
		this.BuyCardSpeechPopup(customerBuyItemChance, cardPrice, this.m_CurrentCostTotal + cardPrice <= this.m_MaxMoney);
		if (cardPrice > 0f && flag && this.m_CurrentCostTotal + cardPrice <= this.m_MaxMoney && interactableCard3d.IsDisplayedOnShelf())
		{
			this.m_CurrentCardCompartment.RemoveCardFromShelf(this.m_ShoppingBagTransform, this.m_ShoppingBagTransform);
			this.m_CardInBagList.Add(interactableCard3d);
			interactableCard3d.SetCurrentPrice(cardPrice);
			interactableCard3d.SetHideItemAfterFinishLerp();
			this.m_CurrentCostTotal += cardPrice;
			this.m_ShoppingBagTransform.gameObject.SetActive(true);
			this.m_Anim.SetBool("HoldingBag", true);
			this.m_Anim.SetTrigger("GrabItem");
			if (this.m_DecideFinishShopping != null)
			{
				base.StopCoroutine(this.m_DecideFinishShopping);
			}
			this.m_DecideFinishShopping = base.StartCoroutine(this.DecideIfFinishShopping());
			return;
		}
		if (this.m_DecideFinishShopping != null)
		{
			base.StopCoroutine(this.m_DecideFinishShopping);
		}
		this.m_DecideFinishShopping = base.StartCoroutine(this.DecideIfFinishShopping());
	}

	// Token: 0x060000A4 RID: 164 RVA: 0x0000AA58 File Offset: 0x00008C58
	private bool BuyCardSpeechPopup(int randomBuyItemChance, float cardPrice, bool hasEnoughMoney)
	{
		int appearChance = 15;
		int num = 70;
		List<string> list = new List<string>();
		if (randomBuyItemChance >= 100)
		{
			if (hasEnoughMoney)
			{
				list.Add(LocalizationManager.GetTranslation("Buy buy buy!!", true, 0, true, false, null, null, true));
				list.Add(LocalizationManager.GetTranslation("Wow this is the cheapest I've seen!", true, 0, true, false, null, null, true));
				list.Add(LocalizationManager.GetTranslation("What a steal!", true, 0, true, false, null, null, true));
			}
			else
			{
				appearChance = num;
				list.Add(LocalizationManager.GetTranslation("I want this, but I am broke.", true, 0, true, false, null, null, true));
				list.Add(LocalizationManager.GetTranslation("This is a steal, but I don't have enough money.", true, 0, true, false, null, null, true));
				list.Add(LocalizationManager.GetTranslation("I would so buy this if I have enough money", true, 0, true, false, null, null, true));
				list.Add(LocalizationManager.GetTranslation("This is the cheapest I've seen, but I am broke.", true, 0, true, false, null, null, true));
			}
		}
		else if (randomBuyItemChance >= 90)
		{
			if (hasEnoughMoney)
			{
				list.Add(LocalizationManager.GetTranslation("Cheap card. What a bargain!", true, 0, true, false, null, null, true));
				list.Add(LocalizationManager.GetTranslation("This is tempting!", true, 0, true, false, null, null, true));
				list.Add(LocalizationManager.GetTranslation("Wow so cheap!", true, 0, true, false, null, null, true));
			}
			else
			{
				appearChance = num;
				list.Add(LocalizationManager.GetTranslation("So tempting, but I am broke.", true, 0, true, false, null, null, true));
				list.Add(LocalizationManager.GetTranslation("Tempting, but I don't have enough money.", true, 0, true, false, null, null, true));
				list.Add(LocalizationManager.GetTranslation("Wow, if only I have enough money.", true, 0, true, false, null, null, true));
			}
		}
		else if (randomBuyItemChance >= 70)
		{
			if (hasEnoughMoney)
			{
				if (cardPrice >= 2f)
				{
					list.Add(LocalizationManager.GetTranslation("XXX bucks for this is fair.", true, 0, true, false, null, null, true).Replace("XXX", Mathf.RoundToInt(cardPrice).ToString()));
				}
				list.Add(LocalizationManager.GetTranslation("Good price!", true, 0, true, false, null, null, true));
				list.Add(LocalizationManager.GetTranslation("Wow, gotta take one of these.", true, 0, true, false, null, null, true));
			}
			else
			{
				appearChance = num;
				list.Add(LocalizationManager.GetTranslation("Good price, but I am broke.", true, 0, true, false, null, null, true));
				list.Add(LocalizationManager.GetTranslation("Seems fair, but I don't have enough money.", true, 0, true, false, null, null, true));
				list.Add(LocalizationManager.GetTranslation("Wow, if only I have enough money.", true, 0, true, false, null, null, true));
			}
		}
		else if (randomBuyItemChance >= 50)
		{
			if (hasEnoughMoney)
			{
				list.Add(LocalizationManager.GetTranslation("Not a bad price really.", true, 0, true, false, null, null, true));
				list.Add(LocalizationManager.GetTranslation("Fair price I'd say.", true, 0, true, false, null, null, true));
				list.Add(LocalizationManager.GetTranslation("This is fine.", true, 0, true, false, null, null, true));
			}
			else
			{
				appearChance = num;
				list.Add(LocalizationManager.GetTranslation("Not a bad price, but I am broke.", true, 0, true, false, null, null, true));
				list.Add(LocalizationManager.GetTranslation("Fair price, but I don't have enough money.", true, 0, true, false, null, null, true));
				list.Add(LocalizationManager.GetTranslation("Maybe if I have enough money.", true, 0, true, false, null, null, true));
			}
		}
		else if (randomBuyItemChance >= 30)
		{
			list.Add(LocalizationManager.GetTranslation("It's a little expensive, hmm...", true, 0, true, false, null, null, true));
			list.Add(LocalizationManager.GetTranslation("Can't decide if I really want this.", true, 0, true, false, null, null, true));
			list.Add(LocalizationManager.GetTranslation("It's pricey, I need to think a little.", true, 0, true, false, null, null, true));
		}
		else if (randomBuyItemChance >= 1)
		{
			if (cardPrice >= 2f)
			{
				list.Add(LocalizationManager.GetTranslation("This cost XXX bucks!?", true, 0, true, false, null, null, true).Replace("XXX", Mathf.RoundToInt(cardPrice).ToString()));
			}
			list.Add(LocalizationManager.GetTranslation("Man, this is expensive!", true, 0, true, false, null, null, true));
			list.Add(LocalizationManager.GetTranslation("God, so expensive.", true, 0, true, false, null, null, true));
		}
		else if (randomBuyItemChance <= 0)
		{
			if (cardPrice >= 2f)
			{
				list.Add(LocalizationManager.GetTranslation("Ridiculous. XXX bucks!?", true, 0, true, false, null, null, true).Replace("XXX", Mathf.RoundToInt(cardPrice).ToString()));
			}
			list.Add(LocalizationManager.GetTranslation("Crazy. Who's gonna buy at this price!?", true, 0, true, false, null, null, true));
			list.Add(LocalizationManager.GetTranslation("This is a scam!", true, 0, true, false, null, null, true));
			list.Add(LocalizationManager.GetTranslation("This card is way overpriced!", true, 0, true, false, null, null, true));
		}
		return list.Count > 0 && this.PopupText(list, appearChance);
	}

	// Token: 0x060000A5 RID: 165 RVA: 0x0000AE7C File Offset: 0x0000907C
	private void AttemptFindCardShelf()
	{
		this.m_ReachedEndOfPath = false;
		this.m_CurrentCardShelf = ShelfManager.GetCardShelfToBuyCard();
		bool flag = false;
		if (this.m_CurrentCardShelf)
		{
			flag = true;
			this.m_CurrentCardCompartment = this.m_CurrentCardShelf.GetCustomerTargetCardCompartment();
			this.m_TargetTransform = this.m_CurrentCardCompartment.m_CustomerStandLoc;
		}
		else
		{
			this.m_TargetTransform = CustomerManager.GetRandomShopLocationPoint();
		}
		if (this.m_TargetTransform && flag)
		{
			this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
			this.m_IsWaitingForPathCallback = true;
			this.m_UnableToFindQueue = false;
			this.SetState(ECustomerState.WalkToCardShelf);
			return;
		}
		this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
		this.m_IsWaitingForPathCallback = true;
		this.m_UnableToFindQueue = true;
		this.m_FailFindItemAttemptCount++;
		Debug.Log(base.transform.name + " unable to find card shelf");
		this.DetermineShopAction();
	}

	// Token: 0x060000A6 RID: 166 RVA: 0x0000AF9C File Offset: 0x0000919C
	private void AttemptFindPlayTable()
	{
		this.m_ReachedEndOfPath = false;
		if (ShelfManager.HasPlayTableWithPlayerWaiting())
		{
			this.m_CurrentPlayTable = ShelfManager.GetPlayTableToPlay(true);
		}
		else
		{
			this.m_CurrentPlayTable = ShelfManager.GetPlayTableToPlay(false);
		}
		if (this.m_CurrentPlayTable)
		{
			this.m_CurrentPlayTableSeatIndex = this.m_CurrentPlayTable.GetEmptySeatBookingIndex();
			if (this.m_CurrentPlayTableSeatIndex != -1)
			{
				this.m_CurrentPlayTable.CustomerBookSeatIndex(this.m_CurrentPlayTableSeatIndex);
				this.m_TargetTransform = this.m_CurrentPlayTable.GetStandLoc(this.m_CurrentPlayTableSeatIndex, false);
			}
		}
		else
		{
			this.m_TargetTransform = CustomerManager.GetRandomShopLocationPoint();
		}
		if (this.m_TargetTransform && this.m_CurrentPlayTableSeatIndex != -1)
		{
			this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
			this.m_IsWaitingForPathCallback = true;
			this.m_UnableToFindQueue = false;
			this.SetState(ECustomerState.WalkToPlayTable);
			return;
		}
		this.m_TargetTransform = CustomerManager.GetRandomShopLocationPoint();
		this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
		this.m_IsWaitingForPathCallback = true;
		this.m_UnableToFindQueue = true;
		this.m_FailFindItemAttemptCount++;
		Debug.Log(base.transform.name + " unable to find play table");
		this.DetermineShopAction();
	}

	// Token: 0x060000A7 RID: 167 RVA: 0x0000B0FE File Offset: 0x000092FE
	private IEnumerator DecideIfFinishShopping()
	{
		yield return new WaitForSeconds(1.5f);
		this.m_HasTookItemFromShelf = false;
		this.m_HasTookCardFromShelf = false;
		float num = 0f;
		for (int i = 0; i < this.m_ItemInBagList.Count; i++)
		{
			num += this.m_ItemInBagList[i].GetItemVolume();
		}
		if (Random.Range(0, 100) < 50 && num < 50f && this.m_CurrentCostTotal < this.m_MaxMoney)
		{
			this.DetermineShopAction();
		}
		else if (this.m_ItemInBagList.Count == 0 && this.m_CardInBagList.Count == 0)
		{
			this.DetermineShopAction();
		}
		else
		{
			this.ThinkWantToPay();
		}
		yield break;
	}

	// Token: 0x060000A8 RID: 168 RVA: 0x0000B10D File Offset: 0x0000930D
	private void ThinkWantToPay()
	{
		if (this.m_HasCheckedOut)
		{
			this.ExitShop();
			return;
		}
		this.SetState(ECustomerState.WantToPay);
		this.AttemptFindQueue();
	}

	// Token: 0x060000A9 RID: 169 RVA: 0x0000B12C File Offset: 0x0000932C
	private void AttemptFindQueue()
	{
		this.m_ReachedEndOfPath = false;
		this.m_CurrentQueueCashierCounter = ShelfManager.GetCashierCounter();
		if (this.m_CurrentQueueCashierCounter)
		{
			this.m_TargetTransform = this.m_CurrentQueueCashierCounter.GetQueuePosition();
		}
		else
		{
			this.m_TargetTransform = null;
		}
		if (this.m_TargetTransform)
		{
			this.m_Seeker.startEndModifier = this.m_OriginalStartEndModifier;
			this.m_CurrentQueueCashierCounter.AddCustomerToQueue(this);
			this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
			this.m_IsWaitingForPathCallback = true;
			this.m_UnableToFindQueue = false;
			this.SetState(ECustomerState.QueuingToPay);
			return;
		}
		this.m_TargetTransform = CustomerManager.GetRandomShopLocationPoint();
		this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
		this.m_IsWaitingForPathCallback = true;
		this.m_UnableToFindQueue = true;
	}

	// Token: 0x060000AA RID: 170 RVA: 0x0000B228 File Offset: 0x00009428
	private void OnReachedPathEnd()
	{
		if (this.m_TargetTransform)
		{
			this.m_TargetLerpRotation = this.m_TargetTransform.rotation;
		}
		float num = 0f;
		if (this.m_TargetTransform)
		{
			num = (this.m_TargetTransform.position - base.transform.position).magnitude;
		}
		if (num > 1f && this.m_CurrentState == ECustomerState.ExitingShop && this.m_IsInsideShop)
		{
			Vector3 forward = this.m_TargetTransform.position - base.transform.position;
			forward.y = 0f;
			this.m_TargetLerpRotation = Quaternion.LookRotation(forward, Vector3.up);
			this.PopupText(new List<string>
			{
				LocalizationManager.GetTranslation("The door is blocked!!", true, 0, true, false, null, null, true),
				LocalizationManager.GetTranslation("I can't fit in the exit!", true, 0, true, false, null, null, true),
				LocalizationManager.GetTranslation("How do I get out!?", true, 0, true, false, null, null, true),
				LocalizationManager.GetTranslation("Wait, how do I get out!?", true, 0, true, false, null, null, true),
				LocalizationManager.GetTranslation("Let me out!", true, 0, true, false, null, null, true)
			}, 50);
			this.m_TargetTransform = CustomerManager.GetRandomShopLocationPoint();
			this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
			this.m_IsWaitingForPathCallback = true;
			this.CustomerConfused();
			this.SetState(ECustomerState.Idle);
			return;
		}
		if (num > 1f && !this.m_UnableToFindQueue && this.m_CurrentState != ECustomerState.QueuingToPay && this.m_CurrentState != ECustomerState.WantToPay)
		{
			Vector3 forward2 = this.m_TargetTransform.position - base.transform.position;
			forward2.y = 0f;
			this.m_TargetLerpRotation = Quaternion.LookRotation(forward2, Vector3.up);
			this.PopupText(new List<string>
			{
				LocalizationManager.GetTranslation("The door is blocked!!", true, 0, true, false, null, null, true),
				LocalizationManager.GetTranslation("I can't fit in the entrance!", true, 0, true, false, null, null, true),
				LocalizationManager.GetTranslation("How do I get in!?", true, 0, true, false, null, null, true),
				LocalizationManager.GetTranslation("Wait, how do I get in!?", true, 0, true, false, null, null, true),
				LocalizationManager.GetTranslation("Let me in!", true, 0, true, false, null, null, true)
			}, 50);
			this.m_TargetTransform = CustomerManager.GetRandomShopWindowOutsidePoint();
			this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
			this.m_IsWaitingForPathCallback = true;
			this.CustomerConfused();
			this.m_FailFindItemAttemptCount++;
			this.m_FailFindShelfAttemptCount++;
			return;
		}
		if (this.m_CurrentState == ECustomerState.ShopNotOpen)
		{
			if (CPlayerData.m_IsShopOpen)
			{
				this.DetermineShopAction();
				return;
			}
			this.CustomerConfused();
			this.m_HasTookItemFromShelf = false;
			this.m_FailFindItemAttemptCount++;
			this.SetState(ECustomerState.Idle);
			return;
		}
		else if (this.m_CurrentState == ECustomerState.WalkToShelf)
		{
			if (!this.m_CurrentShelf)
			{
				this.CustomerConfused();
				if (this.m_FailFindShelfAttemptCount > Random.Range(1, 5))
				{
					base.StartCoroutine(this.DelayExitShop(2f));
				}
				else
				{
					this.AttemptFindShelf();
				}
				this.m_FailFindShelfAttemptCount++;
				return;
			}
			Vector3 forward3 = this.m_CurrentItemCompartment.transform.position - base.transform.position;
			forward3.y = 0f;
			this.m_TargetLerpRotation = Quaternion.LookRotation(forward3, Vector3.up);
			if (this.m_CurrentItemCompartment.GetItemCount() <= 0 || !this.m_CurrentShelf.IsValidObject())
			{
				this.CustomerConfused();
				this.m_FailFindItemAttemptCount++;
				this.SetState(ECustomerState.Idle);
				return;
			}
			if (this.m_CurrentShelf.HasItemTypeOnShelf(this.m_TargetBuyItemList))
			{
				this.SetState(ECustomerState.TakingItemFromShelf);
				return;
			}
			if (ShelfManager.GetShelfToBuyItem(this.m_TargetBuyItemList, 50))
			{
				this.m_FailFindItemAttemptCount++;
				this.SetState(ECustomerState.Idle);
				return;
			}
			ItemData itemData = InventoryBase.GetItemData(this.m_TargetBuyItemList[Random.Range(0, this.m_TargetBuyItemList.Count)]);
			this.PopupText(new List<string>
			{
				LocalizationManager.GetTranslation("I can't find XXX.", true, 0, true, false, null, null, true).Replace("XXX", itemData.GetName()),
				LocalizationManager.GetTranslation("Where is XXX?", true, 0, true, false, null, null, true).Replace("XXX", itemData.GetName()),
				LocalizationManager.GetTranslation("No XXX here.", true, 0, true, false, null, null, true).Replace("XXX", itemData.GetName()),
				LocalizationManager.GetTranslation("I need XXX.", true, 0, true, false, null, null, true).Replace("XXX", itemData.GetName()),
				LocalizationManager.GetTranslation("Why can't I get XXX in this shop!?", true, 0, true, false, null, null, true).Replace("XXX", itemData.GetName()),
				LocalizationManager.GetTranslation("I am looking for XXX.", true, 0, true, false, null, null, true).Replace("XXX", itemData.GetName()),
				LocalizationManager.GetTranslation("No XXX here.", true, 0, true, false, null, null, true).Replace("XXX", itemData.GetName())
			}, 80);
			this.CustomerConfused();
			this.m_FailFindItemAttemptCount++;
			this.SetState(ECustomerState.Idle);
			return;
		}
		else
		{
			if (this.m_CurrentState != ECustomerState.WalkToCardShelf)
			{
				if (this.m_CurrentState == ECustomerState.WalkToPlayTable)
				{
					if (!this.m_CurrentPlayTable || (this.m_CurrentPlayTable && !this.m_CurrentPlayTable.IsValidObject()))
					{
						this.CustomerConfused();
						if (this.m_FailFindShelfAttemptCount > Random.Range(1, 5))
						{
							base.StartCoroutine(this.DelayExitShop(2f));
						}
						else
						{
							this.AttemptFindPlayTable();
						}
						this.m_FailFindShelfAttemptCount++;
						return;
					}
					Vector3 forward4 = this.m_CurrentPlayTable.transform.position - base.transform.position;
					forward4.y = 0f;
					this.m_TargetLerpRotation = Quaternion.LookRotation(forward4, Vector3.up);
					this.m_CurrentPlayTableFee = PriceChangeManager.GetGameEventPrice(CPlayerData.m_GameEventFormat, true);
					int customerBuyItemChance = CSingleton<CustomerManager>.Instance.GetCustomerBuyItemChance(this.m_CurrentPlayTableFee, PriceChangeManager.GetGameEventMarketPrice(CPlayerData.m_GameEventFormat));
					if (Random.Range(0, 90) >= customerBuyItemChance)
					{
						this.PopupText(new List<string>
						{
							LocalizationManager.GetTranslation("Too expensive to play...", true, 0, true, false, null, null, true),
							LocalizationManager.GetTranslation("Fee is too high here!", true, 0, true, false, null, null, true),
							LocalizationManager.GetTranslation("I will play somewhere else!", true, 0, true, false, null, null, true)
						}, 100);
						this.m_IsAngry = true;
						this.m_FailFindItemAttemptCount++;
						this.SetState(ECustomerState.Idle);
						return;
					}
					if (!this.SitDownAndStartPlay())
					{
						if (Random.Range(0, 100) >= 30)
						{
							if (this.m_CurrentPlayTable && this.m_CurrentPlayTableSeatIndex != -1)
							{
								this.m_CurrentPlayTable.CustomerUnbookSeatIndex(this.m_CurrentPlayTableSeatIndex);
							}
							this.m_CurrentPlayTable = null;
							this.m_CurrentPlayTableSeatIndex = -1;
							this.CustomerConfused();
							this.m_FailFindItemAttemptCount++;
							this.SetState(ECustomerState.Idle);
							return;
						}
						if (!this.m_CurrentPlayTable.IsQueueEmpty(this.m_CurrentPlayTableSeatIndex))
						{
							this.AttemptFindPlayTable();
							return;
						}
						this.m_CurrentPlayTable.CustomerBookQueueIndex(this.m_CurrentPlayTableSeatIndex);
						this.SetState(ECustomerState.QueueingPlayTable);
						this.m_TimerMax = (float)Random.Range(5, 30);
						this.m_TargetTransform = null;
						return;
					}
				}
				else if (this.m_CurrentState == ECustomerState.QueueingPlayTable)
				{
					if (!this.m_CurrentPlayTable || (this.m_CurrentPlayTable && !this.m_CurrentPlayTable.IsValidObject()))
					{
						this.CustomerConfused();
						if (this.m_FailFindShelfAttemptCount > Random.Range(1, 5))
						{
							base.StartCoroutine(this.DelayExitShop(2f));
						}
						else
						{
							this.AttemptFindPlayTable();
						}
						this.m_FailFindShelfAttemptCount++;
						return;
					}
					if (!CPlayerData.m_IsShopOpen || LightManager.GetHasDayEnded())
					{
						this.m_FailFindItemAttemptCount = 5;
						this.GoShopNotOpenState();
						return;
					}
					bool flag = this.SitDownAndStartPlay();
					if (flag && this.m_TimerMax > 0f)
					{
						this.m_TimerMax = 0f;
						this.m_CurrentPlayTable.CustomerUnbookQueueIndex(this.m_CurrentPlayTableSeatIndex);
						this.m_CurrentPlayTable.CustomerUnbookSeatIndex(this.m_CurrentPlayTableSeatIndex);
						return;
					}
					if (!flag && this.m_TimerMax > 0f)
					{
						if (ShelfManager.HasPlayTableWithPlayerWaiting())
						{
							this.AttemptFindPlayTable();
							return;
						}
					}
					else if (!flag && this.m_TimerMax <= 0f)
					{
						if (this.m_CurrentPlayTable && this.m_CurrentPlayTableSeatIndex != -1)
						{
							this.m_CurrentPlayTable.CustomerUnbookQueueIndex(this.m_CurrentPlayTableSeatIndex);
							this.m_CurrentPlayTable.CustomerUnbookSeatIndex(this.m_CurrentPlayTableSeatIndex);
						}
						this.m_CurrentPlayTable = null;
						this.m_CurrentPlayTableSeatIndex = -1;
						this.CustomerConfused();
						this.m_FailFindItemAttemptCount++;
						this.SetState(ECustomerState.Idle);
						return;
					}
				}
				else
				{
					if (this.m_CurrentState == ECustomerState.ExitingShop)
					{
						this.DeactivateCustomer();
						return;
					}
					if ((this.m_CurrentState == ECustomerState.WantToBuyItem || this.m_CurrentState == ECustomerState.WantToPay || this.m_CurrentState == ECustomerState.WantToBuyCard || this.m_CurrentState == ECustomerState.WantToPlayGame) && this.m_UnableToFindQueue)
					{
						this.CustomerConfused();
					}
				}
				return;
			}
			if (!this.m_CurrentCardShelf)
			{
				this.CustomerConfused();
				if (this.m_FailFindShelfAttemptCount > Random.Range(1, 5))
				{
					base.StartCoroutine(this.DelayExitShop(2f));
				}
				else
				{
					this.AttemptFindCardShelf();
				}
				this.m_FailFindShelfAttemptCount++;
				return;
			}
			Vector3 forward5 = this.m_CurrentCardCompartment.transform.position - base.transform.position;
			forward5.y = 0f;
			this.m_TargetLerpRotation = Quaternion.LookRotation(forward5, Vector3.up);
			if (this.m_CurrentCardCompartment.m_StoredCardList.Count > 0 && this.m_CurrentCardShelf.IsValidObject())
			{
				this.SetState(ECustomerState.TakingItemFromCardShelf);
				return;
			}
			this.CustomerConfused();
			this.m_FailFindItemAttemptCount++;
			this.SetState(ECustomerState.Idle);
			return;
		}
	}

	// Token: 0x060000AB RID: 171 RVA: 0x0000BC74 File Offset: 0x00009E74
	private bool SitDownAndStartPlay()
	{
		this.m_IsInsideShop = true;
		if (this.m_CurrentPlayTable && this.m_CurrentPlayTable.IsSeatEmpty(this.m_CurrentPlayTableSeatIndex) && this.m_CurrentPlayTable.IsValidObject())
		{
			this.SetState(ECustomerState.PlayingAtTable);
			this.m_TargetTransform = this.m_CurrentPlayTable.GetSitLoc(this.m_CurrentPlayTableSeatIndex);
			this.m_Timer = 0f;
			this.m_SecondaryTimer = 0f;
			this.m_SecondaryTimerMax = (float)Random.Range(5, 30);
			this.m_LerpStartPos = base.transform.position;
			this.m_TargetLerpPos = this.m_TargetTransform.position;
			this.m_TargetLerpRotation = this.m_TargetTransform.rotation;
			this.m_CurrentPlayTable.CustomerHasReached(this, this.m_CurrentPlayTableSeatIndex);
			if (this.m_ItemInBagList.Count > 0 || this.m_CardInBagList.Count > 0)
			{
				this.m_ShoppingBagTransform.gameObject.SetActive(false);
				this.m_Anim.SetBool("HoldingBag", false);
			}
			this.m_Anim.SetBool("IsSitting", true);
			CSingleton<CustomerManager>.Instance.AddPlayTableSitdownCustomerCount(1);
			return true;
		}
		if (this.m_CurrentPlayTable && !this.m_CurrentPlayTable.IsSeatEmpty(this.m_CurrentPlayTableSeatIndex) && this.m_CurrentPlayTable.IsValidObject() && this.m_CurrentPlayTable.GetEmptySeatIndex() != -1)
		{
			this.m_CurrentPlayTableSeatIndex = this.m_CurrentPlayTable.GetEmptySeatIndex();
			this.m_TargetTransform = this.m_CurrentPlayTable.GetStandLoc(this.m_CurrentPlayTableSeatIndex, false);
			if (this.m_TargetTransform)
			{
				this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
				this.m_IsWaitingForPathCallback = true;
				this.m_UnableToFindQueue = false;
				this.SetState(ECustomerState.WalkToPlayTable);
				return true;
			}
		}
		return false;
	}

	// Token: 0x060000AC RID: 172 RVA: 0x0000BE64 File Offset: 0x0000A064
	public void SetOutOfScreen()
	{
		base.transform.position = Vector3.one * 10000f;
	}

	// Token: 0x060000AD RID: 173 RVA: 0x0000BE80 File Offset: 0x0000A080
	private void WaypointEndUpdate()
	{
		if (this.m_CurrentState == ECustomerState.QueuingToPay && !this.m_IsAtPayingPosition && !this.m_IsWaitingForPathCallback)
		{
			if (!this.m_TargetTransform)
			{
				this.SetState(ECustomerState.Idle);
				return;
			}
			if ((this.m_TargetTransform.position - base.transform.position).magnitude < 0.1f + this.m_CounterQueueDistanceReducer)
			{
				this.m_IsAtPayingPosition = this.m_CurrentQueueCashierCounter.IsCustomerAtPayingPosition(this.m_TargetTransform.position);
			}
			if (!this.m_IsAtPayingPosition && this.m_CurrentQueueCashierCounter.IsCustomerNextInLine(this))
			{
				this.m_CounterQueueDistanceReducer += Time.deltaTime * 0.1f;
				if (this.m_CounterQueueDistanceReducer > 0.4f)
				{
					this.m_CounterQueueDistanceReducer = 0f;
					this.m_CurrentQueueCashierCounter.RemoveCustomerFromQueue(this);
					this.m_CurrentQueueCashierCounter.RemoveCurrentCustomerFromQueue();
					this.ThinkWantToPay();
					return;
				}
			}
			if (this.m_IsAtPayingPosition)
			{
				this.m_CounterQueueDistanceReducer = 0f;
				Vector3 forward = this.m_CurrentQueueCashierCounter.transform.position - base.transform.position;
				forward.y = 0f;
				this.m_TargetLerpRotation = Quaternion.LookRotation(forward, Vector3.up);
				this.SetState(ECustomerState.ReadyToPay);
				this.m_ShoppingBagTransform.gameObject.SetActive(false);
				this.m_Anim.SetBool("HoldingBag", false);
				this.m_CurrentQueueCashierCounter.SetPlsaticBagVisibility(true);
				this.m_CurrentQueueCashierCounter.UpdateCashierCounterState(ECashierCounterState.ScanningItem);
				this.m_CurrentQueueCashierCounter.UpdateCurrentCustomer(this);
				for (int i = 0; i < this.m_ItemInBagList.Count; i++)
				{
					this.m_ItemInBagList[i].transform.parent = this.m_CurrentQueueCashierCounter.transform;
					this.m_ItemInBagList[i].transform.position = this.m_CurrentQueueCashierCounter.m_CustomerPlaceItemPos.position;
					int num = i % 8;
					int num2 = Mathf.Clamp(i / 8, 0, 1);
					int num3 = Mathf.Clamp(i / 16, 0, 2);
					this.m_ItemInBagList[i].transform.position += this.m_CurrentQueueCashierCounter.m_CustomerPlaceItemPos.forward * (-0.025f * (float)num);
					this.m_ItemInBagList[i].transform.position += this.m_CurrentQueueCashierCounter.m_CustomerPlaceItemPos.right * (0.1f * (float)num2);
					this.m_ItemInBagList[i].transform.position += Vector3.up * (0.2f * (float)num3);
					this.m_ItemInBagList[i].transform.rotation = this.m_CurrentQueueCashierCounter.m_CustomerPlaceItemPos.rotation;
					this.m_ItemInBagList[i].transform.Rotate(new Vector3((float)Random.Range(-30, -5), (float)Random.Range(-5, 5), (float)Random.Range(-5, 5)));
					this.m_ItemInBagList[i].m_Mesh.enabled = true;
					this.m_ItemInBagList[i].gameObject.SetActive(true);
					this.m_ItemInBagList[i].m_Collider.enabled = true;
					this.m_ItemInBagList[i].m_Rigidbody.isKinematic = false;
					this.m_ItemInBagList[i].m_InteractableScanItem.enabled = true;
					this.m_ItemInBagList[i].m_InteractableScanItem.RegisterScanItem(this, this.m_CurrentQueueCashierCounter.m_ScannedItemLerpPos);
				}
				for (int j = 0; j < this.m_CardInBagList.Count; j++)
				{
					this.m_CardInBagList[j].transform.parent = this.m_CurrentQueueCashierCounter.transform;
					this.m_CardInBagList[j].transform.position = this.m_CurrentQueueCashierCounter.m_CustomerPlaceItemPos.position;
					this.m_CardInBagList[j].transform.localScale = Vector3.one;
					int num4 = j % 8;
					int num5 = Mathf.Clamp(j / 8, 0, 1);
					int num6 = Mathf.Clamp(j / 16, 0, 2);
					this.m_CardInBagList[j].transform.position += this.m_CurrentQueueCashierCounter.m_CustomerPlaceItemPos.forward * (-0.035f * (float)num4);
					this.m_CardInBagList[j].transform.position += this.m_CurrentQueueCashierCounter.m_CustomerPlaceItemPos.right * (0.1f * (float)num5);
					this.m_CardInBagList[j].transform.position += Vector3.up * (0.3f * (float)num6);
					this.m_CardInBagList[j].transform.rotation = this.m_CurrentQueueCashierCounter.m_CustomerPlaceItemPos.rotation;
					this.m_CardInBagList[j].transform.Rotate(new Vector3((float)(Random.Range(-30, -5) + 180), (float)Random.Range(-5, 5), (float)Random.Range(-5, 5)));
					this.m_CardInBagList[j].m_Card3dUI.gameObject.SetActive(true);
					this.m_CardInBagList[j].gameObject.SetActive(true);
					this.m_CardInBagList[j].m_Collider.enabled = true;
					this.m_CardInBagList[j].m_Rigidbody.isKinematic = false;
					this.m_CardInBagList[j].RegisterScanCard(this, this.m_CurrentQueueCashierCounter.m_ScannedItemLerpPos);
				}
				this.m_IsCheckScanItemOutOfBound = true;
				this.m_CheckScanItemOutOfBoundTimer = 2f;
			}
		}
	}

	// Token: 0x060000AE RID: 174 RVA: 0x0000C490 File Offset: 0x0000A690
	private void CheckItemOutOfCashierBound()
	{
		float num = 0.2f;
		float num2 = 0.9f;
		float num3 = 0.33f;
		for (int i = 0; i < this.m_ItemInBagList.Count; i++)
		{
			if (this.m_ItemInBagList[i].m_InteractableScanItem.IsNotScanned())
			{
				if (this.m_ItemInBagList[i].transform.position.y < num2)
				{
					this.m_ItemInBagList[i].transform.position = this.m_CurrentQueueCashierCounter.m_CustomerPlaceItemPos.position;
				}
				else if (Mathf.Abs(this.m_ItemInBagList[i].transform.localPosition.z) > num3)
				{
					this.m_ItemInBagList[i].transform.position = this.m_CurrentQueueCashierCounter.m_CustomerPlaceItemPos.position;
				}
				else if (Mathf.Abs(this.m_ItemInBagList[i].transform.localPosition.x) > num)
				{
					this.m_ItemInBagList[i].transform.position = this.m_CurrentQueueCashierCounter.m_CustomerPlaceItemPos.position;
				}
				this.m_ItemInBagList[i].gameObject.SetActive(true);
				this.m_ItemInBagList[i].m_Mesh.enabled = true;
			}
		}
		for (int j = 0; j < this.m_CardInBagList.Count; j++)
		{
			if (this.m_CardInBagList[j].IsNotScanned())
			{
				if (this.m_CardInBagList[j].transform.position.y < num2)
				{
					this.m_CardInBagList[j].transform.position = this.m_CurrentQueueCashierCounter.m_CustomerPlaceItemPos.position;
				}
				else if (Mathf.Abs(this.m_CardInBagList[j].transform.localPosition.z) > num3)
				{
					this.m_CardInBagList[j].transform.position = this.m_CurrentQueueCashierCounter.m_CustomerPlaceItemPos.position;
				}
				else if (Mathf.Abs(this.m_CardInBagList[j].transform.localPosition.x) > num)
				{
					this.m_CardInBagList[j].transform.position = this.m_CurrentQueueCashierCounter.m_CustomerPlaceItemPos.position;
				}
				this.m_CardInBagList[j].m_Card3dUI.m_IgnoreCulling = true;
				this.m_CardInBagList[j].m_Card3dUI.m_CardUIAnimGrp.gameObject.SetActive(true);
			}
		}
	}

	// Token: 0x060000AF RID: 175 RVA: 0x0000C748 File Offset: 0x0000A948
	public void OnItemScanned(Item item)
	{
		float currentPrice = item.GetCurrentPrice();
		this.m_ItemScannedCount++;
		this.m_CurrentQueueCashierCounter.AddScannedItemCostTotal(currentPrice, item.GetItemType());
		this.m_TotalScannedItemCost += currentPrice;
		this.m_TotalScannedItemCost = (float)Mathf.RoundToInt(this.m_TotalScannedItemCost * GameInstance.GetCurrencyRoundDivideAmount()) / GameInstance.GetCurrencyRoundDivideAmount();
		this.EvaluateFinishScanItem();
	}

	// Token: 0x060000B0 RID: 176 RVA: 0x0000C7B0 File Offset: 0x0000A9B0
	public void OnCardScanned(InteractableCard3d card)
	{
		float currentPrice = card.GetCurrentPrice();
		this.m_ItemScannedCount++;
		this.m_CurrentQueueCashierCounter.AddScannedCardCostTotal(currentPrice, card.m_Card3dUI.m_CardUI.GetCardData());
		this.m_TotalScannedItemCost += currentPrice;
		this.m_TotalScannedItemCost = (float)Mathf.RoundToInt(this.m_TotalScannedItemCost * GameInstance.GetCurrencyRoundDivideAmount()) / GameInstance.GetCurrencyRoundDivideAmount();
		this.EvaluateFinishScanItem();
	}

	// Token: 0x060000B1 RID: 177 RVA: 0x0000C820 File Offset: 0x0000AA20
	private void EvaluateFinishScanItem()
	{
		if (this.m_ItemScannedCount >= this.m_ItemInBagList.Count + this.m_CardInBagList.Count)
		{
			bool flag = false;
			if (Random.Range(0, 100) < 30 && this.m_TotalScannedItemCost >= 5f)
			{
				flag = true;
			}
			if (this.m_TotalScannedItemCost >= 500f)
			{
				flag = true;
			}
			this.m_CustomerCash.SetIsCard(flag);
			this.m_CustomerCash.gameObject.SetActive(true);
			this.m_Anim.SetBool("HandingOverCash", true);
			this.m_CurrentQueueCashierCounter.SetCustomerPaidAmount(flag, this.GetRandomPayAmount(this.m_TotalScannedItemCost));
			this.m_CurrentQueueCashierCounter.UpdateCashierCounterState(ECashierCounterState.TakingCash);
			this.m_IsCheckScanItemOutOfBound = false;
		}
	}

	// Token: 0x060000B2 RID: 178 RVA: 0x0000C8D4 File Offset: 0x0000AAD4
	private float GetRandomPayAmount(float limit)
	{
		float num = 0f;
		List<int> list = new List<int>();
		list.Add(1);
		list.Add(5);
		list.Add(10);
		list.Add(20);
		list.Add(50);
		list.Add(100);
		list.Add(5);
		list.Add(10);
		list.Add(20);
		list.Add(5);
		list.Add(10);
		list.Add(-1);
		list.Add(5);
		list.Add(10);
		list.Add(-1);
		list.Add(5);
		list.Add(10);
		list.Add(-2);
		list.Add(1);
		list.Add(5);
		list.Add(1);
		list.Add(20);
		list.Add(50);
		list.Add(1);
		list.Add(1);
		list.Add(5);
		list.Add(10);
		list.Add(20);
		list.Add(50);
		list.Add(100);
		while (num < limit)
		{
			float num2 = (float)list[Random.Range(0, list.Count)];
			if (num2 == -1f)
			{
				num = (float)(Mathf.CeilToInt(this.m_TotalScannedItemCost / 5f) * 5);
			}
			else if (num2 == -2f)
			{
				num = this.m_TotalScannedItemCost;
			}
			else
			{
				num += num2;
			}
		}
		if (Random.Range(0, 100) < CSingleton<CustomerManager>.Instance.GetCustomerExactChangeChance())
		{
			num = this.m_TotalScannedItemCost;
		}
		if (Mathf.RoundToInt(num * 100f) == Mathf.RoundToInt(this.m_TotalScannedItemCost * 100f))
		{
			CSingleton<CustomerManager>.Instance.ResetCustomerExactChangeChance();
		}
		else
		{
			CSingleton<CustomerManager>.Instance.AddCustomerExactChangeChance();
			if (num - limit >= 50f)
			{
				num = (float)Mathf.CeilToInt(limit / 50f) * 50f;
			}
			if (num > limit)
			{
				if (num >= 100f)
				{
					num = (float)Mathf.CeilToInt(limit / 50f) * 50f;
				}
				else if (num >= 50f)
				{
					num = (float)Mathf.CeilToInt(limit / 20f) * 20f;
				}
				else if (num >= 20f)
				{
					num = (float)Mathf.CeilToInt(limit / 10f) * 10f;
				}
				else if (num >= 10f)
				{
					num = (float)Mathf.CeilToInt(limit / 5f) * 5f;
				}
				else if (num >= 2f)
				{
					num = (float)Mathf.CeilToInt(limit / 5f) * 5f;
				}
				else if (num < 1f)
				{
					int num3 = Random.Range(0, 5);
					if (num3 == 0)
					{
						num = 10f;
					}
					else if (num3 == 1)
					{
						num = 5f;
					}
					else
					{
						num = 1f;
					}
				}
				if (Random.Range(0, 100) < 10)
				{
					int num4 = Mathf.FloorToInt(num);
					float num5 = num - (float)num4;
					num += num5;
				}
			}
		}
		num = (float)Mathf.RoundToInt(num * 100f) / 100f;
		if (num < this.m_TotalScannedItemCost)
		{
			num = this.m_TotalScannedItemCost;
		}
		return num;
	}

	// Token: 0x060000B3 RID: 179 RVA: 0x0000CBA5 File Offset: 0x0000ADA5
	public void OnCashTaken(bool isCard)
	{
		this.m_CustomerCash.gameObject.SetActive(false);
		this.m_Anim.SetBool("HandingOverCash", false);
		this.m_CurrentQueueCashierCounter.StartGivingChange();
		this.m_CurrentQueueCashierCounter.UpdateCashierCounterState(ECashierCounterState.GivingChange);
	}

	// Token: 0x060000B4 RID: 180 RVA: 0x0000CBE0 File Offset: 0x0000ADE0
	public void CounterGiveChangeCompleted()
	{
		this.OnPayingDone();
	}

	// Token: 0x060000B5 RID: 181 RVA: 0x0000CBE8 File Offset: 0x0000ADE8
	private void OnPayingDone()
	{
		this.m_IsAtPayingPosition = false;
		this.m_HasCheckedOut = true;
		this.m_Path = null;
		if (this.m_ItemInBagList.Count + this.m_CardInBagList.Count > 0)
		{
			this.m_ShoppingBagTransform.gameObject.SetActive(true);
		}
		this.m_Anim.SetBool("HoldingBag", true);
		this.m_CurrentQueueCashierCounter.SetPlsaticBagVisibility(false);
		this.m_CurrentQueueCashierCounter.UpdateCashierCounterState(ECashierCounterState.Idle);
		this.m_CurrentQueueCashierCounter.UpdateCurrentCustomer(null);
		float num = 0f;
		for (int i = 0; i < this.m_ItemInBagList.Count; i++)
		{
			this.m_ItemInBagList[i].transform.parent = this.m_ShoppingBagTransform;
			this.m_ItemInBagList[i].transform.position = this.m_ShoppingBagTransform.position;
			this.m_ItemInBagList[i].transform.rotation = this.m_ShoppingBagTransform.rotation;
			this.m_ItemInBagList[i].gameObject.SetActive(false);
			this.m_ItemInBagList[i].m_Collider.enabled = false;
			this.m_ItemInBagList[i].m_Rigidbody.isKinematic = true;
			this.m_ItemInBagList[i].m_InteractableScanItem.enabled = false;
			num += this.m_ItemInBagList[i].GetItemVolume();
		}
		for (int j = 0; j < this.m_CardInBagList.Count; j++)
		{
			this.m_CardInBagList[j].transform.parent = this.m_ShoppingBagTransform;
			this.m_CardInBagList[j].transform.position = this.m_ShoppingBagTransform.position;
			this.m_CardInBagList[j].transform.rotation = this.m_ShoppingBagTransform.rotation;
			this.m_CardInBagList[j].m_Card3dUI.gameObject.SetActive(false);
			this.m_CardInBagList[j].gameObject.SetActive(false);
			this.m_CardInBagList[j].m_Collider.enabled = false;
			this.m_CardInBagList[j].m_Rigidbody.isKinematic = true;
		}
		base.StartCoroutine(this.DelayRemoveCustomerFromQueue(Random.Range(0.25f, 1f)));
		this.DetermineShopAction();
		CEventManager.QueueEvent(new CEventPlayer_AddShopExp(this.m_ItemInBagList.Count * 4 + Mathf.RoundToInt(num) + this.m_CardInBagList.Count * 10, false));
	}

	// Token: 0x060000B6 RID: 182 RVA: 0x0000CE88 File Offset: 0x0000B088
	private void ExitShop()
	{
		this.m_TargetTransform = CustomerManager.GetRandomExitPoint();
		this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
		this.m_IsWaitingForPathCallback = true;
		this.SetState(ECustomerState.ExitingShop);
		bool flag = true;
		if (this.m_HasUpdatedCustomerCount)
		{
			flag = false;
		}
		if (!this.m_HasUpdatedCustomerCount)
		{
			this.m_HasUpdatedCustomerCount = true;
			CSingleton<CustomerManager>.Instance.UpdateCustomerCount(-1);
		}
		if (!CPlayerData.m_IsShopOnceOpen)
		{
			return;
		}
		if (flag)
		{
			if (this.m_ItemInBagList.Count + this.m_CardInBagList.Count <= 0 && !this.m_HasPlayedGame)
			{
				CPlayerData.m_GameReportDataCollect.customerDisatisfied = CPlayerData.m_GameReportDataCollect.customerDisatisfied + 1;
				CPlayerData.m_GameReportDataCollectPermanent.customerDisatisfied = CPlayerData.m_GameReportDataCollectPermanent.customerDisatisfied + 1;
			}
			if (this.m_ItemInBagList.Count > 0)
			{
				CPlayerData.m_GameReportDataCollect.customerBoughtItem = CPlayerData.m_GameReportDataCollect.customerBoughtItem + 1;
				CPlayerData.m_GameReportDataCollectPermanent.customerBoughtItem = CPlayerData.m_GameReportDataCollectPermanent.customerBoughtItem + 1;
				CPlayerData.m_GameReportDataCollect.itemAmountSold = CPlayerData.m_GameReportDataCollect.itemAmountSold + this.m_ItemInBagList.Count;
				CPlayerData.m_GameReportDataCollectPermanent.itemAmountSold = CPlayerData.m_GameReportDataCollectPermanent.itemAmountSold + this.m_ItemInBagList.Count;
				for (int i = 0; i < this.m_ItemInBagList.Count; i++)
				{
					CPlayerData.m_GameReportDataCollect.totalItemEarning = CPlayerData.m_GameReportDataCollect.totalItemEarning + this.m_ItemInBagList[i].GetCurrentPrice();
					CPlayerData.m_GameReportDataCollectPermanent.totalItemEarning = CPlayerData.m_GameReportDataCollectPermanent.totalItemEarning + this.m_ItemInBagList[i].GetCurrentPrice();
				}
			}
			if (this.m_CardInBagList.Count > 0)
			{
				CPlayerData.m_GameReportDataCollect.customerBoughtCard = CPlayerData.m_GameReportDataCollect.customerBoughtCard + 1;
				CPlayerData.m_GameReportDataCollectPermanent.customerBoughtCard = CPlayerData.m_GameReportDataCollectPermanent.customerBoughtCard + 1;
				CPlayerData.m_GameReportDataCollect.cardAmountSold = CPlayerData.m_GameReportDataCollect.cardAmountSold + this.m_CardInBagList.Count;
				CPlayerData.m_GameReportDataCollectPermanent.cardAmountSold = CPlayerData.m_GameReportDataCollectPermanent.cardAmountSold + this.m_CardInBagList.Count;
				for (int j = 0; j < this.m_CardInBagList.Count; j++)
				{
					CPlayerData.m_GameReportDataCollect.totalCardEarning = CPlayerData.m_GameReportDataCollect.totalCardEarning + this.m_CardInBagList[j].GetCurrentPrice();
					CPlayerData.m_GameReportDataCollectPermanent.totalCardEarning = CPlayerData.m_GameReportDataCollectPermanent.totalCardEarning + this.m_CardInBagList[j].GetCurrentPrice();
					AchievementManager.OnSoldCardPrice(this.m_CardInBagList[j].GetCurrentPrice());
				}
				TutorialManager.AddTaskValue(ETutorialTaskCondition.SellCard, (float)this.m_CardInBagList.Count);
			}
			if (this.m_ItemInBagList.Count + this.m_CardInBagList.Count > 0)
			{
				CPlayerData.m_GameReportDataCollect.checkoutCount = CPlayerData.m_GameReportDataCollect.checkoutCount + 1;
				CPlayerData.m_GameReportDataCollectPermanent.checkoutCount = CPlayerData.m_GameReportDataCollectPermanent.checkoutCount + 1;
			}
		}
	}

	// Token: 0x060000B7 RID: 183 RVA: 0x0000D11B File Offset: 0x0000B31B
	private IEnumerator DelayExitShop(float delayTime)
	{
		yield return new WaitForSeconds(delayTime);
		if (!this.m_HasCheckedOut && (this.m_ItemInBagList.Count > 0 || this.m_CardInBagList.Count > 0))
		{
			this.ThinkWantToPay();
		}
		else
		{
			this.ExitShop();
		}
		yield break;
	}

	// Token: 0x060000B8 RID: 184 RVA: 0x0000D131 File Offset: 0x0000B331
	private IEnumerator DelayRemoveCustomerFromQueue(float waitTime)
	{
		yield return new WaitForSeconds(waitTime);
		this.m_CurrentQueueCashierCounter.RemoveCustomerFromQueue(this);
		this.m_CurrentQueueCashierCounter.RemoveCurrentCustomerFromQueue();
		yield break;
	}

	// Token: 0x060000B9 RID: 185 RVA: 0x0000D147 File Offset: 0x0000B347
	public void OnCashierCounterQueueMoved(int index)
	{
		base.StartCoroutine(this.DelayQueueMoved(index));
	}

	// Token: 0x060000BA RID: 186 RVA: 0x0000D157 File Offset: 0x0000B357
	private IEnumerator DelayQueueMoved(int index)
	{
		yield return new WaitForSeconds(Random.Range(0.25f, 0.4f) * (float)index);
		this.m_ReachedEndOfPath = false;
		this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
		this.m_IsWaitingForPathCallback = true;
		yield break;
	}

	// Token: 0x060000BB RID: 187 RVA: 0x0000D16D File Offset: 0x0000B36D
	private void SetState(ECustomerState state)
	{
		this.m_CurrentState = state;
	}

	// Token: 0x060000BC RID: 188 RVA: 0x0000D178 File Offset: 0x0000B378
	public void OnPathComplete(Path p)
	{
		p.Claim(this);
		if (!p.error)
		{
			if (this.m_Path != null)
			{
				this.m_Path.Release(this, false);
			}
			this.m_Path = p;
			this.m_CurrentWaypoint = 0;
		}
		else
		{
			p.Release(this, false);
		}
		this.m_IsWaitingForPathCallback = false;
		this.m_ReachedEndOfPath = false;
		if (p.error && !this.m_IsInsideShop)
		{
			this.GoShopNotOpenState();
		}
	}

	// Token: 0x060000BD RID: 189 RVA: 0x0000D1E8 File Offset: 0x0000B3E8
	private void GoShopNotOpenState()
	{
		if (!this.m_HasCheckedOut && (this.m_ItemInBagList.Count > 0 || this.m_CardInBagList.Count > 0))
		{
			this.ThinkWantToPay();
			return;
		}
		this.m_ReachedEndOfPath = false;
		this.m_TargetTransform = CustomerManager.GetRandomShopWindowOutsidePoint();
		this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
		this.m_IsWaitingForPathCallback = true;
		this.m_UnableToFindQueue = false;
		this.SetState(ECustomerState.ShopNotOpen);
	}

	// Token: 0x060000BE RID: 190 RVA: 0x0000D278 File Offset: 0x0000B478
	public void InstantSnapToPlayTable(InteractablePlayTable playTable, int seatIndex, bool isGameStarted)
	{
		this.m_CurrentPlayTable = playTable;
		this.m_CurrentPlayTableSeatIndex = seatIndex;
		this.SetState(ECustomerState.PlayingAtTable);
		this.m_TargetTransform = this.m_CurrentPlayTable.GetSitLoc(this.m_CurrentPlayTableSeatIndex);
		this.m_LerpStartPos = this.m_TargetTransform.position;
		this.m_TargetLerpPos = this.m_TargetTransform.position;
		this.m_TargetLerpRotation = this.m_TargetTransform.rotation;
		base.transform.position = this.m_TargetLerpPos;
		base.transform.rotation = this.m_TargetLerpRotation;
		this.m_Timer = 0f;
		this.m_SecondaryTimer = 0f;
		this.m_SecondaryTimerMax = (float)Random.Range(5, 30);
		this.m_IsInsideShop = true;
		this.m_Anim.SetBool("IsSitting", true);
		CSingleton<CustomerManager>.Instance.AddPlayTableSitdownCustomerCount(1);
		if (isGameStarted)
		{
			this.PlayTableGameStarted();
		}
	}

	// Token: 0x060000BF RID: 191 RVA: 0x0000D358 File Offset: 0x0000B558
	public void PlayTableGameStarted()
	{
		this.m_HasPlayedGame = true;
		this.m_Anim.SetBool("IsPlaying", true);
		this.m_GameCardFanOut.SetActive(true);
		this.m_GameCardSingle.SetActive(true);
	}

	// Token: 0x060000C0 RID: 192 RVA: 0x0000D38C File Offset: 0x0000B58C
	public void PlayTableGameEnded(float totalPlayTime, float playTableFee)
	{
		this.m_HasPlayedGame = true;
		this.m_Anim.SetBool("IsPlaying", false);
		this.m_Anim.SetInteger("RandomPlayIndex", 0);
		this.m_GameCardFanOut.SetActive(false);
		this.m_GameCardSingle.SetActive(false);
		this.m_TargetTransform = this.m_CurrentPlayTable.GetStandLocB(this.m_CurrentPlayTableSeatIndex, false);
		if (this.m_TargetTransform == null)
		{
			this.m_TargetTransform = base.transform;
		}
		this.m_LerpStartPos = base.transform.position;
		this.m_TargetLerpPos = this.m_TargetTransform.position;
		this.m_TargetLerpRotation = this.m_TargetTransform.rotation;
		this.m_CurrentPlayTable = null;
		this.m_CurrentPlayTableSeatIndex = -1;
		this.m_Timer = 0f;
		this.m_TimerMax = Random.Range(0.7f, 1.25f);
		this.SetState(ECustomerState.EndingPlayTableGame);
		float num = playTableFee * (totalPlayTime / 60f);
		if (num > 0f)
		{
			CEventManager.QueueEvent(new CEventPlayer_AddCoin(num, false));
			CSingleton<PricePopupSpawner>.Instance.ShowPricePopup(num, 1.8f, base.transform);
		}
		if (this.m_ItemInBagList.Count > 0 || this.m_CardInBagList.Count > 0)
		{
			this.m_ShoppingBagTransform.gameObject.SetActive(true);
			this.m_Anim.SetBool("HoldingBag", true);
		}
		this.m_Anim.SetBool("IsSitting", false);
		CSingleton<CustomerManager>.Instance.AddPlayTableSitdownCustomerCount(-1);
		if (totalPlayTime > 0f)
		{
			CPlayerData.m_GameReportDataCollect.customerPlayed = CPlayerData.m_GameReportDataCollect.customerPlayed + 1;
			CPlayerData.m_GameReportDataCollect.totalPlayTableTime = CPlayerData.m_GameReportDataCollect.totalPlayTableTime + totalPlayTime;
			CPlayerData.m_GameReportDataCollect.totalPlayTableEarning = CPlayerData.m_GameReportDataCollect.totalPlayTableEarning + num;
			CPlayerData.m_GameReportDataCollectPermanent.customerPlayed = CPlayerData.m_GameReportDataCollectPermanent.customerPlayed + 1;
			CPlayerData.m_GameReportDataCollectPermanent.totalPlayTableTime = CPlayerData.m_GameReportDataCollectPermanent.totalPlayTableTime + totalPlayTime;
			CPlayerData.m_GameReportDataCollectPermanent.totalPlayTableEarning = CPlayerData.m_GameReportDataCollectPermanent.totalPlayTableEarning + num;
			AchievementManager.OnCustomerFinishPlay(CPlayerData.m_GameReportDataCollectPermanent.customerPlayed);
			TutorialManager.AddTaskValue(ETutorialTaskCondition.CustomerPlay, 1f);
			CEventManager.QueueEvent(new CEventPlayer_AddShopExp(Mathf.RoundToInt(10f * (totalPlayTime / 60f)), false));
		}
	}

	// Token: 0x060000C1 RID: 193 RVA: 0x0000D5A0 File Offset: 0x0000B7A0
	public void Update()
	{
		if (!this.m_IsActive)
		{
			return;
		}
		base.transform.rotation = Quaternion.Lerp(base.transform.rotation, this.m_TargetLerpRotation, Time.fixedDeltaTime * this.m_RotationLerpSpeed);
		this.m_CurrentMoveSpeed = (this.m_LastFramePos - base.transform.position).magnitude * 50f;
		this.m_LastFramePos = base.transform.position;
		this.m_Anim.SetFloat("MoveSpeed", this.m_CurrentMoveSpeed);
		if (this.m_IsCheckScanItemOutOfBound)
		{
			this.m_CheckScanItemOutOfBoundTimer += Time.deltaTime;
			if (this.m_CheckScanItemOutOfBoundTimer > 3f)
			{
				this.m_CheckScanItemOutOfBoundTimer = 0f;
				this.CheckItemOutOfCashierBound();
			}
		}
		if (this.m_IsBeingSprayed)
		{
			this.m_BeingSprayedResetTimer += Time.deltaTime;
			if (this.m_BeingSprayedResetTimer > this.m_BeingSprayedResetTimeMax)
			{
				this.m_BeingSprayedResetTimer = 0f;
				this.m_IsBeingSprayed = false;
				this.m_Anim.SetBool("IsBeingSprayed", false);
			}
		}
		if (this.m_CurrentState == ECustomerState.Idle)
		{
			this.m_Timer += Time.deltaTime;
			if (this.m_Timer > 2f)
			{
				this.m_Timer = 0f;
				if (CPlayerData.m_IsShopOpen)
				{
					this.DetermineShopAction();
					return;
				}
				if (this.m_FailFindItemAttemptCount > Random.Range(1, 5))
				{
					if (this.m_ItemInBagList.Count > 0 || this.m_CardInBagList.Count > 0)
					{
						this.ThinkWantToPay();
						return;
					}
					this.ExitShop();
					return;
				}
				else
				{
					this.GoShopNotOpenState();
				}
			}
			return;
		}
		if (this.m_CurrentState == ECustomerState.WantToBuyItem)
		{
			if (this.m_UnableToFindQueue)
			{
				this.m_Timer += Time.deltaTime;
				if (this.m_Timer > 8f)
				{
					this.m_Timer = 0f;
					this.AttemptFindShelf();
				}
			}
		}
		else if (this.m_CurrentState == ECustomerState.WantToBuyCard)
		{
			if (this.m_UnableToFindQueue)
			{
				this.m_Timer += Time.deltaTime;
				if (this.m_Timer > 8f)
				{
					this.m_Timer = 0f;
					this.AttemptFindCardShelf();
				}
			}
		}
		else if (this.m_CurrentState == ECustomerState.WantToPlayGame)
		{
			if (this.m_UnableToFindQueue)
			{
				this.m_Timer += Time.deltaTime;
				if (this.m_Timer > 8f)
				{
					this.m_Timer = 0f;
					this.AttemptFindPlayTable();
				}
			}
		}
		else if (this.m_CurrentState == ECustomerState.WalkToShelf)
		{
			if (!this.m_IsInsideShop)
			{
				this.m_Timer += Time.deltaTime;
				if (this.m_Timer > 1f)
				{
					this.m_Timer = 0f;
					if (!CPlayerData.m_IsShopOpen)
					{
						this.GoShopNotOpenState();
					}
					else if (LightManager.GetHasDayEnded())
					{
						this.m_FailFindItemAttemptCount = 5;
						this.GoShopNotOpenState();
					}
				}
			}
		}
		else if (this.m_CurrentState == ECustomerState.TakingItemFromShelf)
		{
			if (!this.m_HasTookItemFromShelf)
			{
				this.m_Timer += Time.deltaTime;
				if (this.m_Timer > 1f)
				{
					this.m_HasTookItemFromShelf = true;
					this.m_Timer = 0f;
					this.TakeItemFromShelf();
				}
			}
			else
			{
				this.SetState(ECustomerState.Idle);
			}
		}
		else if (this.m_CurrentState == ECustomerState.TakingItemFromCardShelf)
		{
			if (!this.m_HasTookCardFromShelf)
			{
				this.m_Timer += Time.deltaTime;
				if (this.m_Timer > 1f)
				{
					this.m_HasTookCardFromShelf = true;
					this.m_Timer = 0f;
					this.TakeCardFromShelf();
				}
			}
			else
			{
				this.SetState(ECustomerState.Idle);
			}
		}
		else if (this.m_CurrentState == ECustomerState.WantToPay)
		{
			if (this.m_UnableToFindQueue)
			{
				this.m_Timer += Time.deltaTime;
				if (this.m_Timer > 8f)
				{
					this.m_Timer = 0f;
					this.AttemptFindQueue();
				}
			}
		}
		else if (this.m_CurrentState == ECustomerState.ReadyToPay)
		{
			if (!this.m_CurrentQueueCashierCounter)
			{
				this.ThinkWantToPay();
				return;
			}
			if (this.m_IsAtPayingPosition)
			{
				return;
			}
		}
		else if (this.m_CurrentState == ECustomerState.WalkToPlayTable)
		{
			this.m_Timer += Time.deltaTime;
			if (this.m_Timer > 2f)
			{
				if (!this.m_IsInsideShop && !CPlayerData.m_IsShopOpen)
				{
					this.GoShopNotOpenState();
				}
				else if (!this.m_IsInsideShop && LightManager.GetHasDayEnded())
				{
					this.m_FailFindItemAttemptCount = 5;
					this.GoShopNotOpenState();
				}
				else if (this.m_CurrentPlayTable && !this.m_CurrentPlayTable.IsQueueEmpty(this.m_CurrentPlayTableSeatIndex))
				{
					this.AttemptFindPlayTable();
				}
			}
		}
		else
		{
			if (this.m_CurrentState == ECustomerState.PlayingAtTable)
			{
				this.m_Timer = Mathf.Clamp(this.m_Timer + Time.deltaTime, 0f, 1f);
				base.transform.position = Vector3.Lerp(this.m_LerpStartPos, this.m_TargetLerpPos, this.m_Timer * 3f);
				this.m_SecondaryTimer += Time.deltaTime;
				if (this.m_SecondaryTimer >= this.m_SecondaryTimerMax)
				{
					this.m_Anim.SetInteger("RandomPlayIndex", Random.Range(0, 5));
					this.m_Anim.SetTrigger("PlayGameEmote");
					this.m_SecondaryTimerMax = (float)Random.Range(5, 30);
					this.m_SecondaryTimer = 0f;
				}
				return;
			}
			if (this.m_CurrentState == ECustomerState.QueueingPlayTable)
			{
				this.m_Timer += Time.deltaTime;
				bool flag = false;
				if (this.m_Timer > 2f)
				{
					this.m_Timer = 0f;
					this.m_TimerMax -= 2f;
					if (!LightManager.GetHasDayEnded())
					{
						this.OnReachedPathEnd();
					}
					else
					{
						flag = true;
					}
				}
				if (this.m_Timer > this.m_TimerMax || flag)
				{
					this.m_CurrentPlayTable.CustomerUnbookQueueIndex(this.m_CurrentPlayTableSeatIndex);
					this.m_Timer = 0f;
					this.m_TimerMax = 0f;
					if (Random.Range(0, 100) < 40)
					{
						if (this.m_ItemInBagList.Count > 0 || this.m_CardInBagList.Count > 0)
						{
							this.ThinkWantToPay();
							return;
						}
						this.ExitShop();
						return;
					}
					else
					{
						this.SetState(ECustomerState.Idle);
						this.m_Timer = 1.5f;
					}
				}
				return;
			}
			if (this.m_CurrentState == ECustomerState.EndingPlayTableGame)
			{
				this.m_Timer += Time.deltaTime;
				base.transform.position = Vector3.Lerp(this.m_LerpStartPos, this.m_TargetLerpPos, this.m_Timer * 3f);
				if (this.m_Timer > this.m_TimerMax)
				{
					this.m_Timer = 0f;
					this.m_TimerMax = 0f;
					if (Random.Range(0, 100) < 60)
					{
						if (this.m_ItemInBagList.Count > 0 || this.m_CardInBagList.Count > 0)
						{
							this.ThinkWantToPay();
							return;
						}
						this.ExitShop();
						return;
					}
					else
					{
						this.SetState(ECustomerState.Idle);
						this.m_Timer = 2f;
					}
				}
				return;
			}
		}
		if (!this.m_ReachedEndOfPath && Time.time > this.m_LastRepath + this.m_RepathRate && this.m_Seeker.IsDone() && this.m_TargetTransform)
		{
			this.m_LastRepath = Time.time;
			this.m_Seeker.StartPath(base.transform.position, this.m_TargetTransform.position, new OnPathDelegate(this.OnPathComplete));
			this.m_IsWaitingForPathCallback = true;
		}
		if (this.m_Path == null)
		{
			return;
		}
		while (Vector3.Distance(base.transform.position, this.m_Path.vectorPath[this.m_CurrentWaypoint]) < this.m_NextWaypointDistance)
		{
			if (!this.m_IsInsideShop && this.m_CurrentState != ECustomerState.ExitingShop)
			{
				this.m_IsInsideShop = CustomerManager.CheckIsInsideShop(base.transform.position);
				if (this.m_IsInsideShop)
				{
					this.OnCustomerReachInsideShop();
				}
			}
			else if (this.m_IsInsideShop && this.m_CurrentState == ECustomerState.ExitingShop && CustomerManager.CheckIsInsideShop(base.transform.position))
			{
				this.m_IsInsideShop = false;
				if (this.m_IsSmelly)
				{
					this.m_IsSmelly = false;
					CSingleton<CustomerManager>.Instance.RemoveFromSmellyCustomerList(this);
				}
			}
			if (this.m_CurrentWaypoint + 1 >= this.m_Path.vectorPath.Count)
			{
				if (!this.m_ReachedEndOfPath)
				{
					this.m_ReachedEndOfPath = true;
					this.OnReachedPathEnd();
				}
				this.WaypointEndUpdate();
				break;
			}
			this.m_CurrentWaypoint++;
		}
		base.transform.position = Vector3.MoveTowards(base.transform.position, this.m_Path.vectorPath[this.m_CurrentWaypoint], this.m_ModifiedSpeed * this.m_ExtraSpeedMultiplier * Time.deltaTime);
		if (!this.m_ReachedEndOfPath)
		{
			Vector3 vector = this.m_Path.vectorPath[this.m_CurrentWaypoint] - base.transform.position;
			vector.y = 0f;
			if (vector != Vector3.zero)
			{
				this.m_TargetLerpRotation = Quaternion.LookRotation(vector, Vector3.up);
			}
		}
	}

	// Token: 0x060000C2 RID: 194 RVA: 0x0000DEAF File Offset: 0x0000C0AF
	public List<Item> GetItemInBagList()
	{
		return this.m_ItemInBagList;
	}

	// Token: 0x060000C3 RID: 195 RVA: 0x0000DEB7 File Offset: 0x0000C0B7
	public List<InteractableCard3d> GetCardInBagList()
	{
		return this.m_CardInBagList;
	}

	// Token: 0x060000C4 RID: 196 RVA: 0x0000DEBF File Offset: 0x0000C0BF
	public bool IsUnableToFindQueue()
	{
		return this.m_UnableToFindQueue || this.m_FailFindShelfAttemptCount > 0;
	}

	// Token: 0x060000C5 RID: 197 RVA: 0x0000DED4 File Offset: 0x0000C0D4
	public bool IsActive()
	{
		return this.m_IsActive;
	}

	// Token: 0x060000C6 RID: 198 RVA: 0x0000DEDC File Offset: 0x0000C0DC
	public bool IsInsideShop()
	{
		return this.m_IsInsideShop;
	}

	// Token: 0x060000C7 RID: 199 RVA: 0x0000DEE4 File Offset: 0x0000C0E4
	public bool IsSmelly()
	{
		return this.m_IsSmelly;
	}

	// Token: 0x060000C8 RID: 200 RVA: 0x0000DEEC File Offset: 0x0000C0EC
	public void SetExtraSpeedMultiplier(float extraSpeedMultiplier)
	{
		this.m_ExtraSpeedMultiplier = extraSpeedMultiplier;
	}

	// Token: 0x060000C9 RID: 201 RVA: 0x0000DEF5 File Offset: 0x0000C0F5
	public void ResetExtraSpeedMultiplier()
	{
		this.m_ExtraSpeedMultiplier = 1f;
	}

	// Token: 0x060000CA RID: 202 RVA: 0x0000DF04 File Offset: 0x0000C104
	private bool PopupText(List<string> textList, int appearChance = 15)
	{
		int num = Random.Range(0, 100);
		if (this.m_IsChattyCustomer)
		{
			num = 0;
		}
		if (num < appearChance)
		{
			CSingleton<PricePopupSpawner>.Instance.ShowTextPopup(textList[Random.Range(0, textList.Count)], 1.8f, base.transform);
			return true;
		}
		return false;
	}

	// Token: 0x060000CB RID: 203 RVA: 0x0000DF52 File Offset: 0x0000C152
	private void CustomerConfused()
	{
		this.m_Anim.SetTrigger("ShakeHead");
	}

	// Token: 0x060000CC RID: 204 RVA: 0x0000DF64 File Offset: 0x0000C164
	public float GetCurrentPlayTableFee()
	{
		return this.m_CurrentPlayTableFee;
	}

	// Token: 0x060000CD RID: 205 RVA: 0x0000DF6C File Offset: 0x0000C16C
	public bool HasCheckedOut()
	{
		return this.m_HasCheckedOut;
	}

	// Token: 0x060000CE RID: 206 RVA: 0x0000DF74 File Offset: 0x0000C174
	public CustomerSaveData GetCustomerSaveData()
	{
		CustomerSaveData customerSaveData = new CustomerSaveData();
		if (this.m_CurrentState == ECustomerState.WantToBuyItem || this.m_CurrentState == ECustomerState.WantToBuyItem || this.m_CurrentState == ECustomerState.WantToPay || this.m_CurrentState == ECustomerState.WantToPlayGame || this.m_CurrentState == ECustomerState.WantToBuyCard || this.m_CurrentState == ECustomerState.PlayingAtTable || this.m_CurrentState == ECustomerState.ExitingShop)
		{
			customerSaveData.currentState = this.m_CurrentState;
		}
		else if (this.m_CurrentState == ECustomerState.QueuingToPay || this.m_CurrentState == ECustomerState.ReadyToPay)
		{
			customerSaveData.currentState = ECustomerState.WantToPay;
		}
		else
		{
			customerSaveData.currentState = ECustomerState.Idle;
		}
		customerSaveData.hasCheckedOut = this.m_HasCheckedOut;
		customerSaveData.hasPlayedGame = this.m_HasPlayedGame;
		customerSaveData.hasTookItemFromShelf = this.m_HasTookItemFromShelf;
		customerSaveData.hasTookCardFromShelf = this.m_HasTookCardFromShelf;
		customerSaveData.isInsideShop = this.m_IsInsideShop;
		customerSaveData.isSmelly = this.m_IsSmelly;
		customerSaveData.smellyMeter = this.m_SmellyMeter;
		customerSaveData.pos.SetData(base.transform.position);
		customerSaveData.rot.SetData(base.transform.rotation);
		if (!this.m_HasCheckedOut)
		{
			List<EItemType> list = new List<EItemType>();
			List<float> list2 = new List<float>();
			for (int i = 0; i < this.m_ItemInBagList.Count; i++)
			{
				list.Add(this.m_ItemInBagList[i].GetItemType());
				list2.Add(this.m_ItemInBagList[i].GetCurrentPrice());
			}
			customerSaveData.itemInBagList = list;
			customerSaveData.itemInBagPriceList = list2;
			List<CardData> list3 = new List<CardData>();
			List<float> list4 = new List<float>();
			for (int j = 0; j < this.m_CardInBagList.Count; j++)
			{
				list3.Add(this.m_CardInBagList[j].m_Card3dUI.m_CardUI.GetCardData());
				list4.Add(this.m_CardInBagList[j].GetCurrentPrice());
			}
			customerSaveData.cardInBagList = list3;
			customerSaveData.cardInBagPriceList = list4;
		}
		customerSaveData.currentCostTotal = this.m_CurrentCostTotal;
		customerSaveData.maxMoney = this.m_MaxMoney;
		customerSaveData.totalScannedItemCost = this.m_TotalScannedItemCost;
		customerSaveData.currentPlayTableFee = this.m_CurrentPlayTableFee;
		return customerSaveData;
	}

	// Token: 0x060000CF RID: 207 RVA: 0x0000E18C File Offset: 0x0000C38C
	public void LoadCustomerSaveData(CustomerSaveData data)
	{
		this.m_Timer = 0f;
		this.m_CurrentState = data.currentState;
		this.m_HasCheckedOut = data.hasCheckedOut;
		this.m_HasPlayedGame = data.hasPlayedGame;
		this.m_HasTookCardFromShelf = data.hasTookCardFromShelf;
		this.m_IsInsideShop = data.isInsideShop;
		this.m_IsSmelly = data.isSmelly;
		this.m_SmellyMeter = data.smellyMeter;
		this.m_CurrentCostTotal = data.currentCostTotal;
		this.m_MaxMoney = data.maxMoney;
		this.m_TotalScannedItemCost = data.totalScannedItemCost;
		this.m_CurrentPlayTableFee = data.currentPlayTableFee;
		base.transform.position = data.pos.Data;
		base.transform.rotation = data.rot.Data;
		this.m_SmellyFX.SetActive(this.m_IsSmelly);
		if (this.m_IsSmelly)
		{
			CSingleton<CustomerManager>.Instance.AddToSmellyCustomerList(this);
		}
		else
		{
			CSingleton<CustomerManager>.Instance.RemoveFromSmellyCustomerList(this);
		}
		if (this.m_HasCheckedOut)
		{
			this.m_ShoppingBagTransform.gameObject.SetActive(true);
			return;
		}
		if (data.itemInBagList.Count + data.cardInBagList.Count > 0)
		{
			this.m_ShoppingBagTransform.gameObject.SetActive(true);
		}
		for (int i = 0; i < data.itemInBagList.Count; i++)
		{
			ItemMeshData itemMeshData = InventoryBase.GetItemMeshData(data.itemInBagList[i]);
			Item item = ItemSpawnManager.GetItem(this.m_ShoppingBagTransform);
			item.SetMesh(itemMeshData.mesh, itemMeshData.material, data.itemInBagList[i], itemMeshData.meshSecondary, itemMeshData.materialSecondary);
			item.SetCurrentPrice(data.itemInBagPriceList[i]);
			item.transform.position = this.m_ShoppingBagTransform.position;
			item.transform.rotation = this.m_ShoppingBagTransform.rotation;
			item.gameObject.SetActive(false);
			this.m_ItemInBagList.Add(item);
		}
		for (int j = 0; j < data.cardInBagList.Count; j++)
		{
			Card3dUIGroup cardUI = CSingleton<Card3dUISpawner>.Instance.GetCardUI();
			InteractableCard3d component = ShelfManager.SpawnInteractableObject(EObjectType.Card3d).GetComponent<InteractableCard3d>();
			cardUI.m_CardUI.SetCardUI(data.cardInBagList[j]);
			component.SetCardUIFollow(cardUI);
			component.SetEnableCollision(false);
			component.SetCurrentPrice(data.cardInBagPriceList[j]);
			component.transform.position = this.m_ShoppingBagTransform.position;
			component.transform.rotation = this.m_ShoppingBagTransform.rotation;
			this.m_CardInBagList.Add(component);
			component.m_Card3dUI.gameObject.SetActive(false);
			component.gameObject.SetActive(false);
		}
		if (this.m_CurrentState == ECustomerState.WantToPay)
		{
			this.AttemptFindQueue();
		}
	}

	// Token: 0x040000F8 RID: 248
	public CharacterCustomization m_CharacterCustom;

	// Token: 0x040000F9 RID: 249
	public Animator m_Anim;

	// Token: 0x040000FA RID: 250
	public float m_CurrentMoveSpeed;

	// Token: 0x040000FB RID: 251
	private Vector3 m_LastFramePos;

	// Token: 0x040000FC RID: 252
	public bool m_IsFemale;

	// Token: 0x040000FD RID: 253
	public bool m_IsActive;

	// Token: 0x040000FE RID: 254
	public Seeker m_Seeker;

	// Token: 0x040000FF RID: 255
	private StartEndModifier m_DefaultStartEndModifier;

	// Token: 0x04000100 RID: 256
	public StartEndModifier m_OriginalStartEndModifier;

	// Token: 0x04000101 RID: 257
	private Path m_Path;

	// Token: 0x04000102 RID: 258
	public float m_Speed = 1f;

	// Token: 0x04000103 RID: 259
	private float m_ModifiedSpeed = 1f;

	// Token: 0x04000104 RID: 260
	public float m_NextWaypointDistance = 0.1f;

	// Token: 0x04000105 RID: 261
	public float m_RepathRate = 2f;

	// Token: 0x04000106 RID: 262
	public float m_RotationLerpSpeed = 2f;

	// Token: 0x04000107 RID: 263
	public GameObject m_GameCardFanOut;

	// Token: 0x04000108 RID: 264
	public GameObject m_GameCardSingle;

	// Token: 0x04000109 RID: 265
	public GameObject m_SmellyFX;

	// Token: 0x0400010A RID: 266
	public GameObject m_CleanFX;

	// Token: 0x0400010B RID: 267
	public GameObject m_CustomerMeshGrp;

	// Token: 0x0400010C RID: 268
	public GameObject m_DebugCube;

	// Token: 0x0400010D RID: 269
	public Transform m_ShoppingBagTransform;

	// Token: 0x0400010E RID: 270
	public InteractableCustomerCash m_CustomerCash;

	// Token: 0x0400010F RID: 271
	public ParentTo m_ShoppingBagParentTo;

	// Token: 0x04000110 RID: 272
	public ParentTo m_CustomerCashParentTo;

	// Token: 0x04000111 RID: 273
	private List<Item> m_ItemInBagList = new List<Item>();

	// Token: 0x04000112 RID: 274
	private List<InteractableCard3d> m_CardInBagList = new List<InteractableCard3d>();

	// Token: 0x04000113 RID: 275
	public ECustomerState m_CurrentState;

	// Token: 0x04000114 RID: 276
	private Shelf m_CurrentShelf;

	// Token: 0x04000115 RID: 277
	private ShelfCompartment m_CurrentItemCompartment;

	// Token: 0x04000116 RID: 278
	private CardShelf m_CurrentCardShelf;

	// Token: 0x04000117 RID: 279
	private InteractablePlayTable m_CurrentPlayTable;

	// Token: 0x04000118 RID: 280
	private int m_CurrentPlayTableSeatIndex = -1;

	// Token: 0x04000119 RID: 281
	private InteractableCardCompartment m_CurrentCardCompartment;

	// Token: 0x0400011A RID: 282
	private InteractableCashierCounter m_CurrentQueueCashierCounter;

	// Token: 0x0400011B RID: 283
	private bool m_ReachedEndOfPath;

	// Token: 0x0400011C RID: 284
	private bool m_HasPlayedGame;

	// Token: 0x0400011D RID: 285
	private bool m_IsSmelly;

	// Token: 0x0400011E RID: 286
	private bool m_IsAngry;

	// Token: 0x0400011F RID: 287
	private bool m_HasCheckedOut;

	// Token: 0x04000120 RID: 288
	private bool m_IsBeingSprayed;

	// Token: 0x04000121 RID: 289
	private bool m_IsCheckScanItemOutOfBound;

	// Token: 0x04000122 RID: 290
	private float m_CheckScanItemOutOfBoundTimer;

	// Token: 0x04000123 RID: 291
	private float m_BeingSprayedResetTimer;

	// Token: 0x04000124 RID: 292
	private float m_BeingSprayedResetTimeMax;

	// Token: 0x04000125 RID: 293
	private int m_SmellyMeter;

	// Token: 0x04000126 RID: 294
	private int m_CurrentWaypoint;

	// Token: 0x04000127 RID: 295
	private int m_FailFindShelfAttemptCount;

	// Token: 0x04000128 RID: 296
	private int m_FailFindItemAttemptCount;

	// Token: 0x04000129 RID: 297
	private int m_ItemScannedCount;

	// Token: 0x0400012A RID: 298
	private float m_LastRepath = float.NegativeInfinity;

	// Token: 0x0400012B RID: 299
	private float m_ExtraSpeedMultiplier = 1f;

	// Token: 0x0400012C RID: 300
	private float m_CounterQueueDistanceReducer;

	// Token: 0x0400012D RID: 301
	private float m_CurrentPlayTableFee;

	// Token: 0x0400012E RID: 302
	public Transform m_TargetTransform;

	// Token: 0x0400012F RID: 303
	private Quaternion m_TargetLerpRotation;

	// Token: 0x04000130 RID: 304
	private Vector3 m_LerpStartPos;

	// Token: 0x04000131 RID: 305
	private Vector3 m_TargetLerpPos;

	// Token: 0x04000132 RID: 306
	private Coroutine m_DecideFinishShopping;

	// Token: 0x04000133 RID: 307
	private bool m_IsInsideShop;

	// Token: 0x04000134 RID: 308
	private bool m_HasTookItemFromShelf;

	// Token: 0x04000135 RID: 309
	private bool m_HasTookCardFromShelf;

	// Token: 0x04000136 RID: 310
	private bool m_IsAtPayingPosition;

	// Token: 0x04000137 RID: 311
	private bool m_IsWaitingForPathCallback;

	// Token: 0x04000138 RID: 312
	private bool m_UnableToFindQueue;

	// Token: 0x04000139 RID: 313
	private bool m_IsChattyCustomer;

	// Token: 0x0400013A RID: 314
	private bool m_HasUpdatedCustomerCount;

	// Token: 0x0400013B RID: 315
	private float m_Timer;

	// Token: 0x0400013C RID: 316
	private float m_TimerMax;

	// Token: 0x0400013D RID: 317
	private float m_SecondaryTimer;

	// Token: 0x0400013E RID: 318
	private float m_SecondaryTimerMax;

	// Token: 0x0400013F RID: 319
	private float m_TotalScannedItemCost;

	// Token: 0x04000140 RID: 320
	public float m_CurrentCostTotal;

	// Token: 0x04000141 RID: 321
	public float m_MaxMoney;

	// Token: 0x04000142 RID: 322
	public List<EItemType> m_TargetBuyItemList = new List<EItemType>();
}
