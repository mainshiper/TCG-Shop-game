﻿using System;

// Token: 0x020000C7 RID: 199
public class CEventPlayer_GhostCardEffectUpdated : CEvent
{
	// Token: 0x17000023 RID: 35
	// (get) Token: 0x06000740 RID: 1856 RVA: 0x0003955B File Offset: 0x0003775B
	// (set) Token: 0x06000741 RID: 1857 RVA: 0x00039563 File Offset: 0x00037763
	public bool m_GetNewCard { get; private set; }

	// Token: 0x06000742 RID: 1858 RVA: 0x0003956C File Offset: 0x0003776C
	public CEventPlayer_GhostCardEffectUpdated(bool getNewCard)
	{
		this.m_GetNewCard = getNewCard;
	}
}
