﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

// Token: 0x0200013E RID: 318
public class PEButtonScript : MonoBehaviour, IEventSystemHandler, IPointerEnterHandler, IPointerExitHandler
{
	// Token: 0x06000912 RID: 2322 RVA: 0x000433CE File Offset: 0x000415CE
	private void Start()
	{
		this.myButton = base.gameObject.GetComponent<Button>();
	}

	// Token: 0x06000913 RID: 2323 RVA: 0x000433E1 File Offset: 0x000415E1
	public void OnPointerEnter(PointerEventData eventData)
	{
		UICanvasManager.GlobalAccess.MouseOverButton = true;
		UICanvasManager.GlobalAccess.UpdateToolTip(this.ButtonType);
	}

	// Token: 0x06000914 RID: 2324 RVA: 0x000433FE File Offset: 0x000415FE
	public void OnPointerExit(PointerEventData eventData)
	{
		UICanvasManager.GlobalAccess.MouseOverButton = false;
		UICanvasManager.GlobalAccess.ClearToolTip();
	}

	// Token: 0x06000915 RID: 2325 RVA: 0x00043415 File Offset: 0x00041615
	public void OnButtonClicked()
	{
		UICanvasManager.GlobalAccess.UIButtonClick(this.ButtonType);
	}

	// Token: 0x04001148 RID: 4424
	private Button myButton;

	// Token: 0x04001149 RID: 4425
	public ButtonTypes ButtonType;
}
