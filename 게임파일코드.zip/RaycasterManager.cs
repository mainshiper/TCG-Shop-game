﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000120 RID: 288
public class RaycasterManager : CSingleton<RaycasterManager>
{
	// Token: 0x06000870 RID: 2160 RVA: 0x0003FDC0 File Offset: 0x0003DFC0
	private void Start()
	{
		GraphicRaycaster[] componentsInChildren = base.gameObject.GetComponentsInChildren<GraphicRaycaster>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			this.m_RaycasterList.Add(componentsInChildren[i]);
		}
		for (int j = 0; j < this.m_CustomRaycasterList.Count; j++)
		{
			this.m_RaycasterList.Add(this.m_CustomRaycasterList[j]);
		}
		HorizontalLayoutGroup[] componentsInChildren2 = base.gameObject.GetComponentsInChildren<HorizontalLayoutGroup>();
		for (int k = 0; k < componentsInChildren2.Length; k++)
		{
			if (!this.m_HLayoutGrpExceptionList.Contains(componentsInChildren2[k]))
			{
				this.m_HLayoutGrpList.Add(componentsInChildren2[k]);
			}
		}
		VerticalLayoutGroup[] componentsInChildren3 = base.gameObject.GetComponentsInChildren<VerticalLayoutGroup>();
		for (int l = 0; l < componentsInChildren3.Length; l++)
		{
			this.m_VLayoutGrpList.Add(componentsInChildren3[l]);
		}
	}

	// Token: 0x06000871 RID: 2161 RVA: 0x0003FE92 File Offset: 0x0003E092
	private IEnumerator DisableLayoutGrp()
	{
		yield return new WaitForSeconds(1f);
		for (int i = 0; i < this.m_HLayoutGrpList.Count; i++)
		{
			this.m_HLayoutGrpList[i].enabled = false;
		}
		for (int j = 0; j < this.m_VLayoutGrpList.Count; j++)
		{
			this.m_VLayoutGrpList[j].enabled = false;
		}
		yield break;
	}

	// Token: 0x06000872 RID: 2162 RVA: 0x0003FEA4 File Offset: 0x0003E0A4
	public static void SetUIRaycastEnabled(bool isEnabled)
	{
		for (int i = 0; i < CSingleton<RaycasterManager>.Instance.m_RaycasterList.Count; i++)
		{
			CSingleton<RaycasterManager>.Instance.m_RaycasterList[i].enabled = isEnabled;
		}
	}

	// Token: 0x04001046 RID: 4166
	public List<GraphicRaycaster> m_RaycasterList = new List<GraphicRaycaster>();

	// Token: 0x04001047 RID: 4167
	public List<GraphicRaycaster> m_CustomRaycasterList = new List<GraphicRaycaster>();

	// Token: 0x04001048 RID: 4168
	public List<HorizontalLayoutGroup> m_HLayoutGrpList = new List<HorizontalLayoutGroup>();

	// Token: 0x04001049 RID: 4169
	public List<VerticalLayoutGroup> m_VLayoutGrpList = new List<VerticalLayoutGroup>();

	// Token: 0x0400104A RID: 4170
	public List<HorizontalLayoutGroup> m_HLayoutGrpExceptionList = new List<HorizontalLayoutGroup>();
}
