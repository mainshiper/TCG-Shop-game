﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000052 RID: 82
public class ShelfMoveStateValidArea : MonoBehaviour
{
	// Token: 0x0400049D RID: 1181
	public bool m_CanSnap = true;

	// Token: 0x0400049E RID: 1182
	public List<Transform> m_SnapLocList;
}
