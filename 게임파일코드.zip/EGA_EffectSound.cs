﻿using System;
using UnityEngine;

// Token: 0x02000148 RID: 328
public class EGA_EffectSound : MonoBehaviour
{
	// Token: 0x0600094A RID: 2378 RVA: 0x00044620 File Offset: 0x00042820
	private void Start()
	{
		this.soundComponent = base.GetComponent<AudioSource>();
		this.clip = this.soundComponent.clip;
		if (this.RandomVolume)
		{
			this.soundComponent.volume = Random.Range(this.minVolume, this.maxVolume);
			this.RepeatSound();
		}
		if (this.Repeating)
		{
			base.InvokeRepeating("RepeatSound", this.StartTime, this.RepeatTime);
		}
	}

	// Token: 0x0600094B RID: 2379 RVA: 0x00044693 File Offset: 0x00042893
	private void RepeatSound()
	{
		this.soundComponent.PlayOneShot(this.clip);
	}

	// Token: 0x0400117F RID: 4479
	public bool Repeating = true;

	// Token: 0x04001180 RID: 4480
	public float RepeatTime = 2f;

	// Token: 0x04001181 RID: 4481
	public float StartTime;

	// Token: 0x04001182 RID: 4482
	public bool RandomVolume;

	// Token: 0x04001183 RID: 4483
	public float minVolume = 0.4f;

	// Token: 0x04001184 RID: 4484
	public float maxVolume = 1f;

	// Token: 0x04001185 RID: 4485
	private AudioClip clip;

	// Token: 0x04001186 RID: 4486
	private AudioSource soundComponent;
}
