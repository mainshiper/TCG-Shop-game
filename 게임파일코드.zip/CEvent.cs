﻿using System;

// Token: 0x020000A8 RID: 168
public class CEvent
{
}
