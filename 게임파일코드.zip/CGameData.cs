﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000A2 RID: 162
[Serializable]
public class CGameData
{
	// Token: 0x06000656 RID: 1622 RVA: 0x00033C96 File Offset: 0x00031E96
	public CGameData()
	{
		if (CGameData.instance == null)
		{
			CGameData.instance = this;
		}
	}

	// Token: 0x06000657 RID: 1623 RVA: 0x00033CAB File Offset: 0x00031EAB
	private void Awake()
	{
	}

	// Token: 0x06000658 RID: 1624 RVA: 0x00033CB0 File Offset: 0x00031EB0
	public bool IsCloudVersionNewerThanLocal()
	{
		int num = 0;
		int num2 = 0;
		string text = "";
		if (CSaveLoad.m_SavedGame != null)
		{
			num = CSaveLoad.m_SavedGame.m_SaveIndex;
			num2 = CSaveLoad.m_SavedGame.m_SaveCycle;
			text = CSaveLoad.m_SavedGame.m_LastLoginPlayfabID;
		}
		Debug.Log("DSCloudSaveLoadTest Local save index : " + num.ToString() + " Cloud save index : " + CSaveLoad.m_SavedGameBackup.m_SaveIndex.ToString());
		Debug.Log("DSCloudSaveLoadTest Local save cycle : " + num2.ToString() + " Cloud save cycle : " + CSaveLoad.m_SavedGameBackup.m_SaveCycle.ToString());
		bool result = false;
		bool flag = false;
		if (CSaveLoad.m_SavedGameBackup.m_LastLoginPlayfabID != null && CSaveLoad.m_SavedGameBackup.m_LastLoginPlayfabID != " " && CSaveLoad.m_SavedGameBackup.m_LastLoginPlayfabID != "" && CSaveLoad.m_SavedGameBackup.m_LastLoginPlayfabID != text)
		{
			flag = true;
		}
		Debug.Log(string.Concat(new string[]
		{
			"DSCloudSaveLoadTest localPlayfabID : ",
			text,
			" CSaveLoad.m_SavedGameBackup.m_LastLoginPlayfabID : ",
			CSaveLoad.m_SavedGameBackup.m_LastLoginPlayfabID,
			" isDifferentID : ",
			flag.ToString()
		}));
		if (flag)
		{
			CSaveLoad.Delete();
			CSaveLoad.DeleteBackup();
			Debug.Log("DSCloudSaveLoadTest has different id");
			return true;
		}
		if (CSaveLoad.m_SavedGameBackup.m_SaveCycle > num2)
		{
			Debug.Log("DSCloudSaveLoadTest Cloud file has higher version number");
			result = true;
		}
		else if (CSaveLoad.m_SavedGameBackup.m_SaveCycle == num2)
		{
			if (CSaveLoad.m_SavedGameBackup.m_SaveIndex > num)
			{
				Debug.Log("DSCloudSaveLoadTest Cloud file has higher version number");
				result = true;
			}
			else if (CSaveLoad.m_SavedGameBackup.m_SaveIndex == num)
			{
				Debug.Log("DSCloudSaveLoadTest Cloud and local file have same version number");
			}
			else
			{
				Debug.Log("DSCloudSaveLoadTest Local file has higher version number");
			}
		}
		else
		{
			Debug.Log("DSCloudSaveLoadTest Local file has higher version number");
		}
		return result;
	}

	// Token: 0x06000659 RID: 1625 RVA: 0x00033E68 File Offset: 0x00032068
	public LoadSavedSlotData GetLoadSavedSlotData(CGameData gameData)
	{
		LoadSavedSlotData result = default(LoadSavedSlotData);
		if (gameData != null)
		{
			result.name = gameData.m_PlayerName;
			result.moneyAmount = gameData.m_CoinAmount;
			result.level = gameData.m_ShopLevel;
			result.daysPassed = gameData.m_CurrentDay;
			result.hasSaveData = true;
		}
		return result;
	}

	// Token: 0x0600065A RID: 1626 RVA: 0x00033EBD File Offset: 0x000320BD
	public void PropagateLoadDataPrologue(CGameData gameData)
	{
	}

	// Token: 0x0600065B RID: 1627 RVA: 0x00033EC0 File Offset: 0x000320C0
	public void PropagateLoadData(CGameData gameData)
	{
		GameInstance.m_HasLoadingError = true;
		if (!gameData.m_IsMainGame)
		{
			GameInstance.m_HasLoadingError = false;
			GameInstance.m_SaveFileNotFound = true;
			CPlayerData.CreateDefaultData(false);
			return;
		}
		try
		{
			CPlayerData.m_SaveIndex = gameData.m_SaveIndex;
			CPlayerData.m_SaveCycle = gameData.m_SaveCycle;
			CPlayerData.m_LastLoginPlayfabID = gameData.m_LastLoginPlayfabID;
			CPlayerData.m_LastLocalExitTime = gameData.m_LastLocalExitTime;
			CPlayerData.PlayerName = gameData.m_PlayerName;
			CPlayerData.m_CoinAmount = gameData.m_CoinAmount;
			CEventManager.QueueEvent(new CEventPlayer_SetCoin(CPlayerData.m_CoinAmount));
			CPlayerData.m_FamePoint = gameData.m_FamePoint;
			CPlayerData.m_IsWarehouseRoomUnlocked = gameData.m_IsWarehouseRoomUnlocked;
			CPlayerData.m_UnlockRoomCount = gameData.m_UnlockRoomCount;
			CPlayerData.m_UnlockWarehouseRoomCount = gameData.m_UnlockWarehouseRoomCount;
			CEventManager.QueueEvent(new CEventPlayer_SetFame(CPlayerData.m_FamePoint));
			CPlayerData.m_TotalFameAdd = gameData.m_TotalFameAdd;
			CPlayerData.m_CloudSaveCountdown = gameData.m_CloudSaveCountdown;
			CPlayerData.m_IsShopOpen = gameData.m_IsShopOpen;
			CPlayerData.m_IsShopOnceOpen = gameData.m_IsShopOnceOpen;
			CPlayerData.m_IsWarehouseDoorClosed = gameData.m_IsWarehouseDoorClosed;
			CPlayerData.m_IsItemPriceGenerated = gameData.m_IsItemPriceGenerated;
			CPlayerData.m_IsCardPriceGenerated = gameData.m_IsCardPriceGenerated;
			CPlayerData.m_CurrentDay = gameData.m_CurrentDay;
			CPlayerData.m_ShopExpPoint = gameData.m_ShopExpPoint;
			CPlayerData.m_ShopLevel = gameData.m_ShopLevel;
			if (gameData.m_CurrentTotalItemCountList != null && gameData.m_CurrentTotalItemCountList.Count > 0)
			{
				CPlayerData.m_CurrentTotalItemCountList = gameData.m_CurrentTotalItemCountList;
			}
			else
			{
				CPlayerData.m_CurrentTotalItemCountList.Clear();
				for (int i = 0; i < 100; i++)
				{
					CPlayerData.m_CurrentTotalItemCountList.Add(0);
				}
			}
			if (gameData.m_SetItemPriceList != null && gameData.m_SetItemPriceList.Count > 0)
			{
				CPlayerData.m_SetItemPriceList = gameData.m_SetItemPriceList;
			}
			else
			{
				CPlayerData.m_SetItemPriceList.Clear();
				for (int j = 0; j < 100; j++)
				{
					CPlayerData.m_SetItemPriceList.Add(0f);
				}
			}
			if (gameData.m_AverageItemCostList != null && gameData.m_AverageItemCostList.Count > 0)
			{
				CPlayerData.m_AverageItemCostList = gameData.m_AverageItemCostList;
			}
			else
			{
				CPlayerData.m_AverageItemCostList.Clear();
				for (int k = 0; k < 100; k++)
				{
					CPlayerData.m_AverageItemCostList.Add(0f);
				}
			}
			if (gameData.m_GeneratedCostPriceList != null && gameData.m_GeneratedCostPriceList.Count > 0)
			{
				CPlayerData.m_GeneratedCostPriceList = gameData.m_GeneratedCostPriceList;
			}
			else
			{
				CPlayerData.m_GeneratedCostPriceList.Clear();
				for (int l = 0; l < 100; l++)
				{
					CPlayerData.m_GeneratedCostPriceList.Add(0f);
				}
			}
			if (gameData.m_GeneratedMarketPriceList != null && gameData.m_GeneratedMarketPriceList.Count > 0)
			{
				CPlayerData.m_GeneratedMarketPriceList = gameData.m_GeneratedMarketPriceList;
			}
			else
			{
				CPlayerData.m_GeneratedMarketPriceList.Clear();
				for (int m = 0; m < 100; m++)
				{
					CPlayerData.m_GeneratedMarketPriceList.Add(0f);
				}
			}
			if (gameData.m_ItemPricePercentChangeList != null && gameData.m_ItemPricePercentChangeList.Count > 0)
			{
				CPlayerData.m_ItemPricePercentChangeList = gameData.m_ItemPricePercentChangeList;
			}
			else
			{
				CPlayerData.m_ItemPricePercentChangeList.Clear();
				for (int n = 0; n < 100; n++)
				{
					CPlayerData.m_ItemPricePercentChangeList.Add(0f);
				}
			}
			if (gameData.m_ItemPricePercentPastChangeList != null && gameData.m_ItemPricePercentPastChangeList.Count > 0)
			{
				CPlayerData.m_ItemPricePercentPastChangeList = gameData.m_ItemPricePercentPastChangeList;
			}
			if (gameData.m_SetGameEventPriceList != null && gameData.m_SetGameEventPriceList.Count > 0)
			{
				CPlayerData.m_SetGameEventPriceList = gameData.m_SetGameEventPriceList;
			}
			else
			{
				CPlayerData.m_SetGameEventPriceList.Clear();
				for (int num = 0; num < 100; num++)
				{
					CPlayerData.m_SetGameEventPriceList.Add(0f);
				}
			}
			if (gameData.m_GeneratedGameEventPriceList != null && gameData.m_GeneratedGameEventPriceList.Count > 0)
			{
				CPlayerData.m_GeneratedGameEventPriceList = gameData.m_GeneratedGameEventPriceList;
			}
			else
			{
				CPlayerData.m_GeneratedGameEventPriceList.Clear();
				for (int num2 = 0; num2 < 100; num2++)
				{
					CPlayerData.m_GeneratedGameEventPriceList.Add(0f);
				}
			}
			if (gameData.m_GameEventPricePercentChangeList != null && gameData.m_GameEventPricePercentChangeList.Count > 0)
			{
				CPlayerData.m_GameEventPricePercentChangeList = gameData.m_GameEventPricePercentChangeList;
			}
			else
			{
				CPlayerData.m_GameEventPricePercentChangeList.Clear();
				for (int num3 = 0; num3 < 100; num3++)
				{
					CPlayerData.m_GameEventPricePercentChangeList.Add(0f);
				}
			}
			if (gameData.m_StockSoldList != null && gameData.m_StockSoldList.Count > 0)
			{
				CPlayerData.m_StockSoldList = gameData.m_StockSoldList;
			}
			if (gameData.m_CollectionCardPackCountList != null && gameData.m_CollectionCardPackCountList.Count > 0)
			{
				CPlayerData.m_CollectionCardPackCountList = gameData.m_CollectionCardPackCountList;
			}
			if (gameData.m_CardCollectedList != null && gameData.m_CardCollectedList.Count > 0)
			{
				CPlayerData.m_CardCollectedList = gameData.m_CardCollectedList;
			}
			if (CPlayerData.m_CardCollectedList.Count < CPlayerData.GetCardCollectionDataCount())
			{
				int num4 = CPlayerData.GetCardCollectionDataCount() - CPlayerData.m_CardCollectedList.Count;
				for (int num5 = 0; num5 < num4; num5++)
				{
					CPlayerData.m_CardCollectedList.Add(0);
				}
			}
			if (gameData.m_CardCollectedListDestiny != null && gameData.m_CardCollectedListDestiny.Count > 0)
			{
				CPlayerData.m_CardCollectedListDestiny = gameData.m_CardCollectedListDestiny;
			}
			if (CPlayerData.m_CardCollectedListDestiny.Count < CPlayerData.GetCardCollectionDataCount())
			{
				int num6 = CPlayerData.GetCardCollectionDataCount() - CPlayerData.m_CardCollectedListDestiny.Count;
				for (int num7 = 0; num7 < num6; num7++)
				{
					CPlayerData.m_CardCollectedListDestiny.Add(0);
				}
			}
			if (gameData.m_CardCollectedListGhost != null && gameData.m_CardCollectedListGhost.Count > 0)
			{
				CPlayerData.m_CardCollectedListGhost = gameData.m_CardCollectedListGhost;
			}
			if (CPlayerData.m_CardCollectedListGhost.Count < CPlayerData.GetCardCollectionDataCount())
			{
				int num8 = CPlayerData.GetCardCollectionDataCount() - CPlayerData.m_CardCollectedListGhost.Count;
				for (int num9 = 0; num9 < num8; num9++)
				{
					CPlayerData.m_CardCollectedListGhost.Add(0);
				}
			}
			if (gameData.m_CardCollectedListGhostBlack != null && gameData.m_CardCollectedListGhostBlack.Count > 0)
			{
				CPlayerData.m_CardCollectedListGhostBlack = gameData.m_CardCollectedListGhostBlack;
			}
			if (CPlayerData.m_CardCollectedListGhostBlack.Count < CPlayerData.GetCardCollectionDataCount())
			{
				int num10 = CPlayerData.GetCardCollectionDataCount() - CPlayerData.m_CardCollectedListGhostBlack.Count;
				for (int num11 = 0; num11 < num10; num11++)
				{
					CPlayerData.m_CardCollectedListGhostBlack.Add(0);
				}
			}
			if (gameData.m_CardCollectedListMegabot != null && gameData.m_CardCollectedListMegabot.Count > 0)
			{
				CPlayerData.m_CardCollectedListMegabot = gameData.m_CardCollectedListMegabot;
			}
			if (CPlayerData.m_CardCollectedListMegabot.Count < CPlayerData.GetCardCollectionDataCount())
			{
				int num12 = CPlayerData.GetCardCollectionDataCount() - CPlayerData.m_CardCollectedListMegabot.Count;
				for (int num13 = 0; num13 < num12; num13++)
				{
					CPlayerData.m_CardCollectedListMegabot.Add(0);
				}
			}
			if (gameData.m_CardCollectedListFantasyRPG != null && gameData.m_CardCollectedListFantasyRPG.Count > 0)
			{
				CPlayerData.m_CardCollectedListFantasyRPG = gameData.m_CardCollectedListFantasyRPG;
			}
			if (CPlayerData.m_CardCollectedListFantasyRPG.Count < CPlayerData.GetCardCollectionDataCount())
			{
				int num14 = CPlayerData.GetCardCollectionDataCount() - CPlayerData.m_CardCollectedListFantasyRPG.Count;
				for (int num15 = 0; num15 < num14; num15++)
				{
					CPlayerData.m_CardCollectedListFantasyRPG.Add(0);
				}
			}
			if (gameData.m_CardCollectedListCatJob != null && gameData.m_CardCollectedListCatJob.Count > 0)
			{
				CPlayerData.m_CardCollectedListCatJob = gameData.m_CardCollectedListCatJob;
			}
			if (CPlayerData.m_CardCollectedListCatJob.Count < CPlayerData.GetCardCollectionDataCount())
			{
				int num16 = CPlayerData.GetCardCollectionDataCount() - CPlayerData.m_CardCollectedListCatJob.Count;
				for (int num17 = 0; num17 < num16; num17++)
				{
					CPlayerData.m_CardCollectedListCatJob.Add(0);
				}
			}
			if (gameData.m_IsCardCollectedList != null && gameData.m_IsCardCollectedList.Count > 0)
			{
				CPlayerData.m_IsCardCollectedList = gameData.m_IsCardCollectedList;
			}
			if (CPlayerData.m_IsCardCollectedList.Count < CPlayerData.GetCardCollectionDataCount())
			{
				int num18 = CPlayerData.GetCardCollectionDataCount() - CPlayerData.m_IsCardCollectedList.Count;
				for (int num19 = 0; num19 < num18; num19++)
				{
					CPlayerData.m_IsCardCollectedList.Add(false);
				}
			}
			if (gameData.m_IsCardCollectedListDestiny != null && gameData.m_IsCardCollectedListDestiny.Count > 0)
			{
				CPlayerData.m_IsCardCollectedListDestiny = gameData.m_IsCardCollectedListDestiny;
			}
			if (CPlayerData.m_IsCardCollectedListDestiny.Count < CPlayerData.GetCardCollectionDataCount())
			{
				int num20 = CPlayerData.GetCardCollectionDataCount() - CPlayerData.m_IsCardCollectedListDestiny.Count;
				for (int num21 = 0; num21 < num20; num21++)
				{
					CPlayerData.m_IsCardCollectedListDestiny.Add(false);
				}
			}
			if (gameData.m_IsCardCollectedListGhost != null && gameData.m_IsCardCollectedListGhost.Count > 0)
			{
				CPlayerData.m_IsCardCollectedListGhost = gameData.m_IsCardCollectedListGhost;
			}
			if (CPlayerData.m_IsCardCollectedListGhost.Count < CPlayerData.GetCardCollectionDataCount())
			{
				int num22 = CPlayerData.GetCardCollectionDataCount() - CPlayerData.m_IsCardCollectedListGhost.Count;
				for (int num23 = 0; num23 < num22; num23++)
				{
					CPlayerData.m_IsCardCollectedListGhost.Add(false);
				}
			}
			if (gameData.m_IsCardCollectedListGhostBlack != null && gameData.m_IsCardCollectedListGhostBlack.Count > 0)
			{
				CPlayerData.m_IsCardCollectedListGhostBlack = gameData.m_IsCardCollectedListGhostBlack;
			}
			if (CPlayerData.m_IsCardCollectedListGhostBlack.Count < CPlayerData.GetCardCollectionDataCount())
			{
				int num24 = CPlayerData.GetCardCollectionDataCount() - CPlayerData.m_IsCardCollectedListGhostBlack.Count;
				for (int num25 = 0; num25 < num24; num25++)
				{
					CPlayerData.m_IsCardCollectedListGhostBlack.Add(false);
				}
			}
			if (gameData.m_IsCardCollectedListMegabot != null && gameData.m_IsCardCollectedListMegabot.Count > 0)
			{
				CPlayerData.m_IsCardCollectedListMegabot = gameData.m_IsCardCollectedListMegabot;
			}
			if (CPlayerData.m_IsCardCollectedListMegabot.Count < CPlayerData.GetCardCollectionDataCount())
			{
				int num26 = CPlayerData.GetCardCollectionDataCount() - CPlayerData.m_IsCardCollectedListMegabot.Count;
				for (int num27 = 0; num27 < num26; num27++)
				{
					CPlayerData.m_IsCardCollectedListMegabot.Add(false);
				}
			}
			if (gameData.m_IsCardCollectedListFantasyRPG != null && gameData.m_IsCardCollectedListFantasyRPG.Count > 0)
			{
				CPlayerData.m_IsCardCollectedListFantasyRPG = gameData.m_IsCardCollectedListFantasyRPG;
			}
			if (CPlayerData.m_IsCardCollectedListFantasyRPG.Count < CPlayerData.GetCardCollectionDataCount())
			{
				int num28 = CPlayerData.GetCardCollectionDataCount() - CPlayerData.m_IsCardCollectedListFantasyRPG.Count;
				for (int num29 = 0; num29 < num28; num29++)
				{
					CPlayerData.m_IsCardCollectedListFantasyRPG.Add(false);
				}
			}
			if (gameData.m_IsCardCollectedListCatJob != null && gameData.m_IsCardCollectedListCatJob.Count > 0)
			{
				CPlayerData.m_IsCardCollectedListCatJob = gameData.m_IsCardCollectedListCatJob;
			}
			if (CPlayerData.m_IsCardCollectedListCatJob.Count < CPlayerData.GetCardCollectionDataCount())
			{
				int num30 = CPlayerData.GetCardCollectionDataCount() - CPlayerData.m_IsCardCollectedListCatJob.Count;
				for (int num31 = 0; num31 < num30; num31++)
				{
					CPlayerData.m_IsCardCollectedListCatJob.Add(false);
				}
			}
			if (gameData.m_CardPriceSetList != null && gameData.m_CardPriceSetList.Count > 0)
			{
				CPlayerData.m_CardPriceSetList = gameData.m_CardPriceSetList;
				CPlayerData.m_CardPriceSetListDestiny = gameData.m_CardPriceSetListDestiny;
				CPlayerData.m_CardPriceSetListGhost = gameData.m_CardPriceSetListGhost;
				CPlayerData.m_CardPriceSetListGhostBlack = gameData.m_CardPriceSetListGhostBlack;
				CPlayerData.m_CardPriceSetListMegabot = gameData.m_CardPriceSetListMegabot;
				CPlayerData.m_CardPriceSetListFantasyRPG = gameData.m_CardPriceSetListFantasyRPG;
				CPlayerData.m_CardPriceSetListCatJob = gameData.m_CardPriceSetListCatJob;
				CPlayerData.m_GenCardMarketPriceList = gameData.m_GenCardMarketPriceList;
				CPlayerData.m_GenCardMarketPriceListDestiny = gameData.m_GenCardMarketPriceListDestiny;
				CPlayerData.m_GenCardMarketPriceListGhost = gameData.m_GenCardMarketPriceListGhost;
				CPlayerData.m_GenCardMarketPriceListGhostBlack = gameData.m_GenCardMarketPriceListGhostBlack;
				CPlayerData.m_GenCardMarketPriceListMegabot = gameData.m_GenCardMarketPriceListMegabot;
				CPlayerData.m_GenCardMarketPriceListFantasyRPG = gameData.m_GenCardMarketPriceListFantasyRPG;
				CPlayerData.m_GenCardMarketPriceListCatJob = gameData.m_GenCardMarketPriceListCatJob;
			}
			if (gameData.m_ChampionCardCollectedList != null && gameData.m_ChampionCardCollectedList.Count > 0)
			{
				CPlayerData.m_ChampionCardCollectedList = gameData.m_ChampionCardCollectedList;
			}
			if (gameData.m_CollectionSortingMethodIndexList != null && gameData.m_CollectionSortingMethodIndexList.Count > 0)
			{
				CPlayerData.m_CollectionSortingMethodIndexList = gameData.m_CollectionSortingMethodIndexList;
			}
			if (gameData.m_IsItemLicenseUnlocked != null && gameData.m_IsItemLicenseUnlocked.Count > 0)
			{
				CPlayerData.m_IsItemLicenseUnlocked = gameData.m_IsItemLicenseUnlocked;
			}
			if (CPlayerData.m_IsItemLicenseUnlocked.Count < 500)
			{
				for (int num32 = 0; num32 < 500; num32++)
				{
					CPlayerData.m_IsItemLicenseUnlocked.Add(false);
				}
			}
			if (gameData.m_IsWorkerHired != null && gameData.m_IsWorkerHired.Count > 0)
			{
				CPlayerData.m_IsWorkerHired = gameData.m_IsWorkerHired;
			}
			if (gameData.m_IsAchievementUnlocked != null && gameData.m_IsAchievementUnlocked.Count > 0)
			{
				CPlayerData.m_IsAchievementUnlocked = gameData.m_IsAchievementUnlocked;
			}
			CPlayerData.m_TutorialIndex = gameData.m_TutorialIndex;
			CPlayerData.m_TutorialSubgroupIndex = gameData.m_TutorialSubgroupIndex;
			CPlayerData.m_HasFinishedTutorial = gameData.m_HasFinishedTutorial;
			CPlayerData.m_HasGetGhostCard = gameData.m_HasGetGhostCard;
			CPlayerData.m_MusicVolumeDecrease = gameData.m_MusicVolumeDecrease;
			CPlayerData.m_SoundVolumeDecrease = gameData.m_SoundVolumeDecrease;
			CPlayerData.m_WorkbenchMinimumCardLimit = gameData.m_WorkbenchMinimumCardLimit;
			CPlayerData.m_WorkbenchPriceLimit = gameData.m_WorkbenchPriceLimit;
			CPlayerData.m_WorkbenchRarityLimit = gameData.m_WorkbenchRarityLimit;
			CPlayerData.m_WorkbenchCardExpansionType = gameData.m_WorkbenchCardExpansionType;
			CPlayerData.m_DebugString = gameData.m_DebugString;
			CPlayerData.m_DebugString2 = gameData.m_DebugString2;
			CPlayerData.m_LastLoginPlayfabID = gameData.m_LastLoginPlayfabID;
			if (gameData.m_LightTimeData != null)
			{
				CPlayerData.m_LightTimeData = gameData.m_LightTimeData;
			}
			CPlayerData.m_GameEventFormat = gameData.m_GameEventFormat;
			CPlayerData.m_PendingGameEventFormat = gameData.m_PendingGameEventFormat;
			CPlayerData.m_GameEventExpansionType = gameData.m_GameEventExpansionType;
			CPlayerData.m_PendingGameEventExpansionType = gameData.m_PendingGameEventExpansionType;
			CPlayerData.m_GameReportDataCollect = gameData.m_GameReportDataCollect;
			CPlayerData.m_GameReportDataCollectPermanent = gameData.m_GameReportDataCollectPermanent;
			if (gameData.m_GameReportDataCollectPastList != null)
			{
				CPlayerData.m_GameReportDataCollectPastList = gameData.m_GameReportDataCollectPastList;
			}
			CPlayerData.m_ShelfSaveDataList = gameData.m_ShelfSaveDataList;
			CPlayerData.m_WarehouseShelfSaveDataList = gameData.m_WarehouseShelfSaveDataList;
			CPlayerData.m_PackageBoxItemSaveDataList = gameData.m_PackageBoxItemSaveDataList;
			CPlayerData.m_InteractableObjectSaveDataList = gameData.m_InteractableObjectSaveDataList;
			if (gameData.m_CardShelfSaveDataList != null)
			{
				CPlayerData.m_CardShelfSaveDataList = gameData.m_CardShelfSaveDataList;
			}
			if (gameData.m_PlayTableSaveDataList != null)
			{
				CPlayerData.m_PlayTableSaveDataList = gameData.m_PlayTableSaveDataList;
			}
			if (gameData.m_AutoCleanserSaveDataList != null)
			{
				CPlayerData.m_AutoCleanserSaveDataList = gameData.m_AutoCleanserSaveDataList;
			}
			if (gameData.m_WorkbenchSaveDataList != null)
			{
				CPlayerData.m_WorkbenchSaveDataList = gameData.m_WorkbenchSaveDataList;
			}
			if (gameData.m_CustomerSaveDataList != null)
			{
				CPlayerData.m_CustomerSaveDataList = gameData.m_CustomerSaveDataList;
			}
			if (gameData.m_WorkerSaveDataList != null)
			{
				CPlayerData.m_WorkerSaveDataList = gameData.m_WorkerSaveDataList;
			}
			if (gameData.m_TutorialDataList != null)
			{
				CPlayerData.m_TutorialDataList = gameData.m_TutorialDataList;
			}
			if (gameData.m_BillList != null)
			{
				CPlayerData.m_BillList = gameData.m_BillList;
			}
			if (gameData.m_HoldCardDataList != null)
			{
				CPlayerData.m_HoldCardDataList = gameData.m_HoldCardDataList;
			}
			if (gameData.m_HoldItemTypeList != null)
			{
				CPlayerData.m_HoldItemTypeList = gameData.m_HoldItemTypeList;
			}
			if (CPlayerData.m_CurrentTotalItemCountList.Count < 500)
			{
				for (int num33 = 0; num33 < 500; num33++)
				{
					CPlayerData.m_CurrentTotalItemCountList.Add(0);
					CPlayerData.m_SetItemPriceList.Add(0f);
					CPlayerData.m_AverageItemCostList.Add(0f);
					CPlayerData.m_GeneratedCostPriceList.Add(0f);
					CPlayerData.m_GeneratedMarketPriceList.Add(0f);
					CPlayerData.m_ItemPricePercentChangeList.Add(0f);
					FloatList floatList = new FloatList();
					floatList.floatDataList = new List<float>();
					CPlayerData.m_ItemPricePercentPastChangeList.Add(floatList);
					CPlayerData.m_StockSoldList.Add(0);
				}
			}
			CSingleton<ShelfManager>.Instance.LoadInteractableObjectData();
			GameInstance.m_HasLoadingError = false;
		}
		catch
		{
			Debug.LogError("Version : " + Application.version + "Error: Loading game data error");
			this.m_CanCloudLoad = true;
		}
	}

	// Token: 0x0600065C RID: 1628 RVA: 0x00034C98 File Offset: 0x00032E98
	public void SetLoadData<T>(ref T data, T loadData)
	{
		this.m_DebugDataCount++;
		if (loadData != null)
		{
			if (data == null)
			{
				Debug.Log("Null Ref Data Present SetLoadData" + this.m_DebugDataCount.ToString());
			}
			data = loadData;
			return;
		}
		Debug.Log("Null Data Present SetLoadData" + this.m_DebugDataCount.ToString());
	}

	// Token: 0x0600065D RID: 1629 RVA: 0x00034D08 File Offset: 0x00032F08
	public void SaveGameData(int saveSlotIndex)
	{
		this.m_DebugDataCount = 0;
		Debug.Log("SaveGameData saveSlotIndex " + saveSlotIndex.ToString());
		this.SetLoadData<EGameEventFormat>(ref this.m_GameEventFormat, CPlayerData.m_GameEventFormat);
		this.SetLoadData<EGameEventFormat>(ref this.m_PendingGameEventFormat, CPlayerData.m_PendingGameEventFormat);
		this.SetLoadData<ECardExpansionType>(ref this.m_GameEventExpansionType, CPlayerData.m_GameEventExpansionType);
		this.SetLoadData<ECardExpansionType>(ref this.m_PendingGameEventExpansionType, CPlayerData.m_PendingGameEventExpansionType);
		this.SetLoadData<LightTimeData>(ref this.m_LightTimeData, CPlayerData.m_LightTimeData);
		this.SetLoadData<GameReportDataCollect>(ref this.m_GameReportDataCollect, CPlayerData.m_GameReportDataCollect);
		this.SetLoadData<GameReportDataCollect>(ref this.m_GameReportDataCollectPermanent, CPlayerData.m_GameReportDataCollectPermanent);
		this.SetLoadData<List<GameReportDataCollect>>(ref this.m_GameReportDataCollectPastList, CPlayerData.m_GameReportDataCollectPastList);
		this.SetLoadData<List<ShelfSaveData>>(ref this.m_ShelfSaveDataList, CPlayerData.m_ShelfSaveDataList);
		this.SetLoadData<List<WarehouseShelfSaveData>>(ref this.m_WarehouseShelfSaveDataList, CPlayerData.m_WarehouseShelfSaveDataList);
		this.SetLoadData<List<PackageBoxItemaveData>>(ref this.m_PackageBoxItemSaveDataList, CPlayerData.m_PackageBoxItemSaveDataList);
		this.SetLoadData<List<InteractableObjectSaveData>>(ref this.m_InteractableObjectSaveDataList, CPlayerData.m_InteractableObjectSaveDataList);
		this.SetLoadData<List<CardShelfSaveData>>(ref this.m_CardShelfSaveDataList, CPlayerData.m_CardShelfSaveDataList);
		this.SetLoadData<List<PlayTableSaveData>>(ref this.m_PlayTableSaveDataList, CPlayerData.m_PlayTableSaveDataList);
		this.SetLoadData<List<AutoCleanserSaveData>>(ref this.m_AutoCleanserSaveDataList, CPlayerData.m_AutoCleanserSaveDataList);
		this.SetLoadData<List<WorkbenchSaveData>>(ref this.m_WorkbenchSaveDataList, CPlayerData.m_WorkbenchSaveDataList);
		this.SetLoadData<List<CustomerSaveData>>(ref this.m_CustomerSaveDataList, CPlayerData.m_CustomerSaveDataList);
		this.SetLoadData<List<WorkerSaveData>>(ref this.m_WorkerSaveDataList, CPlayerData.m_WorkerSaveDataList);
		this.SetLoadData<List<TutorialData>>(ref this.m_TutorialDataList, CPlayerData.m_TutorialDataList);
		this.SetLoadData<List<BillData>>(ref this.m_BillList, CPlayerData.m_BillList);
		this.SetLoadData<List<CardData>>(ref this.m_HoldCardDataList, CPlayerData.m_HoldCardDataList);
		this.SetLoadData<List<EItemType>>(ref this.m_HoldItemTypeList, CPlayerData.m_HoldItemTypeList);
		CPlayerData.m_SaveIndex++;
		if (CPlayerData.m_SaveIndex >= 1000000000)
		{
			CPlayerData.m_SaveIndex = 0;
			CPlayerData.m_SaveCycle++;
		}
		this.SetLoadData<int>(ref this.m_SaveIndex, CPlayerData.m_SaveIndex);
		this.SetLoadData<int>(ref this.m_SaveCycle, CPlayerData.m_SaveCycle);
		this.SetLoadData<string>(ref this.m_LastLoginPlayfabID, CPlayerData.m_LastLoginPlayfabID);
		this.SetLoadData<bool>(ref this.m_CanCloudLoad, CPlayerData.m_CanCloudLoad);
		this.SetLoadData<DateTime>(ref this.m_LastLocalExitTime, CPlayerData.m_LastLocalExitTime);
		this.SetLoadData<string>(ref this.m_PlayerName, CPlayerData.PlayerName);
		this.SetLoadData<float>(ref this.m_CoinAmount, CPlayerData.m_CoinAmount);
		this.SetLoadData<int>(ref this.m_FamePoint, CPlayerData.m_FamePoint);
		this.SetLoadData<int>(ref this.m_TotalFameAdd, CPlayerData.m_TotalFameAdd);
		this.SetLoadData<int>(ref this.m_CloudSaveCountdown, CPlayerData.m_CloudSaveCountdown);
		this.SetLoadData<int>(ref this.m_CurrentDay, CPlayerData.m_CurrentDay);
		this.SetLoadData<int>(ref this.m_ShopExpPoint, CPlayerData.m_ShopExpPoint);
		this.SetLoadData<int>(ref this.m_ShopLevel, CPlayerData.m_ShopLevel);
		this.SetLoadData<List<int>>(ref this.m_CurrentTotalItemCountList, CPlayerData.m_CurrentTotalItemCountList);
		this.SetLoadData<bool>(ref this.m_IsShopOpen, CPlayerData.m_IsShopOpen);
		this.SetLoadData<bool>(ref this.m_IsShopOnceOpen, CPlayerData.m_IsShopOnceOpen);
		this.SetLoadData<bool>(ref this.m_IsWarehouseDoorClosed, CPlayerData.m_IsWarehouseDoorClosed);
		this.SetLoadData<bool>(ref this.m_IsItemPriceGenerated, CPlayerData.m_IsItemPriceGenerated);
		this.SetLoadData<bool>(ref this.m_IsCardPriceGenerated, CPlayerData.m_IsCardPriceGenerated);
		this.SetLoadData<List<float>>(ref this.m_SetItemPriceList, CPlayerData.m_SetItemPriceList);
		this.SetLoadData<List<float>>(ref this.m_AverageItemCostList, CPlayerData.m_AverageItemCostList);
		this.SetLoadData<List<float>>(ref this.m_GeneratedCostPriceList, CPlayerData.m_GeneratedCostPriceList);
		this.SetLoadData<List<float>>(ref this.m_GeneratedMarketPriceList, CPlayerData.m_GeneratedMarketPriceList);
		this.SetLoadData<List<float>>(ref this.m_ItemPricePercentChangeList, CPlayerData.m_ItemPricePercentChangeList);
		this.SetLoadData<List<FloatList>>(ref this.m_ItemPricePercentPastChangeList, CPlayerData.m_ItemPricePercentPastChangeList);
		this.SetLoadData<List<float>>(ref this.m_SetGameEventPriceList, CPlayerData.m_SetGameEventPriceList);
		this.SetLoadData<List<float>>(ref this.m_GeneratedGameEventPriceList, CPlayerData.m_GeneratedGameEventPriceList);
		this.SetLoadData<List<float>>(ref this.m_GameEventPricePercentChangeList, CPlayerData.m_GameEventPricePercentChangeList);
		this.SetLoadData<List<int>>(ref this.m_StockSoldList, CPlayerData.m_StockSoldList);
		this.SetLoadData<List<int>>(ref this.m_CollectionCardPackCountList, CPlayerData.m_CollectionCardPackCountList);
		this.SetLoadData<List<int>>(ref this.m_CardCollectedList, CPlayerData.m_CardCollectedList);
		this.SetLoadData<List<int>>(ref this.m_CardCollectedListDestiny, CPlayerData.m_CardCollectedListDestiny);
		this.SetLoadData<List<int>>(ref this.m_CardCollectedListGhost, CPlayerData.m_CardCollectedListGhost);
		this.SetLoadData<List<int>>(ref this.m_CardCollectedListGhostBlack, CPlayerData.m_CardCollectedListGhostBlack);
		this.SetLoadData<List<int>>(ref this.m_CardCollectedListMegabot, CPlayerData.m_CardCollectedListMegabot);
		this.SetLoadData<List<int>>(ref this.m_CardCollectedListFantasyRPG, CPlayerData.m_CardCollectedListFantasyRPG);
		this.SetLoadData<List<int>>(ref this.m_CardCollectedListCatJob, CPlayerData.m_CardCollectedListCatJob);
		this.SetLoadData<List<bool>>(ref this.m_IsCardCollectedList, CPlayerData.m_IsCardCollectedList);
		this.SetLoadData<List<bool>>(ref this.m_IsCardCollectedListDestiny, CPlayerData.m_IsCardCollectedListDestiny);
		this.SetLoadData<List<bool>>(ref this.m_IsCardCollectedListGhost, CPlayerData.m_IsCardCollectedListGhost);
		this.SetLoadData<List<bool>>(ref this.m_IsCardCollectedListGhostBlack, CPlayerData.m_IsCardCollectedListGhostBlack);
		this.SetLoadData<List<bool>>(ref this.m_IsCardCollectedListMegabot, CPlayerData.m_IsCardCollectedListMegabot);
		this.SetLoadData<List<bool>>(ref this.m_IsCardCollectedListFantasyRPG, CPlayerData.m_IsCardCollectedListFantasyRPG);
		this.SetLoadData<List<bool>>(ref this.m_IsCardCollectedListCatJob, CPlayerData.m_IsCardCollectedListCatJob);
		this.SetLoadData<List<float>>(ref this.m_CardPriceSetList, CPlayerData.m_CardPriceSetList);
		this.SetLoadData<List<float>>(ref this.m_CardPriceSetListDestiny, CPlayerData.m_CardPriceSetListDestiny);
		this.SetLoadData<List<float>>(ref this.m_CardPriceSetListGhost, CPlayerData.m_CardPriceSetListGhost);
		this.SetLoadData<List<float>>(ref this.m_CardPriceSetListGhostBlack, CPlayerData.m_CardPriceSetListGhostBlack);
		this.SetLoadData<List<float>>(ref this.m_CardPriceSetListMegabot, CPlayerData.m_CardPriceSetListMegabot);
		this.SetLoadData<List<float>>(ref this.m_CardPriceSetListFantasyRPG, CPlayerData.m_CardPriceSetListFantasyRPG);
		this.SetLoadData<List<float>>(ref this.m_CardPriceSetListCatJob, CPlayerData.m_CardPriceSetListCatJob);
		this.SetLoadData<List<MarketPrice>>(ref this.m_GenCardMarketPriceList, CPlayerData.m_GenCardMarketPriceList);
		this.SetLoadData<List<MarketPrice>>(ref this.m_GenCardMarketPriceListDestiny, CPlayerData.m_GenCardMarketPriceListDestiny);
		this.SetLoadData<List<MarketPrice>>(ref this.m_GenCardMarketPriceListGhost, CPlayerData.m_GenCardMarketPriceListGhost);
		this.SetLoadData<List<MarketPrice>>(ref this.m_GenCardMarketPriceListGhostBlack, CPlayerData.m_GenCardMarketPriceListGhostBlack);
		this.SetLoadData<List<MarketPrice>>(ref this.m_GenCardMarketPriceListMegabot, CPlayerData.m_GenCardMarketPriceListMegabot);
		this.SetLoadData<List<MarketPrice>>(ref this.m_GenCardMarketPriceListFantasyRPG, CPlayerData.m_GenCardMarketPriceListFantasyRPG);
		this.SetLoadData<List<MarketPrice>>(ref this.m_GenCardMarketPriceListCatJob, CPlayerData.m_GenCardMarketPriceListCatJob);
		this.SetLoadData<List<int>>(ref this.m_CollectionSortingMethodIndexList, CPlayerData.m_CollectionSortingMethodIndexList);
		this.SetLoadData<List<int>>(ref this.m_ChampionCardCollectedList, CPlayerData.m_ChampionCardCollectedList);
		this.SetLoadData<List<bool>>(ref this.m_IsItemLicenseUnlocked, CPlayerData.m_IsItemLicenseUnlocked);
		this.SetLoadData<List<bool>>(ref this.m_IsWorkerHired, CPlayerData.m_IsWorkerHired);
		this.SetLoadData<List<bool>>(ref this.m_IsAchievementUnlocked, CPlayerData.m_IsAchievementUnlocked);
		this.SetLoadData<bool>(ref this.m_IsWarehouseRoomUnlocked, CPlayerData.m_IsWarehouseRoomUnlocked);
		this.SetLoadData<int>(ref this.m_UnlockRoomCount, CPlayerData.m_UnlockRoomCount);
		this.SetLoadData<int>(ref this.m_UnlockWarehouseRoomCount, CPlayerData.m_UnlockWarehouseRoomCount);
		this.SetLoadData<float>(ref this.m_MusicVolumeDecrease, CPlayerData.m_MusicVolumeDecrease);
		this.SetLoadData<float>(ref this.m_SoundVolumeDecrease, CPlayerData.m_SoundVolumeDecrease);
		this.SetLoadData<int>(ref this.m_TutorialIndex, CPlayerData.m_TutorialIndex);
		this.SetLoadData<int>(ref this.m_TutorialSubgroupIndex, CPlayerData.m_TutorialSubgroupIndex);
		this.SetLoadData<bool>(ref this.m_HasFinishedTutorial, CPlayerData.m_HasFinishedTutorial);
		this.SetLoadData<bool>(ref this.m_HasGetGhostCard, CPlayerData.m_HasGetGhostCard);
		this.SetLoadData<bool>(ref this.m_IsMainGame, CPlayerData.m_IsMainGame);
		this.SetLoadData<int>(ref this.m_WorkbenchMinimumCardLimit, CPlayerData.m_WorkbenchMinimumCardLimit);
		this.SetLoadData<float>(ref this.m_WorkbenchPriceLimit, CPlayerData.m_WorkbenchPriceLimit);
		this.SetLoadData<ERarity>(ref this.m_WorkbenchRarityLimit, CPlayerData.m_WorkbenchRarityLimit);
		this.SetLoadData<ECardExpansionType>(ref this.m_WorkbenchCardExpansionType, CPlayerData.m_WorkbenchCardExpansionType);
		this.SetLoadData<string>(ref this.m_DebugString, CPlayerData.m_DebugString);
		this.SetLoadData<string>(ref this.m_DebugString2, CPlayerData.m_DebugString2);
		Debug.Log("SetLoadData finish");
		CSaveLoad.Save(saveSlotIndex, false);
		Debug.Log("CSaveLoad.Save() finish");
	}

	// Token: 0x0600065E RID: 1630 RVA: 0x0003542C File Offset: 0x0003362C
	public void MatchSaveIndex(CGameData gameData)
	{
		if (gameData != null)
		{
			this.m_SaveIndex = gameData.m_SaveIndex;
			this.m_SaveCycle = gameData.m_SaveCycle;
			this.m_LastLoginPlayfabID = gameData.m_LastLoginPlayfabID;
		}
	}

	// Token: 0x0400080F RID: 2063
	public static CGameData instance;

	// Token: 0x04000810 RID: 2064
	public int m_SaveIndex;

	// Token: 0x04000811 RID: 2065
	public int m_SaveCycle;

	// Token: 0x04000812 RID: 2066
	public bool m_CanCloudLoad;

	// Token: 0x04000813 RID: 2067
	public DateTime m_LastLocalExitTime;

	// Token: 0x04000814 RID: 2068
	public string m_LastLoginPlayfabID;

	// Token: 0x04000815 RID: 2069
	public LightTimeData m_LightTimeData;

	// Token: 0x04000816 RID: 2070
	public EGameEventFormat m_GameEventFormat;

	// Token: 0x04000817 RID: 2071
	public EGameEventFormat m_PendingGameEventFormat;

	// Token: 0x04000818 RID: 2072
	public ECardExpansionType m_GameEventExpansionType;

	// Token: 0x04000819 RID: 2073
	public ECardExpansionType m_PendingGameEventExpansionType;

	// Token: 0x0400081A RID: 2074
	public GameReportDataCollect m_GameReportDataCollect;

	// Token: 0x0400081B RID: 2075
	public GameReportDataCollect m_GameReportDataCollectPermanent;

	// Token: 0x0400081C RID: 2076
	public List<GameReportDataCollect> m_GameReportDataCollectPastList;

	// Token: 0x0400081D RID: 2077
	public List<ShelfSaveData> m_ShelfSaveDataList;

	// Token: 0x0400081E RID: 2078
	public List<WarehouseShelfSaveData> m_WarehouseShelfSaveDataList;

	// Token: 0x0400081F RID: 2079
	public List<PackageBoxItemaveData> m_PackageBoxItemSaveDataList;

	// Token: 0x04000820 RID: 2080
	public List<InteractableObjectSaveData> m_InteractableObjectSaveDataList;

	// Token: 0x04000821 RID: 2081
	public List<CardShelfSaveData> m_CardShelfSaveDataList;

	// Token: 0x04000822 RID: 2082
	public List<PlayTableSaveData> m_PlayTableSaveDataList;

	// Token: 0x04000823 RID: 2083
	public List<AutoCleanserSaveData> m_AutoCleanserSaveDataList;

	// Token: 0x04000824 RID: 2084
	public List<WorkbenchSaveData> m_WorkbenchSaveDataList;

	// Token: 0x04000825 RID: 2085
	public List<CustomerSaveData> m_CustomerSaveDataList;

	// Token: 0x04000826 RID: 2086
	public List<WorkerSaveData> m_WorkerSaveDataList;

	// Token: 0x04000827 RID: 2087
	public List<TutorialData> m_TutorialDataList;

	// Token: 0x04000828 RID: 2088
	public List<BillData> m_BillList;

	// Token: 0x04000829 RID: 2089
	public List<CardData> m_HoldCardDataList;

	// Token: 0x0400082A RID: 2090
	public List<EItemType> m_HoldItemTypeList;

	// Token: 0x0400082B RID: 2091
	public bool m_IsShopOpen;

	// Token: 0x0400082C RID: 2092
	public bool m_IsShopOnceOpen;

	// Token: 0x0400082D RID: 2093
	public bool m_IsWarehouseDoorClosed;

	// Token: 0x0400082E RID: 2094
	public bool m_IsItemPriceGenerated;

	// Token: 0x0400082F RID: 2095
	public bool m_IsCardPriceGenerated;

	// Token: 0x04000830 RID: 2096
	public List<int> m_CurrentTotalItemCountList;

	// Token: 0x04000831 RID: 2097
	public List<float> m_SetItemPriceList;

	// Token: 0x04000832 RID: 2098
	public List<float> m_AverageItemCostList;

	// Token: 0x04000833 RID: 2099
	public List<float> m_GeneratedCostPriceList;

	// Token: 0x04000834 RID: 2100
	public List<float> m_GeneratedMarketPriceList;

	// Token: 0x04000835 RID: 2101
	public List<float> m_ItemPricePercentChangeList;

	// Token: 0x04000836 RID: 2102
	public List<FloatList> m_ItemPricePercentPastChangeList;

	// Token: 0x04000837 RID: 2103
	public List<float> m_SetGameEventPriceList;

	// Token: 0x04000838 RID: 2104
	public List<float> m_GeneratedGameEventPriceList;

	// Token: 0x04000839 RID: 2105
	public List<float> m_GameEventPricePercentChangeList;

	// Token: 0x0400083A RID: 2106
	public List<int> m_StockSoldList;

	// Token: 0x0400083B RID: 2107
	public List<int> m_CollectionCardPackCountList;

	// Token: 0x0400083C RID: 2108
	public List<int> m_CardCollectedList;

	// Token: 0x0400083D RID: 2109
	public List<int> m_CardCollectedListDestiny;

	// Token: 0x0400083E RID: 2110
	public List<int> m_CardCollectedListGhost;

	// Token: 0x0400083F RID: 2111
	public List<int> m_CardCollectedListGhostBlack;

	// Token: 0x04000840 RID: 2112
	public List<int> m_CardCollectedListMegabot;

	// Token: 0x04000841 RID: 2113
	public List<int> m_CardCollectedListFantasyRPG;

	// Token: 0x04000842 RID: 2114
	public List<int> m_CardCollectedListCatJob;

	// Token: 0x04000843 RID: 2115
	public List<bool> m_IsCardCollectedList;

	// Token: 0x04000844 RID: 2116
	public List<bool> m_IsCardCollectedListDestiny;

	// Token: 0x04000845 RID: 2117
	public List<bool> m_IsCardCollectedListGhost;

	// Token: 0x04000846 RID: 2118
	public List<bool> m_IsCardCollectedListGhostBlack;

	// Token: 0x04000847 RID: 2119
	public List<bool> m_IsCardCollectedListMegabot;

	// Token: 0x04000848 RID: 2120
	public List<bool> m_IsCardCollectedListFantasyRPG;

	// Token: 0x04000849 RID: 2121
	public List<bool> m_IsCardCollectedListCatJob;

	// Token: 0x0400084A RID: 2122
	public List<float> m_CardPriceSetList;

	// Token: 0x0400084B RID: 2123
	public List<float> m_CardPriceSetListDestiny;

	// Token: 0x0400084C RID: 2124
	public List<float> m_CardPriceSetListGhost;

	// Token: 0x0400084D RID: 2125
	public List<float> m_CardPriceSetListGhostBlack;

	// Token: 0x0400084E RID: 2126
	public List<float> m_CardPriceSetListMegabot;

	// Token: 0x0400084F RID: 2127
	public List<float> m_CardPriceSetListFantasyRPG;

	// Token: 0x04000850 RID: 2128
	public List<float> m_CardPriceSetListCatJob;

	// Token: 0x04000851 RID: 2129
	public List<MarketPrice> m_GenCardMarketPriceList;

	// Token: 0x04000852 RID: 2130
	public List<MarketPrice> m_GenCardMarketPriceListDestiny;

	// Token: 0x04000853 RID: 2131
	public List<MarketPrice> m_GenCardMarketPriceListGhost;

	// Token: 0x04000854 RID: 2132
	public List<MarketPrice> m_GenCardMarketPriceListGhostBlack;

	// Token: 0x04000855 RID: 2133
	public List<MarketPrice> m_GenCardMarketPriceListMegabot;

	// Token: 0x04000856 RID: 2134
	public List<MarketPrice> m_GenCardMarketPriceListFantasyRPG;

	// Token: 0x04000857 RID: 2135
	public List<MarketPrice> m_GenCardMarketPriceListCatJob;

	// Token: 0x04000858 RID: 2136
	public List<int> m_CollectionSortingMethodIndexList;

	// Token: 0x04000859 RID: 2137
	public List<int> m_ChampionCardCollectedList;

	// Token: 0x0400085A RID: 2138
	public List<bool> m_IsItemLicenseUnlocked;

	// Token: 0x0400085B RID: 2139
	public List<bool> m_IsWorkerHired;

	// Token: 0x0400085C RID: 2140
	public List<bool> m_IsAchievementUnlocked;

	// Token: 0x0400085D RID: 2141
	public string m_PlayerName;

	// Token: 0x0400085E RID: 2142
	public float m_CoinAmount;

	// Token: 0x0400085F RID: 2143
	public int m_FamePoint;

	// Token: 0x04000860 RID: 2144
	public int m_TotalFameAdd;

	// Token: 0x04000861 RID: 2145
	public bool m_IsWarehouseRoomUnlocked;

	// Token: 0x04000862 RID: 2146
	public int m_UnlockRoomCount;

	// Token: 0x04000863 RID: 2147
	public int m_UnlockWarehouseRoomCount;

	// Token: 0x04000864 RID: 2148
	public int m_CurrentDay;

	// Token: 0x04000865 RID: 2149
	public int m_ShopExpPoint;

	// Token: 0x04000866 RID: 2150
	public int m_ShopLevel;

	// Token: 0x04000867 RID: 2151
	public int m_CloudSaveCountdown;

	// Token: 0x04000868 RID: 2152
	public int m_TutorialIndex;

	// Token: 0x04000869 RID: 2153
	public int m_TutorialSubgroupIndex;

	// Token: 0x0400086A RID: 2154
	public bool m_HasFinishedTutorial;

	// Token: 0x0400086B RID: 2155
	public bool m_IsMainGame;

	// Token: 0x0400086C RID: 2156
	public bool m_HasGetGhostCard;

	// Token: 0x0400086D RID: 2157
	public float m_MusicVolumeDecrease;

	// Token: 0x0400086E RID: 2158
	public float m_SoundVolumeDecrease;

	// Token: 0x0400086F RID: 2159
	public int m_WorkbenchMinimumCardLimit;

	// Token: 0x04000870 RID: 2160
	public float m_WorkbenchPriceLimit;

	// Token: 0x04000871 RID: 2161
	public ERarity m_WorkbenchRarityLimit;

	// Token: 0x04000872 RID: 2162
	public ECardExpansionType m_WorkbenchCardExpansionType;

	// Token: 0x04000873 RID: 2163
	public string m_DebugString;

	// Token: 0x04000874 RID: 2164
	public string m_DebugString2;

	// Token: 0x04000875 RID: 2165
	public int m_DebugDataCount;
}
