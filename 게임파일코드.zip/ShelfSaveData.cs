﻿using System;
using System.Collections.Generic;

// Token: 0x02000049 RID: 73
[Serializable]
public class ShelfSaveData
{
	// Token: 0x0400043C RID: 1084
	public List<ItemTypeAmount> itemTypeAmountList;

	// Token: 0x0400043D RID: 1085
	public Vector3Serializer pos;

	// Token: 0x0400043E RID: 1086
	public QuaternionSerializer rot;

	// Token: 0x0400043F RID: 1087
	public bool isBoxed;

	// Token: 0x04000440 RID: 1088
	public Vector3Serializer boxedPackagePos;

	// Token: 0x04000441 RID: 1089
	public QuaternionSerializer boxedPackageRot;

	// Token: 0x04000442 RID: 1090
	public EObjectType objectType;
}
