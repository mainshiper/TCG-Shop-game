﻿using System;

// Token: 0x02000062 RID: 98
[Serializable]
public struct GameReportDataCollect
{
	// Token: 0x06000449 RID: 1097 RVA: 0x0002588C File Offset: 0x00023A8C
	public void CopyData(GameReportDataCollect data)
	{
		this.customerVisited = data.customerVisited;
		this.checkoutCount = data.checkoutCount;
		this.customerDisatisfied = data.customerDisatisfied;
		this.customerBoughtItem = data.customerBoughtItem;
		this.customerBoughtCard = data.customerBoughtCard;
		this.customerPlayed = data.customerPlayed;
		this.storeExpGained = data.storeExpGained;
		this.storeLevelGained = data.storeLevelGained;
		this.itemAmountSold = data.itemAmountSold;
		this.cardAmountSold = data.cardAmountSold;
		this.totalPlayTableTime = data.totalPlayTableTime;
		this.totalItemEarning = data.totalItemEarning;
		this.totalCardEarning = data.totalCardEarning;
		this.totalPlayTableEarning = data.totalPlayTableEarning;
		this.supplyCost = data.supplyCost;
		this.upgradeCost = data.upgradeCost;
		this.employeeCost = data.employeeCost;
		this.rentCost = data.rentCost;
		this.billCost = data.billCost;
		this.cardPackOpened = data.cardPackOpened;
		this.smellyCustomerCleaned = data.smellyCustomerCleaned;
		this.manualCheckoutCount = data.manualCheckoutCount;
	}

	// Token: 0x0600044A RID: 1098 RVA: 0x000259A4 File Offset: 0x00023BA4
	public void ResetData()
	{
		this.customerVisited = 0;
		this.checkoutCount = 0;
		this.customerDisatisfied = 0;
		this.customerBoughtItem = 0;
		this.customerBoughtCard = 0;
		this.customerPlayed = 0;
		this.storeExpGained = 0;
		this.storeLevelGained = 0;
		this.itemAmountSold = 0;
		this.cardAmountSold = 0;
		this.totalPlayTableTime = 0f;
		this.totalItemEarning = 0f;
		this.totalCardEarning = 0f;
		this.totalPlayTableEarning = 0f;
		this.supplyCost = 0f;
		this.upgradeCost = 0f;
		this.employeeCost = 0f;
		this.rentCost = 0f;
		this.billCost = 0f;
		this.cardPackOpened = 0;
		this.smellyCustomerCleaned = 0;
		this.manualCheckoutCount = 0;
	}

	// Token: 0x04000521 RID: 1313
	public int customerVisited;

	// Token: 0x04000522 RID: 1314
	public int checkoutCount;

	// Token: 0x04000523 RID: 1315
	public int customerDisatisfied;

	// Token: 0x04000524 RID: 1316
	public int customerBoughtItem;

	// Token: 0x04000525 RID: 1317
	public int customerBoughtCard;

	// Token: 0x04000526 RID: 1318
	public int customerPlayed;

	// Token: 0x04000527 RID: 1319
	public int storeExpGained;

	// Token: 0x04000528 RID: 1320
	public int storeLevelGained;

	// Token: 0x04000529 RID: 1321
	public int itemAmountSold;

	// Token: 0x0400052A RID: 1322
	public int cardAmountSold;

	// Token: 0x0400052B RID: 1323
	public float totalPlayTableTime;

	// Token: 0x0400052C RID: 1324
	public float totalItemEarning;

	// Token: 0x0400052D RID: 1325
	public float totalCardEarning;

	// Token: 0x0400052E RID: 1326
	public float totalPlayTableEarning;

	// Token: 0x0400052F RID: 1327
	public float supplyCost;

	// Token: 0x04000530 RID: 1328
	public float upgradeCost;

	// Token: 0x04000531 RID: 1329
	public float employeeCost;

	// Token: 0x04000532 RID: 1330
	public float rentCost;

	// Token: 0x04000533 RID: 1331
	public float billCost;

	// Token: 0x04000534 RID: 1332
	public int cardPackOpened;

	// Token: 0x04000535 RID: 1333
	public int smellyCustomerCleaned;

	// Token: 0x04000536 RID: 1334
	public int manualCheckoutCount;
}
