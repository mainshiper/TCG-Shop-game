﻿using System;
using UnityEngine;

// Token: 0x02000117 RID: 279
[Serializable]
public class KeybindBaseKey
{
	// Token: 0x04000F9A RID: 3994
	public EGameBaseKey baseKey;

	// Token: 0x04000F9B RID: 3995
	public KeyCode bindKey;
}
