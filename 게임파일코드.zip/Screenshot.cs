﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000122 RID: 290
public class Screenshot : MonoBehaviour
{
	// Token: 0x0600087A RID: 2170 RVA: 0x000400E0 File Offset: 0x0003E2E0
	protected static string SaveImageToGallery(Texture2D a_Texture, string a_Title, string a_Description)
	{
		string result;
		using (AndroidJavaClass androidJavaClass = new AndroidJavaClass("android.provider.MediaStore$Images$Media"))
		{
			using (AndroidJavaObject androidJavaObject = Screenshot.Activity.Call<AndroidJavaObject>("getContentResolver", Array.Empty<object>()))
			{
				AndroidJavaObject androidJavaObject2 = Screenshot.Texture2DToAndroidBitmap(a_Texture);
				result = androidJavaClass.CallStatic<string>("insertImage", new object[]
				{
					androidJavaObject,
					androidJavaObject2,
					a_Title,
					a_Description
				});
			}
		}
		return result;
	}

	// Token: 0x0600087B RID: 2171 RVA: 0x0004016C File Offset: 0x0003E36C
	protected static AndroidJavaObject Texture2DToAndroidBitmap(Texture2D a_Texture)
	{
		byte[] array = ImageConversion.EncodeToPNG(a_Texture);
		AndroidJavaObject result;
		using (AndroidJavaClass androidJavaClass = new AndroidJavaClass("android.graphics.BitmapFactory"))
		{
			result = androidJavaClass.CallStatic<AndroidJavaObject>("decodeByteArray", new object[]
			{
				array,
				0,
				array.Length
			});
		}
		return result;
	}

	// Token: 0x17000034 RID: 52
	// (get) Token: 0x0600087C RID: 2172 RVA: 0x000401D4 File Offset: 0x0003E3D4
	protected static AndroidJavaObject Activity
	{
		get
		{
			if (Screenshot.m_Activity == null)
			{
				Screenshot.m_Activity = new AndroidJavaClass("com.unity3d.player.UnityPlayer").GetStatic<AndroidJavaObject>("currentActivity");
			}
			return Screenshot.m_Activity;
		}
	}

	// Token: 0x0600087D RID: 2173 RVA: 0x000401FB File Offset: 0x0003E3FB
	public void CaptureScreenshot()
	{
	}

	// Token: 0x0600087E RID: 2174 RVA: 0x000401FD File Offset: 0x0003E3FD
	private IEnumerator CaptureScreenshotCoroutine(int width, int height)
	{
		yield return new WaitForEndOfFrame();
		Texture2D tex = new Texture2D(width, height);
		tex.ReadPixels(new Rect(0f, 0f, (float)width, (float)height), 0, 0);
		tex.Apply();
		yield return tex;
		string str = Screenshot.SaveImageToGallery(tex, "Name", "Description");
		Debug.Log("Picture has been saved at:\n" + str);
		yield break;
	}

	// Token: 0x04001051 RID: 4177
	protected const string MEDIA_STORE_IMAGE_MEDIA = "android.provider.MediaStore$Images$Media";

	// Token: 0x04001052 RID: 4178
	protected static AndroidJavaObject m_Activity;
}
