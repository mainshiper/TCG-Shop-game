﻿using System;

// Token: 0x02000118 RID: 280
[Serializable]
public class KeybindBaseGamepadControl
{
	// Token: 0x04000F9C RID: 3996
	public EGameBaseKey baseKey;

	// Token: 0x04000F9D RID: 3997
	public EGamepadControlBtn ctrlBtn;
}
