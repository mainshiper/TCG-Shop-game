﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200008D RID: 141
public class UnlockRoomManager : CSingleton<UnlockRoomManager>
{
	// Token: 0x06000588 RID: 1416 RVA: 0x0002E468 File Offset: 0x0002C668
	private void Init()
	{
		for (int i = 0; i < this.m_GlassDoorGrpList.Count; i++)
		{
			this.m_GlassDoorGrpList[i].SetActive(false);
		}
		for (int j = 0; j < CPlayerData.m_UnlockRoomCount; j++)
		{
			this.SetRoomBlockerVisibility(j, false);
			this.EvaluateGlassDoorVisibility(false, j);
		}
		this.SetUnlockWarehouseRoom(CPlayerData.m_IsWarehouseRoomUnlocked);
		for (int k = 0; k < CPlayerData.m_UnlockWarehouseRoomCount; k++)
		{
			this.SetWarehouseRoomBlockerVisibility(k, false);
		}
		this.EvaluateWarehouseRoomOpenClose();
	}

	// Token: 0x06000589 RID: 1417 RVA: 0x0002E4E8 File Offset: 0x0002C6E8
	public void SetUnlockWarehouseRoom(bool isUnlocked)
	{
		CPlayerData.m_IsWarehouseRoomUnlocked = isUnlocked;
		for (int i = 0; i < this.m_WarehouseRoomUnlockHideList.Count; i++)
		{
			this.m_WarehouseRoomUnlockHideList[i].SetActive(!isUnlocked);
		}
		for (int j = 0; j < this.m_WarehouseRoomUnlockShowList.Count; j++)
		{
			this.m_WarehouseRoomUnlockShowList[j].SetActive(isUnlocked);
		}
		this.EvaluateWarehouseRoomOpenClose();
	}

	// Token: 0x0600058A RID: 1418 RVA: 0x0002E554 File Offset: 0x0002C754
	public void StartUnlockNextRoom()
	{
		if (CPlayerData.m_UnlockRoomCount >= this.m_LockedRoomBlockerList.Count)
		{
			return;
		}
		this.m_LockedRoomBlockerList[CPlayerData.m_UnlockRoomCount].HideBlocker();
		this.EvaluateGlassDoorVisibility(true, CPlayerData.m_UnlockRoomCount);
		CPlayerData.m_UnlockRoomCount++;
		CEventManager.QueueEvent(new CEventPlayer_NewRoomUnlocked());
		AchievementManager.OnUnlockShopExpansion(CPlayerData.m_UnlockRoomCount);
		UnityAnalytic.UnlockNewRoom(CPlayerData.m_UnlockRoomCount);
	}

	// Token: 0x0600058B RID: 1419 RVA: 0x0002E5BF File Offset: 0x0002C7BF
	private void SetRoomBlockerVisibility(int index, bool isVisible)
	{
		this.m_LockedRoomBlockerList[index].gameObject.SetActive(isVisible);
	}

	// Token: 0x0600058C RID: 1420 RVA: 0x0002E5D8 File Offset: 0x0002C7D8
	public void StartUnlockNextWarehouseRoom()
	{
		if (CPlayerData.m_UnlockWarehouseRoomCount >= this.m_LockedWarehouseRoomBlockerList.Count)
		{
			return;
		}
		this.m_LockedWarehouseRoomBlockerList[CPlayerData.m_UnlockWarehouseRoomCount].HideBlocker();
		CPlayerData.m_UnlockWarehouseRoomCount++;
		CEventManager.QueueEvent(new CEventPlayer_NewRoomUnlocked());
	}

	// Token: 0x0600058D RID: 1421 RVA: 0x0002E618 File Offset: 0x0002C818
	private void SetWarehouseRoomBlockerVisibility(int index, bool isVisible)
	{
		this.m_LockedWarehouseRoomBlockerList[index].gameObject.SetActive(isVisible);
	}

	// Token: 0x0600058E RID: 1422 RVA: 0x0002E634 File Offset: 0x0002C834
	private void EvaluateGlassDoorVisibility(bool playAnim, int index)
	{
		if (index % 4 == 0)
		{
			int index2 = index / 4;
			if (playAnim)
			{
				this.m_GlassDoorGrpList[index2].SetActive(true);
				this.m_GlassDoorAnimList[index2].Play();
				return;
			}
			this.m_GlassDoorGrpList[index2].SetActive(true);
		}
	}

	// Token: 0x0600058F RID: 1423 RVA: 0x0002E684 File Offset: 0x0002C884
	public void EvaluateWarehouseRoomOpenClose()
	{
		this.m_WarehouseNoEntrySign.SetActive(CPlayerData.m_IsWarehouseRoomUnlocked);
		this.m_WarehouseNoEntryGrp.SetActive(CPlayerData.m_IsWarehouseDoorClosed && CPlayerData.m_IsWarehouseRoomUnlocked);
	}

	// Token: 0x06000590 RID: 1424 RVA: 0x0002E6B0 File Offset: 0x0002C8B0
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x06000591 RID: 1425 RVA: 0x0002E6D1 File Offset: 0x0002C8D1
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x06000592 RID: 1426 RVA: 0x0002E6F2 File Offset: 0x0002C8F2
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.Init();
	}

	// Token: 0x0400072E RID: 1838
	public List<GameObject> m_WarehouseRoomUnlockHideList;

	// Token: 0x0400072F RID: 1839
	public List<GameObject> m_WarehouseRoomUnlockShowList;

	// Token: 0x04000730 RID: 1840
	public List<GameObject> m_GlassDoorGrpList;

	// Token: 0x04000731 RID: 1841
	public List<Animation> m_GlassDoorAnimList;

	// Token: 0x04000732 RID: 1842
	public List<LockedRoomBlocker> m_LockedRoomBlockerList;

	// Token: 0x04000733 RID: 1843
	public List<LockedRoomBlocker> m_LockedWarehouseRoomBlockerList;

	// Token: 0x04000734 RID: 1844
	public GameObject m_WarehouseNoEntryGrp;

	// Token: 0x04000735 RID: 1845
	public GameObject m_WarehouseNoEntrySign;
}
