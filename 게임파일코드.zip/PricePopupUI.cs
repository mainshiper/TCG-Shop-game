﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000042 RID: 66
public class PricePopupUI : MonoBehaviour
{
	// Token: 0x0600032B RID: 811 RVA: 0x0001D9FF File Offset: 0x0001BBFF
	public void Init()
	{
		this.m_Transform = base.transform;
	}

	// Token: 0x0600032C RID: 812 RVA: 0x0001DA0D File Offset: 0x0001BC0D
	public void SetFollowTransform(Transform follow, float offsetUp)
	{
		this.m_FollowTransform = follow;
		this.m_OffsetUp = offsetUp;
	}

	// Token: 0x040003D7 RID: 983
	public Transform m_Transform;

	// Token: 0x040003D8 RID: 984
	public Transform m_FollowTransform;

	// Token: 0x040003D9 RID: 985
	public TextMeshProUGUI m_Text;

	// Token: 0x040003DA RID: 986
	public float m_OffsetUp;
}
