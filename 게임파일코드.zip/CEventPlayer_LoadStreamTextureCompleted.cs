﻿using System;

// Token: 0x020000D2 RID: 210
public class CEventPlayer_LoadStreamTextureCompleted : CEvent
{
	// Token: 0x1700002E RID: 46
	// (get) Token: 0x06000761 RID: 1889 RVA: 0x000396BB File Offset: 0x000378BB
	// (set) Token: 0x06000762 RID: 1890 RVA: 0x000396C3 File Offset: 0x000378C3
	public bool m_IsSuccess { get; private set; }

	// Token: 0x1700002F RID: 47
	// (get) Token: 0x06000763 RID: 1891 RVA: 0x000396CC File Offset: 0x000378CC
	// (set) Token: 0x06000764 RID: 1892 RVA: 0x000396D4 File Offset: 0x000378D4
	public string m_FileName { get; private set; }

	// Token: 0x06000765 RID: 1893 RVA: 0x000396DD File Offset: 0x000378DD
	public CEventPlayer_LoadStreamTextureCompleted(bool isSuccess, string fileName)
	{
		this.m_IsSuccess = isSuccess;
		this.m_FileName = fileName;
	}
}
