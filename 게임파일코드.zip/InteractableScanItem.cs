﻿using System;
using UnityEngine;

// Token: 0x02000028 RID: 40
public class InteractableScanItem : InteractableObject
{
	// Token: 0x06000223 RID: 547 RVA: 0x000153A8 File Offset: 0x000135A8
	public override void OnMouseButtonUp()
	{
		this.m_Item.m_Collider.enabled = false;
		this.m_Item.m_Rigidbody.isKinematic = true;
		this.m_CurrentCustomer.OnItemScanned(this.m_Item);
		this.m_CurrentCustomer = null;
		base.LerpToTransform(this.m_ScannedItemLerpPos, this.m_ScannedItemLerpPos);
		base.SetHideItemAfterFinishLerp();
	}

	// Token: 0x06000224 RID: 548 RVA: 0x00015407 File Offset: 0x00013607
	public void RegisterScanItem(Customer customer, Transform scannedItemLerpPos)
	{
		this.m_CurrentCustomer = customer;
		this.m_ScannedItemLerpPos = scannedItemLerpPos;
	}

	// Token: 0x06000225 RID: 549 RVA: 0x00015417 File Offset: 0x00013617
	public bool IsNotScanned()
	{
		return this.m_CurrentCustomer;
	}

	// Token: 0x04000269 RID: 617
	public Item m_Item;

	// Token: 0x0400026A RID: 618
	private Customer m_CurrentCustomer;

	// Token: 0x0400026B RID: 619
	private Transform m_ScannedItemLerpPos;
}
