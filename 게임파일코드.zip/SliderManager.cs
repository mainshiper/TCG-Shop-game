﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000128 RID: 296
public class SliderManager : MonoBehaviour
{
	// Token: 0x060008B4 RID: 2228 RVA: 0x00040F11 File Offset: 0x0003F111
	private void Awake()
	{
		this.m_LerpSlider = this.m_Slider.GetComponent<LerpSlider>();
		this.m_PreviousBtnSetIndex = this.m_CurrentBtnSetIndex;
	}

	// Token: 0x060008B5 RID: 2229 RVA: 0x00040F30 File Offset: 0x0003F130
	private void Start()
	{
		this.m_SliderStartPos = this.m_Slider.transform.localPosition;
		this.EvaluateScrollerPosition();
	}

	// Token: 0x060008B6 RID: 2230 RVA: 0x00040F4E File Offset: 0x0003F14E
	private IEnumerator DelayEnable()
	{
		this.m_IsEnabled = false;
		this.m_IsMouseDown = false;
		yield return new WaitForSeconds(0.1f);
		this.m_IsEnabled = true;
		this.m_IsMouseDown = false;
		yield break;
	}

	// Token: 0x060008B7 RID: 2231 RVA: 0x00040F5D File Offset: 0x0003F15D
	private void Update()
	{
		this.EvaluateMouseSlider();
	}

	// Token: 0x060008B8 RID: 2232 RVA: 0x00040F68 File Offset: 0x0003F168
	private void EvaluateMouseSlider()
	{
		if (!this.m_Slider.activeSelf)
		{
			return;
		}
		if (!this.m_IsEnabled)
		{
			return;
		}
		if (InputManager.GetKeyDownAction(EGameAction.InteractLeft))
		{
			this.m_MouseStartPos = Input.mousePosition;
			this.m_MouseFirstStartPos = this.m_MouseStartPos;
			this.m_IsMouseDown = true;
		}
		if (Input.GetMouseButtonUp(0))
		{
			this.m_IsMouseDown = false;
			this.EvaluateScrollerPosition();
		}
		if (this.m_IsMouseDown)
		{
			float num = Input.mousePosition.x - this.m_MouseStartPos.x;
			float num2 = this.m_Slider.transform.localPosition.x + num * 1.5f;
			float num3 = Input.mousePosition.y - this.m_MouseStartPos.y;
			float num4 = this.m_Slider.transform.localPosition.y + num3 * 1.5f;
			if (this.m_ScrollYAxis)
			{
				this.m_MaxScrollY = (float)(this.m_MaxItemInABox - 1) * this.m_ScrollButtonOffsetY;
				num4 = Mathf.Clamp(num4, this.m_InitPosY, this.m_MaxScrollY);
				this.m_Slider.transform.localPosition = new Vector3(this.m_SliderStartPos.x, num4, 0f);
				this.m_LerpSlider.SetLerpPosY(num4);
				this.m_MouseStartPos = Input.mousePosition;
				if (num3 > 0f)
				{
					this.m_CurrentBtnSetIndex = Mathf.CeilToInt((num4 - this.m_ScrollButtonOffsetY * 0.1f) / this.m_ScrollButtonOffsetY);
				}
				else
				{
					this.m_CurrentBtnSetIndex = Mathf.CeilToInt((num4 - this.m_ScrollButtonOffsetY * 0.9f) / this.m_ScrollButtonOffsetY);
				}
			}
			else
			{
				this.m_MaxScrollX = (float)(this.m_MaxItemInABox - 1) * -this.m_ScrollButtonOffsetX;
				num2 = Mathf.Clamp(num2, this.m_MaxScrollX, 0f);
				this.m_Slider.transform.localPosition = new Vector3(num2, this.m_SliderStartPos.y, 0f);
				this.m_LerpSlider.SetLerpPos(num2);
				this.m_MouseStartPos = Input.mousePosition;
				if (num > 0f)
				{
					this.m_CurrentBtnSetIndex = Mathf.CeilToInt((num2 - this.m_ScrollButtonOffsetX * 0.1f) / this.m_ScrollButtonOffsetX) * -1;
				}
				else
				{
					this.m_CurrentBtnSetIndex = Mathf.CeilToInt((num2 - this.m_ScrollButtonOffsetX * 0.9f) / this.m_ScrollButtonOffsetX) * -1;
				}
			}
			if (this.m_CurrentBtnSetIndex != this.m_PreviousBtnSetIndex)
			{
				this.m_PreviousBtnSetIndex = this.m_CurrentBtnSetIndex;
			}
		}
	}

	// Token: 0x060008B9 RID: 2233 RVA: 0x000411E0 File Offset: 0x0003F3E0
	private void EvaluateScrollerPosition()
	{
		if (this.m_ScrollYAxis)
		{
			float lerpPosY = -this.m_ScrollItemOffsetY * (float)this.m_CurrentBtnSetIndex;
			lerpPosY = this.m_ScrollButtonOffsetY * (float)this.m_CurrentBtnSetIndex;
			this.m_LerpSlider.SetLerpPosY(lerpPosY);
			return;
		}
		float lerpPos = -this.m_ScrollItemOffsetX * (float)this.m_CurrentBtnSetIndex;
		lerpPos = -this.m_ScrollButtonOffsetX * (float)this.m_CurrentBtnSetIndex;
		this.m_LerpSlider.SetLerpPos(lerpPos);
	}

	// Token: 0x060008BA RID: 2234 RVA: 0x0004124D File Offset: 0x0003F44D
	private void EvaluateItemSliderChanged()
	{
	}

	// Token: 0x060008BB RID: 2235 RVA: 0x0004124F File Offset: 0x0003F44F
	private void OnEnable()
	{
		base.StartCoroutine(this.DelayEnable());
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_TouchScreen>(new CEventManager.EventDelegate<CEventPlayer_TouchScreen>(this.CPlayer_OnTouchScreen));
		}
	}

	// Token: 0x060008BC RID: 2236 RVA: 0x0004127D File Offset: 0x0003F47D
	private void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_TouchScreen>(new CEventManager.EventDelegate<CEventPlayer_TouchScreen>(this.CPlayer_OnTouchScreen));
		}
	}

	// Token: 0x060008BD RID: 2237 RVA: 0x0004129E File Offset: 0x0003F49E
	private void CPlayer_OnTouchScreen(CEventPlayer_TouchScreen evt)
	{
	}

	// Token: 0x0400108B RID: 4235
	public bool m_ScrollYAxis = true;

	// Token: 0x0400108C RID: 4236
	private float m_ScrollItemOffsetX = 0.4f;

	// Token: 0x0400108D RID: 4237
	public float m_ScrollButtonOffsetX = 1800f;

	// Token: 0x0400108E RID: 4238
	private float m_ScrollItemOffsetY = 0.4f;

	// Token: 0x0400108F RID: 4239
	public float m_ScrollButtonOffsetY = 800f;

	// Token: 0x04001090 RID: 4240
	public float m_InitPosY = -50f;

	// Token: 0x04001091 RID: 4241
	public int m_CurrentItemIndex;

	// Token: 0x04001092 RID: 4242
	public int m_CurrentBtnSetIndex;

	// Token: 0x04001093 RID: 4243
	private int m_PreviousBtnSetIndex;

	// Token: 0x04001094 RID: 4244
	private int m_PreviousItemIndex;

	// Token: 0x04001095 RID: 4245
	private float m_MaxScrollX;

	// Token: 0x04001096 RID: 4246
	private float m_MaxScrollY;

	// Token: 0x04001097 RID: 4247
	private bool m_IsMouseDown;

	// Token: 0x04001098 RID: 4248
	private bool m_IsSwiping;

	// Token: 0x04001099 RID: 4249
	private Vector2 m_MouseStartPos;

	// Token: 0x0400109A RID: 4250
	private Vector2 m_MouseFirstStartPos;

	// Token: 0x0400109B RID: 4251
	public GameObject m_Slider;

	// Token: 0x0400109C RID: 4252
	private LerpSlider m_LerpSlider;

	// Token: 0x0400109D RID: 4253
	private Vector3 m_SliderStartPos;

	// Token: 0x0400109E RID: 4254
	public int m_MaxItemInABox = 12;

	// Token: 0x0400109F RID: 4255
	private bool m_IsEnabled;
}
