﻿using System;
using I2.Loc;

// Token: 0x02000119 RID: 281
[Serializable]
public class GameActionBaseKeyData
{
	// Token: 0x06000830 RID: 2096 RVA: 0x0003D8BA File Offset: 0x0003BABA
	public string GetName()
	{
		return LocalizationManager.GetTranslation(this.actionName, true, 0, true, false, null, null, true);
	}

	// Token: 0x04000F9E RID: 3998
	public string actionName;

	// Token: 0x04000F9F RID: 3999
	public EGameAction gameAction;

	// Token: 0x04000FA0 RID: 4000
	public EGameBaseKey baseKey;
}
