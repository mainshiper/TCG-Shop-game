﻿using System;

// Token: 0x020000FE RID: 254
public enum ECurrencyType
{
	// Token: 0x04000EB2 RID: 3762
	Gold,
	// Token: 0x04000EB3 RID: 3763
	Gem,
	// Token: 0x04000EB4 RID: 3764
	FamePoint
}
