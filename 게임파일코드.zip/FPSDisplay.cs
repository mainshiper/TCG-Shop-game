﻿using System;
using UnityEngine;

// Token: 0x02000105 RID: 261
public class FPSDisplay : MonoBehaviour
{
	// Token: 0x060007B2 RID: 1970 RVA: 0x0003A87B File Offset: 0x00038A7B
	private void Update()
	{
		this.deltaTime += (Time.deltaTime - this.deltaTime) * 0.1f;
	}

	// Token: 0x060007B3 RID: 1971 RVA: 0x0003A89C File Offset: 0x00038A9C
	private void OnGUI()
	{
		int width = Screen.width;
		int height = Screen.height;
		GUIStyle guistyle = new GUIStyle();
		Rect rect = new Rect(250f, 550f, (float)width, (float)(height * 2 / 100));
		guistyle.alignment = 0;
		guistyle.fontSize = height * 4 / 100;
		guistyle.normal.textColor = new Color(0f, 1f, 0f, 1f);
		float num = this.deltaTime * 1000f;
		float num2 = 1f / this.deltaTime;
		string text = string.Format("{0:0.0} ms ({1:0.} fps)", num, num2);
		GUI.Label(rect, text, guistyle);
	}

	// Token: 0x04000EF8 RID: 3832
	private float deltaTime;
}
