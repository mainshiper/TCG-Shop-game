﻿using System;
using UnityEngine;

// Token: 0x02000075 RID: 117
public class RestockCategoryBar : MonoBehaviour
{
	// Token: 0x060004C3 RID: 1219 RVA: 0x00029CC9 File Offset: 0x00027EC9
	public void OnPressWebsite()
	{
		Application.OpenURL(this.m_URL);
	}

	// Token: 0x04000635 RID: 1589
	public string m_URL;
}
