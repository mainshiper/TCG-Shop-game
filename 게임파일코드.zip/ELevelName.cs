﻿using System;

// Token: 0x020000D7 RID: 215
public enum ELevelName
{
	// Token: 0x0400099A RID: 2458
	Start
}
