﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000058 RID: 88
public class CardExpansionSelectScreen : CSingleton<CardExpansionSelectScreen>
{
	// Token: 0x060003FD RID: 1021 RVA: 0x00023E84 File Offset: 0x00022084
	public static void OpenScreen(ECardExpansionType initCardExpansion)
	{
		CSingleton<CardExpansionSelectScreen>.Instance.m_CurrentIndex = (int)initCardExpansion;
		for (int i = 0; i < CSingleton<CardExpansionSelectScreen>.Instance.m_BtnHighlightList.Count; i++)
		{
			CSingleton<CardExpansionSelectScreen>.Instance.m_BtnHighlightList[i].SetActive(false);
		}
		CSingleton<CardExpansionSelectScreen>.Instance.m_BtnHighlightList[CSingleton<CardExpansionSelectScreen>.Instance.m_CurrentIndex].SetActive(true);
		SoundManager.GenericMenuOpen(1f, 1f);
		CSingleton<CardExpansionSelectScreen>.Instance.m_ScreenGrp.SetActive(true);
		ControllerScreenUIExtManager.OnOpenScreen(CSingleton<CardExpansionSelectScreen>.Instance.m_ControllerScreenUIExtension);
	}

	// Token: 0x060003FE RID: 1022 RVA: 0x00023F19 File Offset: 0x00022119
	private void CloseScreen()
	{
		this.m_ScreenGrp.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<CardExpansionSelectScreen>.Instance.m_ControllerScreenUIExtension);
	}

	// Token: 0x060003FF RID: 1023 RVA: 0x00023F36 File Offset: 0x00022136
	public void OnPressButton(int index)
	{
		this.m_CurrentIndex = index;
		CEventManager.QueueEvent(new CEventPlayer_OnCardExpansionSelectScreenUpdated(index));
		this.CloseScreen();
		SoundManager.GenericConfirm(1f, 1f);
	}

	// Token: 0x06000400 RID: 1024 RVA: 0x00023F5F File Offset: 0x0002215F
	public void OnPressBackButton()
	{
		CEventManager.QueueEvent(new CEventPlayer_OnCardExpansionSelectScreenUpdated(this.m_CurrentIndex));
		this.CloseScreen();
		SoundManager.GenericMenuClose(1f, 1f);
	}

	// Token: 0x040004D1 RID: 1233
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x040004D2 RID: 1234
	public GameObject m_ScreenGrp;

	// Token: 0x040004D3 RID: 1235
	public List<GameObject> m_BtnHighlightList;

	// Token: 0x040004D4 RID: 1236
	private int m_CurrentIndex;
}
