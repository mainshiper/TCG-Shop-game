﻿using System;
using UnityEngine;

// Token: 0x0200001F RID: 31
public class InteractableCustomerCash : InteractableObject
{
	// Token: 0x0600017D RID: 381 RVA: 0x000125CD File Offset: 0x000107CD
	public void Init(Customer customer)
	{
		this.m_CurrentCustomer = customer;
	}

	// Token: 0x0600017E RID: 382 RVA: 0x000125D8 File Offset: 0x000107D8
	public void SetIsCard(bool isCard)
	{
		this.m_IsCard = isCard;
		this.m_CashModel.SetActive(!this.m_IsCard);
		this.m_CardModel.SetActive(this.m_IsCard);
		this.m_CashOutlineModel.SetActive(!this.m_IsCard);
		this.m_CardOutlineModel.SetActive(this.m_IsCard);
		if (!this.m_IsCard && this.m_CurrentCurrencyType != CSingleton<CGameManager>.Instance.m_CurrencyType)
		{
			this.m_CurrentCurrencyType = CSingleton<CGameManager>.Instance.m_CurrencyType;
			this.m_CashMeshRender.material = InventoryBase.GetCurrencyMaterial(this.m_CurrentCurrencyType);
		}
	}

	// Token: 0x0600017F RID: 383 RVA: 0x00012676 File Offset: 0x00010876
	public override void OnMouseButtonUp()
	{
		this.m_CurrentCustomer.OnCashTaken(this.m_IsCard);
	}

	// Token: 0x06000180 RID: 384 RVA: 0x00012689 File Offset: 0x00010889
	protected virtual void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x06000181 RID: 385 RVA: 0x000126AA File Offset: 0x000108AA
	protected virtual void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x06000182 RID: 386 RVA: 0x000126CB File Offset: 0x000108CB
	protected void OnMoneyCurrencyUpdated(CEventPlayer_OnMoneyCurrencyUpdated evt)
	{
		if (!this.m_IsCard)
		{
			this.SetIsCard(false);
		}
	}

	// Token: 0x040001F7 RID: 503
	public bool m_IsCard;

	// Token: 0x040001F8 RID: 504
	public GameObject m_CashModel;

	// Token: 0x040001F9 RID: 505
	public GameObject m_CardModel;

	// Token: 0x040001FA RID: 506
	public GameObject m_CashOutlineModel;

	// Token: 0x040001FB RID: 507
	public GameObject m_CardOutlineModel;

	// Token: 0x040001FC RID: 508
	public MeshRenderer m_CashMeshRender;

	// Token: 0x040001FD RID: 509
	private Customer m_CurrentCustomer;

	// Token: 0x040001FE RID: 510
	private EMoneyCurrencyType m_CurrentCurrencyType;
}
