﻿using System;

// Token: 0x02000050 RID: 80
[Serializable]
public class PackageBoxItemaveData
{
	// Token: 0x04000471 RID: 1137
	public ItemTypeAmount itemTypeAmount;

	// Token: 0x04000472 RID: 1138
	public bool isBigBox;

	// Token: 0x04000473 RID: 1139
	public bool isStored;

	// Token: 0x04000474 RID: 1140
	public int storedWarehouseShelfIndex;

	// Token: 0x04000475 RID: 1141
	public int storageCompartmentIndex;

	// Token: 0x04000476 RID: 1142
	public Vector3Serializer pos;

	// Token: 0x04000477 RID: 1143
	public QuaternionSerializer rot;
}
