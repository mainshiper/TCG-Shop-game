﻿using System;
using UnityEngine;

// Token: 0x02000129 RID: 297
public class TouchDragUI : MonoBehaviour
{
	// Token: 0x060008BF RID: 2239 RVA: 0x000412F9 File Offset: 0x0003F4F9
	private void Awake()
	{
		this.m_StartDragIconGrp.SetActive(false);
		this.m_CurrentDragIconImage.SetActive(false);
		this.m_LineRendererIcon.SetActive(false);
	}

	// Token: 0x060008C0 RID: 2240 RVA: 0x0004131F File Offset: 0x0003F51F
	private void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_TouchReleased>(new CEventManager.EventDelegate<CEventPlayer_TouchReleased>(this.CPlayer_OnTouchReleased));
			CEventManager.AddListener<CEventPlayer_TouchScreen>(new CEventManager.EventDelegate<CEventPlayer_TouchScreen>(this.CPlayer_OnTouchScreen));
		}
	}

	// Token: 0x060008C1 RID: 2241 RVA: 0x00041351 File Offset: 0x0003F551
	private void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_TouchReleased>(new CEventManager.EventDelegate<CEventPlayer_TouchReleased>(this.CPlayer_OnTouchReleased));
			CEventManager.RemoveListener<CEventPlayer_TouchScreen>(new CEventManager.EventDelegate<CEventPlayer_TouchScreen>(this.CPlayer_OnTouchScreen));
		}
	}

	// Token: 0x060008C2 RID: 2242 RVA: 0x00041383 File Offset: 0x0003F583
	private void CPlayer_OnTouchReleased(CEventPlayer_TouchReleased evt)
	{
		this.m_StartDragIconGrp.SetActive(false);
		this.m_CurrentDragIconImage.SetActive(false);
		this.m_LineRendererIcon.SetActive(false);
	}

	// Token: 0x060008C3 RID: 2243 RVA: 0x000413AC File Offset: 0x0003F5AC
	private void CPlayer_OnTouchScreen(CEventPlayer_TouchScreen evt)
	{
		this.m_StartDragIconGrp.SetActive(true);
		this.m_CurrentDragIconImage.SetActive(true);
		this.m_LineRendererIcon.SetActive(true);
		Vector3 mousePosition = Input.mousePosition;
		mousePosition.z = 2f;
		this.m_StartDragIconGrp.transform.position = Camera.main.ScreenToWorldPoint(mousePosition);
	}

	// Token: 0x040010A0 RID: 4256
	public GameObject m_StartDragIconGrp;

	// Token: 0x040010A1 RID: 4257
	public GameObject m_CurrentDragIconImage;

	// Token: 0x040010A2 RID: 4258
	public GameObject m_CurrentDragIconGrp;

	// Token: 0x040010A3 RID: 4259
	public GameObject m_LineRendererIcon;
}
