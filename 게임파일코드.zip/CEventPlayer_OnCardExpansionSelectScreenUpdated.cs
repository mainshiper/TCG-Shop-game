﻿using System;

// Token: 0x020000C4 RID: 196
public class CEventPlayer_OnCardExpansionSelectScreenUpdated : CEvent
{
	// Token: 0x17000020 RID: 32
	// (get) Token: 0x06000737 RID: 1847 RVA: 0x000394FB File Offset: 0x000376FB
	// (set) Token: 0x06000738 RID: 1848 RVA: 0x00039503 File Offset: 0x00037703
	public int m_CardExpansionTypeIndex { get; private set; }

	// Token: 0x06000739 RID: 1849 RVA: 0x0003950C File Offset: 0x0003770C
	public CEventPlayer_OnCardExpansionSelectScreenUpdated(int cardExpansionTypeIndex)
	{
		this.m_CardExpansionTypeIndex = cardExpansionTypeIndex;
	}
}
