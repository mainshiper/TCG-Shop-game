﻿using System;

// Token: 0x020000C3 RID: 195
public class CEventPlayer_OnMoneyCurrencyUpdated : CEvent
{
}
