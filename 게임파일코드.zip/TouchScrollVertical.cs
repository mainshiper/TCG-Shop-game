﻿using System;
using UnityEngine;

// Token: 0x02000124 RID: 292
public class TouchScrollVertical : MonoBehaviour
{
	// Token: 0x06000890 RID: 2192 RVA: 0x000406D8 File Offset: 0x0003E8D8
	private void OnEnable()
	{
		this.ResetTouch();
	}

	// Token: 0x06000891 RID: 2193 RVA: 0x000406E0 File Offset: 0x0003E8E0
	private void Start()
	{
		this.m_RectTransform = base.GetComponent<RectTransform>();
		if (this.m_ScrollIndicator && this.m_ScrollIndicatorEnd)
		{
			this.m_ScrollIndicatorStartPos = this.m_ScrollIndicator.transform.position;
			this.m_ScrollIndicatorEndPos = this.m_ScrollIndicatorEnd.transform.position;
		}
	}

	// Token: 0x06000892 RID: 2194 RVA: 0x0004073F File Offset: 0x0003E93F
	private void Update()
	{
		this.SwipeDetection();
		this.EvaluateScrollIndicator();
	}

	// Token: 0x06000893 RID: 2195 RVA: 0x0004074D File Offset: 0x0003E94D
	public void SetScrollingNormal()
	{
		this.m_IsScrollingInverse = false;
	}

	// Token: 0x06000894 RID: 2196 RVA: 0x00040756 File Offset: 0x0003E956
	public void SetScrollingInverse()
	{
		this.m_IsScrollingInverse = true;
	}

	// Token: 0x06000895 RID: 2197 RVA: 0x00040760 File Offset: 0x0003E960
	private void EvaluateScrollIndicator()
	{
		if (this.m_ScrollIndicator && this.m_ScrollIndicatorEnd)
		{
			this.m_ScrollIndicatorLerpAlpha = this.m_RectTransform.localPosition.y / this.m_ScrollLimitMinY;
			this.m_ScrollIndicator.transform.position = Vector3.Lerp(this.m_ScrollIndicatorStartPos, this.m_ScrollIndicatorEndPos, this.m_ScrollIndicatorLerpAlpha);
		}
	}

	// Token: 0x06000896 RID: 2198 RVA: 0x000407CB File Offset: 0x0003E9CB
	public void IsMouseDown()
	{
	}

	// Token: 0x06000897 RID: 2199 RVA: 0x000407CD File Offset: 0x0003E9CD
	public void IsMouseUp()
	{
	}

	// Token: 0x06000898 RID: 2200 RVA: 0x000407CF File Offset: 0x0003E9CF
	public void SetScrollLerpPos(float posY)
	{
		this.m_ScrollerLerpPos = new Vector3(0f, posY, 0f);
	}

	// Token: 0x06000899 RID: 2201 RVA: 0x000407E8 File Offset: 0x0003E9E8
	private void SwipeDetection()
	{
		this.m_RectTransform.localPosition = Vector3.Lerp(this.m_RectTransform.localPosition, this.m_ScrollerLerpPos, Time.deltaTime * this.m_ScrollerLerpSpeed);
		if (InputManager.GetKeyDownAction(EGameAction.InteractLeft))
		{
			this.mStartPosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
			this.mSwipeStartTime = Time.time;
			this.m_FingerTouched = true;
		}
		if (this.m_FingerTouched)
		{
			this.m_FingerTouchTime += Time.deltaTime;
		}
		Vector2 vector = new Vector2(Input.mousePosition.x, Input.mousePosition.y) - this.mStartPosition;
		float num = Time.time - this.mSwipeStartTime;
		float num2 = vector.magnitude / num;
		if (this.m_FingerTouchTime > 0.01f && this.m_RectTransform.localPosition.y <= this.m_ScrollLimitMinY && this.m_RectTransform.localPosition.y >= this.m_ScrollLimitMaxY)
		{
			float y;
			if (this.m_IsScrollingInverse)
			{
				y = vector.y * this.m_ScrollSensitivity;
			}
			else
			{
				y = vector.y * this.m_ScrollSensitivity * -1f;
			}
			this.m_ScrollerLerpPos += new Vector3(0f, y, 0f);
			this.mStartPosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
			if (this.m_ScrollerLerpPos.y > this.m_ScrollLimitMinY)
			{
				this.m_ScrollerLerpPos = new Vector3(0f, this.m_ScrollLimitMinY, 0f);
			}
			else if (this.m_ScrollerLerpPos.y < this.m_ScrollLimitMaxY)
			{
				this.m_ScrollerLerpPos = new Vector3(0f, this.m_ScrollLimitMaxY, 0f);
			}
			if (this.m_RectTransform.localPosition.y > this.m_ScrollLimitMinY)
			{
				this.m_RectTransform.localPosition = new Vector3(0f, this.m_ScrollLimitMinY, 0f);
			}
			else if (this.m_RectTransform.localPosition.y < this.m_ScrollLimitMaxY)
			{
				this.m_RectTransform.localPosition = new Vector3(0f, this.m_ScrollLimitMaxY, 0f);
			}
		}
		if (Input.GetMouseButtonUp(0) && this.m_FingerTouched)
		{
			this.m_FingerTouched = false;
			this.m_FingerTouchTime = 0f;
			num = Time.time - this.mSwipeStartTime;
			vector = new Vector2(Input.mousePosition.x, Input.mousePosition.y) - this.mStartPosition;
			if (vector.magnitude / num > 0.1f && vector.magnitude > 0.1f)
			{
				vector.Normalize();
				float num3 = Vector2.Dot(vector, this.mXAxis);
				num3 = Mathf.Acos(num3) * 57.29578f;
				if (num3 < 44f)
				{
					this.OnSwipeRight();
					return;
				}
				if (180f - num3 < 44f)
				{
					this.OnSwipeLeft();
					return;
				}
				num3 = Vector2.Dot(vector, this.mYAxis);
				num3 = Mathf.Acos(num3) * 57.29578f;
				if (num3 < 44f)
				{
					this.OnSwipeTop();
					return;
				}
				if (180f - num3 < 44f)
				{
					this.OnSwipeBottom();
					return;
				}
			}
			else
			{
				this.OnTapDetection();
			}
		}
	}

	// Token: 0x0600089A RID: 2202 RVA: 0x00040B41 File Offset: 0x0003ED41
	private void ResetTouch()
	{
		this.m_FingerTouched = false;
		this.m_FingerTouchTime = 0f;
		this.m_ScrollerLerpPos = new Vector3(0f, 0f, 0f);
	}

	// Token: 0x0600089B RID: 2203 RVA: 0x00040B6F File Offset: 0x0003ED6F
	private void OnTapDetection()
	{
	}

	// Token: 0x0600089C RID: 2204 RVA: 0x00040B71 File Offset: 0x0003ED71
	private void OnSwipeLeft()
	{
	}

	// Token: 0x0600089D RID: 2205 RVA: 0x00040B73 File Offset: 0x0003ED73
	private void OnSwipeRight()
	{
	}

	// Token: 0x0600089E RID: 2206 RVA: 0x00040B75 File Offset: 0x0003ED75
	private void OnSwipeTop()
	{
	}

	// Token: 0x0600089F RID: 2207 RVA: 0x00040B77 File Offset: 0x0003ED77
	private void OnSwipeBottom()
	{
	}

	// Token: 0x04001068 RID: 4200
	public float m_ScrollLimitMinY = 150f;

	// Token: 0x04001069 RID: 4201
	public float m_ScrollLimitMaxY;

	// Token: 0x0400106A RID: 4202
	public float m_ScrollerLerpSpeed = 5f;

	// Token: 0x0400106B RID: 4203
	public float m_ScrollSensitivity = 0.4f;

	// Token: 0x0400106C RID: 4204
	public float m_Inverse = -1f;

	// Token: 0x0400106D RID: 4205
	public GameObject m_ScrollIndicator;

	// Token: 0x0400106E RID: 4206
	public GameObject m_ScrollIndicatorEnd;

	// Token: 0x0400106F RID: 4207
	private Vector3 m_ScrollIndicatorStartPos;

	// Token: 0x04001070 RID: 4208
	private Vector3 m_ScrollIndicatorEndPos;

	// Token: 0x04001071 RID: 4209
	private float m_ScrollIndicatorLerpAlpha;

	// Token: 0x04001072 RID: 4210
	private bool m_IsScrollingInverse = true;

	// Token: 0x04001073 RID: 4211
	private RectTransform m_RectTransform;

	// Token: 0x04001074 RID: 4212
	private Vector3 m_ScrollerLerpPos;

	// Token: 0x04001075 RID: 4213
	private bool m_FingerTouched;

	// Token: 0x04001076 RID: 4214
	private float m_FingerTouchTime;

	// Token: 0x04001077 RID: 4215
	private readonly Vector2 mXAxis = new Vector2(1f, 0f);

	// Token: 0x04001078 RID: 4216
	private readonly Vector2 mYAxis = new Vector2(0f, 1f);

	// Token: 0x04001079 RID: 4217
	private const float mAngleRange = 44f;

	// Token: 0x0400107A RID: 4218
	private const float mMinSwipeDist = 0.1f;

	// Token: 0x0400107B RID: 4219
	private const float mMinVelocity = 0.1f;

	// Token: 0x0400107C RID: 4220
	private Vector2 mStartPosition;

	// Token: 0x0400107D RID: 4221
	private float mSwipeStartTime;
}
