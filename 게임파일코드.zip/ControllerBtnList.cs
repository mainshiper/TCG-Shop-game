﻿using System;
using System.Collections.Generic;

// Token: 0x0200010C RID: 268
[Serializable]
public struct ControllerBtnList
{
	// Token: 0x04000F28 RID: 3880
	public List<ControllerButton> rowList;
}
