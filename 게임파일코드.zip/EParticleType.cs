﻿using System;

// Token: 0x02000099 RID: 153
public enum EParticleType
{
	// Token: 0x040007CF RID: 1999
	ArenaRankUpFirework,
	// Token: 0x040007D0 RID: 2000
	StarStream
}
