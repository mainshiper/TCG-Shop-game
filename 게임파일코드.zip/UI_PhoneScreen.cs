﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200008B RID: 139
public class UI_PhoneScreen : UIScreenBase
{
	// Token: 0x06000573 RID: 1395 RVA: 0x0002E16E File Offset: 0x0002C36E
	protected override void RunUpdate()
	{
		base.RunUpdate();
		this.m_TimeText.text = CSingleton<LightManager>.Instance.m_TimeString;
		this.m_BatteryFill.fillAmount = 1f - CSingleton<LightManager>.Instance.GetPercentTillDayEnd();
	}

	// Token: 0x06000574 RID: 1396 RVA: 0x0002E1A6 File Offset: 0x0002C3A6
	protected override void OnOpenScreen()
	{
		base.OnOpenScreen();
		this.SetPhoneButtonRaycastEnable(true);
		this.m_DayText.text = CSingleton<GameUIScreen>.Instance.m_DayText.text;
	}

	// Token: 0x06000575 RID: 1397 RVA: 0x0002E1CF File Offset: 0x0002C3CF
	protected override void OnCloseScreen()
	{
		base.OnCloseScreen();
		this.SetPhoneButtonRaycastEnable(false);
	}

	// Token: 0x06000576 RID: 1398 RVA: 0x0002E1DE File Offset: 0x0002C3DE
	public void OnPressExitPhoneMode()
	{
		PhoneManager.ExitPhoneMode();
	}

	// Token: 0x06000577 RID: 1399 RVA: 0x0002E1E5 File Offset: 0x0002C3E5
	public void OnPressBuyProductBtn()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.15f, 1f);
		base.OpenChildScreen(CSingleton<PhoneManager>.Instance.m_RestockItemScreen);
		PhoneManager.SetCanClosePhone(false);
		this.SetPhoneButtonRaycastEnable(false);
		UnityAnalytic.PhoneRestock();
	}

	// Token: 0x06000578 RID: 1400 RVA: 0x0002E21D File Offset: 0x0002C41D
	public void OnPressBuyBoardGameProductBtn()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.15f, 1f);
		base.OpenChildScreen(CSingleton<PhoneManager>.Instance.m_RestockItemBoardGameScreen);
		PhoneManager.SetCanClosePhone(false);
		this.SetPhoneButtonRaycastEnable(false);
	}

	// Token: 0x06000579 RID: 1401 RVA: 0x0002E250 File Offset: 0x0002C450
	public void OnPressBuyFurnitureBtn()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.15f, 1f);
		base.OpenChildScreen(CSingleton<PhoneManager>.Instance.m_FurnitureShopUIScreen);
		PhoneManager.SetCanClosePhone(false);
		this.SetPhoneButtonRaycastEnable(false);
		UnityAnalytic.PhoneBuyShelf();
	}

	// Token: 0x0600057A RID: 1402 RVA: 0x0002E288 File Offset: 0x0002C488
	public void OnPressExpandShopBtn()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.15f, 1f);
		base.OpenChildScreen(CSingleton<PhoneManager>.Instance.m_ExpandShopUIScreen);
		PhoneManager.SetCanClosePhone(false);
		this.SetPhoneButtonRaycastEnable(false);
		UnityAnalytic.PhoneShopExpansion();
	}

	// Token: 0x0600057B RID: 1403 RVA: 0x0002E2C0 File Offset: 0x0002C4C0
	public void OnPressSettingBtn()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.15f, 1f);
		SettingScreen.OpenScreen(false);
	}

	// Token: 0x0600057C RID: 1404 RVA: 0x0002E2DC File Offset: 0x0002C4DC
	public void OnPressManageEventBtn()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.15f, 1f);
		base.OpenChildScreen(CSingleton<PhoneManager>.Instance.m_SetGameEventUIScreen);
		PhoneManager.SetCanClosePhone(false);
		this.SetPhoneButtonRaycastEnable(false);
		UnityAnalytic.PhoneManageEvent();
	}

	// Token: 0x0600057D RID: 1405 RVA: 0x0002E314 File Offset: 0x0002C514
	public void OnPressHireWorkerBtn()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.15f, 1f);
		base.OpenChildScreen(CSingleton<PhoneManager>.Instance.m_HireWorkerScreen);
		PhoneManager.SetCanClosePhone(false);
		this.SetPhoneButtonRaycastEnable(false);
		UnityAnalytic.PhoneHireWorker();
	}

	// Token: 0x0600057E RID: 1406 RVA: 0x0002E34C File Offset: 0x0002C54C
	public void OnPressCheckPriceScreenBtn()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.15f, 1f);
		base.OpenChildScreen(CSingleton<PhoneManager>.Instance.m_CheckPriceScreen);
		PhoneManager.SetCanClosePhone(false);
		this.SetPhoneButtonRaycastEnable(false);
		UnityAnalytic.PhoneCheckPrice();
	}

	// Token: 0x0600057F RID: 1407 RVA: 0x0002E384 File Offset: 0x0002C584
	public void OnPressRentBillBtn()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.15f, 1f);
		base.OpenChildScreen(CSingleton<PhoneManager>.Instance.m_RentBillScreen);
		PhoneManager.SetCanClosePhone(false);
		this.SetPhoneButtonRaycastEnable(false);
		UnityAnalytic.PhoneHireWorker();
	}

	// Token: 0x06000580 RID: 1408 RVA: 0x0002E3BC File Offset: 0x0002C5BC
	public void SetBillNotificationVisible(bool isVisible)
	{
		this.m_RentBillNotification.SetActive(isVisible);
	}

	// Token: 0x06000581 RID: 1409 RVA: 0x0002E3CA File Offset: 0x0002C5CA
	protected override void OnChildScreenClosed(UIScreenBase childScreen)
	{
		PhoneManager.SetCanClosePhone(true);
		this.SetPhoneButtonRaycastEnable(true);
	}

	// Token: 0x06000582 RID: 1410 RVA: 0x0002E3DC File Offset: 0x0002C5DC
	private void SetPhoneButtonRaycastEnable(bool isEnable)
	{
		for (int i = 0; i < this.m_PhoneButtonList.Count; i++)
		{
			this.m_PhoneButtonList[i].interactable = isEnable;
		}
	}

	// Token: 0x04000725 RID: 1829
	public TextMeshProUGUI m_TimeText;

	// Token: 0x04000726 RID: 1830
	public TextMeshProUGUI m_DayText;

	// Token: 0x04000727 RID: 1831
	public Image m_BatteryFill;

	// Token: 0x04000728 RID: 1832
	public List<Button> m_PhoneButtonList;

	// Token: 0x04000729 RID: 1833
	public GameObject m_RentBillNotification;
}
