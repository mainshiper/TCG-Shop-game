﻿using System;

// Token: 0x020000D8 RID: 216
public enum EGameState
{
	// Token: 0x0400099C RID: 2460
	DefaultState,
	// Token: 0x0400099D RID: 2461
	HoldingBoxState,
	// Token: 0x0400099E RID: 2462
	HoldingCardState,
	// Token: 0x0400099F RID: 2463
	HoldingItemState,
	// Token: 0x040009A0 RID: 2464
	ViewAlbumState,
	// Token: 0x040009A1 RID: 2465
	MovingObjectState,
	// Token: 0x040009A2 RID: 2466
	CashCounterState,
	// Token: 0x040009A3 RID: 2467
	PhoneState,
	// Token: 0x040009A4 RID: 2468
	OpeningPackState,
	// Token: 0x040009A5 RID: 2469
	HoldSprayState,
	// Token: 0x040009A6 RID: 2470
	WorkerInteractState,
	// Token: 0x040009A7 RID: 2471
	MovingBoxState
}
