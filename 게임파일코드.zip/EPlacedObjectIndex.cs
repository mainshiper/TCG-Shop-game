﻿using System;

// Token: 0x020000DF RID: 223
public enum EPlacedObjectIndex
{
	// Token: 0x04000A68 RID: 2664
	None = -1,
	// Token: 0x04000A69 RID: 2665
	MainCounter,
	// Token: 0x04000A6A RID: 2666
	SmallShelf,
	// Token: 0x04000A6B RID: 2667
	MediumShelf,
	// Token: 0x04000A6C RID: 2668
	LargeShelf,
	// Token: 0x04000A6D RID: 2669
	SmallTable,
	// Token: 0x04000A6E RID: 2670
	LongTable,
	// Token: 0x04000A6F RID: 2671
	VendingMachine,
	// Token: 0x04000A70 RID: 2672
	SmallRack,
	// Token: 0x04000A71 RID: 2673
	MediumTable,
	// Token: 0x04000A72 RID: 2674
	GiantShelf,
	// Token: 0x04000A73 RID: 2675
	SHELFMAX,
	// Token: 0x04000A74 RID: 2676
	Statue_PiggyA = 3000,
	// Token: 0x04000A75 RID: 2677
	Statue_PiggyB,
	// Token: 0x04000A76 RID: 2678
	Statue_PiggyC,
	// Token: 0x04000A77 RID: 2679
	Statue_PiggyD,
	// Token: 0x04000A78 RID: 2680
	TapBooster,
	// Token: 0x04000A79 RID: 2681
	CustomerBuyingPowerBooster,
	// Token: 0x04000A7A RID: 2682
	CustomerBuyAmountBooster,
	// Token: 0x04000A7B RID: 2683
	PackStorage,
	// Token: 0x04000A7C RID: 2684
	Statue_StarfishA,
	// Token: 0x04000A7D RID: 2685
	Statue_StarfishB,
	// Token: 0x04000A7E RID: 2686
	Statue_StarfishC,
	// Token: 0x04000A7F RID: 2687
	Statue_StarfishD,
	// Token: 0x04000A80 RID: 2688
	Statue_GolemA,
	// Token: 0x04000A81 RID: 2689
	Statue_GolemB,
	// Token: 0x04000A82 RID: 2690
	Statue_GolemC,
	// Token: 0x04000A83 RID: 2691
	Statue_GolemD,
	// Token: 0x04000A84 RID: 2692
	Statue_BatA,
	// Token: 0x04000A85 RID: 2693
	Statue_BatB,
	// Token: 0x04000A86 RID: 2694
	Statue_BatC,
	// Token: 0x04000A87 RID: 2695
	Statue_BatD,
	// Token: 0x04000A88 RID: 2696
	SellCardDisplay,
	// Token: 0x04000A89 RID: 2697
	BOOSTERMAX,
	// Token: 0x04000A8A RID: 2698
	Builder = 10000,
	// Token: 0x04000A8B RID: 2699
	TrashCan,
	// Token: 0x04000A8C RID: 2700
	Plant,
	// Token: 0x04000A8D RID: 2701
	OrangeLamp,
	// Token: 0x04000A8E RID: 2702
	WhiteLamp,
	// Token: 0x04000A8F RID: 2703
	RoundLeafPlant,
	// Token: 0x04000A90 RID: 2704
	GreenPlant,
	// Token: 0x04000A91 RID: 2705
	YellowPlant,
	// Token: 0x04000A92 RID: 2706
	PinkPlant,
	// Token: 0x04000A93 RID: 2707
	BushyPlant,
	// Token: 0x04000A94 RID: 2708
	WaterDispenser,
	// Token: 0x04000A95 RID: 2709
	SnackMachine,
	// Token: 0x04000A96 RID: 2710
	RedBeanBag,
	// Token: 0x04000A97 RID: 2711
	BeigeArmChair,
	// Token: 0x04000A98 RID: 2712
	OrangeArmChair,
	// Token: 0x04000A99 RID: 2713
	GamingStation,
	// Token: 0x04000A9A RID: 2714
	Bonsai,
	// Token: 0x04000A9B RID: 2715
	BambooPot,
	// Token: 0x04000A9C RID: 2716
	StoneLantern,
	// Token: 0x04000A9D RID: 2717
	KatanaDisplay,
	// Token: 0x04000A9E RID: 2718
	ArcadeMachine,
	// Token: 0x04000A9F RID: 2719
	ArcadeClaw,
	// Token: 0x04000AA0 RID: 2720
	EarlyPlayerTrophy,
	// Token: 0x04000AA1 RID: 2721
	LuckyCatStatue,
	// Token: 0x04000AA2 RID: 2722
	DECOMAX
}
