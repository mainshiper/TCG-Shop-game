﻿using System;

// Token: 0x020000B5 RID: 181
public class CEventPlayer_SetShopExp : CEvent
{
	// Token: 0x17000017 RID: 23
	// (get) Token: 0x06000716 RID: 1814 RVA: 0x000393AB File Offset: 0x000375AB
	// (set) Token: 0x06000717 RID: 1815 RVA: 0x000393B3 File Offset: 0x000375B3
	public int m_ExpValue { get; private set; }

	// Token: 0x06000718 RID: 1816 RVA: 0x000393BC File Offset: 0x000375BC
	public CEventPlayer_SetShopExp(int ExpValue)
	{
		this.m_ExpValue = ExpValue;
	}
}
