﻿using System;

// Token: 0x0200004A RID: 74
[Serializable]
public class ItemTypeAmount
{
	// Token: 0x04000443 RID: 1091
	public EItemType itemType;

	// Token: 0x04000444 RID: 1092
	public int amount;
}
