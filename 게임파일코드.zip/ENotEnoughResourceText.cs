﻿using System;

// Token: 0x0200006F RID: 111
public enum ENotEnoughResourceText
{
	// Token: 0x040005F1 RID: 1521
	None = -1,
	// Token: 0x040005F2 RID: 1522
	Money,
	// Token: 0x040005F3 RID: 1523
	AlreadyPurchased,
	// Token: 0x040005F4 RID: 1524
	ShopLevelNotEnough,
	// Token: 0x040005F5 RID: 1525
	CustomerPlayNotEnough,
	// Token: 0x040005F6 RID: 1526
	GenericNoSlot,
	// Token: 0x040005F7 RID: 1527
	ShelfNoItem,
	// Token: 0x040005F8 RID: 1528
	ShelfNoSlot,
	// Token: 0x040005F9 RID: 1529
	ShelfWrongItemType,
	// Token: 0x040005FA RID: 1530
	BoxNoItem,
	// Token: 0x040005FB RID: 1531
	BoxNoSlot,
	// Token: 0x040005FC RID: 1532
	BoxWrongItemType,
	// Token: 0x040005FD RID: 1533
	HandFull,
	// Token: 0x040005FE RID: 1534
	NoItemOnHand,
	// Token: 0x040005FF RID: 1535
	NothingInCart,
	// Token: 0x04000600 RID: 1536
	WrongCounterChangeAmount,
	// Token: 0x04000601 RID: 1537
	WrongCounterCardAmount,
	// Token: 0x04000602 RID: 1538
	CannotMoveCounterCustomerInQueue,
	// Token: 0x04000603 RID: 1539
	CanOnlyPutItemOnThisShelf,
	// Token: 0x04000604 RID: 1540
	CanOnlyStoreBoxOnThisShelf,
	// Token: 0x04000605 RID: 1541
	CannotStoreEmptyBox,
	// Token: 0x04000606 RID: 1542
	CannotMixDifferentBoxSizes,
	// Token: 0x04000607 RID: 1543
	UnlockPreviousRoomExpansionFirst,
	// Token: 0x04000608 RID: 1544
	CannotOpenShopYet,
	// Token: 0x04000609 RID: 1545
	NeedAtLeastOneCashierCounter,
	// Token: 0x0400060A RID: 1546
	NotEnoughCardForBundle,
	// Token: 0x0400060B RID: 1547
	TooMuchCounterChangeAmount,
	// Token: 0x0400060C RID: 1548
	CartTooManyItem,
	// Token: 0x0400060D RID: 1549
	AutoCleanserNoSlot,
	// Token: 0x0400060E RID: 1550
	AutoCleanserOnlyAllowCleanser,
	// Token: 0x0400060F RID: 1551
	AutoCleanserRefill,
	// Token: 0x04000610 RID: 1552
	CantSellLastCashierCounter,
	// Token: 0x04000611 RID: 1553
	NoSpaceToStartBundle,
	// Token: 0x04000612 RID: 1554
	ShelfDataNotLoadedCorrectly,
	// Token: 0x04000613 RID: 1555
	CanOnlyPutBulkBox
}
