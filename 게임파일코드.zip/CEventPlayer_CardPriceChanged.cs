﻿using System;

// Token: 0x020000B9 RID: 185
public class CEventPlayer_CardPriceChanged : CEvent
{
	// Token: 0x1700001C RID: 28
	// (get) Token: 0x06000724 RID: 1828 RVA: 0x00039443 File Offset: 0x00037643
	// (set) Token: 0x06000725 RID: 1829 RVA: 0x0003944B File Offset: 0x0003764B
	public CardData m_CardData { get; private set; }

	// Token: 0x1700001D RID: 29
	// (get) Token: 0x06000726 RID: 1830 RVA: 0x00039454 File Offset: 0x00037654
	// (set) Token: 0x06000727 RID: 1831 RVA: 0x0003945C File Offset: 0x0003765C
	public float m_Price { get; private set; }

	// Token: 0x06000728 RID: 1832 RVA: 0x00039465 File Offset: 0x00037665
	public CEventPlayer_CardPriceChanged(CardData cardData, float price)
	{
		this.m_CardData = cardData;
		this.m_Price = price;
	}
}
