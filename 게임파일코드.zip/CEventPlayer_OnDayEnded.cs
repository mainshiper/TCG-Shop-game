﻿using System;

// Token: 0x020000C0 RID: 192
public class CEventPlayer_OnDayEnded : CEvent
{
}
