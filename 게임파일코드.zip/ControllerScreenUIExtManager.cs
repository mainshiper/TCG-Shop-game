﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x0200010F RID: 271
public class ControllerScreenUIExtManager : CSingleton<ControllerScreenUIExtManager>
{
	// Token: 0x060007FA RID: 2042 RVA: 0x0003C3B8 File Offset: 0x0003A5B8
	public void Update()
	{
		if (this.m_TimeSkipUpdate > 0f)
		{
			this.m_TimeSkipUpdate -= Time.unscaledDeltaTime;
			if (this.m_TimeSkipUpdate <= 0f)
			{
				this.m_TimeSkipUpdate = 0f;
			}
			return;
		}
		if (this.m_IsControllerActive && this.m_CurrentCtrlScreenUIExt)
		{
			this.m_CurrentCtrlScreenUIExt.RunUpdate();
		}
	}

	// Token: 0x060007FB RID: 2043 RVA: 0x0003C41D File Offset: 0x0003A61D
	public static void SetLockLJoystickVertical(bool isLock)
	{
		CSingleton<ControllerScreenUIExtManager>.Instance.m_LockLJoystickVertical = isLock;
		CSingleton<ControllerScreenUIExtManager>.Instance.m_LockLJoystickHorizontal = isLock;
	}

	// Token: 0x060007FC RID: 2044 RVA: 0x0003C435 File Offset: 0x0003A635
	public static void StartVirtualKeyboard(string initText, TMP_InputField inputText)
	{
		CSingleton<ControllerScreenUIExtManager>.Instance.m_VirtualKeyboardScreenUI.SetInitialText(initText, inputText);
		CSingleton<ControllerScreenUIExtManager>.Instance.m_VirtualKeyboardScreenUI.OpenScreen();
	}

	// Token: 0x060007FD RID: 2045 RVA: 0x0003C458 File Offset: 0x0003A658
	public static void SetControllerActive(bool isActive)
	{
		if (CSingleton<ControllerScreenUIExtManager>.Instance.m_CurrentControllerButton != null)
		{
			CSingleton<ControllerScreenUIExtManager>.Instance.m_ControllerSelectorUIGrp.m_TopUIGrp.SetActive(isActive);
		}
		else
		{
			CSingleton<ControllerScreenUIExtManager>.Instance.m_ControllerSelectorUIGrp.m_TopUIGrp.SetActive(false);
		}
		CSingleton<ControllerScreenUIExtManager>.Instance.m_IsControllerActive = isActive;
	}

	// Token: 0x060007FE RID: 2046 RVA: 0x0003C4B0 File Offset: 0x0003A6B0
	public static void OnOpenScreen(ControllerScreenUIExtension ctrlScreenUIExt)
	{
		if (!ctrlScreenUIExt)
		{
			return;
		}
		CSingleton<ControllerScreenUIExtManager>.Instance.m_ActiveCtrlScreenUIExtList.Add(ctrlScreenUIExt);
		CSingleton<ControllerScreenUIExtManager>.Instance.m_CurrentCtrlScreenUIExt = ctrlScreenUIExt;
		CSingleton<ControllerScreenUIExtManager>.Instance.m_CurrentCtrlScreenUIExt.OnOpenScreen();
		CSingleton<ControllerScreenUIExtManager>.Instance.m_TimeSkipUpdate = 0.02f;
	}

	// Token: 0x060007FF RID: 2047 RVA: 0x0003C500 File Offset: 0x0003A700
	public static void OnCloseScreen(ControllerScreenUIExtension ctrlScreenUIExt)
	{
		if (!ctrlScreenUIExt)
		{
			return;
		}
		CSingleton<ControllerScreenUIExtManager>.Instance.m_ActiveCtrlScreenUIExtList.Remove(ctrlScreenUIExt);
		if (CSingleton<ControllerScreenUIExtManager>.Instance.m_ActiveCtrlScreenUIExtList.Count > 0)
		{
			CSingleton<ControllerScreenUIExtManager>.Instance.m_CurrentCtrlScreenUIExt = CSingleton<ControllerScreenUIExtManager>.Instance.m_ActiveCtrlScreenUIExtList[CSingleton<ControllerScreenUIExtManager>.Instance.m_ActiveCtrlScreenUIExtList.Count - 1];
			CSingleton<ControllerScreenUIExtManager>.Instance.m_CurrentCtrlScreenUIExt.OnCloseChildScreen();
			return;
		}
		CSingleton<ControllerScreenUIExtManager>.Instance.m_CurrentCtrlScreenUIExt = null;
	}

	// Token: 0x06000800 RID: 2048 RVA: 0x0003C580 File Offset: 0x0003A780
	public static void SetControllerSelectorUI(ControllerButton controllerButton, float rectTransformOffsetMultiplier = 1f, float btnHighlightScale = 1f)
	{
		CSingleton<ControllerScreenUIExtManager>.Instance.m_CurrentControllerButton = controllerButton;
		if (controllerButton == null)
		{
			CSingleton<ControllerScreenUIExtManager>.Instance.m_ControllerSelectorUIGrp.m_TopUIGrp.SetActive(false);
			return;
		}
		CSingleton<ControllerScreenUIExtManager>.Instance.m_ControllerSelectorUIGrp.m_Rect.parent = controllerButton.transform;
		CSingleton<ControllerScreenUIExtManager>.Instance.m_ControllerSelectorUIGrp.m_Rect.localPosition = Vector3.zero;
		CSingleton<ControllerScreenUIExtManager>.Instance.m_ControllerSelectorUIGrp.m_Rect.localRotation = Quaternion.identity;
		CSingleton<ControllerScreenUIExtManager>.Instance.m_ControllerSelectorUIGrp.m_Rect.localScale = Vector3.one;
		CSingleton<ControllerScreenUIExtManager>.Instance.m_ControllerSelectorUIGrp.SetSpriteGrpScale(btnHighlightScale);
		CSingleton<ControllerScreenUIExtManager>.Instance.m_ControllerSelectorUIGrp.m_Rect.anchorMin = new Vector2(0f, 0f);
		CSingleton<ControllerScreenUIExtManager>.Instance.m_ControllerSelectorUIGrp.m_Rect.anchorMax = new Vector2(1f, 1f);
		CSingleton<ControllerScreenUIExtManager>.Instance.m_ControllerSelectorUIGrp.m_Rect.pivot = new Vector2(0.5f, 0.5f);
		CSingleton<ControllerScreenUIExtManager>.Instance.m_ControllerSelectorUIGrp.m_Rect.offsetMin = Vector2.one * 60f * rectTransformOffsetMultiplier;
		CSingleton<ControllerScreenUIExtManager>.Instance.m_ControllerSelectorUIGrp.m_Rect.offsetMax = Vector2.one * -60f * rectTransformOffsetMultiplier;
		CSingleton<ControllerScreenUIExtManager>.Instance.m_ControllerSelectorUIGrp.m_TopUIGrp.SetActive(true);
	}

	// Token: 0x04000F48 RID: 3912
	public bool m_IsControllerActive;

	// Token: 0x04000F49 RID: 3913
	public bool m_LockLJoystickVertical;

	// Token: 0x04000F4A RID: 3914
	public bool m_LockLJoystickHorizontal;

	// Token: 0x04000F4B RID: 3915
	public ControllerSelectorUIGrp m_ControllerSelectorUIGrp;

	// Token: 0x04000F4C RID: 3916
	public VirtualKeyboardScreenUI m_VirtualKeyboardScreenUI;

	// Token: 0x04000F4D RID: 3917
	public ControllerScreenUIExtension m_CurrentCtrlScreenUIExt;

	// Token: 0x04000F4E RID: 3918
	public List<ControllerScreenUIExtension> m_ActiveCtrlScreenUIExtList;

	// Token: 0x04000F4F RID: 3919
	private ControllerButton m_CurrentControllerButton;

	// Token: 0x04000F50 RID: 3920
	private float m_TimeSkipUpdate;
}
