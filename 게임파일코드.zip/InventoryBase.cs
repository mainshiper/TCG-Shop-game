﻿using System;
using System.Collections.Generic;
using I2.Loc;
using UnityEngine;

// Token: 0x02000036 RID: 54
public class InventoryBase : CSingleton<InventoryBase>
{
	// Token: 0x060002AE RID: 686 RVA: 0x0001A187 File Offset: 0x00018387
	private void Awake()
	{
	}

	// Token: 0x060002AF RID: 687 RVA: 0x0001A189 File Offset: 0x00018389
	private void Start()
	{
	}

	// Token: 0x060002B0 RID: 688 RVA: 0x0001A18C File Offset: 0x0001838C
	public static InteractableObject GetSpawnInteractableObjectPrefab(EObjectType objType)
	{
		for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_ObjectData_SO.m_ObjectDataList.Count; i++)
		{
			if (CSingleton<InventoryBase>.Instance.m_ObjectData_SO.m_ObjectDataList[i].objectType == objType)
			{
				return CSingleton<InventoryBase>.Instance.m_ObjectData_SO.m_ObjectDataList[i].spawnPrefab;
			}
		}
		return null;
	}

	// Token: 0x060002B1 RID: 689 RVA: 0x0001A1F1 File Offset: 0x000183F1
	public static FurniturePurchaseData GetFurniturePurchaseData(int index)
	{
		return CSingleton<InventoryBase>.Instance.m_ObjectData_SO.m_FurniturePurchaseDataList[index];
	}

	// Token: 0x060002B2 RID: 690 RVA: 0x0001A208 File Offset: 0x00018408
	public static FurniturePurchaseData GetFurniturePurchaseData(EObjectType objType)
	{
		for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_ObjectData_SO.m_ObjectDataList.Count; i++)
		{
			if (CSingleton<InventoryBase>.Instance.m_ObjectData_SO.m_FurniturePurchaseDataList[i].objectType == objType)
			{
				return CSingleton<InventoryBase>.Instance.m_ObjectData_SO.m_FurniturePurchaseDataList[i];
			}
		}
		return null;
	}

	// Token: 0x060002B3 RID: 691 RVA: 0x0001A268 File Offset: 0x00018468
	public static GameEventData GetGameEventData(EGameEventFormat gameEventFormat)
	{
		if (gameEventFormat == EGameEventFormat.None)
		{
			return new GameEventData();
		}
		return CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_GameEventDataList[(int)gameEventFormat];
	}

	// Token: 0x060002B4 RID: 692 RVA: 0x0001A289 File Offset: 0x00018489
	public static ItemData GetItemData(EItemType itemType)
	{
		if (itemType == EItemType.None)
		{
			return new ItemData();
		}
		return CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ItemDataList[(int)itemType];
	}

	// Token: 0x060002B5 RID: 693 RVA: 0x0001A2AA File Offset: 0x000184AA
	public static ItemMeshData GetItemMeshData(EItemType itemType)
	{
		if (itemType == EItemType.None)
		{
			return new ItemMeshData();
		}
		return CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ItemMeshDataList[(int)itemType];
	}

	// Token: 0x060002B6 RID: 694 RVA: 0x0001A2CB File Offset: 0x000184CB
	public static RestockData GetRestockData(int index)
	{
		return CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList[index];
	}

	// Token: 0x060002B7 RID: 695 RVA: 0x0001A2E4 File Offset: 0x000184E4
	public static List<RestockData> GetRestockDataUsingItemType(EItemType itemType)
	{
		List<RestockData> list = new List<RestockData>();
		for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList.Count; i++)
		{
			if (CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList[i].itemType == itemType)
			{
				list.Add(CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList[i]);
			}
		}
		return list;
	}

	// Token: 0x060002B8 RID: 696 RVA: 0x0001A350 File Offset: 0x00018550
	public static int GetRestockDataIndex(EItemType itemType)
	{
		for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList.Count; i++)
		{
			if (CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList[i].itemType == itemType)
			{
				return i;
			}
		}
		return -1;
	}

	// Token: 0x060002B9 RID: 697 RVA: 0x0001A39C File Offset: 0x0001859C
	public static List<EItemType> GetUnlockableItemTypeAtShopLevel(int level)
	{
		List<EItemType> list = new List<EItemType>();
		for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList.Count; i++)
		{
			if (!CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList[i].isHideItemUntilUnlocked && level >= CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList[i].licenseShopLevelRequired)
			{
				list.Add(CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList[i].itemType);
			}
		}
		return list;
	}

	// Token: 0x060002BA RID: 698 RVA: 0x0001A428 File Offset: 0x00018628
	public static List<EMonsterType> GetShownMonsterList(ECardExpansionType expansionType)
	{
		if (expansionType == ECardExpansionType.Tetramon || expansionType == ECardExpansionType.Destiny)
		{
			return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_ShownMonsterList;
		}
		if (expansionType == ECardExpansionType.Ghost)
		{
			return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_ShownGhostMonsterList;
		}
		if (expansionType == ECardExpansionType.Megabot)
		{
			return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_ShownMegabotList;
		}
		if (expansionType == ECardExpansionType.FantasyRPG)
		{
			return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_ShownFantasyRPGList;
		}
		if (expansionType == ECardExpansionType.CatJob)
		{
			return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_ShownCatJobList;
		}
		return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_ShownMonsterList;
	}

	// Token: 0x060002BB RID: 699 RVA: 0x0001A4AC File Offset: 0x000186AC
	public static MonsterData GetMonsterData(EMonsterType monsterType)
	{
		if (monsterType == EMonsterType.None)
		{
			return null;
		}
		if (monsterType < EMonsterType.MAX)
		{
			return InventoryBase.GetMonsterDataMatchWithType(CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_DataList, monsterType);
		}
		if (monsterType > EMonsterType.MAX && monsterType < EMonsterType.MAX_MEGABOT)
		{
			return InventoryBase.GetMonsterDataMatchWithType(CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_MegabotDataList, monsterType);
		}
		if (monsterType > EMonsterType.MAX_MEGABOT && monsterType < EMonsterType.MAX_FANTASYRPG)
		{
			return InventoryBase.GetMonsterDataMatchWithType(CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_FantasyRPGDataList, monsterType);
		}
		if (monsterType > EMonsterType.MAX_FANTASYRPG && monsterType < EMonsterType.MAX_CATJOB)
		{
			return InventoryBase.GetMonsterDataMatchWithType(CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_CatJobDataList, monsterType);
		}
		return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_DataList[(int)monsterType];
	}

	// Token: 0x060002BC RID: 700 RVA: 0x0001A560 File Offset: 0x00018760
	private static MonsterData GetMonsterDataMatchWithType(List<MonsterData> listMonsterData, EMonsterType monsterType)
	{
		for (int i = 0; i < listMonsterData.Count; i++)
		{
			if (listMonsterData[i].MonsterType == monsterType)
			{
				return listMonsterData[i];
			}
		}
		return null;
	}

	// Token: 0x060002BD RID: 701 RVA: 0x0001A596 File Offset: 0x00018796
	public static Sprite GetAncientArtifactSprite(EMonsterType monsterType)
	{
		return null;
	}

	// Token: 0x060002BE RID: 702 RVA: 0x0001A59D File Offset: 0x0001879D
	public static Sprite GetMonsterGhostIconSprite(EMonsterType monsterType)
	{
		return null;
	}

	// Token: 0x060002BF RID: 703 RVA: 0x0001A5A4 File Offset: 0x000187A4
	public static Sprite GetTetramonIconSprite(EMonsterType monsterType)
	{
		if (monsterType == EMonsterType.None)
		{
			return null;
		}
		int index = (int)(monsterType % (EMonsterType)CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_TetramonImageList.Count);
		return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_TetramonImageList[index];
	}

	// Token: 0x060002C0 RID: 704 RVA: 0x0001A5E4 File Offset: 0x000187E4
	public static Sprite GetSpecialCardImage(EMonsterType monsterType)
	{
		if (monsterType == EMonsterType.None)
		{
			return null;
		}
		for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_SpecialCardImageList.Count; i++)
		{
			if (CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_SpecialCardImageList[i].MonsterType == monsterType)
			{
				return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_SpecialCardImageList[i].GetIcon(ECardExpansionType.None);
			}
		}
		return null;
	}

	// Token: 0x060002C1 RID: 705 RVA: 0x0001A64F File Offset: 0x0001884F
	public static CardUISetting GetCardUISetting(ECardExpansionType expansionType)
	{
		return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_CardUISettingList[(int)expansionType];
	}

	// Token: 0x060002C2 RID: 706 RVA: 0x0001A668 File Offset: 0x00018868
	public static ECardExpansionType GetCardExpansionType(ECollectionPackType collectionPackType)
	{
		if (collectionPackType == ECollectionPackType.BasicCardPack || collectionPackType == ECollectionPackType.RareCardPack || collectionPackType == ECollectionPackType.EpicCardPack || collectionPackType == ECollectionPackType.LegendaryCardPack)
		{
			return ECardExpansionType.Tetramon;
		}
		if (collectionPackType == ECollectionPackType.DestinyBasicCardPack || collectionPackType == ECollectionPackType.DestinyRareCardPack || collectionPackType == ECollectionPackType.DestinyEpicCardPack || collectionPackType == ECollectionPackType.DestinyLegendaryCardPack)
		{
			return ECardExpansionType.Destiny;
		}
		if (collectionPackType == ECollectionPackType.GhostPack)
		{
			return ECardExpansionType.Ghost;
		}
		if (collectionPackType == ECollectionPackType.MegabotPack)
		{
			return ECardExpansionType.Megabot;
		}
		if (collectionPackType == ECollectionPackType.FantasyRPGPack)
		{
			return ECardExpansionType.FantasyRPG;
		}
		if (collectionPackType == ECollectionPackType.CatJobPack)
		{
			return ECardExpansionType.CatJob;
		}
		return ECardExpansionType.None;
	}

	// Token: 0x060002C3 RID: 707 RVA: 0x0001A6B4 File Offset: 0x000188B4
	public static ECollectionPackType ItemTypeToCollectionPackType(EItemType itemType)
	{
		if (itemType == EItemType.BasicCardPack || itemType == EItemType.BasicCardBox)
		{
			return ECollectionPackType.BasicCardPack;
		}
		if (itemType == EItemType.RareCardPack || itemType == EItemType.RareCardBox)
		{
			return ECollectionPackType.RareCardPack;
		}
		if (itemType == EItemType.EpicCardPack || itemType == EItemType.EpicCardBox)
		{
			return ECollectionPackType.EpicCardPack;
		}
		if (itemType == EItemType.LegendaryCardPack || itemType == EItemType.LegendaryCardBox)
		{
			return ECollectionPackType.LegendaryCardPack;
		}
		if (itemType == EItemType.DestinyBasicCardPack || itemType == EItemType.DestinyBasicCardBox)
		{
			return ECollectionPackType.DestinyBasicCardPack;
		}
		if (itemType == EItemType.DestinyRareCardPack || itemType == EItemType.DestinyRareCardBox)
		{
			return ECollectionPackType.DestinyRareCardPack;
		}
		if (itemType == EItemType.DestinyEpicCardPack || itemType == EItemType.DestinyEpicCardBox)
		{
			return ECollectionPackType.DestinyEpicCardPack;
		}
		if (itemType == EItemType.DestinyLegendaryCardPack || itemType == EItemType.DestinyLegendaryCardBox)
		{
			return ECollectionPackType.DestinyLegendaryCardPack;
		}
		if (itemType == EItemType.GhostPack)
		{
			return ECollectionPackType.GhostPack;
		}
		if (itemType == EItemType.MegabotPack)
		{
			return ECollectionPackType.MegabotPack;
		}
		if (itemType == EItemType.FantasyRPGPack)
		{
			return ECollectionPackType.FantasyRPGPack;
		}
		if (itemType == EItemType.CatJobPack)
		{
			return ECollectionPackType.CatJobPack;
		}
		return ECollectionPackType.None;
	}

	// Token: 0x060002C4 RID: 708 RVA: 0x0001A738 File Offset: 0x00018938
	public static string GetPriceChangeTypeText(EPriceChangeType priceChangeType, bool isIncrease)
	{
		for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_TextSO.m_PriceChangeTypeTextList.Count; i++)
		{
			if (CSingleton<InventoryBase>.Instance.m_TextSO.m_PriceChangeTypeTextList[i].priceChangeType == priceChangeType)
			{
				return CSingleton<InventoryBase>.Instance.m_TextSO.m_PriceChangeTypeTextList[i].GetName(isIncrease);
			}
		}
		return LocalizationManager.GetTranslation("No effect on card pack price.", true, 0, true, false, null, null, true);
	}

	// Token: 0x060002C5 RID: 709 RVA: 0x0001A7AE File Offset: 0x000189AE
	public static string GetCardExpansionName(ECardExpansionType cardExpansion)
	{
		return LocalizationManager.GetTranslation(CSingleton<InventoryBase>.Instance.m_TextSO.m_CardExpansionNameList[(int)cardExpansion], true, 0, true, false, null, null, true);
	}

	// Token: 0x060002C6 RID: 710 RVA: 0x0001A7D1 File Offset: 0x000189D1
	public static Material GetCurrencyMaterial(EMoneyCurrencyType currencyType)
	{
		return CSingleton<InventoryBase>.Instance.m_TextSO.m_CurrencyMaterialList[(int)currencyType];
	}

	// Token: 0x060002C7 RID: 711 RVA: 0x0001A7E8 File Offset: 0x000189E8
	public static Sprite GetQuestionMarkSprite()
	{
		return CSingleton<InventoryBase>.Instance.m_TextSO.m_QuestionMarkImage;
	}

	// Token: 0x0400032C RID: 812
	public StockItemData_ScriptableObject m_StockItemData_SO;

	// Token: 0x0400032D RID: 813
	public MonsterData_ScriptableObject m_MonsterData_SO;

	// Token: 0x0400032E RID: 814
	public ShelfData_ScriptableObject m_ObjectData_SO;

	// Token: 0x0400032F RID: 815
	public Text_ScriptableObject m_TextSO;

	// Token: 0x04000330 RID: 816
	public static InventoryBase m_Instance;
}
