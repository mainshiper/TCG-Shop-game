﻿using System;

// Token: 0x0200011A RID: 282
public enum EGameBaseKey
{
	// Token: 0x04000FA2 RID: 4002
	None,
	// Token: 0x04000FA3 RID: 4003
	LeftMouseClick,
	// Token: 0x04000FA4 RID: 4004
	LeftMouseHold,
	// Token: 0x04000FA5 RID: 4005
	RightMouseClick,
	// Token: 0x04000FA6 RID: 4006
	RightMouseHold,
	// Token: 0x04000FA7 RID: 4007
	MiddleMouseScroll,
	// Token: 0x04000FA8 RID: 4008
	MiddleMouseClick,
	// Token: 0x04000FA9 RID: 4009
	MiddleMouseHold,
	// Token: 0x04000FAA RID: 4010
	F,
	// Token: 0x04000FAB RID: 4011
	R,
	// Token: 0x04000FAC RID: 4012
	Q,
	// Token: 0x04000FAD RID: 4013
	E,
	// Token: 0x04000FAE RID: 4014
	Escape,
	// Token: 0x04000FAF RID: 4015
	Enter,
	// Token: 0x04000FB0 RID: 4016
	Spacebar,
	// Token: 0x04000FB1 RID: 4017
	A,
	// Token: 0x04000FB2 RID: 4018
	W,
	// Token: 0x04000FB3 RID: 4019
	S,
	// Token: 0x04000FB4 RID: 4020
	D,
	// Token: 0x04000FB5 RID: 4021
	Backspace,
	// Token: 0x04000FB6 RID: 4022
	C,
	// Token: 0x04000FB7 RID: 4023
	Tab,
	// Token: 0x04000FB8 RID: 4024
	Shift,
	// Token: 0x04000FB9 RID: 4025
	UpArrow,
	// Token: 0x04000FBA RID: 4026
	DownArrow,
	// Token: 0x04000FBB RID: 4027
	LeftArrow,
	// Token: 0x04000FBC RID: 4028
	RightArrow,
	// Token: 0x04000FBD RID: 4029
	JStick_Confirm,
	// Token: 0x04000FBE RID: 4030
	JStick_Cancel,
	// Token: 0x04000FBF RID: 4031
	JStick_Square,
	// Token: 0x04000FC0 RID: 4032
	JStick_Triangle,
	// Token: 0x04000FC1 RID: 4033
	JStick_L1,
	// Token: 0x04000FC2 RID: 4034
	JStick_R1,
	// Token: 0x04000FC3 RID: 4035
	JStick_L2,
	// Token: 0x04000FC4 RID: 4036
	JStick_R2,
	// Token: 0x04000FC5 RID: 4037
	JStick_DPad_L,
	// Token: 0x04000FC6 RID: 4038
	JStick_DPad_R,
	// Token: 0x04000FC7 RID: 4039
	JStick_DPad_Up,
	// Token: 0x04000FC8 RID: 4040
	JStick_DPad_Down,
	// Token: 0x04000FC9 RID: 4041
	RotateL,
	// Token: 0x04000FCA RID: 4042
	RotateR
}
