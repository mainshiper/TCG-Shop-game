﻿using System;

// Token: 0x020000B4 RID: 180
public class CEventPlayer_AddShopExp : CEvent
{
	// Token: 0x17000015 RID: 21
	// (get) Token: 0x06000711 RID: 1809 RVA: 0x00039373 File Offset: 0x00037573
	// (set) Token: 0x06000712 RID: 1810 RVA: 0x0003937B File Offset: 0x0003757B
	public int m_ExpValue { get; private set; }

	// Token: 0x17000016 RID: 22
	// (get) Token: 0x06000713 RID: 1811 RVA: 0x00039384 File Offset: 0x00037584
	// (set) Token: 0x06000714 RID: 1812 RVA: 0x0003938C File Offset: 0x0003758C
	public bool m_NoLerp { get; private set; }

	// Token: 0x06000715 RID: 1813 RVA: 0x00039395 File Offset: 0x00037595
	public CEventPlayer_AddShopExp(int ExpValue, bool noLerp = false)
	{
		this.m_ExpValue = ExpValue;
		this.m_NoLerp = noLerp;
	}
}
