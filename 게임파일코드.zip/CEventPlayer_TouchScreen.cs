﻿using System;

// Token: 0x020000C8 RID: 200
public class CEventPlayer_TouchScreen : CEvent
{
}
