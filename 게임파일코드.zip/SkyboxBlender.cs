﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Rendering;

// Token: 0x0200014D RID: 333
[ExecuteInEditMode]
[AddComponentMenu("Skybox Blender/Skybox Blender")]
public class SkyboxBlender : MonoBehaviour
{
	// Token: 0x17000035 RID: 53
	// (get) Token: 0x06000968 RID: 2408 RVA: 0x00044FCF File Offset: 0x000431CF
	public int CurrentIndex
	{
		get
		{
			return this.index;
		}
	}

	// Token: 0x06000969 RID: 2409 RVA: 0x00044FD8 File Offset: 0x000431D8
	private void Awake()
	{
		this.skyboxBlenderMaterial = (Resources.Load("Material & Shader/Skybox Blend Material", typeof(Material)) as Material);
		if (this.skyboxBlenderMaterial)
		{
			this.defaultBlend = this.skyboxBlenderMaterial.GetFloat("_BlendCubemaps");
			this.defaultRotation = this.skyboxBlenderMaterial.GetFloat("_Rotation");
			this.defaultSkyboxMaterial = this.skyboxBlenderMaterial;
			this.InspectorAndAwakeChanges();
		}
		else
		{
			Debug.LogWarning("Can't find Skybox Blend Material in resources. Please re-import!");
		}
		if (this.updateLighting || this.updateReflections)
		{
			this.SetReflectionProbe();
			this.UpdateLightingAndReflections(true);
		}
	}

	// Token: 0x0600096A RID: 2410 RVA: 0x00045078 File Offset: 0x00043278
	private void OnValidate()
	{
		if (this.skyboxBlenderMaterial == null)
		{
			this.skyboxBlenderMaterial = (Resources.Load("Material & Shader/Skybox Blend Material", typeof(Material)) as Material);
		}
		this.InspectorAndAwakeChanges();
	}

	// Token: 0x0600096B RID: 2411 RVA: 0x000450B0 File Offset: 0x000432B0
	private void OnApplicationQuit()
	{
		this.skyboxBlenderMaterial.SetFloat("_BlendCubemaps", this.defaultBlend);
		this.skyboxBlenderMaterial.SetFloat("_Rotation", this.defaultRotation);
		if (this.currentTexture != null)
		{
			this.skyboxBlenderMaterial.SetTexture("_Tex", this.currentTexture);
		}
		RenderSettings.skybox = this.defaultSkyboxMaterial;
	}

	// Token: 0x0600096C RID: 2412 RVA: 0x00045118 File Offset: 0x00043318
	private void Update()
	{
		if (!Application.isPlaying)
		{
			if (RenderSettings.skybox == null)
			{
				return;
			}
			if (RenderSettings.skybox.HasProperty("_Tex"))
			{
				this.skyboxBlenderMaterial.SetTexture("_Tex", RenderSettings.skybox.GetTexture("_Tex"));
				this.skyboxBlenderMaterial.SetColor("_Tint", RenderSettings.skybox.GetColor("_Tint"));
			}
			return;
		}
		else
		{
			if (this.updateReflections && !this.isSetReflectionProbeOnStart && !this.SetReflectionProbeTexture())
			{
				return;
			}
			if (this.linearBlending && !this.stopped)
			{
				this.usedBlend = 1;
				this.blendValue += Time.deltaTime * this.blendSpeed;
				this.skyboxBlenderMaterial.SetFloat("_BlendCubemaps", this.blendValue);
				this.UpdateLightingAndReflections(false);
				if (this.skyboxBlenderMaterial.GetFloat("_BlendCubemaps") >= this.totalBlendValue)
				{
					this.blendFinished = true;
					this.linearBlending = false;
					this.blendValue = 0f;
					base.StopAllCoroutines();
					this.skyboxBlenderMaterial.SetFloat("_BlendCubemaps", 0f);
					this.SetSkyBoxes(true, this.index, false, 0, true);
					this.UpdateLightingAndReflections(true);
					if (this.comingFromLoop)
					{
						this.index = 0;
					}
					if (this.index + 1 < this.skyboxMaterials.Length)
					{
						if (!this.comingFromLoop)
						{
							this.index++;
						}
						this.comingFromLoop = false;
						this.SetSkyBoxes(true, this.index, false, 0, false);
						if (this.index + 1 < this.skyboxMaterials.Length)
						{
							this.SetSkyBoxes(false, 0, true, this.index + 1, false);
						}
						if (this.index - (this.skyboxMaterials.Length - 1) > 0)
						{
							if (!this.oneTickBlend)
							{
								this.linearBlending = true;
							}
						}
						else if (!this.oneTickBlend)
						{
							base.StartCoroutine(this.WaitBeforeBlending());
						}
					}
					if (this.index >= this.skyboxMaterials.Length - 1)
					{
						if (this.loop)
						{
							if (this.oneTickBlend)
							{
								this.stillRunning = false;
								return;
							}
							this.SetSkyBoxes(true, this.index, true, 0, true);
							this.comingFromLoop = true;
							base.StartCoroutine(this.WaitBeforeBlending());
						}
						else
						{
							this.stillRunning = false;
							if (this.stopRotationOnBlendFinish)
							{
								this.StopRotation();
							}
						}
					}
				}
				else
				{
					this.blendFinished = false;
				}
			}
			if (this.singleBlend && !this.stopped)
			{
				this.blendValue += Time.deltaTime * this.blendSpeed;
				this.skyboxBlenderMaterial.SetFloat("_BlendCubemaps", this.blendValue);
				this.UpdateLightingAndReflections(false);
				if (this.skyboxBlenderMaterial.GetFloat("_BlendCubemaps") >= this.totalBlendValue)
				{
					this.blendFinished = true;
					this.singleBlend = false;
					this.blendValue = 0f;
					base.StopAllCoroutines();
					if (this.blendByIndex)
					{
						this.index = this.indexToBlend;
						this.blendByIndex = false;
					}
					else if (this.index + 1 < this.skyboxMaterials.Length)
					{
						this.index++;
					}
					else
					{
						this.index = 0;
					}
					this.skyboxBlenderMaterial.SetFloat("_BlendCubemaps", 0f);
					this.SetSkyBoxes(true, this.index, false, 0, true);
					this.UpdateLightingAndReflections(true);
					this.stillRunning = false;
					if (this.stopRotationOnBlendFinish)
					{
						this.StopRotation();
					}
				}
				else
				{
					this.blendFinished = false;
				}
			}
			if (this.currentSkyboxNotFirstMaterialBlending && !this.stopped)
			{
				this.usedBlend = 2;
				this.blendValue += Time.deltaTime * this.blendSpeed;
				this.skyboxBlenderMaterial.SetFloat("_BlendCubemaps", this.blendValue);
				this.UpdateLightingAndReflections(false);
				if (this.skyboxBlenderMaterial.GetFloat("_BlendCubemaps") >= this.totalBlendValue)
				{
					this.blendFinished = true;
					this.currentSkyboxNotFirstMaterialBlending = false;
					this.blendValue = 0f;
					base.StopAllCoroutines();
					int secondTexIndex = 1;
					this.skyboxBlenderMaterial.SetFloat("_BlendCubemaps", 0f);
					if (this.skyboxMaterials.Length == 1)
					{
						secondTexIndex = 0;
					}
					this.SetSkyBoxes(true, 0, true, secondTexIndex, true);
					this.UpdateLightingAndReflections(true);
					if (this.oneTickBlend)
					{
						this.stillRunning = false;
					}
					else
					{
						base.StartCoroutine(this.WaitBeforeBlending());
					}
					if (this.stopRotationOnBlendFinish && !this.blendingCurrentSkyToListNotSingleBlend)
					{
						this.StopRotation();
					}
					this.blendingCurrentSkyToListNotSingleBlend = false;
				}
				else
				{
					this.blendFinished = false;
				}
			}
			this.rotationSpeedValue += Time.deltaTime * this.rotationSpeed;
			if (this.keepRotating)
			{
				this.skyboxBlenderMaterial.SetFloat("_Rotation", this.rotationSpeedValue);
				return;
			}
			if (this.skyboxBlenderMaterial.GetFloat("_Rotation") < this.rotateToAngle)
			{
				this.skyboxBlenderMaterial.SetFloat("_Rotation", this.rotationSpeedValue);
				return;
			}
			this.rotateSkybox = false;
			this.skyboxBlenderMaterial.SetFloat("_Rotation", this.rotateToAngle);
			return;
		}
	}

	// Token: 0x0600096D RID: 2413 RVA: 0x0004561C File Offset: 0x0004381C
	private void SetSkyBoxes(bool firstTex = false, int firstTexIndex = 0, bool secondTex = false, int secondTexIndex = 0, bool apply = false)
	{
		if (firstTex)
		{
			this.skyboxBlenderMaterial.SetTexture("_Tex", this.skyboxMaterials[firstTexIndex].GetTexture("_Tex"));
			this.skyboxBlenderMaterial.SetColor("_Tint", this.skyboxMaterials[firstTexIndex].GetColor("_Tint"));
		}
		if (secondTex)
		{
			this.skyboxBlenderMaterial.SetTexture("_Tex2", this.skyboxMaterials[secondTexIndex].GetTexture("_Tex"));
			this.skyboxBlenderMaterial.SetColor("_Tint2", this.skyboxMaterials[secondTexIndex].GetColor("_Tint"));
		}
		if (apply)
		{
			RenderSettings.skybox = this.skyboxBlenderMaterial;
		}
	}

	// Token: 0x0600096E RID: 2414 RVA: 0x000456C8 File Offset: 0x000438C8
	private void PrepareMaterialForBlend(int skyboxIndex)
	{
		this.skyboxBlenderMaterial.SetTexture("_Tex", RenderSettings.skybox.GetTexture("_Tex"));
		this.skyboxBlenderMaterial.SetTexture("_Tex2", this.skyboxMaterials[skyboxIndex].GetTexture("_Tex"));
		this.skyboxBlenderMaterial.SetColor("_Tint", RenderSettings.skybox.GetColor("_Tint"));
		this.skyboxBlenderMaterial.SetColor("_Tint2", this.skyboxMaterials[skyboxIndex].GetColor("_Tint"));
	}

	// Token: 0x0600096F RID: 2415 RVA: 0x00045757 File Offset: 0x00043957
	private IEnumerator WaitBeforeBlending()
	{
		this.isLinearBlend = true;
		yield return new WaitForSeconds(this.timeToWait);
		this.linearBlending = true;
		yield break;
	}

	// Token: 0x06000970 RID: 2416 RVA: 0x00045768 File Offset: 0x00043968
	private void InspectorAndAwakeChanges()
	{
		if (this.makeFirstMaterialSkybox)
		{
			if (this.skyboxMaterials.Length >= 1)
			{
				if (this.skyboxMaterials[0] != null)
				{
					this.skyboxBlenderMaterial.SetTexture("_Tex", this.skyboxMaterials[0].GetTexture("_Tex"));
					this.skyboxBlenderMaterial.SetColor("_Tint", this.skyboxMaterials[0].GetColor("_Tint"));
					RenderSettings.skybox = this.skyboxBlenderMaterial;
				}
			}
			else
			{
				Debug.LogWarning("You need to set a material first to make it the skybox");
			}
		}
		if (this.skyboxMaterials != null && this.skyboxMaterials.Length > 1 && this.skyboxMaterials[1] != null)
		{
			this.skyboxBlenderMaterial.SetTexture("_Tex2", this.skyboxMaterials[1].GetTexture("_Tex"));
			this.skyboxBlenderMaterial.SetColor("_Tint2", this.skyboxMaterials[1].GetColor("_Tint"));
		}
	}

	// Token: 0x06000971 RID: 2417 RVA: 0x0004585C File Offset: 0x00043A5C
	private void SetReflectionProbe()
	{
		this.reflectionProbe = base.GetComponent<ReflectionProbe>();
		if (this.reflectionProbe == null)
		{
			this.reflectionProbe = base.gameObject.AddComponent<ReflectionProbe>();
		}
		this.reflectionProbe.cullingMask = 0;
		this.reflectionProbe.refreshMode = ReflectionProbeRefreshMode.ViaScripting;
		this.reflectionProbe.mode = ReflectionProbeMode.Realtime;
		this.reflectionProbe.timeSlicingMode = ReflectionProbeTimeSlicingMode.NoTimeSlicing;
		if (this.updateReflections)
		{
			RenderSettings.defaultReflectionMode = DefaultReflectionMode.Custom;
			this.cubemap = new Cubemap(this.reflectionProbe.resolution, this.reflectionProbe.hdr ? TextureFormat.RGBAHalf : TextureFormat.RGBA32, true);
		}
	}

	// Token: 0x06000972 RID: 2418 RVA: 0x000458FC File Offset: 0x00043AFC
	public void UpdateLightingAndReflections(bool forceUpdate = false)
	{
		if (!this.updateReflections && !this.updateLighting)
		{
			this.LightAndReflectionFrames = 0;
			return;
		}
		if (!forceUpdate && this.LightAndReflectionFrames < this.updateEveryFrames)
		{
			this.LightAndReflectionFrames++;
			return;
		}
		if (this.updateLighting && this.blendValue > 0.02f && this.blendValue < 0.98f)
		{
			DynamicGI.UpdateEnvironment();
		}
		if (!this.updateReflections)
		{
			return;
		}
		this.LightAndReflectionFrames = 0;
		this.reflectionProbe.RenderProbe();
		if (this.reflectionProbe.texture != null)
		{
			Graphics.CopyTexture(this.reflectionProbe.texture, this.cubemap);
			RenderSettings.customReflection = this.cubemap;
			return;
		}
	}

	// Token: 0x06000973 RID: 2419 RVA: 0x000459B9 File Offset: 0x00043BB9
	private bool SetReflectionProbeTexture()
	{
		if (!this.isSetReflectionProbeOnStart)
		{
			this.SetReflectionProbe();
			this.UpdateLightingAndReflections(true);
			if (this.reflectionProbe.texture != null)
			{
				this.isSetReflectionProbeOnStart = true;
			}
		}
		return this.isSetReflectionProbeOnStart;
	}

	// Token: 0x06000974 RID: 2420 RVA: 0x000459F0 File Offset: 0x00043BF0
	public void Blend(bool singlePassBlend = false, bool rotate = true)
	{
		if (this.currentSkyboxNotFirstMaterialBlending && !this.stopped)
		{
			return;
		}
		if (this.isLinearBlend && !this.stopped)
		{
			return;
		}
		if (rotate)
		{
			this.rotateSkybox = true;
			this.stopRotation = false;
		}
		if ((this.stopped || this.stillRunning) && !singlePassBlend)
		{
			this.stopped = false;
			if (this.blendFinished && (this.usedBlend == 1 || this.usedBlend == 2) && !this.stillRunning)
			{
				base.StartCoroutine(this.WaitBeforeBlending());
				return;
			}
		}
		this.stopped = false;
		this.blendByIndex = false;
		base.StopAllCoroutines();
		this.currentTexture = RenderSettings.skybox.GetTexture("_Tex");
		if (this.blendValue > 0f)
		{
			this.oneTickBlend = singlePassBlend;
			return;
		}
		if (singlePassBlend)
		{
			if (this.index == 0 && this.currentTexture != this.skyboxMaterials[0].GetTexture("_Tex"))
			{
				this.PrepareMaterialForBlend(0);
				this.currentSkyboxNotFirstMaterialBlending = true;
			}
			else
			{
				int num = this.index;
				if (!this.stopped)
				{
					if (this.index >= this.skyboxMaterials.Length - 1)
					{
						num = 0;
					}
					else
					{
						num++;
					}
				}
				this.PrepareMaterialForBlend(num);
				this.singleBlend = true;
			}
			RenderSettings.skybox = this.skyboxBlenderMaterial;
			this.stillRunning = true;
		}
		else
		{
			if (this.skyboxMaterials.Length == 1)
			{
				if (this.currentTexture != this.skyboxMaterials[0].GetTexture("_Tex"))
				{
					this.PrepareMaterialForBlend(0);
					RenderSettings.skybox = this.skyboxBlenderMaterial;
				}
			}
			else if (this.index == 0 && this.skyboxMaterials[0] != null)
			{
				if (this.currentTexture == this.skyboxMaterials[0].GetTexture("_Tex"))
				{
					this.SetSkyBoxes(true, 0, false, 0, true);
				}
				else
				{
					this.SetSkyBoxes(false, 0, true, 0, true);
					this.currentSkyboxNotFirstMaterialBlending = true;
					this.blendingCurrentSkyToListNotSingleBlend = true;
				}
			}
			if (this.index >= this.skyboxMaterials.Length - 1)
			{
				this.comingFromLoop = true;
			}
			if (rotate)
			{
				this.rotateSkybox = true;
				this.stopRotation = false;
			}
			if (!this.currentSkyboxNotFirstMaterialBlending)
			{
				this.linearBlending = true;
				this.stillRunning = true;
				if (rotate)
				{
					this.rotateSkybox = true;
				}
			}
			this.isLinearBlend = true;
		}
		this.oneTickBlend = singlePassBlend;
	}

	// Token: 0x06000975 RID: 2421 RVA: 0x00045C38 File Offset: 0x00043E38
	public void Blend(int skyboxIndex, bool rotate = true)
	{
		this.stopped = false;
		if (this.stillRunning)
		{
			return;
		}
		if (this.index == skyboxIndex)
		{
			return;
		}
		if (skyboxIndex > this.skyboxMaterials.Length - 1)
		{
			Debug.Log("The passed index is bigger than the length of the skybox materials list.");
			return;
		}
		if (skyboxIndex < 0)
		{
			skyboxIndex = this.skyboxMaterials.Length - 1;
		}
		if (this.skyboxMaterials[skyboxIndex] == null)
		{
			Debug.Log("There is no material in the list with the passed index.");
			return;
		}
		base.StopAllCoroutines();
		this.currentTexture = RenderSettings.skybox.GetTexture("_Tex");
		this.blendByIndex = true;
		this.indexToBlend = skyboxIndex;
		this.PrepareMaterialForBlend(skyboxIndex);
		this.singleBlend = true;
		RenderSettings.skybox = this.skyboxBlenderMaterial;
		if (rotate)
		{
			this.rotateSkybox = true;
			this.stopRotation = false;
		}
		this.stillRunning = true;
		this.oneTickBlend = true;
	}

	// Token: 0x06000976 RID: 2422 RVA: 0x00045D04 File Offset: 0x00043F04
	public void Cancel()
	{
		base.StopAllCoroutines();
		this.linearBlending = false;
		this.singleBlend = false;
		this.currentSkyboxNotFirstMaterialBlending = false;
		this.blendingCurrentSkyToListNotSingleBlend = false;
		this.oneTickBlend = false;
		this.stopped = false;
		this.blendValue = 0f;
		this.stillRunning = false;
		this.isLinearBlend = false;
		this.comingFromLoop = false;
		this.skyboxBlenderMaterial.SetFloat("_BlendCubemaps", 0f);
		this.SetSkyBoxes(true, this.index, false, 0, true);
		this.UpdateLightingAndReflections(true);
	}

	// Token: 0x06000977 RID: 2423 RVA: 0x00045D8D File Offset: 0x00043F8D
	public void Stop(bool stopRot = true)
	{
		this.stopped = true;
		base.StopAllCoroutines();
		if (stopRot && this.rotateSkybox)
		{
			this.stopRotation = true;
		}
	}

	// Token: 0x06000978 RID: 2424 RVA: 0x00045DAE File Offset: 0x00043FAE
	public void Resume(bool resumeRot = true)
	{
		this.stopped = false;
		if (resumeRot)
		{
			this.stopRotation = false;
		}
		if ((this.usedBlend == 1 || this.usedBlend == 2) && this.blendFinished)
		{
			base.StartCoroutine(this.WaitBeforeBlending());
		}
	}

	// Token: 0x06000979 RID: 2425 RVA: 0x00045DE8 File Offset: 0x00043FE8
	public bool IsBlending()
	{
		return !this.stopped && (this.linearBlending || this.singleBlend || this.currentSkyboxNotFirstMaterialBlending);
	}

	// Token: 0x0600097A RID: 2426 RVA: 0x00045E10 File Offset: 0x00044010
	public void Rotate()
	{
		this.skyboxBlenderMaterial.SetTexture("_Tex", RenderSettings.skybox.GetTexture("_Tex"));
		this.skyboxBlenderMaterial.SetColor("_Tint", RenderSettings.skybox.GetColor("_Tint"));
		RenderSettings.skybox = this.skyboxBlenderMaterial;
		this.rotateSkybox = true;
		this.stopRotation = false;
	}

	// Token: 0x0600097B RID: 2427 RVA: 0x00045E74 File Offset: 0x00044074
	public void StopRotation()
	{
		this.rotateSkybox = false;
		this.stopRotation = false;
	}

	// Token: 0x040011AF RID: 4527
	[Tooltip("The materials you want to blend to linearly.")]
	public Material[] skyboxMaterials;

	// Token: 0x040011B0 RID: 4528
	[Tooltip("Checking this will instantly make the first material your current skybox.")]
	public bool makeFirstMaterialSkybox;

	// Token: 0x040011B1 RID: 4529
	[Min(0f)]
	[Tooltip("The speed of the blending between the skyboxes.")]
	public float blendSpeed = 0.5f;

	// Token: 0x040011B2 RID: 4530
	[Min(0f)]
	[Tooltip("The time to wait before blending the next skybox material.")]
	public float timeToWait;

	// Token: 0x040011B3 RID: 4531
	[Tooltip("If enabled, will loop the materials list. When the blender reaches the last skybox in the list, it'll blend back to the first one.")]
	public bool loop = true;

	// Token: 0x040011B4 RID: 4532
	[Tooltip("If enabled, the lighting of the world will be updated to that of the skyboxes blending.")]
	public bool updateLighting;

	// Token: 0x040011B5 RID: 4533
	[Tooltip("If enabled, the reflections of the world will be updated to that of the skyboxes blending.")]
	public bool updateReflections;

	// Token: 0x040011B6 RID: 4534
	[Range(1f, 30f)]
	[Tooltip("Set how many frames need to pass during blend before updating the reflections & lighting each time. Updating these take a toll on performance so the higher this number is, the more performant your game will be (during blend) but the less accurate the lighting & reflections update will be. The less this number is, the slower the game will be but the accuracy increases. By average the best performance/accuracy results is setting it between 5-10.")]
	public int updateEveryFrames = 5;

	// Token: 0x040011B7 RID: 4535
	[Tooltip("Keep rotating the skybox infinetly while blending.")]
	public bool keepRotating;

	// Token: 0x040011B8 RID: 4536
	[Tooltip("if you would prefer a certain degree to rotate the skybox to during blending - 360 is a full turn.")]
	public float rotateToAngle = 180f;

	// Token: 0x040011B9 RID: 4537
	[Min(0f)]
	[Tooltip("The speed of the skybox rotation.")]
	public float rotationSpeed;

	// Token: 0x040011BA RID: 4538
	[Tooltip("If enabled, the rotation will stop when the blend finishes. If disabled, even after blending the skybox will continue rotating. TAKE NOTE: if loop is enabled in blend options. This will not take effect.")]
	public bool stopRotationOnBlendFinish;

	// Token: 0x040011BB RID: 4539
	private Material defaultSkyboxMaterial;

	// Token: 0x040011BC RID: 4540
	private Material skyboxBlenderMaterial;

	// Token: 0x040011BD RID: 4541
	private Texture currentTexture;

	// Token: 0x040011BE RID: 4542
	private float totalBlendValue = 1f;

	// Token: 0x040011BF RID: 4543
	public float blendValue;

	// Token: 0x040011C0 RID: 4544
	private float defaultBlend;

	// Token: 0x040011C1 RID: 4545
	private float defaultRotation;

	// Token: 0x040011C2 RID: 4546
	private float rotationSpeedValue;

	// Token: 0x040011C3 RID: 4547
	private int index;

	// Token: 0x040011C4 RID: 4548
	private int indexToBlend;

	// Token: 0x040011C5 RID: 4549
	private int usedBlend;

	// Token: 0x040011C6 RID: 4550
	private int LightAndReflectionFrames;

	// Token: 0x040011C7 RID: 4551
	private bool linearBlending;

	// Token: 0x040011C8 RID: 4552
	private bool currentSkyboxNotFirstMaterialBlending;

	// Token: 0x040011C9 RID: 4553
	private bool comingFromLoop;

	// Token: 0x040011CA RID: 4554
	private bool rotateSkybox;

	// Token: 0x040011CB RID: 4555
	private bool oneTickBlend;

	// Token: 0x040011CC RID: 4556
	private bool stillRunning;

	// Token: 0x040011CD RID: 4557
	private bool singleBlend;

	// Token: 0x040011CE RID: 4558
	private bool stopped;

	// Token: 0x040011CF RID: 4559
	private bool blendByIndex;

	// Token: 0x040011D0 RID: 4560
	private bool stopRotation;

	// Token: 0x040011D1 RID: 4561
	private bool blendFinished;

	// Token: 0x040011D2 RID: 4562
	private bool blendingCurrentSkyToListNotSingleBlend;

	// Token: 0x040011D3 RID: 4563
	private bool isLinearBlend;

	// Token: 0x040011D4 RID: 4564
	private bool isSetReflectionProbeOnStart;

	// Token: 0x040011D5 RID: 4565
	private ReflectionProbe reflectionProbe;

	// Token: 0x040011D6 RID: 4566
	private Cubemap cubemap;
}
