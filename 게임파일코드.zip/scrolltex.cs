﻿using System;
using UnityEngine;

// Token: 0x02000150 RID: 336
public class scrolltex : MonoBehaviour
{
	// Token: 0x06000988 RID: 2440 RVA: 0x000461F0 File Offset: 0x000443F0
	private void Update()
	{
		float x = Time.time * this.Scrollx;
		float y = Time.time * this.Scrolly;
		base.GetComponent<Renderer>().material.mainTextureOffset = new Vector2(x, y);
	}

	// Token: 0x040011E6 RID: 4582
	public float Scrollx = 0.5f;

	// Token: 0x040011E7 RID: 4583
	public float Scrolly = 0.5f;
}
