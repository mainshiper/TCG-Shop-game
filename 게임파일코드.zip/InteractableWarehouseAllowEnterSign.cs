﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x0200002B RID: 43
public class InteractableWarehouseAllowEnterSign : InteractableObject
{
	// Token: 0x0600022E RID: 558 RVA: 0x00015568 File Offset: 0x00013768
	public override void OnMouseButtonUp()
	{
		if (this.m_IsSwapping)
		{
			return;
		}
		CPlayerData.m_IsWarehouseDoorClosed = !CPlayerData.m_IsWarehouseDoorClosed;
		this.m_IsSwapping = true;
		this.m_Anim.Play();
		base.StartCoroutine(this.DelaySwapMesh());
		SoundManager.GenericPop(1f, 1f);
	}

	// Token: 0x0600022F RID: 559 RVA: 0x000155BA File Offset: 0x000137BA
	private IEnumerator DelaySwapMesh()
	{
		yield return new WaitForSeconds(0.6f);
		SoundManager.PlayAudio("SFX_WhipSoft", 0.4f, 1.2f);
		this.EvaluateSignOpenCloseMesh();
		yield return new WaitForSeconds(0.7f);
		this.m_IsSwapping = false;
		yield break;
	}

	// Token: 0x06000230 RID: 560 RVA: 0x000155C9 File Offset: 0x000137C9
	private void EvaluateSignOpenCloseMesh()
	{
		this.m_OpenShopMesh.SetActive(CPlayerData.m_IsWarehouseDoorClosed);
		this.m_CloseShopMesh.SetActive(!CPlayerData.m_IsWarehouseDoorClosed);
		CSingleton<UnlockRoomManager>.Instance.EvaluateWarehouseRoomOpenClose();
	}

	// Token: 0x06000231 RID: 561 RVA: 0x000155F8 File Offset: 0x000137F8
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x06000232 RID: 562 RVA: 0x00015619 File Offset: 0x00013819
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x06000233 RID: 563 RVA: 0x0001563A File Offset: 0x0001383A
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.EvaluateSignOpenCloseMesh();
	}

	// Token: 0x0400026E RID: 622
	public Animation m_Anim;

	// Token: 0x0400026F RID: 623
	public GameObject m_OpenShopMesh;

	// Token: 0x04000270 RID: 624
	public GameObject m_CloseShopMesh;

	// Token: 0x04000271 RID: 625
	private bool m_IsSwapping;

	// Token: 0x04000272 RID: 626
	private bool m_IsDayEnded;
}
