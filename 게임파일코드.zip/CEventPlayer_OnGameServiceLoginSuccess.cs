﻿using System;

// Token: 0x020000BA RID: 186
public class CEventPlayer_OnGameServiceLoginSuccess : CEvent
{
	// Token: 0x1700001E RID: 30
	// (get) Token: 0x06000729 RID: 1833 RVA: 0x0003947B File Offset: 0x0003767B
	// (set) Token: 0x0600072A RID: 1834 RVA: 0x00039483 File Offset: 0x00037683
	public bool m_LoginSuccess { get; private set; }

	// Token: 0x0600072B RID: 1835 RVA: 0x0003948C File Offset: 0x0003768C
	public CEventPlayer_OnGameServiceLoginSuccess(bool loginSuccess)
	{
		this.m_LoginSuccess = loginSuccess;
	}
}
