﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200009A RID: 154
public class UIParticleManager : CSingleton<UIParticleManager>
{
	// Token: 0x060005FD RID: 1533 RVA: 0x000321A1 File Offset: 0x000303A1
	public void Awake()
	{
		this.m_Camera.SetActive(false);
	}

	// Token: 0x060005FE RID: 1534 RVA: 0x000321B0 File Offset: 0x000303B0
	public void Update()
	{
		if (this.m_HasActiveParticle)
		{
			if (this.m_IsLerp)
			{
				this.m_LerpTimer += Time.deltaTime * this.m_LerpSpeed;
				this.m_CurrentParticleTransform.position = Vector3.Lerp(this.m_StartPos, this.m_TargetPos, this.m_LerpTimer);
			}
			this.m_Timer += Time.deltaTime;
			if (this.m_Timer >= this.m_DeactivateTime)
			{
				this.m_CurrentParticleTransform.position = this.m_StartPos;
				this.m_IsLerp = true;
				this.m_HasActiveParticle = false;
				this.m_Camera.SetActive(false);
			}
		}
	}

	// Token: 0x060005FF RID: 1535 RVA: 0x00032258 File Offset: 0x00030458
	public static void SpawnParticle(EParticleType particleType)
	{
		CSingleton<UIParticleManager>.Instance.m_Camera.SetActive(true);
		CSingleton<UIParticleManager>.Instance.m_HasActiveParticle = true;
		CSingleton<UIParticleManager>.Instance.m_Timer = 0f;
		CSingleton<UIParticleManager>.Instance.m_DeactivateTime = CSingleton<UIParticleManager>.Instance.m_DeactivateTimeList[(int)particleType];
		CSingleton<UIParticleManager>.Instance.m_ParticleList[(int)particleType].gameObject.SetActive(true);
		CSingleton<UIParticleManager>.Instance.m_ParticleList[(int)particleType].Play();
	}

	// Token: 0x06000600 RID: 1536 RVA: 0x000322DC File Offset: 0x000304DC
	public static void SpawnParticleMove(EParticleType particleType, Vector3 movePos, float time)
	{
		CSingleton<UIParticleManager>.Instance.m_LerpTimer = 0f;
		if (CSingleton<UIParticleManager>.Instance.m_CurrentParticleTransform)
		{
			CSingleton<UIParticleManager>.Instance.m_CurrentParticleTransform.position = CSingleton<UIParticleManager>.Instance.m_StartPos;
		}
		UIParticleManager.SpawnParticle(particleType);
		CSingleton<UIParticleManager>.Instance.m_CurrentParticleTransform = CSingleton<UIParticleManager>.Instance.m_ParticleList[(int)particleType].transform;
		CSingleton<UIParticleManager>.Instance.m_StartPos = CSingleton<UIParticleManager>.Instance.m_CurrentParticleTransform.position;
		CSingleton<UIParticleManager>.Instance.m_TargetPos = CSingleton<UIParticleManager>.Instance.m_StartPos + movePos;
		if (time <= 0f)
		{
			time = 0.01f;
		}
		CSingleton<UIParticleManager>.Instance.m_LerpSpeed = 1f / time;
		CSingleton<UIParticleManager>.Instance.m_IsLerp = true;
	}

	// Token: 0x040007D1 RID: 2001
	public GameObject m_Camera;

	// Token: 0x040007D2 RID: 2002
	public List<ParticleSystem> m_ParticleList;

	// Token: 0x040007D3 RID: 2003
	public List<float> m_DeactivateTimeList;

	// Token: 0x040007D4 RID: 2004
	private bool m_HasActiveParticle;

	// Token: 0x040007D5 RID: 2005
	private float m_Timer;

	// Token: 0x040007D6 RID: 2006
	private float m_DeactivateTime = 3f;

	// Token: 0x040007D7 RID: 2007
	private bool m_IsLerp;

	// Token: 0x040007D8 RID: 2008
	private float m_LerpTimer;

	// Token: 0x040007D9 RID: 2009
	private float m_LerpSpeed = 1f;

	// Token: 0x040007DA RID: 2010
	private Vector3 m_StartPos;

	// Token: 0x040007DB RID: 2011
	private Vector3 m_TargetPos;

	// Token: 0x040007DC RID: 2012
	private Transform m_CurrentParticleTransform;
}
