﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace LayerLab.CasualGame
{
	// Token: 0x020001AC RID: 428
	public class PanelControlCasualGame : MonoBehaviour
	{
		// Token: 0x06000C60 RID: 3168 RVA: 0x00057124 File Offset: 0x00055324
		private void Start()
		{
			this.textTitle = base.transform.GetComponentInChildren<TextMeshProUGUI>();
			this.buttonPrev.onClick.AddListener(new UnityAction(this.Click_Prev));
			this.buttonNext.onClick.AddListener(new UnityAction(this.Click_Next));
			foreach (object obj in this.panelTransform)
			{
				Transform transform = (Transform)obj;
				this.panels.Add(transform.gameObject);
				transform.gameObject.SetActive(false);
			}
			this.panels[this.page].SetActive(true);
			this.isReady = true;
			this.CheckControl();
		}

		// Token: 0x06000C61 RID: 3169 RVA: 0x00057200 File Offset: 0x00055400
		private void Update()
		{
			if (this.panels.Count <= 0 || !this.isReady)
			{
				return;
			}
			if (Input.GetKeyDown(KeyCode.LeftArrow))
			{
				this.Click_Prev();
				return;
			}
			if (Input.GetKeyDown(KeyCode.RightArrow))
			{
				this.Click_Next();
			}
		}

		// Token: 0x06000C62 RID: 3170 RVA: 0x00057240 File Offset: 0x00055440
		public void Click_Prev()
		{
			if (this.page <= 0 || !this.isReady)
			{
				return;
			}
			this.panels[this.page].SetActive(false);
			this.panels[--this.page].SetActive(true);
			this.textTitle.text = this.panels[this.page].name;
			this.CheckControl();
		}

		// Token: 0x06000C63 RID: 3171 RVA: 0x000572C0 File Offset: 0x000554C0
		public void Click_Next()
		{
			if (this.page >= this.panels.Count - 1)
			{
				return;
			}
			this.panels[this.page].SetActive(false);
			this.panels[++this.page].SetActive(true);
			this.CheckControl();
		}

		// Token: 0x06000C64 RID: 3172 RVA: 0x00057322 File Offset: 0x00055522
		private void SetArrowActive()
		{
			this.buttonPrev.gameObject.SetActive(this.page > 0);
			this.buttonNext.gameObject.SetActive(this.page < this.panels.Count - 1);
		}

		// Token: 0x06000C65 RID: 3173 RVA: 0x00057362 File Offset: 0x00055562
		private void CheckControl()
		{
			this.textTitle.text = this.panels[this.page].name.Replace("_", " ");
			this.SetArrowActive();
		}

		// Token: 0x0400133C RID: 4924
		private int page;

		// Token: 0x0400133D RID: 4925
		private bool isReady;

		// Token: 0x0400133E RID: 4926
		[SerializeField]
		private List<GameObject> panels = new List<GameObject>();

		// Token: 0x0400133F RID: 4927
		private TextMeshProUGUI textTitle;

		// Token: 0x04001340 RID: 4928
		[SerializeField]
		private Transform panelTransform;

		// Token: 0x04001341 RID: 4929
		[SerializeField]
		private Button buttonPrev;

		// Token: 0x04001342 RID: 4930
		[SerializeField]
		private Button buttonNext;
	}
}
