﻿using System;

// Token: 0x02000033 RID: 51
[Serializable]
public class RestockData
{
	// Token: 0x04000316 RID: 790
	public string name;

	// Token: 0x04000317 RID: 791
	public bool isBigBox;

	// Token: 0x04000318 RID: 792
	public bool ignoreDoubleImage;

	// Token: 0x04000319 RID: 793
	public int index;

	// Token: 0x0400031A RID: 794
	public int amount;

	// Token: 0x0400031B RID: 795
	public int licenseShopLevelRequired;

	// Token: 0x0400031C RID: 796
	public float licensePrice;

	// Token: 0x0400031D RID: 797
	public EItemType itemType;

	// Token: 0x0400031E RID: 798
	public bool prologueShow;

	// Token: 0x0400031F RID: 799
	public bool isHideItemUntilUnlocked;
}
