﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000142 RID: 322
public class ETFXSceneManager : MonoBehaviour
{
	// Token: 0x06000927 RID: 2343 RVA: 0x00043787 File Offset: 0x00041987
	public void LoadScene1()
	{
		SceneManager.LoadScene("etfx_explosions");
	}

	// Token: 0x06000928 RID: 2344 RVA: 0x00043793 File Offset: 0x00041993
	public void LoadScene2()
	{
		SceneManager.LoadScene("etfx_explosions2");
	}

	// Token: 0x06000929 RID: 2345 RVA: 0x0004379F File Offset: 0x0004199F
	public void LoadScene3()
	{
		SceneManager.LoadScene("etfx_portals");
	}

	// Token: 0x0600092A RID: 2346 RVA: 0x000437AB File Offset: 0x000419AB
	public void LoadScene4()
	{
		SceneManager.LoadScene("etfx_magic");
	}

	// Token: 0x0600092B RID: 2347 RVA: 0x000437B7 File Offset: 0x000419B7
	public void LoadScene5()
	{
		SceneManager.LoadScene("etfx_emojis");
	}

	// Token: 0x0600092C RID: 2348 RVA: 0x000437C3 File Offset: 0x000419C3
	public void LoadScene6()
	{
		SceneManager.LoadScene("etfx_sparkles");
	}

	// Token: 0x0600092D RID: 2349 RVA: 0x000437CF File Offset: 0x000419CF
	public void LoadScene7()
	{
		SceneManager.LoadScene("etfx_fireworks");
	}

	// Token: 0x0600092E RID: 2350 RVA: 0x000437DB File Offset: 0x000419DB
	public void LoadScene8()
	{
		SceneManager.LoadScene("etfx_powerups");
	}

	// Token: 0x0600092F RID: 2351 RVA: 0x000437E7 File Offset: 0x000419E7
	public void LoadScene9()
	{
		SceneManager.LoadScene("etfx_swordcombat");
	}

	// Token: 0x06000930 RID: 2352 RVA: 0x000437F3 File Offset: 0x000419F3
	public void LoadScene10()
	{
		SceneManager.LoadScene("etfx_maindemo");
	}

	// Token: 0x06000931 RID: 2353 RVA: 0x000437FF File Offset: 0x000419FF
	public void LoadScene11()
	{
		SceneManager.LoadScene("etfx_combat");
	}

	// Token: 0x06000932 RID: 2354 RVA: 0x0004380B File Offset: 0x00041A0B
	public void LoadScene12()
	{
		SceneManager.LoadScene("etfx_2ddemo");
	}

	// Token: 0x06000933 RID: 2355 RVA: 0x00043817 File Offset: 0x00041A17
	public void LoadScene13()
	{
		SceneManager.LoadScene("etfx_missiles");
	}

	// Token: 0x06000934 RID: 2356 RVA: 0x00043824 File Offset: 0x00041A24
	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.L))
		{
			this.GUIHide = !this.GUIHide;
			if (this.GUIHide)
			{
				GameObject.Find("CanvasSceneSelect").GetComponent<Canvas>().enabled = false;
			}
			else
			{
				GameObject.Find("CanvasSceneSelect").GetComponent<Canvas>().enabled = true;
			}
		}
		if (Input.GetKeyDown(KeyCode.J))
		{
			this.GUIHide2 = !this.GUIHide2;
			if (this.GUIHide2)
			{
				GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
			}
			else
			{
				GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
			}
		}
		if (Input.GetKeyDown(KeyCode.H))
		{
			this.GUIHide3 = !this.GUIHide3;
			if (this.GUIHide3)
			{
				GameObject.Find("ParticleSysDisplayCanvas").GetComponent<Canvas>().enabled = false;
				return;
			}
			GameObject.Find("ParticleSysDisplayCanvas").GetComponent<Canvas>().enabled = true;
		}
	}

	// Token: 0x04001155 RID: 4437
	public bool GUIHide;

	// Token: 0x04001156 RID: 4438
	public bool GUIHide2;

	// Token: 0x04001157 RID: 4439
	public bool GUIHide3;
}
