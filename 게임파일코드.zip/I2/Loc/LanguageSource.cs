﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x0200016A RID: 362
	[AddComponentMenu("I2/Localization/Source")]
	[ExecuteInEditMode]
	public class LanguageSource : MonoBehaviour, ISerializationCallbackReceiver, ILanguageSource
	{
		// Token: 0x17000037 RID: 55
		// (get) Token: 0x06000A13 RID: 2579 RVA: 0x0004C68A File Offset: 0x0004A88A
		// (set) Token: 0x06000A14 RID: 2580 RVA: 0x0004C692 File Offset: 0x0004A892
		public LanguageSourceData SourceData
		{
			get
			{
				return this.mSource;
			}
			set
			{
				this.mSource = value;
			}
		}

		// Token: 0x14000001 RID: 1
		// (add) Token: 0x06000A15 RID: 2581 RVA: 0x0004C69C File Offset: 0x0004A89C
		// (remove) Token: 0x06000A16 RID: 2582 RVA: 0x0004C6D4 File Offset: 0x0004A8D4
		public event LanguageSource.fnOnSourceUpdated Event_OnSourceUpdateFromGoogle;

		// Token: 0x06000A17 RID: 2583 RVA: 0x0004C709 File Offset: 0x0004A909
		private void Awake()
		{
			this.mSource.owner = this;
			this.mSource.Awake();
		}

		// Token: 0x06000A18 RID: 2584 RVA: 0x0004C722 File Offset: 0x0004A922
		private void OnDestroy()
		{
			this.NeverDestroy = false;
			if (!this.NeverDestroy)
			{
				this.mSource.OnDestroy();
			}
		}

		// Token: 0x06000A19 RID: 2585 RVA: 0x0004C740 File Offset: 0x0004A940
		public string GetSourceName()
		{
			string text = base.gameObject.name;
			Transform parent = base.transform.parent;
			while (parent)
			{
				text = parent.name + "_" + text;
				parent = parent.parent;
			}
			return text;
		}

		// Token: 0x06000A1A RID: 2586 RVA: 0x0004C789 File Offset: 0x0004A989
		public void OnBeforeSerialize()
		{
			this.version = 1;
		}

		// Token: 0x06000A1B RID: 2587 RVA: 0x0004C794 File Offset: 0x0004A994
		public void OnAfterDeserialize()
		{
			if (this.version == 0 || this.mSource == null)
			{
				this.mSource = new LanguageSourceData();
				this.mSource.owner = this;
				this.mSource.UserAgreesToHaveItOnTheScene = this.UserAgreesToHaveItOnTheScene;
				this.mSource.UserAgreesToHaveItInsideThePluginsFolder = this.UserAgreesToHaveItInsideThePluginsFolder;
				this.mSource.IgnoreDeviceLanguage = this.IgnoreDeviceLanguage;
				this.mSource._AllowUnloadingLanguages = this._AllowUnloadingLanguages;
				this.mSource.CaseInsensitiveTerms = this.CaseInsensitiveTerms;
				this.mSource.OnMissingTranslation = this.OnMissingTranslation;
				this.mSource.mTerm_AppName = this.mTerm_AppName;
				this.mSource.GoogleLiveSyncIsUptoDate = this.GoogleLiveSyncIsUptoDate;
				this.mSource.Google_WebServiceURL = this.Google_WebServiceURL;
				this.mSource.Google_SpreadsheetKey = this.Google_SpreadsheetKey;
				this.mSource.Google_SpreadsheetName = this.Google_SpreadsheetName;
				this.mSource.Google_LastUpdatedVersion = this.Google_LastUpdatedVersion;
				this.mSource.GoogleUpdateFrequency = this.GoogleUpdateFrequency;
				this.mSource.GoogleUpdateDelay = this.GoogleUpdateDelay;
				this.mSource.Event_OnSourceUpdateFromGoogle += this.Event_OnSourceUpdateFromGoogle;
				if (this.mLanguages != null && this.mLanguages.Count > 0)
				{
					this.mSource.mLanguages.Clear();
					this.mSource.mLanguages.AddRange(this.mLanguages);
					this.mLanguages.Clear();
				}
				if (this.Assets != null && this.Assets.Count > 0)
				{
					this.mSource.Assets.Clear();
					this.mSource.Assets.AddRange(this.Assets);
					this.Assets.Clear();
				}
				if (this.mTerms != null && this.mTerms.Count > 0)
				{
					this.mSource.mTerms.Clear();
					for (int i = 0; i < this.mTerms.Count; i++)
					{
						this.mSource.mTerms.Add(this.mTerms[i]);
					}
					this.mTerms.Clear();
				}
				this.version = 1;
				this.Event_OnSourceUpdateFromGoogle = null;
			}
		}

		// Token: 0x04001221 RID: 4641
		public LanguageSourceData mSource = new LanguageSourceData();

		// Token: 0x04001222 RID: 4642
		public int version;

		// Token: 0x04001223 RID: 4643
		public bool NeverDestroy;

		// Token: 0x04001224 RID: 4644
		public bool UserAgreesToHaveItOnTheScene;

		// Token: 0x04001225 RID: 4645
		public bool UserAgreesToHaveItInsideThePluginsFolder;

		// Token: 0x04001226 RID: 4646
		public bool GoogleLiveSyncIsUptoDate = true;

		// Token: 0x04001227 RID: 4647
		public List<Object> Assets = new List<Object>();

		// Token: 0x04001228 RID: 4648
		public string Google_WebServiceURL;

		// Token: 0x04001229 RID: 4649
		public string Google_SpreadsheetKey;

		// Token: 0x0400122A RID: 4650
		public string Google_SpreadsheetName;

		// Token: 0x0400122B RID: 4651
		public string Google_LastUpdatedVersion;

		// Token: 0x0400122C RID: 4652
		public LanguageSourceData.eGoogleUpdateFrequency GoogleUpdateFrequency = LanguageSourceData.eGoogleUpdateFrequency.Weekly;

		// Token: 0x0400122D RID: 4653
		public float GoogleUpdateDelay = 5f;

		// Token: 0x0400122F RID: 4655
		public List<LanguageData> mLanguages = new List<LanguageData>();

		// Token: 0x04001230 RID: 4656
		public bool IgnoreDeviceLanguage;

		// Token: 0x04001231 RID: 4657
		public LanguageSourceData.eAllowUnloadLanguages _AllowUnloadingLanguages;

		// Token: 0x04001232 RID: 4658
		public List<TermData> mTerms = new List<TermData>();

		// Token: 0x04001233 RID: 4659
		public bool CaseInsensitiveTerms;

		// Token: 0x04001234 RID: 4660
		public LanguageSourceData.MissingTranslationAction OnMissingTranslation = LanguageSourceData.MissingTranslationAction.Fallback;

		// Token: 0x04001235 RID: 4661
		public string mTerm_AppName;

		// Token: 0x02000247 RID: 583
		// (Invoke) Token: 0x06000F93 RID: 3987
		public delegate void fnOnSourceUpdated(LanguageSourceData source, bool ReceivedNewData, string errorMsg);
	}
}
