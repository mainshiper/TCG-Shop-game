﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000151 RID: 337
	public class CallbackNotification : MonoBehaviour
	{
		// Token: 0x0600098A RID: 2442 RVA: 0x0004624C File Offset: 0x0004444C
		public void OnModifyLocalization()
		{
			if (string.IsNullOrEmpty(Localize.MainTranslation))
			{
				return;
			}
			string translation = LocalizationManager.GetTranslation("Color/Red", true, 0, true, false, null, null, true);
			Localize.MainTranslation = Localize.MainTranslation.Replace("{PLAYER_COLOR}", translation);
		}
	}
}
