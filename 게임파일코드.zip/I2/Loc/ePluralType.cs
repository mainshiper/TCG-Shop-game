﻿using System;

namespace I2.Loc
{
	// Token: 0x0200015E RID: 350
	public enum ePluralType
	{
		// Token: 0x040011F5 RID: 4597
		Zero,
		// Token: 0x040011F6 RID: 4598
		One,
		// Token: 0x040011F7 RID: 4599
		Two,
		// Token: 0x040011F8 RID: 4600
		Few,
		// Token: 0x040011F9 RID: 4601
		Many,
		// Token: 0x040011FA RID: 4602
		Plural
	}
}
