﻿using System;
using UnityEngine.Networking;

namespace I2.Loc
{
	// Token: 0x02000163 RID: 355
	public class TranslationJob_WWW : TranslationJob
	{
		// Token: 0x060009FA RID: 2554 RVA: 0x0004BD8C File Offset: 0x00049F8C
		public override void Dispose()
		{
			if (this.www != null)
			{
				this.www.Dispose();
			}
			this.www = null;
		}

		// Token: 0x04001205 RID: 4613
		public UnityWebRequest www;
	}
}
