﻿using System;

namespace I2.Loc
{
	// Token: 0x0200016C RID: 364
	public interface ILanguageSource
	{
		// Token: 0x17000039 RID: 57
		// (get) Token: 0x06000A20 RID: 2592
		// (set) Token: 0x06000A21 RID: 2593
		LanguageSourceData SourceData { get; set; }
	}
}
