﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x0200017F RID: 383
	public class LocalizeTarget_UnityStandard_Prefab : LocalizeTarget<GameObject>
	{
		// Token: 0x06000B32 RID: 2866 RVA: 0x000527A5 File Offset: 0x000509A5
		static LocalizeTarget_UnityStandard_Prefab()
		{
			LocalizeTarget_UnityStandard_Prefab.AutoRegister();
		}

		// Token: 0x06000B33 RID: 2867 RVA: 0x000527AC File Offset: 0x000509AC
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
			LocalizationManager.RegisterTarget(new LocalizeTargetDesc_Prefab
			{
				Name = "Prefab",
				Priority = 250
			});
		}

		// Token: 0x06000B34 RID: 2868 RVA: 0x000527CE File Offset: 0x000509CE
		public override bool IsValid(Localize cmp)
		{
			return true;
		}

		// Token: 0x06000B35 RID: 2869 RVA: 0x000527D1 File Offset: 0x000509D1
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.GameObject;
		}

		// Token: 0x06000B36 RID: 2870 RVA: 0x000527D4 File Offset: 0x000509D4
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06000B37 RID: 2871 RVA: 0x000527D7 File Offset: 0x000509D7
		public override bool CanUseSecondaryTerm()
		{
			return false;
		}

		// Token: 0x06000B38 RID: 2872 RVA: 0x000527DA File Offset: 0x000509DA
		public override bool AllowMainTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B39 RID: 2873 RVA: 0x000527DD File Offset: 0x000509DD
		public override bool AllowSecondTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B3A RID: 2874 RVA: 0x000527E0 File Offset: 0x000509E0
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
			primaryTerm = cmp.name;
			secondaryTerm = null;
		}

		// Token: 0x06000B3B RID: 2875 RVA: 0x000527F0 File Offset: 0x000509F0
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
			if (string.IsNullOrEmpty(mainTranslation))
			{
				return;
			}
			if (this.mTarget && this.mTarget.name == mainTranslation)
			{
				return;
			}
			Transform transform = cmp.transform;
			string text = mainTranslation;
			int num = mainTranslation.LastIndexOfAny(LanguageSourceData.CategorySeparators);
			if (num >= 0)
			{
				text = text.Substring(num + 1);
			}
			Transform transform2 = this.InstantiateNewPrefab(cmp, mainTranslation);
			if (transform2 == null)
			{
				return;
			}
			transform2.name = text;
			for (int i = transform.childCount - 1; i >= 0; i--)
			{
				Transform child = transform.GetChild(i);
				if (child != transform2)
				{
					Object.Destroy(child.gameObject);
				}
			}
		}

		// Token: 0x06000B3C RID: 2876 RVA: 0x0005289C File Offset: 0x00050A9C
		private Transform InstantiateNewPrefab(Localize cmp, string mainTranslation)
		{
			GameObject gameObject = cmp.FindTranslatedObject<GameObject>(mainTranslation);
			if (gameObject == null)
			{
				return null;
			}
			GameObject mTarget = this.mTarget;
			this.mTarget = Object.Instantiate<GameObject>(gameObject);
			if (this.mTarget == null)
			{
				return null;
			}
			Transform transform = cmp.transform;
			Transform transform2 = this.mTarget.transform;
			transform2.SetParent(transform);
			Transform transform3 = mTarget ? mTarget.transform : transform;
			transform2.rotation = transform3.rotation;
			transform2.position = transform3.position;
			return transform2;
		}
	}
}
