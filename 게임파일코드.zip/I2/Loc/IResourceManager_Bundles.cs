﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000194 RID: 404
	public interface IResourceManager_Bundles
	{
		// Token: 0x06000BB8 RID: 3000
		Object LoadFromBundle(string path, Type assetType);
	}
}
