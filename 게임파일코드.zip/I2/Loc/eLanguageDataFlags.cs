﻿using System;

namespace I2.Loc
{
	// Token: 0x02000168 RID: 360
	public enum eLanguageDataFlags
	{
		// Token: 0x0400121A RID: 4634
		DISABLED = 1,
		// Token: 0x0400121B RID: 4635
		KEEP_LOADED,
		// Token: 0x0400121C RID: 4636
		NOT_LOADED = 4
	}
}
