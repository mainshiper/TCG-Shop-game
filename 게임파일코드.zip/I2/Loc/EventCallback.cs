﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x0200015D RID: 349
	[Serializable]
	public class EventCallback
	{
		// Token: 0x060009C8 RID: 2504 RVA: 0x000471E8 File Offset: 0x000453E8
		public void Execute(Object Sender = null)
		{
			if (this.HasCallback() && Application.isPlaying)
			{
				this.Target.gameObject.SendMessage(this.MethodName, Sender, SendMessageOptions.DontRequireReceiver);
			}
		}

		// Token: 0x060009C9 RID: 2505 RVA: 0x00047211 File Offset: 0x00045411
		public bool HasCallback()
		{
			return this.Target != null && !string.IsNullOrEmpty(this.MethodName);
		}

		// Token: 0x040011F2 RID: 4594
		public MonoBehaviour Target;

		// Token: 0x040011F3 RID: 4595
		public string MethodName = string.Empty;
	}
}
