﻿using System;

namespace I2.Loc
{
	// Token: 0x02000187 RID: 391
	public enum TranslationFlag : byte
	{
		// Token: 0x040012AA RID: 4778
		Normal = 1,
		// Token: 0x040012AB RID: 4779
		AutoTranslated
	}
}
