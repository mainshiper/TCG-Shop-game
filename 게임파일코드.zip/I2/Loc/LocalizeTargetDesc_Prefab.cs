﻿using System;

namespace I2.Loc
{
	// Token: 0x0200017E RID: 382
	public class LocalizeTargetDesc_Prefab : LocalizeTargetDesc<LocalizeTarget_UnityStandard_Prefab>
	{
		// Token: 0x06000B30 RID: 2864 RVA: 0x0005279A File Offset: 0x0005099A
		public override bool CanLocalize(Localize cmp)
		{
			return true;
		}
	}
}
