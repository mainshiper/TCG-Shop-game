﻿using System;

namespace I2.Loc
{
	// Token: 0x0200016E RID: 366
	public enum eSpreadsheetUpdateMode
	{
		// Token: 0x04001253 RID: 4691
		None,
		// Token: 0x04001254 RID: 4692
		Replace,
		// Token: 0x04001255 RID: 4693
		Merge,
		// Token: 0x04001256 RID: 4694
		AddNewTerms
	}
}
