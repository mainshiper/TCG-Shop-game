﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.Events;

namespace I2.Loc
{
	// Token: 0x02000170 RID: 368
	[AddComponentMenu("I2/Localization/I2 Localize")]
	public class Localize : MonoBehaviour
	{
		// Token: 0x1700003B RID: 59
		// (get) Token: 0x06000A7C RID: 2684 RVA: 0x0004F678 File Offset: 0x0004D878
		// (set) Token: 0x06000A7D RID: 2685 RVA: 0x0004F680 File Offset: 0x0004D880
		public string Term
		{
			get
			{
				return this.mTerm;
			}
			set
			{
				this.SetTerm(value);
			}
		}

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x06000A7E RID: 2686 RVA: 0x0004F689 File Offset: 0x0004D889
		// (set) Token: 0x06000A7F RID: 2687 RVA: 0x0004F691 File Offset: 0x0004D891
		public string SecondaryTerm
		{
			get
			{
				return this.mTermSecondary;
			}
			set
			{
				this.SetTerm(null, value);
			}
		}

		// Token: 0x06000A80 RID: 2688 RVA: 0x0004F69B File Offset: 0x0004D89B
		private void Awake()
		{
			this.UpdateAssetDictionary();
			this.FindTarget();
			if (this.LocalizeOnAwake)
			{
				this.OnLocalize(false);
			}
		}

		// Token: 0x06000A81 RID: 2689 RVA: 0x0004F6B9 File Offset: 0x0004D8B9
		private void OnEnable()
		{
			this.OnLocalize(false);
		}

		// Token: 0x06000A82 RID: 2690 RVA: 0x0004F6C2 File Offset: 0x0004D8C2
		public bool HasCallback()
		{
			return this.LocalizeCallBack.HasCallback() || this.LocalizeEvent.GetPersistentEventCount() > 0;
		}

		// Token: 0x06000A83 RID: 2691 RVA: 0x0004F6E4 File Offset: 0x0004D8E4
		public void OnLocalize(bool Force = false)
		{
			if (!Force && (!base.enabled || base.gameObject == null || !base.gameObject.activeInHierarchy))
			{
				return;
			}
			if (string.IsNullOrEmpty(LocalizationManager.CurrentLanguage))
			{
				return;
			}
			if (!this.AlwaysForceLocalize && !Force && !this.HasCallback() && this.LastLocalizedLanguage == LocalizationManager.CurrentLanguage)
			{
				return;
			}
			this.LastLocalizedLanguage = LocalizationManager.CurrentLanguage;
			if (string.IsNullOrEmpty(this.FinalTerm) || string.IsNullOrEmpty(this.FinalSecondaryTerm))
			{
				this.GetFinalTerms(out this.FinalTerm, out this.FinalSecondaryTerm);
			}
			bool flag = I2Utils.IsPlaying() && this.HasCallback();
			if (!flag && string.IsNullOrEmpty(this.FinalTerm) && string.IsNullOrEmpty(this.FinalSecondaryTerm))
			{
				return;
			}
			Localize.CallBackTerm = this.FinalTerm;
			Localize.CallBackSecondaryTerm = this.FinalSecondaryTerm;
			Localize.MainTranslation = ((string.IsNullOrEmpty(this.FinalTerm) || this.FinalTerm == "-") ? null : LocalizationManager.GetTranslation(this.FinalTerm, false, 0, true, false, null, null, true));
			Localize.SecondaryTranslation = ((string.IsNullOrEmpty(this.FinalSecondaryTerm) || this.FinalSecondaryTerm == "-") ? null : LocalizationManager.GetTranslation(this.FinalSecondaryTerm, false, 0, true, false, null, null, true));
			if (!flag && string.IsNullOrEmpty(this.FinalTerm) && string.IsNullOrEmpty(Localize.SecondaryTranslation))
			{
				return;
			}
			Localize.CurrentLocalizeComponent = this;
			this.LocalizeCallBack.Execute(this);
			this.LocalizeEvent.Invoke();
			if (this.AllowParameters)
			{
				LocalizationManager.ApplyLocalizationParams(ref Localize.MainTranslation, base.gameObject, this.AllowLocalizedParameters);
			}
			if (!this.FindTarget())
			{
				return;
			}
			bool flag2 = LocalizationManager.IsRight2Left && !this.IgnoreRTL;
			if (Localize.MainTranslation != null)
			{
				switch (this.PrimaryTermModifier)
				{
				case Localize.TermModification.ToUpper:
					Localize.MainTranslation = Localize.MainTranslation.ToUpper();
					break;
				case Localize.TermModification.ToLower:
					Localize.MainTranslation = Localize.MainTranslation.ToLower();
					break;
				case Localize.TermModification.ToUpperFirst:
					Localize.MainTranslation = GoogleTranslation.UppercaseFirst(Localize.MainTranslation);
					break;
				case Localize.TermModification.ToTitle:
					Localize.MainTranslation = GoogleTranslation.TitleCase(Localize.MainTranslation);
					break;
				}
				if (!string.IsNullOrEmpty(this.TermPrefix))
				{
					Localize.MainTranslation = (flag2 ? (Localize.MainTranslation + this.TermPrefix) : (this.TermPrefix + Localize.MainTranslation));
				}
				if (!string.IsNullOrEmpty(this.TermSuffix))
				{
					Localize.MainTranslation = (flag2 ? (this.TermSuffix + Localize.MainTranslation) : (Localize.MainTranslation + this.TermSuffix));
				}
				if (this.AddSpacesToJoinedLanguages && LocalizationManager.HasJoinedWords && !string.IsNullOrEmpty(Localize.MainTranslation))
				{
					StringBuilder stringBuilder = new StringBuilder();
					stringBuilder.Append(Localize.MainTranslation[0]);
					int i = 1;
					int length = Localize.MainTranslation.Length;
					while (i < length)
					{
						stringBuilder.Append(' ');
						stringBuilder.Append(Localize.MainTranslation[i]);
						i++;
					}
					Localize.MainTranslation = stringBuilder.ToString();
				}
				if (flag2 && this.mLocalizeTarget.AllowMainTermToBeRTL() && !string.IsNullOrEmpty(Localize.MainTranslation))
				{
					Localize.MainTranslation = LocalizationManager.ApplyRTLfix(Localize.MainTranslation, this.MaxCharactersInRTL, this.IgnoreNumbersInRTL);
				}
			}
			if (Localize.SecondaryTranslation != null)
			{
				switch (this.SecondaryTermModifier)
				{
				case Localize.TermModification.ToUpper:
					Localize.SecondaryTranslation = Localize.SecondaryTranslation.ToUpper();
					break;
				case Localize.TermModification.ToLower:
					Localize.SecondaryTranslation = Localize.SecondaryTranslation.ToLower();
					break;
				case Localize.TermModification.ToUpperFirst:
					Localize.SecondaryTranslation = GoogleTranslation.UppercaseFirst(Localize.SecondaryTranslation);
					break;
				case Localize.TermModification.ToTitle:
					Localize.SecondaryTranslation = GoogleTranslation.TitleCase(Localize.SecondaryTranslation);
					break;
				}
				if (flag2 && this.mLocalizeTarget.AllowSecondTermToBeRTL() && !string.IsNullOrEmpty(Localize.SecondaryTranslation))
				{
					Localize.SecondaryTranslation = LocalizationManager.ApplyRTLfix(Localize.SecondaryTranslation);
				}
			}
			if (LocalizationManager.HighlightLocalizedTargets)
			{
				Localize.MainTranslation = "LOC:" + this.FinalTerm;
			}
			this.mLocalizeTarget.DoLocalize(this, Localize.MainTranslation, Localize.SecondaryTranslation);
			Localize.CurrentLocalizeComponent = null;
		}

		// Token: 0x06000A84 RID: 2692 RVA: 0x0004FB08 File Offset: 0x0004DD08
		public bool FindTarget()
		{
			if (this.mLocalizeTarget != null && this.mLocalizeTarget.IsValid(this))
			{
				return true;
			}
			if (this.mLocalizeTarget != null)
			{
				Object.DestroyImmediate(this.mLocalizeTarget);
				this.mLocalizeTarget = null;
				this.mLocalizeTargetName = null;
			}
			if (!string.IsNullOrEmpty(this.mLocalizeTargetName))
			{
				foreach (ILocalizeTargetDescriptor localizeTargetDescriptor in LocalizationManager.mLocalizeTargets)
				{
					if (this.mLocalizeTargetName == localizeTargetDescriptor.GetTargetType().ToString())
					{
						if (localizeTargetDescriptor.CanLocalize(this))
						{
							this.mLocalizeTarget = localizeTargetDescriptor.CreateTarget(this);
						}
						if (this.mLocalizeTarget != null)
						{
							return true;
						}
					}
				}
			}
			foreach (ILocalizeTargetDescriptor localizeTargetDescriptor2 in LocalizationManager.mLocalizeTargets)
			{
				if (localizeTargetDescriptor2.CanLocalize(this))
				{
					this.mLocalizeTarget = localizeTargetDescriptor2.CreateTarget(this);
					this.mLocalizeTargetName = localizeTargetDescriptor2.GetTargetType().ToString();
					if (this.mLocalizeTarget != null)
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x06000A85 RID: 2693 RVA: 0x0004FC60 File Offset: 0x0004DE60
		public void GetFinalTerms(out string primaryTerm, out string secondaryTerm)
		{
			primaryTerm = string.Empty;
			secondaryTerm = string.Empty;
			if (!this.FindTarget())
			{
				return;
			}
			if (this.mLocalizeTarget != null)
			{
				this.mLocalizeTarget.GetFinalTerms(this, this.mTerm, this.mTermSecondary, out primaryTerm, out secondaryTerm);
				primaryTerm = I2Utils.GetValidTermName(primaryTerm, false);
			}
			if (!string.IsNullOrEmpty(this.mTerm))
			{
				primaryTerm = this.mTerm;
			}
			if (!string.IsNullOrEmpty(this.mTermSecondary))
			{
				secondaryTerm = this.mTermSecondary;
			}
			if (primaryTerm != null)
			{
				primaryTerm = primaryTerm.Trim();
			}
			if (secondaryTerm != null)
			{
				secondaryTerm = secondaryTerm.Trim();
			}
		}

		// Token: 0x06000A86 RID: 2694 RVA: 0x0004FCFC File Offset: 0x0004DEFC
		public string GetMainTargetsText()
		{
			string text = null;
			string text2 = null;
			if (this.mLocalizeTarget != null)
			{
				this.mLocalizeTarget.GetFinalTerms(this, null, null, out text, out text2);
			}
			if (!string.IsNullOrEmpty(text))
			{
				return text;
			}
			return this.mTerm;
		}

		// Token: 0x06000A87 RID: 2695 RVA: 0x0004FD3D File Offset: 0x0004DF3D
		public void SetFinalTerms(string Main, string Secondary, out string primaryTerm, out string secondaryTerm, bool RemoveNonASCII)
		{
			primaryTerm = (RemoveNonASCII ? I2Utils.GetValidTermName(Main, false) : Main);
			secondaryTerm = Secondary;
		}

		// Token: 0x06000A88 RID: 2696 RVA: 0x0004FD54 File Offset: 0x0004DF54
		public void SetTerm(string primary)
		{
			if (!string.IsNullOrEmpty(primary))
			{
				this.mTerm = primary;
				this.FinalTerm = primary;
			}
			this.OnLocalize(true);
		}

		// Token: 0x06000A89 RID: 2697 RVA: 0x0004FD80 File Offset: 0x0004DF80
		public void SetTerm(string primary, string secondary)
		{
			if (!string.IsNullOrEmpty(primary))
			{
				this.mTerm = primary;
				this.FinalTerm = primary;
			}
			this.mTermSecondary = secondary;
			this.FinalSecondaryTerm = secondary;
			this.OnLocalize(true);
		}

		// Token: 0x06000A8A RID: 2698 RVA: 0x0004FDBC File Offset: 0x0004DFBC
		internal T GetSecondaryTranslatedObj<T>(ref string mainTranslation, ref string secondaryTranslation) where T : Object
		{
			string text;
			string text2;
			this.DeserializeTranslation(mainTranslation, out text, out text2);
			T t = default(T);
			if (!string.IsNullOrEmpty(text2))
			{
				t = this.GetObject<T>(text2);
				if (t != null)
				{
					mainTranslation = text;
					secondaryTranslation = text2;
				}
			}
			if (t == null)
			{
				t = this.GetObject<T>(secondaryTranslation);
			}
			return t;
		}

		// Token: 0x06000A8B RID: 2699 RVA: 0x0004FE1C File Offset: 0x0004E01C
		public void UpdateAssetDictionary()
		{
			this.TranslatedObjects.RemoveAll((Object x) => x == null);
			this.mAssetDictionary = (from o in this.TranslatedObjects.Distinct<Object>()
			group o by o.name).ToDictionary((IGrouping<string, Object> g) => g.Key, (IGrouping<string, Object> g) => g.First<Object>());
		}

		// Token: 0x06000A8C RID: 2700 RVA: 0x0004FECC File Offset: 0x0004E0CC
		internal T GetObject<T>(string Translation) where T : Object
		{
			if (string.IsNullOrEmpty(Translation))
			{
				return default(T);
			}
			return this.GetTranslatedObject<T>(Translation);
		}

		// Token: 0x06000A8D RID: 2701 RVA: 0x0004FEF2 File Offset: 0x0004E0F2
		private T GetTranslatedObject<T>(string Translation) where T : Object
		{
			return this.FindTranslatedObject<T>(Translation);
		}

		// Token: 0x06000A8E RID: 2702 RVA: 0x0004FEFC File Offset: 0x0004E0FC
		private void DeserializeTranslation(string translation, out string value, out string secondary)
		{
			if (!string.IsNullOrEmpty(translation) && translation.Length > 1 && translation[0] == '[')
			{
				int num = translation.IndexOf(']');
				if (num > 0)
				{
					secondary = translation.Substring(1, num - 1);
					value = translation.Substring(num + 1);
					return;
				}
			}
			value = translation;
			secondary = string.Empty;
		}

		// Token: 0x06000A8F RID: 2703 RVA: 0x0004FF54 File Offset: 0x0004E154
		public T FindTranslatedObject<T>(string value) where T : Object
		{
			if (string.IsNullOrEmpty(value))
			{
				T result = default(T);
				return result;
			}
			if (this.mAssetDictionary == null || this.mAssetDictionary.Count != this.TranslatedObjects.Count)
			{
				this.UpdateAssetDictionary();
			}
			foreach (KeyValuePair<string, Object> keyValuePair in this.mAssetDictionary)
			{
				if (keyValuePair.Value is T && value.EndsWith(keyValuePair.Key, StringComparison.OrdinalIgnoreCase) && string.Compare(value, keyValuePair.Key, StringComparison.OrdinalIgnoreCase) == 0)
				{
					return (T)((object)keyValuePair.Value);
				}
			}
			T t = LocalizationManager.FindAsset(value) as T;
			if (t)
			{
				return t;
			}
			return ResourceManager.pInstance.GetAsset<T>(value);
		}

		// Token: 0x06000A90 RID: 2704 RVA: 0x00050044 File Offset: 0x0004E244
		public bool HasTranslatedObject(Object Obj)
		{
			return this.TranslatedObjects.Contains(Obj) || ResourceManager.pInstance.HasAsset(Obj);
		}

		// Token: 0x06000A91 RID: 2705 RVA: 0x00050061 File Offset: 0x0004E261
		public void AddTranslatedObject(Object Obj)
		{
			if (this.TranslatedObjects.Contains(Obj))
			{
				return;
			}
			this.TranslatedObjects.Add(Obj);
			this.UpdateAssetDictionary();
		}

		// Token: 0x06000A92 RID: 2706 RVA: 0x00050084 File Offset: 0x0004E284
		public void SetGlobalLanguage(string Language)
		{
			LocalizationManager.CurrentLanguage = Language;
		}

		// Token: 0x04001257 RID: 4695
		public string mTerm = string.Empty;

		// Token: 0x04001258 RID: 4696
		public string mTermSecondary = string.Empty;

		// Token: 0x04001259 RID: 4697
		[NonSerialized]
		public string FinalTerm;

		// Token: 0x0400125A RID: 4698
		[NonSerialized]
		public string FinalSecondaryTerm;

		// Token: 0x0400125B RID: 4699
		public Localize.TermModification PrimaryTermModifier;

		// Token: 0x0400125C RID: 4700
		public Localize.TermModification SecondaryTermModifier;

		// Token: 0x0400125D RID: 4701
		public string TermPrefix;

		// Token: 0x0400125E RID: 4702
		public string TermSuffix;

		// Token: 0x0400125F RID: 4703
		public bool LocalizeOnAwake = true;

		// Token: 0x04001260 RID: 4704
		private string LastLocalizedLanguage;

		// Token: 0x04001261 RID: 4705
		public bool IgnoreRTL;

		// Token: 0x04001262 RID: 4706
		public int MaxCharactersInRTL;

		// Token: 0x04001263 RID: 4707
		public bool IgnoreNumbersInRTL = true;

		// Token: 0x04001264 RID: 4708
		public bool CorrectAlignmentForRTL = true;

		// Token: 0x04001265 RID: 4709
		public bool AddSpacesToJoinedLanguages;

		// Token: 0x04001266 RID: 4710
		public bool AllowLocalizedParameters = true;

		// Token: 0x04001267 RID: 4711
		public bool AllowParameters = true;

		// Token: 0x04001268 RID: 4712
		public List<Object> TranslatedObjects = new List<Object>();

		// Token: 0x04001269 RID: 4713
		[NonSerialized]
		public Dictionary<string, Object> mAssetDictionary = new Dictionary<string, Object>(StringComparer.Ordinal);

		// Token: 0x0400126A RID: 4714
		public UnityEvent LocalizeEvent = new UnityEvent();

		// Token: 0x0400126B RID: 4715
		public static string MainTranslation;

		// Token: 0x0400126C RID: 4716
		public static string SecondaryTranslation;

		// Token: 0x0400126D RID: 4717
		public static string CallBackTerm;

		// Token: 0x0400126E RID: 4718
		public static string CallBackSecondaryTerm;

		// Token: 0x0400126F RID: 4719
		public static Localize CurrentLocalizeComponent;

		// Token: 0x04001270 RID: 4720
		public bool AlwaysForceLocalize;

		// Token: 0x04001271 RID: 4721
		[SerializeField]
		public EventCallback LocalizeCallBack = new EventCallback();

		// Token: 0x04001272 RID: 4722
		public bool mGUI_ShowReferences;

		// Token: 0x04001273 RID: 4723
		public bool mGUI_ShowTems = true;

		// Token: 0x04001274 RID: 4724
		public bool mGUI_ShowCallback;

		// Token: 0x04001275 RID: 4725
		public ILocalizeTarget mLocalizeTarget;

		// Token: 0x04001276 RID: 4726
		public string mLocalizeTargetName;

		// Token: 0x0200024E RID: 590
		public enum TermModification
		{
			// Token: 0x0400163F RID: 5695
			DontModify,
			// Token: 0x04001640 RID: 5696
			ToUpper,
			// Token: 0x04001641 RID: 5697
			ToLower,
			// Token: 0x04001642 RID: 5698
			ToUpperFirst,
			// Token: 0x04001643 RID: 5699
			ToTitle
		}
	}
}
