﻿using System;

namespace I2.Loc
{
	// Token: 0x02000197 RID: 407
	internal enum IsolatedArabicLetters
	{
		// Token: 0x040012C4 RID: 4804
		Hamza = 65152,
		// Token: 0x040012C5 RID: 4805
		Alef = 65165,
		// Token: 0x040012C6 RID: 4806
		AlefHamza = 65155,
		// Token: 0x040012C7 RID: 4807
		WawHamza = 65157,
		// Token: 0x040012C8 RID: 4808
		AlefMaksoor = 65159,
		// Token: 0x040012C9 RID: 4809
		AlefMaksora = 64508,
		// Token: 0x040012CA RID: 4810
		HamzaNabera = 65161,
		// Token: 0x040012CB RID: 4811
		Ba = 65167,
		// Token: 0x040012CC RID: 4812
		Ta = 65173,
		// Token: 0x040012CD RID: 4813
		Tha2 = 65177,
		// Token: 0x040012CE RID: 4814
		Jeem = 65181,
		// Token: 0x040012CF RID: 4815
		H7aa = 65185,
		// Token: 0x040012D0 RID: 4816
		Khaa2 = 65189,
		// Token: 0x040012D1 RID: 4817
		Dal = 65193,
		// Token: 0x040012D2 RID: 4818
		Thal = 65195,
		// Token: 0x040012D3 RID: 4819
		Ra2 = 65197,
		// Token: 0x040012D4 RID: 4820
		Zeen = 65199,
		// Token: 0x040012D5 RID: 4821
		Seen = 65201,
		// Token: 0x040012D6 RID: 4822
		Sheen = 65205,
		// Token: 0x040012D7 RID: 4823
		S9a = 65209,
		// Token: 0x040012D8 RID: 4824
		Dha = 65213,
		// Token: 0x040012D9 RID: 4825
		T6a = 65217,
		// Token: 0x040012DA RID: 4826
		T6ha = 65221,
		// Token: 0x040012DB RID: 4827
		Ain = 65225,
		// Token: 0x040012DC RID: 4828
		Gain = 65229,
		// Token: 0x040012DD RID: 4829
		Fa = 65233,
		// Token: 0x040012DE RID: 4830
		Gaf = 65237,
		// Token: 0x040012DF RID: 4831
		Kaf = 65241,
		// Token: 0x040012E0 RID: 4832
		Lam = 65245,
		// Token: 0x040012E1 RID: 4833
		Meem = 65249,
		// Token: 0x040012E2 RID: 4834
		Noon = 65253,
		// Token: 0x040012E3 RID: 4835
		Ha = 65257,
		// Token: 0x040012E4 RID: 4836
		Waw = 65261,
		// Token: 0x040012E5 RID: 4837
		Ya = 65265,
		// Token: 0x040012E6 RID: 4838
		AlefMad = 65153,
		// Token: 0x040012E7 RID: 4839
		TaMarboota = 65171,
		// Token: 0x040012E8 RID: 4840
		PersianPe = 64342,
		// Token: 0x040012E9 RID: 4841
		PersianChe = 64378,
		// Token: 0x040012EA RID: 4842
		PersianZe = 64394,
		// Token: 0x040012EB RID: 4843
		PersianGaf = 64402,
		// Token: 0x040012EC RID: 4844
		PersianGaf2 = 64398
	}
}
