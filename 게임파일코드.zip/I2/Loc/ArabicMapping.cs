﻿using System;

namespace I2.Loc
{
	// Token: 0x02000199 RID: 409
	internal class ArabicMapping
	{
		// Token: 0x06000BC6 RID: 3014 RVA: 0x000542DD File Offset: 0x000524DD
		public ArabicMapping(int from, int to)
		{
			this.from = from;
			this.to = to;
		}

		// Token: 0x04001317 RID: 4887
		public int from;

		// Token: 0x04001318 RID: 4888
		public int to;
	}
}
