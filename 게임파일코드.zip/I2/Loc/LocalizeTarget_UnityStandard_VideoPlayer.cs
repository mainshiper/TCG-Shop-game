﻿using System;
using UnityEngine;
using UnityEngine.Video;

namespace I2.Loc
{
	// Token: 0x02000182 RID: 386
	public class LocalizeTarget_UnityStandard_VideoPlayer : LocalizeTarget<VideoPlayer>
	{
		// Token: 0x06000B52 RID: 2898 RVA: 0x00052B9F File Offset: 0x00050D9F
		static LocalizeTarget_UnityStandard_VideoPlayer()
		{
			LocalizeTarget_UnityStandard_VideoPlayer.AutoRegister();
		}

		// Token: 0x06000B53 RID: 2899 RVA: 0x00052BA6 File Offset: 0x00050DA6
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
			LocalizationManager.RegisterTarget(new LocalizeTargetDesc_Type<VideoPlayer, LocalizeTarget_UnityStandard_VideoPlayer>
			{
				Name = "VideoPlayer",
				Priority = 100
			});
		}

		// Token: 0x06000B54 RID: 2900 RVA: 0x00052BC5 File Offset: 0x00050DC5
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.Video;
		}

		// Token: 0x06000B55 RID: 2901 RVA: 0x00052BC9 File Offset: 0x00050DC9
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06000B56 RID: 2902 RVA: 0x00052BCC File Offset: 0x00050DCC
		public override bool CanUseSecondaryTerm()
		{
			return false;
		}

		// Token: 0x06000B57 RID: 2903 RVA: 0x00052BCF File Offset: 0x00050DCF
		public override bool AllowMainTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B58 RID: 2904 RVA: 0x00052BD2 File Offset: 0x00050DD2
		public override bool AllowSecondTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B59 RID: 2905 RVA: 0x00052BD8 File Offset: 0x00050DD8
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
			VideoClip clip = this.mTarget.clip;
			primaryTerm = ((clip != null) ? clip.name : string.Empty);
			secondaryTerm = null;
		}

		// Token: 0x06000B5A RID: 2906 RVA: 0x00052C10 File Offset: 0x00050E10
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
			VideoClip clip = this.mTarget.clip;
			if (clip == null || clip.name != mainTranslation)
			{
				this.mTarget.clip = cmp.FindTranslatedObject<VideoClip>(mainTranslation);
			}
		}
	}
}
