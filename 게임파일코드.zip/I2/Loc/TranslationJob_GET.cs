﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine.Networking;

namespace I2.Loc
{
	// Token: 0x02000164 RID: 356
	public class TranslationJob_GET : TranslationJob_WWW
	{
		// Token: 0x060009FC RID: 2556 RVA: 0x0004BDB0 File Offset: 0x00049FB0
		public TranslationJob_GET(Dictionary<string, TranslationQuery> requests, GoogleTranslation.fnOnTranslationReady OnTranslationReady)
		{
			this._requests = requests;
			this._OnTranslationReady = OnTranslationReady;
			this.mQueries = GoogleTranslation.ConvertTranslationRequest(requests, true);
			this.GetState();
		}

		// Token: 0x060009FD RID: 2557 RVA: 0x0004BDDC File Offset: 0x00049FDC
		private void ExecuteNextQuery()
		{
			if (this.mQueries.Count == 0)
			{
				this.mJobState = TranslationJob.eJobState.Succeeded;
				return;
			}
			int index = this.mQueries.Count - 1;
			string str = this.mQueries[index];
			this.mQueries.RemoveAt(index);
			string text = LocalizationManager.GetWebServiceURL(null) + "?action=Translate&list=" + str;
			this.www = UnityWebRequest.Get(text);
			I2Utils.SendWebRequest(this.www);
		}

		// Token: 0x060009FE RID: 2558 RVA: 0x0004BE50 File Offset: 0x0004A050
		public override TranslationJob.eJobState GetState()
		{
			if (this.www != null && this.www.isDone)
			{
				this.ProcessResult(this.www.downloadHandler.data, this.www.error);
				this.www.Dispose();
				this.www = null;
			}
			if (this.www == null)
			{
				this.ExecuteNextQuery();
			}
			return this.mJobState;
		}

		// Token: 0x060009FF RID: 2559 RVA: 0x0004BEBC File Offset: 0x0004A0BC
		public void ProcessResult(byte[] bytes, string errorMsg)
		{
			if (string.IsNullOrEmpty(errorMsg))
			{
				errorMsg = GoogleTranslation.ParseTranslationResult(Encoding.UTF8.GetString(bytes, 0, bytes.Length), this._requests);
				if (string.IsNullOrEmpty(errorMsg))
				{
					if (this._OnTranslationReady != null)
					{
						this._OnTranslationReady(this._requests, null);
					}
					return;
				}
			}
			this.mJobState = TranslationJob.eJobState.Failed;
			this.mErrorMessage = errorMsg;
		}

		// Token: 0x04001206 RID: 4614
		private Dictionary<string, TranslationQuery> _requests;

		// Token: 0x04001207 RID: 4615
		private GoogleTranslation.fnOnTranslationReady _OnTranslationReady;

		// Token: 0x04001208 RID: 4616
		private List<string> mQueries;

		// Token: 0x04001209 RID: 4617
		public string mErrorMessage;
	}
}
