﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x0200019D RID: 413
	[AddComponentMenu("I2/Localization/SetLanguage Button")]
	public class SetLanguage : MonoBehaviour
	{
		// Token: 0x06000BD4 RID: 3028 RVA: 0x00055658 File Offset: 0x00053858
		private void OnClick()
		{
			this.ApplyLanguage();
		}

		// Token: 0x06000BD5 RID: 3029 RVA: 0x00055660 File Offset: 0x00053860
		public void ApplyLanguage()
		{
			if (LocalizationManager.HasLanguage(this._Language, true, true, true))
			{
				LocalizationManager.CurrentLanguage = this._Language;
			}
		}

		// Token: 0x0400131F RID: 4895
		public string _Language;
	}
}
