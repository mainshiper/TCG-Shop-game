﻿using System;
using System.Collections.Generic;

namespace I2.Loc
{
	// Token: 0x0200015B RID: 347
	public class BaseSpecializationManager
	{
		// Token: 0x060009BD RID: 2493 RVA: 0x00046D74 File Offset: 0x00044F74
		public virtual void InitializeSpecializations()
		{
			this.mSpecializations = new string[]
			{
				"Any",
				"PC",
				"Touch",
				"Controller",
				"VR",
				"XBox",
				"PS4",
				"OculusVR",
				"ViveVR",
				"GearVR",
				"Android",
				"IOS"
			};
			this.mSpecializationsFallbacks = new Dictionary<string, string>(StringComparer.Ordinal)
			{
				{
					"XBox",
					"Controller"
				},
				{
					"PS4",
					"Controller"
				},
				{
					"OculusVR",
					"VR"
				},
				{
					"ViveVR",
					"VR"
				},
				{
					"GearVR",
					"VR"
				},
				{
					"Android",
					"Touch"
				},
				{
					"IOS",
					"Touch"
				}
			};
		}

		// Token: 0x060009BE RID: 2494 RVA: 0x00046E71 File Offset: 0x00045071
		public virtual string GetCurrentSpecialization()
		{
			if (this.mSpecializations == null)
			{
				this.InitializeSpecializations();
			}
			return "PC";
		}

		// Token: 0x060009BF RID: 2495 RVA: 0x00046E88 File Offset: 0x00045088
		public virtual string GetFallbackSpecialization(string specialization)
		{
			if (this.mSpecializationsFallbacks == null)
			{
				this.InitializeSpecializations();
			}
			string result;
			if (this.mSpecializationsFallbacks.TryGetValue(specialization, out result))
			{
				return result;
			}
			return "Any";
		}

		// Token: 0x040011EF RID: 4591
		public string[] mSpecializations;

		// Token: 0x040011F0 RID: 4592
		public Dictionary<string, string> mSpecializationsFallbacks;
	}
}
