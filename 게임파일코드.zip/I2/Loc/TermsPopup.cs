﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000189 RID: 393
	public class TermsPopup : PropertyAttribute
	{
		// Token: 0x06000B85 RID: 2949 RVA: 0x00053312 File Offset: 0x00051512
		public TermsPopup(string filter = "")
		{
			this.Filter = filter;
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x06000B86 RID: 2950 RVA: 0x00053321 File Offset: 0x00051521
		// (set) Token: 0x06000B87 RID: 2951 RVA: 0x00053329 File Offset: 0x00051529
		public string Filter { get; private set; }
	}
}
