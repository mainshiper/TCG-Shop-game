﻿using System;
using System.Text;

namespace I2.Loc
{
	// Token: 0x0200019F RID: 415
	public class StringObfucator
	{
		// Token: 0x06000BDA RID: 3034 RVA: 0x00055750 File Offset: 0x00053950
		public static string Encode(string NormalString)
		{
			string result;
			try
			{
				result = StringObfucator.ToBase64(StringObfucator.XoREncode(NormalString));
			}
			catch (Exception)
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000BDB RID: 3035 RVA: 0x00055784 File Offset: 0x00053984
		public static string Decode(string ObfucatedString)
		{
			string result;
			try
			{
				result = StringObfucator.XoREncode(StringObfucator.FromBase64(ObfucatedString));
			}
			catch (Exception)
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000BDC RID: 3036 RVA: 0x000557B8 File Offset: 0x000539B8
		private static string ToBase64(string regularString)
		{
			return Convert.ToBase64String(Encoding.UTF8.GetBytes(regularString));
		}

		// Token: 0x06000BDD RID: 3037 RVA: 0x000557CC File Offset: 0x000539CC
		private static string FromBase64(string base64string)
		{
			byte[] array = Convert.FromBase64String(base64string);
			return Encoding.UTF8.GetString(array, 0, array.Length);
		}

		// Token: 0x06000BDE RID: 3038 RVA: 0x000557F0 File Offset: 0x000539F0
		private static string XoREncode(string NormalString)
		{
			string result;
			try
			{
				char[] stringObfuscatorPassword = StringObfucator.StringObfuscatorPassword;
				char[] array = NormalString.ToCharArray();
				int num = stringObfuscatorPassword.Length;
				int i = 0;
				int num2 = array.Length;
				while (i < num2)
				{
					array[i] = (array[i] ^ stringObfuscatorPassword[i % num] ^ (char)((byte)((i % 2 == 0) ? (i * 23) : (-i * 51))));
					i++;
				}
				result = new string(array);
			}
			catch (Exception)
			{
				result = null;
			}
			return result;
		}

		// Token: 0x04001320 RID: 4896
		public static char[] StringObfuscatorPassword = "ÝúbUu¸CÁÂ§*4PÚ©-á©¾@T6Dl±ÒWâuzÅm4GÐóØ$=Íg,¥Që®iKEßr¡×60Ít4öÃ~^«y:Èd1<QÛÝúbUu¸CÁÂ§*4PÚ©-á©¾@T6Dl±ÒWâuzÅm4GÐóØ$=Íg,¥Që®iKEßr¡×60Ít4öÃ~^«y:Èd".ToCharArray();
	}
}
