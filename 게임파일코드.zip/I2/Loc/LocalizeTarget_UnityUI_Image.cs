﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace I2.Loc
{
	// Token: 0x02000183 RID: 387
	public class LocalizeTarget_UnityUI_Image : LocalizeTarget<Image>
	{
		// Token: 0x06000B5C RID: 2908 RVA: 0x00052C5A File Offset: 0x00050E5A
		static LocalizeTarget_UnityUI_Image()
		{
			LocalizeTarget_UnityUI_Image.AutoRegister();
		}

		// Token: 0x06000B5D RID: 2909 RVA: 0x00052C61 File Offset: 0x00050E61
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
			LocalizationManager.RegisterTarget(new LocalizeTargetDesc_Type<Image, LocalizeTarget_UnityUI_Image>
			{
				Name = "Image",
				Priority = 100
			});
		}

		// Token: 0x06000B5E RID: 2910 RVA: 0x00052C80 File Offset: 0x00050E80
		public override bool CanUseSecondaryTerm()
		{
			return false;
		}

		// Token: 0x06000B5F RID: 2911 RVA: 0x00052C83 File Offset: 0x00050E83
		public override bool AllowMainTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B60 RID: 2912 RVA: 0x00052C86 File Offset: 0x00050E86
		public override bool AllowSecondTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B61 RID: 2913 RVA: 0x00052C89 File Offset: 0x00050E89
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			if (!(this.mTarget.sprite == null))
			{
				return eTermType.Sprite;
			}
			return eTermType.Texture;
		}

		// Token: 0x06000B62 RID: 2914 RVA: 0x00052CA1 File Offset: 0x00050EA1
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06000B63 RID: 2915 RVA: 0x00052CA4 File Offset: 0x00050EA4
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
			primaryTerm = (this.mTarget.mainTexture ? this.mTarget.mainTexture.name : "");
			if (this.mTarget.sprite != null && this.mTarget.sprite.name != primaryTerm)
			{
				primaryTerm = primaryTerm + "." + this.mTarget.sprite.name;
			}
			secondaryTerm = null;
		}

		// Token: 0x06000B64 RID: 2916 RVA: 0x00052D30 File Offset: 0x00050F30
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
			Sprite sprite = this.mTarget.sprite;
			if (sprite == null || sprite.name != mainTranslation)
			{
				this.mTarget.sprite = cmp.FindTranslatedObject<Sprite>(mainTranslation);
			}
		}
	}
}
