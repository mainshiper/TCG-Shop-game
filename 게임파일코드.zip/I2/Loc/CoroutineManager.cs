﻿using System;
using System.Collections;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x0200018B RID: 395
	public class CoroutineManager : MonoBehaviour
	{
		// Token: 0x17000043 RID: 67
		// (get) Token: 0x06000B8A RID: 2954 RVA: 0x00053344 File Offset: 0x00051544
		private static CoroutineManager pInstance
		{
			get
			{
				if (CoroutineManager.mInstance == null)
				{
					GameObject gameObject = new GameObject("_Coroutiner");
					gameObject.hideFlags = HideFlags.HideAndDontSave;
					CoroutineManager.mInstance = gameObject.AddComponent<CoroutineManager>();
					if (Application.isPlaying)
					{
						Object.DontDestroyOnLoad(gameObject);
					}
				}
				return CoroutineManager.mInstance;
			}
		}

		// Token: 0x06000B8B RID: 2955 RVA: 0x0005338E File Offset: 0x0005158E
		private void Awake()
		{
			if (Application.isPlaying)
			{
				Object.DontDestroyOnLoad(base.gameObject);
			}
		}

		// Token: 0x06000B8C RID: 2956 RVA: 0x000533A2 File Offset: 0x000515A2
		public static Coroutine Start(IEnumerator coroutine)
		{
			return CoroutineManager.pInstance.StartCoroutine(coroutine);
		}

		// Token: 0x040012B3 RID: 4787
		private static CoroutineManager mInstance;
	}
}
