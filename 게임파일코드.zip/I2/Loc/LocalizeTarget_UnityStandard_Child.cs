﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x0200017C RID: 380
	public class LocalizeTarget_UnityStandard_Child : LocalizeTarget<GameObject>
	{
		// Token: 0x06000B1B RID: 2843 RVA: 0x00052585 File Offset: 0x00050785
		static LocalizeTarget_UnityStandard_Child()
		{
			LocalizeTarget_UnityStandard_Child.AutoRegister();
		}

		// Token: 0x06000B1C RID: 2844 RVA: 0x0005258C File Offset: 0x0005078C
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
			LocalizationManager.RegisterTarget(new LocalizeTargetDesc_Child
			{
				Name = "Child",
				Priority = 200
			});
		}

		// Token: 0x06000B1D RID: 2845 RVA: 0x000525AE File Offset: 0x000507AE
		public override bool IsValid(Localize cmp)
		{
			return cmp.transform.childCount > 1;
		}

		// Token: 0x06000B1E RID: 2846 RVA: 0x000525BE File Offset: 0x000507BE
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.GameObject;
		}

		// Token: 0x06000B1F RID: 2847 RVA: 0x000525C1 File Offset: 0x000507C1
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06000B20 RID: 2848 RVA: 0x000525C4 File Offset: 0x000507C4
		public override bool CanUseSecondaryTerm()
		{
			return false;
		}

		// Token: 0x06000B21 RID: 2849 RVA: 0x000525C7 File Offset: 0x000507C7
		public override bool AllowMainTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B22 RID: 2850 RVA: 0x000525CA File Offset: 0x000507CA
		public override bool AllowSecondTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B23 RID: 2851 RVA: 0x000525CD File Offset: 0x000507CD
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
			primaryTerm = cmp.name;
			secondaryTerm = null;
		}

		// Token: 0x06000B24 RID: 2852 RVA: 0x000525DC File Offset: 0x000507DC
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
			if (string.IsNullOrEmpty(mainTranslation))
			{
				return;
			}
			Transform transform = cmp.transform;
			string text = mainTranslation;
			int num = mainTranslation.LastIndexOfAny(LanguageSourceData.CategorySeparators);
			if (num >= 0)
			{
				text = text.Substring(num + 1);
			}
			for (int i = 0; i < transform.childCount; i++)
			{
				Transform child = transform.GetChild(i);
				child.gameObject.SetActive(child.name == text);
			}
		}
	}
}
