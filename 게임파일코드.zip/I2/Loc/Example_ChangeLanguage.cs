﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000152 RID: 338
	public class Example_ChangeLanguage : MonoBehaviour
	{
		// Token: 0x0600098C RID: 2444 RVA: 0x00046295 File Offset: 0x00044495
		public void SetLanguage_English()
		{
			this.SetLanguage("English");
		}

		// Token: 0x0600098D RID: 2445 RVA: 0x000462A2 File Offset: 0x000444A2
		public void SetLanguage_French()
		{
			this.SetLanguage("French");
		}

		// Token: 0x0600098E RID: 2446 RVA: 0x000462AF File Offset: 0x000444AF
		public void SetLanguage_Spanish()
		{
			this.SetLanguage("Spanish");
		}

		// Token: 0x0600098F RID: 2447 RVA: 0x000462BC File Offset: 0x000444BC
		public void SetLanguage(string LangName)
		{
			if (LocalizationManager.HasLanguage(LangName, true, true, true))
			{
				LocalizationManager.CurrentLanguage = LangName;
			}
		}
	}
}
