﻿using System;

namespace I2.Loc
{
	// Token: 0x02000186 RID: 390
	public enum eTermType
	{
		// Token: 0x0400129D RID: 4765
		Text,
		// Token: 0x0400129E RID: 4766
		Font,
		// Token: 0x0400129F RID: 4767
		Texture,
		// Token: 0x040012A0 RID: 4768
		AudioClip,
		// Token: 0x040012A1 RID: 4769
		GameObject,
		// Token: 0x040012A2 RID: 4770
		Sprite,
		// Token: 0x040012A3 RID: 4771
		Material,
		// Token: 0x040012A4 RID: 4772
		Child,
		// Token: 0x040012A5 RID: 4773
		Mesh,
		// Token: 0x040012A6 RID: 4774
		TextMeshPFont,
		// Token: 0x040012A7 RID: 4775
		Object,
		// Token: 0x040012A8 RID: 4776
		Video
	}
}
