﻿using System;

namespace I2.Loc
{
	// Token: 0x0200017B RID: 379
	public class LocalizeTargetDesc_Child : LocalizeTargetDesc<LocalizeTarget_UnityStandard_Child>
	{
		// Token: 0x06000B19 RID: 2841 RVA: 0x0005256D File Offset: 0x0005076D
		public override bool CanLocalize(Localize cmp)
		{
			return cmp.transform.childCount > 1;
		}
	}
}
