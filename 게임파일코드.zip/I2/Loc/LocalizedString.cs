﻿using System;

namespace I2.Loc
{
	// Token: 0x02000191 RID: 401
	[Serializable]
	public struct LocalizedString
	{
		// Token: 0x06000BAB RID: 2987 RVA: 0x00053C89 File Offset: 0x00051E89
		public static implicit operator string(LocalizedString s)
		{
			return s.ToString();
		}

		// Token: 0x06000BAC RID: 2988 RVA: 0x00053C98 File Offset: 0x00051E98
		public static implicit operator LocalizedString(string term)
		{
			return new LocalizedString
			{
				mTerm = term
			};
		}

		// Token: 0x06000BAD RID: 2989 RVA: 0x00053CB6 File Offset: 0x00051EB6
		public LocalizedString(LocalizedString str)
		{
			this.mTerm = str.mTerm;
			this.mRTL_IgnoreArabicFix = str.mRTL_IgnoreArabicFix;
			this.mRTL_MaxLineLength = str.mRTL_MaxLineLength;
			this.mRTL_ConvertNumbers = str.mRTL_ConvertNumbers;
			this.m_DontLocalizeParameters = str.m_DontLocalizeParameters;
		}

		// Token: 0x06000BAE RID: 2990 RVA: 0x00053CF4 File Offset: 0x00051EF4
		public override string ToString()
		{
			string translation = LocalizationManager.GetTranslation(this.mTerm, !this.mRTL_IgnoreArabicFix, this.mRTL_MaxLineLength, !this.mRTL_ConvertNumbers, true, null, null, true);
			LocalizationManager.ApplyLocalizationParams(ref translation, !this.m_DontLocalizeParameters);
			return translation;
		}

		// Token: 0x040012BA RID: 4794
		public string mTerm;

		// Token: 0x040012BB RID: 4795
		public bool mRTL_IgnoreArabicFix;

		// Token: 0x040012BC RID: 4796
		public int mRTL_MaxLineLength;

		// Token: 0x040012BD RID: 4797
		public bool mRTL_ConvertNumbers;

		// Token: 0x040012BE RID: 4798
		public bool m_DontLocalizeParameters;
	}
}
