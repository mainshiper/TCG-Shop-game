﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000180 RID: 384
	public class LocalizeTarget_UnityStandard_SpriteRenderer : LocalizeTarget<SpriteRenderer>
	{
		// Token: 0x06000B3E RID: 2878 RVA: 0x0005292A File Offset: 0x00050B2A
		static LocalizeTarget_UnityStandard_SpriteRenderer()
		{
			LocalizeTarget_UnityStandard_SpriteRenderer.AutoRegister();
		}

		// Token: 0x06000B3F RID: 2879 RVA: 0x00052931 File Offset: 0x00050B31
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
			LocalizationManager.RegisterTarget(new LocalizeTargetDesc_Type<SpriteRenderer, LocalizeTarget_UnityStandard_SpriteRenderer>
			{
				Name = "SpriteRenderer",
				Priority = 100
			});
		}

		// Token: 0x06000B40 RID: 2880 RVA: 0x00052950 File Offset: 0x00050B50
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.Sprite;
		}

		// Token: 0x06000B41 RID: 2881 RVA: 0x00052953 File Offset: 0x00050B53
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06000B42 RID: 2882 RVA: 0x00052956 File Offset: 0x00050B56
		public override bool CanUseSecondaryTerm()
		{
			return false;
		}

		// Token: 0x06000B43 RID: 2883 RVA: 0x00052959 File Offset: 0x00050B59
		public override bool AllowMainTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B44 RID: 2884 RVA: 0x0005295C File Offset: 0x00050B5C
		public override bool AllowSecondTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B45 RID: 2885 RVA: 0x00052960 File Offset: 0x00050B60
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
			Sprite sprite = this.mTarget.sprite;
			primaryTerm = ((sprite != null) ? sprite.name : string.Empty);
			secondaryTerm = null;
		}

		// Token: 0x06000B46 RID: 2886 RVA: 0x00052998 File Offset: 0x00050B98
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
			Sprite sprite = this.mTarget.sprite;
			if (sprite == null || sprite.name != mainTranslation)
			{
				this.mTarget.sprite = cmp.FindTranslatedObject<Sprite>(mainTranslation);
			}
		}
	}
}
