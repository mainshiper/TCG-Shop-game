﻿using System;

namespace I2.Loc
{
	// Token: 0x0200019B RID: 411
	internal class TashkeelLocation
	{
		// Token: 0x06000BCA RID: 3018 RVA: 0x0005478C File Offset: 0x0005298C
		public TashkeelLocation(char tashkeel, int position)
		{
			this.tashkeel = tashkeel;
			this.position = position;
		}

		// Token: 0x0400131B RID: 4891
		public char tashkeel;

		// Token: 0x0400131C RID: 4892
		public int position;
	}
}
