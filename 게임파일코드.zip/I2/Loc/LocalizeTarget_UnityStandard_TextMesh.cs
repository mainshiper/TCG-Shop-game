﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000181 RID: 385
	public class LocalizeTarget_UnityStandard_TextMesh : LocalizeTarget<TextMesh>
	{
		// Token: 0x06000B48 RID: 2888 RVA: 0x000529E2 File Offset: 0x00050BE2
		static LocalizeTarget_UnityStandard_TextMesh()
		{
			LocalizeTarget_UnityStandard_TextMesh.AutoRegister();
		}

		// Token: 0x06000B49 RID: 2889 RVA: 0x000529E9 File Offset: 0x00050BE9
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
			LocalizationManager.RegisterTarget(new LocalizeTargetDesc_Type<TextMesh, LocalizeTarget_UnityStandard_TextMesh>
			{
				Name = "TextMesh",
				Priority = 100
			});
		}

		// Token: 0x06000B4A RID: 2890 RVA: 0x00052A08 File Offset: 0x00050C08
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06000B4B RID: 2891 RVA: 0x00052A0B File Offset: 0x00050C0B
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Font;
		}

		// Token: 0x06000B4C RID: 2892 RVA: 0x00052A0E File Offset: 0x00050C0E
		public override bool CanUseSecondaryTerm()
		{
			return true;
		}

		// Token: 0x06000B4D RID: 2893 RVA: 0x00052A11 File Offset: 0x00050C11
		public override bool AllowMainTermToBeRTL()
		{
			return true;
		}

		// Token: 0x06000B4E RID: 2894 RVA: 0x00052A14 File Offset: 0x00050C14
		public override bool AllowSecondTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B4F RID: 2895 RVA: 0x00052A18 File Offset: 0x00050C18
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
			primaryTerm = (this.mTarget ? this.mTarget.text : null);
			secondaryTerm = ((string.IsNullOrEmpty(Secondary) && this.mTarget.font != null) ? this.mTarget.font.name : null);
		}

		// Token: 0x06000B50 RID: 2896 RVA: 0x00052A74 File Offset: 0x00050C74
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
			Font secondaryTranslatedObj = cmp.GetSecondaryTranslatedObj<Font>(ref mainTranslation, ref secondaryTranslation);
			if (secondaryTranslatedObj != null && this.mTarget.font != secondaryTranslatedObj)
			{
				this.mTarget.font = secondaryTranslatedObj;
				this.mTarget.GetComponentInChildren<MeshRenderer>().material = secondaryTranslatedObj.material;
			}
			if (this.mInitializeAlignment)
			{
				this.mInitializeAlignment = false;
				this.mAlignment_LTR = (this.mAlignment_RTL = this.mTarget.alignment);
				if (LocalizationManager.IsRight2Left && this.mAlignment_RTL == 2)
				{
					this.mAlignment_LTR = 0;
				}
				if (!LocalizationManager.IsRight2Left && this.mAlignment_LTR == null)
				{
					this.mAlignment_RTL = 2;
				}
			}
			if (mainTranslation != null && this.mTarget.text != mainTranslation)
			{
				if (cmp.CorrectAlignmentForRTL && this.mTarget.alignment != 1)
				{
					this.mTarget.alignment = (LocalizationManager.IsRight2Left ? this.mAlignment_RTL : this.mAlignment_LTR);
				}
				this.mTarget.font.RequestCharactersInTexture(mainTranslation);
				this.mTarget.text = mainTranslation;
			}
		}

		// Token: 0x04001294 RID: 4756
		private TextAlignment mAlignment_RTL = 2;

		// Token: 0x04001295 RID: 4757
		private TextAlignment mAlignment_LTR;

		// Token: 0x04001296 RID: 4758
		private bool mAlignmentWasRTL;

		// Token: 0x04001297 RID: 4759
		private bool mInitializeAlignment = true;
	}
}
