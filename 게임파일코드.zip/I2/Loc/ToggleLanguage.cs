﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000157 RID: 343
	public class ToggleLanguage : MonoBehaviour
	{
		// Token: 0x060009A3 RID: 2467 RVA: 0x000467D0 File Offset: 0x000449D0
		private void Start()
		{
			base.Invoke("test", 3f);
		}

		// Token: 0x060009A4 RID: 2468 RVA: 0x000467E4 File Offset: 0x000449E4
		private void test()
		{
			List<string> allLanguages = LocalizationManager.GetAllLanguages(true);
			int num = allLanguages.IndexOf(LocalizationManager.CurrentLanguage);
			if (num >= 0)
			{
				num = (num + 1) % allLanguages.Count;
			}
			base.Invoke("test", 3f);
		}
	}
}
