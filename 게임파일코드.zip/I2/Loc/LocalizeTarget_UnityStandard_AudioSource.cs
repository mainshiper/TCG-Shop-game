﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x0200017A RID: 378
	public class LocalizeTarget_UnityStandard_AudioSource : LocalizeTarget<AudioSource>
	{
		// Token: 0x06000B0F RID: 2831 RVA: 0x00052483 File Offset: 0x00050683
		static LocalizeTarget_UnityStandard_AudioSource()
		{
			LocalizeTarget_UnityStandard_AudioSource.AutoRegister();
		}

		// Token: 0x06000B10 RID: 2832 RVA: 0x0005248A File Offset: 0x0005068A
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
			LocalizationManager.RegisterTarget(new LocalizeTargetDesc_Type<AudioSource, LocalizeTarget_UnityStandard_AudioSource>
			{
				Name = "AudioSource",
				Priority = 100
			});
		}

		// Token: 0x06000B11 RID: 2833 RVA: 0x000524A9 File Offset: 0x000506A9
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.AudioClip;
		}

		// Token: 0x06000B12 RID: 2834 RVA: 0x000524AC File Offset: 0x000506AC
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06000B13 RID: 2835 RVA: 0x000524AF File Offset: 0x000506AF
		public override bool CanUseSecondaryTerm()
		{
			return false;
		}

		// Token: 0x06000B14 RID: 2836 RVA: 0x000524B2 File Offset: 0x000506B2
		public override bool AllowMainTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B15 RID: 2837 RVA: 0x000524B5 File Offset: 0x000506B5
		public override bool AllowSecondTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B16 RID: 2838 RVA: 0x000524B8 File Offset: 0x000506B8
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
			AudioClip clip = this.mTarget.clip;
			primaryTerm = (clip ? clip.name : string.Empty);
			secondaryTerm = null;
		}

		// Token: 0x06000B17 RID: 2839 RVA: 0x000524F0 File Offset: 0x000506F0
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
			bool flag = (this.mTarget.isPlaying || this.mTarget.loop) && Application.isPlaying;
			Object clip = this.mTarget.clip;
			AudioClip audioClip = cmp.FindTranslatedObject<AudioClip>(mainTranslation);
			if (clip != audioClip)
			{
				this.mTarget.clip = audioClip;
			}
			if (flag && this.mTarget.clip)
			{
				this.mTarget.Play();
			}
		}
	}
}
