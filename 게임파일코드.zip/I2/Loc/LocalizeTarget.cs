﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000174 RID: 372
	public abstract class LocalizeTarget<T> : ILocalizeTarget where T : Object
	{
		// Token: 0x06000AEB RID: 2795 RVA: 0x00051BE0 File Offset: 0x0004FDE0
		public override bool IsValid(Localize cmp)
		{
			if (this.mTarget != null)
			{
				Component component = this.mTarget as Component;
				if (component != null && component.gameObject != cmp.gameObject)
				{
					this.mTarget = default(T);
				}
			}
			if (this.mTarget == null)
			{
				this.mTarget = cmp.GetComponent<T>();
			}
			return this.mTarget != null;
		}

		// Token: 0x04001289 RID: 4745
		public T mTarget;
	}
}
