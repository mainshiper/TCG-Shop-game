﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000156 RID: 342
	public class RegisterBundlesManager : MonoBehaviour, IResourceManager_Bundles
	{
		// Token: 0x0600099F RID: 2463 RVA: 0x0004678E File Offset: 0x0004498E
		public void OnEnable()
		{
			if (!ResourceManager.pInstance.mBundleManagers.Contains(this))
			{
				ResourceManager.pInstance.mBundleManagers.Add(this);
			}
		}

		// Token: 0x060009A0 RID: 2464 RVA: 0x000467B2 File Offset: 0x000449B2
		public void OnDisable()
		{
			ResourceManager.pInstance.mBundleManagers.Remove(this);
		}

		// Token: 0x060009A1 RID: 2465 RVA: 0x000467C5 File Offset: 0x000449C5
		public virtual Object LoadFromBundle(string path, Type assetType)
		{
			return null;
		}
	}
}
