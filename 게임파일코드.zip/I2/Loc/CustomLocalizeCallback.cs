﻿using System;
using UnityEngine;
using UnityEngine.Events;

namespace I2.Loc
{
	// Token: 0x0200018C RID: 396
	[AddComponentMenu("I2/Localization/I2 Localize Callback")]
	public class CustomLocalizeCallback : MonoBehaviour
	{
		// Token: 0x06000B8E RID: 2958 RVA: 0x000533B7 File Offset: 0x000515B7
		public void OnEnable()
		{
			LocalizationManager.OnLocalizeEvent -= this.OnLocalize;
			LocalizationManager.OnLocalizeEvent += this.OnLocalize;
		}

		// Token: 0x06000B8F RID: 2959 RVA: 0x000533DB File Offset: 0x000515DB
		public void OnDisable()
		{
			LocalizationManager.OnLocalizeEvent -= this.OnLocalize;
		}

		// Token: 0x06000B90 RID: 2960 RVA: 0x000533EE File Offset: 0x000515EE
		public void OnLocalize()
		{
			this._OnLocalize.Invoke();
		}

		// Token: 0x040012B4 RID: 4788
		public UnityEvent _OnLocalize = new UnityEvent();
	}
}
