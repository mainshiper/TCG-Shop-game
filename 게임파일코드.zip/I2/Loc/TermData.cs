﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000188 RID: 392
	[Serializable]
	public class TermData
	{
		// Token: 0x06000B7B RID: 2939 RVA: 0x000530A4 File Offset: 0x000512A4
		public string GetTranslation(int idx, string specialization = null, bool editMode = false)
		{
			string text = this.Languages[idx];
			if (text != null)
			{
				text = SpecializationManager.GetSpecializedText(text, specialization);
				if (!editMode)
				{
					text = text.Replace("[i2nt]", "").Replace("[/i2nt]", "");
				}
			}
			return text;
		}

		// Token: 0x06000B7C RID: 2940 RVA: 0x000530E9 File Offset: 0x000512E9
		public void SetTranslation(int idx, string translation, string specialization = null)
		{
			this.Languages[idx] = SpecializationManager.SetSpecializedText(this.Languages[idx], translation, specialization);
		}

		// Token: 0x06000B7D RID: 2941 RVA: 0x00053104 File Offset: 0x00051304
		public void RemoveSpecialization(string specialization)
		{
			for (int i = 0; i < this.Languages.Length; i++)
			{
				this.RemoveSpecialization(i, specialization);
			}
		}

		// Token: 0x06000B7E RID: 2942 RVA: 0x0005312C File Offset: 0x0005132C
		public void RemoveSpecialization(int idx, string specialization)
		{
			string text = this.Languages[idx];
			if (specialization == "Any" || !text.Contains("[i2s_" + specialization + "]"))
			{
				return;
			}
			Dictionary<string, string> specializations = SpecializationManager.GetSpecializations(text, null);
			specializations.Remove(specialization);
			this.Languages[idx] = SpecializationManager.SetSpecializedText(specializations);
		}

		// Token: 0x06000B7F RID: 2943 RVA: 0x00053186 File Offset: 0x00051386
		public bool IsAutoTranslated(int idx, bool IsTouch)
		{
			return (this.Flags[idx] & 2) > 0;
		}

		// Token: 0x06000B80 RID: 2944 RVA: 0x00053198 File Offset: 0x00051398
		public void Validate()
		{
			int num = Mathf.Max(this.Languages.Length, this.Flags.Length);
			if (this.Languages.Length != num)
			{
				Array.Resize<string>(ref this.Languages, num);
			}
			if (this.Flags.Length != num)
			{
				Array.Resize<byte>(ref this.Flags, num);
			}
			if (this.Languages_Touch != null)
			{
				for (int i = 0; i < Mathf.Min(this.Languages_Touch.Length, num); i++)
				{
					if (string.IsNullOrEmpty(this.Languages[i]) && !string.IsNullOrEmpty(this.Languages_Touch[i]))
					{
						this.Languages[i] = this.Languages_Touch[i];
						this.Languages_Touch[i] = null;
					}
				}
				this.Languages_Touch = null;
			}
		}

		// Token: 0x06000B81 RID: 2945 RVA: 0x00053248 File Offset: 0x00051448
		public bool IsTerm(string name, bool allowCategoryMistmatch)
		{
			if (!allowCategoryMistmatch)
			{
				return name == this.Term;
			}
			return name == LanguageSourceData.GetKeyFromFullTerm(this.Term, false);
		}

		// Token: 0x06000B82 RID: 2946 RVA: 0x0005326C File Offset: 0x0005146C
		public bool HasSpecializations()
		{
			for (int i = 0; i < this.Languages.Length; i++)
			{
				if (!string.IsNullOrEmpty(this.Languages[i]) && this.Languages[i].Contains("[i2s_"))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x06000B83 RID: 2947 RVA: 0x000532B4 File Offset: 0x000514B4
		public List<string> GetAllSpecializations()
		{
			List<string> list = new List<string>();
			for (int i = 0; i < this.Languages.Length; i++)
			{
				SpecializationManager.AppendSpecializations(this.Languages[i], list);
			}
			return list;
		}

		// Token: 0x040012AC RID: 4780
		public string Term = string.Empty;

		// Token: 0x040012AD RID: 4781
		public eTermType TermType;

		// Token: 0x040012AE RID: 4782
		[NonSerialized]
		public string Description;

		// Token: 0x040012AF RID: 4783
		public string[] Languages = Array.Empty<string>();

		// Token: 0x040012B0 RID: 4784
		public byte[] Flags = Array.Empty<byte>();

		// Token: 0x040012B1 RID: 4785
		[SerializeField]
		private string[] Languages_Touch;
	}
}
