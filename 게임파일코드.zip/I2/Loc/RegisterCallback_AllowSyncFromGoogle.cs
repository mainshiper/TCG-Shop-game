﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000192 RID: 402
	public class RegisterCallback_AllowSyncFromGoogle : MonoBehaviour
	{
		// Token: 0x06000BAF RID: 2991 RVA: 0x00053D3A File Offset: 0x00051F3A
		public void Awake()
		{
			LocalizationManager.Callback_AllowSyncFromGoogle = new Func<LanguageSourceData, bool>(this.AllowSyncFromGoogle);
		}

		// Token: 0x06000BB0 RID: 2992 RVA: 0x00053D4E File Offset: 0x00051F4E
		public void OnEnable()
		{
			LocalizationManager.Callback_AllowSyncFromGoogle = new Func<LanguageSourceData, bool>(this.AllowSyncFromGoogle);
		}

		// Token: 0x06000BB1 RID: 2993 RVA: 0x00053D62 File Offset: 0x00051F62
		public void OnDisable()
		{
			LocalizationManager.Callback_AllowSyncFromGoogle = null;
		}

		// Token: 0x06000BB2 RID: 2994 RVA: 0x00053D6A File Offset: 0x00051F6A
		public virtual bool AllowSyncFromGoogle(LanguageSourceData Source)
		{
			return true;
		}
	}
}
