﻿using System;

namespace I2.Loc
{
	// Token: 0x02000154 RID: 340
	public class GlobalParametersExample : RegisterGlobalParameters
	{
		// Token: 0x06000993 RID: 2451 RVA: 0x000463B4 File Offset: 0x000445B4
		public override string GetParameterValue(string ParamName)
		{
			if (ParamName == "WINNER")
			{
				return "Javier";
			}
			if (ParamName == "NUM PLAYERS")
			{
				return 5.ToString();
			}
			return null;
		}
	}
}
