﻿using System;

namespace I2.Loc
{
	// Token: 0x0200015A RID: 346
	public class I2CustomPersistentStorage : I2BasePersistentStorage
	{
	}
}
