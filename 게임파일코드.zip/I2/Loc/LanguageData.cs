﻿using System;

namespace I2.Loc
{
	// Token: 0x02000169 RID: 361
	[Serializable]
	public class LanguageData
	{
		// Token: 0x06000A0C RID: 2572 RVA: 0x0004C5EC File Offset: 0x0004A7EC
		public bool IsEnabled()
		{
			return (this.Flags & 1) == 0;
		}

		// Token: 0x06000A0D RID: 2573 RVA: 0x0004C5F9 File Offset: 0x0004A7F9
		public void SetEnabled(bool bEnabled)
		{
			if (bEnabled)
			{
				this.Flags = (byte)((int)this.Flags & -2);
				return;
			}
			this.Flags |= 1;
		}

		// Token: 0x06000A0E RID: 2574 RVA: 0x0004C61E File Offset: 0x0004A81E
		public bool IsLoaded()
		{
			return (this.Flags & 4) == 0;
		}

		// Token: 0x06000A0F RID: 2575 RVA: 0x0004C62B File Offset: 0x0004A82B
		public bool CanBeUnloaded()
		{
			return (this.Flags & 2) == 0;
		}

		// Token: 0x06000A10 RID: 2576 RVA: 0x0004C638 File Offset: 0x0004A838
		public void SetLoaded(bool loaded)
		{
			if (loaded)
			{
				this.Flags = (byte)((int)this.Flags & -5);
				return;
			}
			this.Flags |= 4;
		}

		// Token: 0x06000A11 RID: 2577 RVA: 0x0004C65D File Offset: 0x0004A85D
		public void SetCanBeUnLoaded(bool allowUnloading)
		{
			if (allowUnloading)
			{
				this.Flags = (byte)((int)this.Flags & -3);
				return;
			}
			this.Flags |= 2;
		}

		// Token: 0x0400121D RID: 4637
		public string Name;

		// Token: 0x0400121E RID: 4638
		public string Code;

		// Token: 0x0400121F RID: 4639
		public byte Flags;

		// Token: 0x04001220 RID: 4640
		[NonSerialized]
		public bool Compressed;
	}
}
