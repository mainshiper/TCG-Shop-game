﻿using System;

namespace I2.Loc.SimpleJSON
{
	// Token: 0x020001A6 RID: 422
	public static class JSON
	{
		// Token: 0x06000C52 RID: 3154 RVA: 0x00056C8F File Offset: 0x00054E8F
		public static JSONNode Parse(string aJSON)
		{
			return JSONNode.Parse(aJSON);
		}
	}
}
