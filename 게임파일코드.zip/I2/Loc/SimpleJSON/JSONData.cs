﻿using System;
using System.IO;

namespace I2.Loc.SimpleJSON
{
	// Token: 0x020001A4 RID: 420
	public class JSONData : JSONNode
	{
		// Token: 0x1700005A RID: 90
		// (get) Token: 0x06000C2F RID: 3119 RVA: 0x000568A0 File Offset: 0x00054AA0
		// (set) Token: 0x06000C30 RID: 3120 RVA: 0x000568A8 File Offset: 0x00054AA8
		public override string Value
		{
			get
			{
				return this.m_Data;
			}
			set
			{
				this.m_Data = value;
			}
		}

		// Token: 0x06000C31 RID: 3121 RVA: 0x000568B1 File Offset: 0x00054AB1
		public JSONData(string aData)
		{
			this.m_Data = aData;
		}

		// Token: 0x06000C32 RID: 3122 RVA: 0x000568C0 File Offset: 0x00054AC0
		public JSONData(float aData)
		{
			this.AsFloat = aData;
		}

		// Token: 0x06000C33 RID: 3123 RVA: 0x000568CF File Offset: 0x00054ACF
		public JSONData(double aData)
		{
			this.AsDouble = aData;
		}

		// Token: 0x06000C34 RID: 3124 RVA: 0x000568DE File Offset: 0x00054ADE
		public JSONData(bool aData)
		{
			this.AsBool = aData;
		}

		// Token: 0x06000C35 RID: 3125 RVA: 0x000568ED File Offset: 0x00054AED
		public JSONData(int aData)
		{
			this.AsInt = aData;
		}

		// Token: 0x06000C36 RID: 3126 RVA: 0x000568FC File Offset: 0x00054AFC
		public override string ToString()
		{
			return "\"" + JSONNode.Escape(this.m_Data) + "\"";
		}

		// Token: 0x06000C37 RID: 3127 RVA: 0x00056918 File Offset: 0x00054B18
		public override string ToString(string aPrefix)
		{
			return "\"" + JSONNode.Escape(this.m_Data) + "\"";
		}

		// Token: 0x06000C38 RID: 3128 RVA: 0x00056934 File Offset: 0x00054B34
		public override void Serialize(BinaryWriter aWriter)
		{
			JSONData jsondata = new JSONData("");
			jsondata.AsInt = this.AsInt;
			if (jsondata.m_Data == this.m_Data)
			{
				aWriter.Write(4);
				aWriter.Write(this.AsInt);
				return;
			}
			jsondata.AsFloat = this.AsFloat;
			if (jsondata.m_Data == this.m_Data)
			{
				aWriter.Write(7);
				aWriter.Write(this.AsFloat);
				return;
			}
			jsondata.AsDouble = this.AsDouble;
			if (jsondata.m_Data == this.m_Data)
			{
				aWriter.Write(5);
				aWriter.Write(this.AsDouble);
				return;
			}
			jsondata.AsBool = this.AsBool;
			if (jsondata.m_Data == this.m_Data)
			{
				aWriter.Write(6);
				aWriter.Write(this.AsBool);
				return;
			}
			aWriter.Write(3);
			aWriter.Write(this.m_Data);
		}

		// Token: 0x0400132B RID: 4907
		private string m_Data;
	}
}
