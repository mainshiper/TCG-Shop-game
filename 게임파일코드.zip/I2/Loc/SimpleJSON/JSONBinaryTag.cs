﻿using System;

namespace I2.Loc.SimpleJSON
{
	// Token: 0x020001A0 RID: 416
	public enum JSONBinaryTag
	{
		// Token: 0x04001322 RID: 4898
		Array = 1,
		// Token: 0x04001323 RID: 4899
		Class,
		// Token: 0x04001324 RID: 4900
		Value,
		// Token: 0x04001325 RID: 4901
		IntValue,
		// Token: 0x04001326 RID: 4902
		DoubleValue,
		// Token: 0x04001327 RID: 4903
		BoolValue,
		// Token: 0x04001328 RID: 4904
		FloatValue
	}
}
