﻿using System;

namespace I2.Loc.SimpleJSON
{
	// Token: 0x020001A5 RID: 421
	internal class JSONLazyCreator : JSONNode
	{
		// Token: 0x06000C39 RID: 3129 RVA: 0x00056A2B File Offset: 0x00054C2B
		public JSONLazyCreator(JSONNode aNode)
		{
			this.m_Node = aNode;
			this.m_Key = null;
		}

		// Token: 0x06000C3A RID: 3130 RVA: 0x00056A41 File Offset: 0x00054C41
		public JSONLazyCreator(JSONNode aNode, string aKey)
		{
			this.m_Node = aNode;
			this.m_Key = aKey;
		}

		// Token: 0x06000C3B RID: 3131 RVA: 0x00056A57 File Offset: 0x00054C57
		private void Set(JSONNode aVal)
		{
			if (this.m_Key == null)
			{
				this.m_Node.Add(aVal);
			}
			else
			{
				this.m_Node.Add(this.m_Key, aVal);
			}
			this.m_Node = null;
		}

		// Token: 0x1700005B RID: 91
		public override JSONNode this[int aIndex]
		{
			get
			{
				return new JSONLazyCreator(this);
			}
			set
			{
				this.Set(new JSONArray
				{
					value
				});
			}
		}

		// Token: 0x1700005C RID: 92
		public override JSONNode this[string aKey]
		{
			get
			{
				return new JSONLazyCreator(this, aKey);
			}
			set
			{
				this.Set(new JSONClass
				{
					{
						aKey,
						value
					}
				});
			}
		}

		// Token: 0x06000C40 RID: 3136 RVA: 0x00056AE0 File Offset: 0x00054CE0
		public override void Add(JSONNode aItem)
		{
			this.Set(new JSONArray
			{
				aItem
			});
		}

		// Token: 0x06000C41 RID: 3137 RVA: 0x00056B04 File Offset: 0x00054D04
		public override void Add(string aKey, JSONNode aItem)
		{
			this.Set(new JSONClass
			{
				{
					aKey,
					aItem
				}
			});
		}

		// Token: 0x06000C42 RID: 3138 RVA: 0x00056B26 File Offset: 0x00054D26
		public static bool operator ==(JSONLazyCreator a, object b)
		{
			return b == null || a == b;
		}

		// Token: 0x06000C43 RID: 3139 RVA: 0x00056B31 File Offset: 0x00054D31
		public static bool operator !=(JSONLazyCreator a, object b)
		{
			return !(a == b);
		}

		// Token: 0x06000C44 RID: 3140 RVA: 0x00056B3D File Offset: 0x00054D3D
		public override bool Equals(object obj)
		{
			return obj == null || this == obj;
		}

		// Token: 0x06000C45 RID: 3141 RVA: 0x00056B48 File Offset: 0x00054D48
		public override int GetHashCode()
		{
			return base.GetHashCode();
		}

		// Token: 0x06000C46 RID: 3142 RVA: 0x00056B50 File Offset: 0x00054D50
		public override string ToString()
		{
			return "";
		}

		// Token: 0x06000C47 RID: 3143 RVA: 0x00056B57 File Offset: 0x00054D57
		public override string ToString(string aPrefix)
		{
			return "";
		}

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x06000C48 RID: 3144 RVA: 0x00056B60 File Offset: 0x00054D60
		// (set) Token: 0x06000C49 RID: 3145 RVA: 0x00056B7C File Offset: 0x00054D7C
		public override int AsInt
		{
			get
			{
				JSONData aVal = new JSONData(0);
				this.Set(aVal);
				return 0;
			}
			set
			{
				JSONData aVal = new JSONData(value);
				this.Set(aVal);
			}
		}

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x06000C4A RID: 3146 RVA: 0x00056B98 File Offset: 0x00054D98
		// (set) Token: 0x06000C4B RID: 3147 RVA: 0x00056BBC File Offset: 0x00054DBC
		public override float AsFloat
		{
			get
			{
				JSONData aVal = new JSONData(0f);
				this.Set(aVal);
				return 0f;
			}
			set
			{
				JSONData aVal = new JSONData(value);
				this.Set(aVal);
			}
		}

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x06000C4C RID: 3148 RVA: 0x00056BD8 File Offset: 0x00054DD8
		// (set) Token: 0x06000C4D RID: 3149 RVA: 0x00056C04 File Offset: 0x00054E04
		public override double AsDouble
		{
			get
			{
				JSONData aVal = new JSONData(0.0);
				this.Set(aVal);
				return 0.0;
			}
			set
			{
				JSONData aVal = new JSONData(value);
				this.Set(aVal);
			}
		}

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x06000C4E RID: 3150 RVA: 0x00056C20 File Offset: 0x00054E20
		// (set) Token: 0x06000C4F RID: 3151 RVA: 0x00056C3C File Offset: 0x00054E3C
		public override bool AsBool
		{
			get
			{
				JSONData aVal = new JSONData(false);
				this.Set(aVal);
				return false;
			}
			set
			{
				JSONData aVal = new JSONData(value);
				this.Set(aVal);
			}
		}

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x06000C50 RID: 3152 RVA: 0x00056C58 File Offset: 0x00054E58
		public override JSONArray AsArray
		{
			get
			{
				JSONArray jsonarray = new JSONArray();
				this.Set(jsonarray);
				return jsonarray;
			}
		}

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x06000C51 RID: 3153 RVA: 0x00056C74 File Offset: 0x00054E74
		public override JSONClass AsObject
		{
			get
			{
				JSONClass jsonclass = new JSONClass();
				this.Set(jsonclass);
				return jsonclass;
			}
		}

		// Token: 0x0400132C RID: 4908
		private JSONNode m_Node;

		// Token: 0x0400132D RID: 4909
		private string m_Key;
	}
}
