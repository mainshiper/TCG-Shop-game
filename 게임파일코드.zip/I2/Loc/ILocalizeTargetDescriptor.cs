﻿using System;

namespace I2.Loc
{
	// Token: 0x02000175 RID: 373
	public abstract class ILocalizeTargetDescriptor
	{
		// Token: 0x06000AED RID: 2797
		public abstract bool CanLocalize(Localize cmp);

		// Token: 0x06000AEE RID: 2798
		public abstract ILocalizeTarget CreateTarget(Localize cmp);

		// Token: 0x06000AEF RID: 2799
		public abstract Type GetTargetType();

		// Token: 0x0400128A RID: 4746
		public string Name;

		// Token: 0x0400128B RID: 4747
		public int Priority;
	}
}
