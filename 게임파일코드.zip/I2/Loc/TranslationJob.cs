﻿using System;

namespace I2.Loc
{
	// Token: 0x02000162 RID: 354
	public class TranslationJob : IDisposable
	{
		// Token: 0x060009F7 RID: 2551 RVA: 0x0004BD7A File Offset: 0x00049F7A
		public virtual TranslationJob.eJobState GetState()
		{
			return this.mJobState;
		}

		// Token: 0x060009F8 RID: 2552 RVA: 0x0004BD82 File Offset: 0x00049F82
		public virtual void Dispose()
		{
		}

		// Token: 0x04001204 RID: 4612
		public TranslationJob.eJobState mJobState;

		// Token: 0x02000245 RID: 581
		public enum eJobState
		{
			// Token: 0x04001616 RID: 5654
			Running,
			// Token: 0x04001617 RID: 5655
			Succeeded,
			// Token: 0x04001618 RID: 5656
			Failed
		}
	}
}
