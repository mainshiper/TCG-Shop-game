﻿using System;

namespace I2.Loc
{
	// Token: 0x02000198 RID: 408
	internal enum GeneralArabicLetters
	{
		// Token: 0x040012EE RID: 4846
		Hamza = 1569,
		// Token: 0x040012EF RID: 4847
		Alef = 1575,
		// Token: 0x040012F0 RID: 4848
		AlefHamza = 1571,
		// Token: 0x040012F1 RID: 4849
		WawHamza,
		// Token: 0x040012F2 RID: 4850
		AlefMaksoor,
		// Token: 0x040012F3 RID: 4851
		AlefMagsora = 1609,
		// Token: 0x040012F4 RID: 4852
		HamzaNabera = 1574,
		// Token: 0x040012F5 RID: 4853
		Ba = 1576,
		// Token: 0x040012F6 RID: 4854
		Ta = 1578,
		// Token: 0x040012F7 RID: 4855
		Tha2,
		// Token: 0x040012F8 RID: 4856
		Jeem,
		// Token: 0x040012F9 RID: 4857
		H7aa,
		// Token: 0x040012FA RID: 4858
		Khaa2,
		// Token: 0x040012FB RID: 4859
		Dal,
		// Token: 0x040012FC RID: 4860
		Thal,
		// Token: 0x040012FD RID: 4861
		Ra2,
		// Token: 0x040012FE RID: 4862
		Zeen,
		// Token: 0x040012FF RID: 4863
		Seen,
		// Token: 0x04001300 RID: 4864
		Sheen,
		// Token: 0x04001301 RID: 4865
		S9a,
		// Token: 0x04001302 RID: 4866
		Dha,
		// Token: 0x04001303 RID: 4867
		T6a,
		// Token: 0x04001304 RID: 4868
		T6ha,
		// Token: 0x04001305 RID: 4869
		Ain,
		// Token: 0x04001306 RID: 4870
		Gain,
		// Token: 0x04001307 RID: 4871
		Fa = 1601,
		// Token: 0x04001308 RID: 4872
		Gaf,
		// Token: 0x04001309 RID: 4873
		Kaf,
		// Token: 0x0400130A RID: 4874
		Lam,
		// Token: 0x0400130B RID: 4875
		Meem,
		// Token: 0x0400130C RID: 4876
		Noon,
		// Token: 0x0400130D RID: 4877
		Ha,
		// Token: 0x0400130E RID: 4878
		Waw,
		// Token: 0x0400130F RID: 4879
		Ya = 1610,
		// Token: 0x04001310 RID: 4880
		AlefMad = 1570,
		// Token: 0x04001311 RID: 4881
		TaMarboota = 1577,
		// Token: 0x04001312 RID: 4882
		PersianPe = 1662,
		// Token: 0x04001313 RID: 4883
		PersianChe = 1670,
		// Token: 0x04001314 RID: 4884
		PersianZe = 1688,
		// Token: 0x04001315 RID: 4885
		PersianGaf = 1711,
		// Token: 0x04001316 RID: 4886
		PersianGaf2 = 1705
	}
}
