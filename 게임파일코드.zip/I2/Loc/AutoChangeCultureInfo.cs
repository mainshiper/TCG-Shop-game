﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x0200018A RID: 394
	public class AutoChangeCultureInfo : MonoBehaviour
	{
		// Token: 0x06000B88 RID: 2952 RVA: 0x00053332 File Offset: 0x00051532
		public void Start()
		{
			LocalizationManager.EnableChangingCultureInfo(true);
		}
	}
}
