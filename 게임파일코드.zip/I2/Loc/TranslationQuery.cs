﻿using System;

namespace I2.Loc
{
	// Token: 0x02000161 RID: 353
	public struct TranslationQuery
	{
		// Token: 0x040011FE RID: 4606
		public string OrigText;

		// Token: 0x040011FF RID: 4607
		public string Text;

		// Token: 0x04001200 RID: 4608
		public string LanguageCode;

		// Token: 0x04001201 RID: 4609
		public string[] TargetLanguagesCode;

		// Token: 0x04001202 RID: 4610
		public string[] Results;

		// Token: 0x04001203 RID: 4611
		public string[] Tags;
	}
}
