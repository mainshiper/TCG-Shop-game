﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace I2.Loc
{
	// Token: 0x02000185 RID: 389
	public class LocalizeTarget_UnityUI_Text : LocalizeTarget<Text>
	{
		// Token: 0x06000B70 RID: 2928 RVA: 0x00052E2E File Offset: 0x0005102E
		static LocalizeTarget_UnityUI_Text()
		{
			LocalizeTarget_UnityUI_Text.AutoRegister();
		}

		// Token: 0x06000B71 RID: 2929 RVA: 0x00052E35 File Offset: 0x00051035
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
			LocalizationManager.RegisterTarget(new LocalizeTargetDesc_Type<Text, LocalizeTarget_UnityUI_Text>
			{
				Name = "Text",
				Priority = 100
			});
		}

		// Token: 0x06000B72 RID: 2930 RVA: 0x00052E54 File Offset: 0x00051054
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06000B73 RID: 2931 RVA: 0x00052E57 File Offset: 0x00051057
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Font;
		}

		// Token: 0x06000B74 RID: 2932 RVA: 0x00052E5A File Offset: 0x0005105A
		public override bool CanUseSecondaryTerm()
		{
			return true;
		}

		// Token: 0x06000B75 RID: 2933 RVA: 0x00052E5D File Offset: 0x0005105D
		public override bool AllowMainTermToBeRTL()
		{
			return true;
		}

		// Token: 0x06000B76 RID: 2934 RVA: 0x00052E60 File Offset: 0x00051060
		public override bool AllowSecondTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B77 RID: 2935 RVA: 0x00052E64 File Offset: 0x00051064
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
			primaryTerm = (this.mTarget ? this.mTarget.text : null);
			secondaryTerm = ((this.mTarget.font != null) ? this.mTarget.font.name : string.Empty);
		}

		// Token: 0x06000B78 RID: 2936 RVA: 0x00052EBC File Offset: 0x000510BC
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
			Font secondaryTranslatedObj = cmp.GetSecondaryTranslatedObj<Font>(ref mainTranslation, ref secondaryTranslation);
			if (secondaryTranslatedObj != null && secondaryTranslatedObj != this.mTarget.font)
			{
				this.mTarget.font = secondaryTranslatedObj;
			}
			if (this.mInitializeAlignment)
			{
				this.mInitializeAlignment = false;
				this.mAlignmentWasRTL = LocalizationManager.IsRight2Left;
				this.InitAlignment(this.mAlignmentWasRTL, this.mTarget.alignment, out this.mAlignment_LTR, out this.mAlignment_RTL);
			}
			else
			{
				TextAnchor textAnchor;
				TextAnchor textAnchor2;
				this.InitAlignment(this.mAlignmentWasRTL, this.mTarget.alignment, out textAnchor, out textAnchor2);
				if ((this.mAlignmentWasRTL && this.mAlignment_RTL != textAnchor2) || (!this.mAlignmentWasRTL && this.mAlignment_LTR != textAnchor))
				{
					this.mAlignment_LTR = textAnchor;
					this.mAlignment_RTL = textAnchor2;
				}
				this.mAlignmentWasRTL = LocalizationManager.IsRight2Left;
			}
			if (mainTranslation != null && this.mTarget.text != mainTranslation)
			{
				if (cmp.CorrectAlignmentForRTL)
				{
					this.mTarget.alignment = (LocalizationManager.IsRight2Left ? this.mAlignment_RTL : this.mAlignment_LTR);
				}
				this.mTarget.text = mainTranslation;
				this.mTarget.SetVerticesDirty();
			}
		}

		// Token: 0x06000B79 RID: 2937 RVA: 0x00052FE8 File Offset: 0x000511E8
		private void InitAlignment(bool isRTL, TextAnchor alignment, out TextAnchor alignLTR, out TextAnchor alignRTL)
		{
			alignRTL = alignment;
			alignLTR = alignment;
			if (isRTL)
			{
				switch (alignment)
				{
				case 0:
					alignLTR = 2;
					return;
				case 1:
				case 4:
				case 7:
					break;
				case 2:
					alignLTR = 0;
					return;
				case 3:
					alignLTR = 5;
					return;
				case 5:
					alignLTR = 3;
					return;
				case 6:
					alignLTR = 8;
					return;
				case 8:
					alignLTR = 6;
					return;
				default:
					return;
				}
			}
			else
			{
				switch (alignment)
				{
				case 0:
					alignRTL = 2;
					return;
				case 1:
				case 4:
				case 7:
					break;
				case 2:
					alignRTL = 0;
					return;
				case 3:
					alignRTL = 5;
					return;
				case 5:
					alignRTL = 3;
					return;
				case 6:
					alignRTL = 8;
					break;
				case 8:
					alignRTL = 6;
					return;
				default:
					return;
				}
			}
		}

		// Token: 0x04001298 RID: 4760
		private TextAnchor mAlignment_RTL = 2;

		// Token: 0x04001299 RID: 4761
		private TextAnchor mAlignment_LTR;

		// Token: 0x0400129A RID: 4762
		private bool mAlignmentWasRTL;

		// Token: 0x0400129B RID: 4763
		private bool mInitializeAlignment = true;
	}
}
