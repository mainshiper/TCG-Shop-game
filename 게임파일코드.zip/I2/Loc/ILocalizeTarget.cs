﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000173 RID: 371
	public abstract class ILocalizeTarget : ScriptableObject
	{
		// Token: 0x06000AE2 RID: 2786
		public abstract bool IsValid(Localize cmp);

		// Token: 0x06000AE3 RID: 2787
		public abstract void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm);

		// Token: 0x06000AE4 RID: 2788
		public abstract void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation);

		// Token: 0x06000AE5 RID: 2789
		public abstract bool CanUseSecondaryTerm();

		// Token: 0x06000AE6 RID: 2790
		public abstract bool AllowMainTermToBeRTL();

		// Token: 0x06000AE7 RID: 2791
		public abstract bool AllowSecondTermToBeRTL();

		// Token: 0x06000AE8 RID: 2792
		public abstract eTermType GetPrimaryTermType(Localize cmp);

		// Token: 0x06000AE9 RID: 2793
		public abstract eTermType GetSecondaryTermType(Localize cmp);
	}
}
