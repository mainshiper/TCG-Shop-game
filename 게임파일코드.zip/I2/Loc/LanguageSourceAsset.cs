﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x0200016B RID: 363
	[CreateAssetMenu(fileName = "I2Languages", menuName = "I2 Localization/LanguageSource", order = 1)]
	public class LanguageSourceAsset : ScriptableObject, ILanguageSource
	{
		// Token: 0x17000038 RID: 56
		// (get) Token: 0x06000A1D RID: 2589 RVA: 0x0004CA2B File Offset: 0x0004AC2B
		// (set) Token: 0x06000A1E RID: 2590 RVA: 0x0004CA33 File Offset: 0x0004AC33
		public LanguageSourceData SourceData
		{
			get
			{
				return this.mSource;
			}
			set
			{
				this.mSource = value;
			}
		}

		// Token: 0x04001236 RID: 4662
		public LanguageSourceData mSource = new LanguageSourceData();
	}
}
