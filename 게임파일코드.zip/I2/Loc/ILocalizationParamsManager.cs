﻿using System;

namespace I2.Loc
{
	// Token: 0x0200018F RID: 399
	public interface ILocalizationParamsManager
	{
		// Token: 0x06000BA3 RID: 2979
		string GetParameterValue(string Param);
	}
}
