﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000190 RID: 400
	public class LocalizationParamsManager : MonoBehaviour, ILocalizationParamsManager
	{
		// Token: 0x06000BA4 RID: 2980 RVA: 0x00053B20 File Offset: 0x00051D20
		public string GetParameterValue(string ParamName)
		{
			if (this._Params != null)
			{
				int i = 0;
				int count = this._Params.Count;
				while (i < count)
				{
					if (this._Params[i].Name == ParamName)
					{
						return this._Params[i].Value;
					}
					i++;
				}
			}
			return null;
		}

		// Token: 0x06000BA5 RID: 2981 RVA: 0x00053B7C File Offset: 0x00051D7C
		public void SetParameterValue(string ParamName, string ParamValue, bool localize = true)
		{
			bool flag = false;
			int i = 0;
			int count = this._Params.Count;
			while (i < count)
			{
				if (this._Params[i].Name == ParamName)
				{
					LocalizationParamsManager.ParamValue value = this._Params[i];
					value.Value = ParamValue;
					this._Params[i] = value;
					flag = true;
					break;
				}
				i++;
			}
			if (!flag)
			{
				this._Params.Add(new LocalizationParamsManager.ParamValue
				{
					Name = ParamName,
					Value = ParamValue
				});
			}
			if (localize)
			{
				this.OnLocalize();
			}
		}

		// Token: 0x06000BA6 RID: 2982 RVA: 0x00053C14 File Offset: 0x00051E14
		public void OnLocalize()
		{
			Localize component = base.GetComponent<Localize>();
			if (component != null)
			{
				component.OnLocalize(true);
			}
		}

		// Token: 0x06000BA7 RID: 2983 RVA: 0x00053C38 File Offset: 0x00051E38
		public virtual void OnEnable()
		{
			if (this._IsGlobalManager)
			{
				this.DoAutoRegister();
			}
		}

		// Token: 0x06000BA8 RID: 2984 RVA: 0x00053C48 File Offset: 0x00051E48
		public void DoAutoRegister()
		{
			if (!LocalizationManager.ParamManagers.Contains(this))
			{
				LocalizationManager.ParamManagers.Add(this);
				LocalizationManager.LocalizeAll(true);
			}
		}

		// Token: 0x06000BA9 RID: 2985 RVA: 0x00053C68 File Offset: 0x00051E68
		public void OnDisable()
		{
			LocalizationManager.ParamManagers.Remove(this);
		}

		// Token: 0x040012B8 RID: 4792
		[SerializeField]
		public List<LocalizationParamsManager.ParamValue> _Params = new List<LocalizationParamsManager.ParamValue>();

		// Token: 0x040012B9 RID: 4793
		public bool _IsGlobalManager;

		// Token: 0x0200025C RID: 604
		[Serializable]
		public struct ParamValue
		{
			// Token: 0x0400165D RID: 5725
			public string Name;

			// Token: 0x0400165E RID: 5726
			public string Value;
		}
	}
}
