﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000176 RID: 374
	public abstract class LocalizeTargetDesc<T> : ILocalizeTargetDescriptor where T : ILocalizeTarget
	{
		// Token: 0x06000AF1 RID: 2801 RVA: 0x00051C79 File Offset: 0x0004FE79
		public override ILocalizeTarget CreateTarget(Localize cmp)
		{
			return ScriptableObject.CreateInstance<T>();
		}

		// Token: 0x06000AF2 RID: 2802 RVA: 0x00051C85 File Offset: 0x0004FE85
		public override Type GetTargetType()
		{
			return typeof(T);
		}
	}
}
