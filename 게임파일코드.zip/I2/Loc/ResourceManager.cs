﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace I2.Loc
{
	// Token: 0x02000195 RID: 405
	public class ResourceManager : MonoBehaviour
	{
		// Token: 0x17000044 RID: 68
		// (get) Token: 0x06000BB9 RID: 3001 RVA: 0x00053DB0 File Offset: 0x00051FB0
		public static ResourceManager pInstance
		{
			get
			{
				bool flag = ResourceManager.mInstance == null;
				if (ResourceManager.mInstance == null)
				{
					ResourceManager.mInstance = (ResourceManager)Object.FindObjectOfType(typeof(ResourceManager));
				}
				if (ResourceManager.mInstance == null)
				{
					GameObject gameObject = new GameObject("I2ResourceManager", new Type[]
					{
						typeof(ResourceManager)
					});
					gameObject.hideFlags |= HideFlags.HideAndDontSave;
					ResourceManager.mInstance = gameObject.GetComponent<ResourceManager>();
					SceneManager.sceneLoaded += ResourceManager.MyOnLevelWasLoaded;
				}
				if (flag && Application.isPlaying)
				{
					Object.DontDestroyOnLoad(ResourceManager.mInstance.gameObject);
				}
				return ResourceManager.mInstance;
			}
		}

		// Token: 0x06000BBA RID: 3002 RVA: 0x00053E61 File Offset: 0x00052061
		public static void MyOnLevelWasLoaded(Scene scene, LoadSceneMode mode)
		{
			ResourceManager.pInstance.CleanResourceCache(false);
			LocalizationManager.UpdateSources();
		}

		// Token: 0x06000BBB RID: 3003 RVA: 0x00053E74 File Offset: 0x00052074
		public T GetAsset<T>(string Name) where T : Object
		{
			T t = this.FindAsset(Name) as T;
			if (t != null)
			{
				return t;
			}
			return this.LoadFromResources<T>(Name);
		}

		// Token: 0x06000BBC RID: 3004 RVA: 0x00053EAC File Offset: 0x000520AC
		private Object FindAsset(string Name)
		{
			if (this.Assets != null)
			{
				int i = 0;
				int num = this.Assets.Length;
				while (i < num)
				{
					if (this.Assets[i] != null && this.Assets[i].name == Name)
					{
						return this.Assets[i];
					}
					i++;
				}
			}
			return null;
		}

		// Token: 0x06000BBD RID: 3005 RVA: 0x00053F05 File Offset: 0x00052105
		public bool HasAsset(Object Obj)
		{
			return this.Assets != null && Array.IndexOf<Object>(this.Assets, Obj) >= 0;
		}

		// Token: 0x06000BBE RID: 3006 RVA: 0x00053F24 File Offset: 0x00052124
		public T LoadFromResources<T>(string Path) where T : Object
		{
			T t;
			try
			{
				Object @object;
				if (string.IsNullOrEmpty(Path))
				{
					t = default(T);
					t = t;
				}
				else if (this.mResourcesCache.TryGetValue(Path, out @object) && @object != null)
				{
					t = (@object as T);
				}
				else
				{
					T t2 = default(T);
					if (Path.EndsWith("]", StringComparison.OrdinalIgnoreCase))
					{
						int num = Path.LastIndexOf("[", StringComparison.OrdinalIgnoreCase);
						int length = Path.Length - num - 2;
						string value = Path.Substring(num + 1, length);
						Path = Path.Substring(0, num);
						T[] array = Resources.LoadAll<T>(Path);
						int i = 0;
						int num2 = array.Length;
						while (i < num2)
						{
							if (array[i].name.Equals(value))
							{
								t2 = array[i];
								break;
							}
							i++;
						}
					}
					else
					{
						t2 = (Resources.Load(Path, typeof(T)) as T);
					}
					if (t2 == null)
					{
						t2 = this.LoadFromBundle<T>(Path);
					}
					if (t2 != null)
					{
						this.mResourcesCache[Path] = t2;
					}
					t = t2;
				}
			}
			catch (Exception ex)
			{
				Debug.LogErrorFormat("Unable to load {0} '{1}'\nERROR: {2}", new object[]
				{
					typeof(T),
					Path,
					ex.ToString()
				});
				t = default(T);
			}
			return t;
		}

		// Token: 0x06000BBF RID: 3007 RVA: 0x000540B0 File Offset: 0x000522B0
		public T LoadFromBundle<T>(string path) where T : Object
		{
			int i = 0;
			int count = this.mBundleManagers.Count;
			while (i < count)
			{
				if (this.mBundleManagers[i] != null)
				{
					T t = this.mBundleManagers[i].LoadFromBundle(path, typeof(T)) as T;
					if (t != null)
					{
						return t;
					}
				}
				i++;
			}
			return default(T);
		}

		// Token: 0x06000BC0 RID: 3008 RVA: 0x00054123 File Offset: 0x00052323
		public void CleanResourceCache(bool unloadResources = false)
		{
			this.mResourcesCache.Clear();
			if (unloadResources)
			{
				Resources.UnloadUnusedAssets();
			}
			base.CancelInvoke();
		}

		// Token: 0x040012BF RID: 4799
		private static ResourceManager mInstance;

		// Token: 0x040012C0 RID: 4800
		public List<IResourceManager_Bundles> mBundleManagers = new List<IResourceManager_Bundles>();

		// Token: 0x040012C1 RID: 4801
		public Object[] Assets;

		// Token: 0x040012C2 RID: 4802
		private readonly Dictionary<string, Object> mResourcesCache = new Dictionary<string, Object>(StringComparer.Ordinal);
	}
}
