﻿using System;
using System.Globalization;
using System.IO;
using System.Text;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000159 RID: 345
	public abstract class I2BasePersistentStorage
	{
		// Token: 0x060009B0 RID: 2480 RVA: 0x00046964 File Offset: 0x00044B64
		public virtual void SetSetting_String(string key, string value)
		{
			try
			{
				int length = value.Length;
				int num = 8000;
				if (length <= num)
				{
					PlayerPrefs.SetString(key, value);
				}
				else
				{
					int num2 = Mathf.CeilToInt((float)length / (float)num);
					for (int i = 0; i < num2; i++)
					{
						int num3 = num * i;
						PlayerPrefs.SetString(string.Format("[I2split]{0}{1}", i, key), value.Substring(num3, Mathf.Min(num, length - num3)));
					}
					PlayerPrefs.SetString(key, "[$I2#@div$]" + num2.ToString());
				}
			}
			catch (Exception)
			{
				Debug.LogError("Error saving PlayerPrefs " + key);
			}
		}

		// Token: 0x060009B1 RID: 2481 RVA: 0x00046A0C File Offset: 0x00044C0C
		public virtual string GetSetting_String(string key, string defaultValue)
		{
			string result;
			try
			{
				string text = PlayerPrefs.GetString(key, defaultValue);
				if (!string.IsNullOrEmpty(text) && text.StartsWith("[I2split]", StringComparison.Ordinal))
				{
					int num = int.Parse(text.Substring("[I2split]".Length), CultureInfo.InvariantCulture);
					text = "";
					for (int i = 0; i < num; i++)
					{
						text += PlayerPrefs.GetString(string.Format("[I2split]{0}{1}", i, key), "");
					}
				}
				result = text;
			}
			catch (Exception)
			{
				Debug.LogError("Error loading PlayerPrefs " + key);
				result = defaultValue;
			}
			return result;
		}

		// Token: 0x060009B2 RID: 2482 RVA: 0x00046AB0 File Offset: 0x00044CB0
		public virtual void DeleteSetting(string key)
		{
			try
			{
				string @string = PlayerPrefs.GetString(key, null);
				if (!string.IsNullOrEmpty(@string) && @string.StartsWith("[I2split]", StringComparison.Ordinal))
				{
					int num = int.Parse(@string.Substring("[I2split]".Length), CultureInfo.InvariantCulture);
					for (int i = 0; i < num; i++)
					{
						PlayerPrefs.DeleteKey(string.Format("[I2split]{0}{1}", i, key));
					}
				}
				PlayerPrefs.DeleteKey(key);
			}
			catch (Exception)
			{
				Debug.LogError("Error deleting PlayerPrefs " + key);
			}
		}

		// Token: 0x060009B3 RID: 2483 RVA: 0x00046B44 File Offset: 0x00044D44
		public virtual void ForceSaveSettings()
		{
			PlayerPrefs.Save();
		}

		// Token: 0x060009B4 RID: 2484 RVA: 0x00046B4B File Offset: 0x00044D4B
		public virtual bool HasSetting(string key)
		{
			return PlayerPrefs.HasKey(key);
		}

		// Token: 0x060009B5 RID: 2485 RVA: 0x00046B53 File Offset: 0x00044D53
		public virtual bool CanAccessFiles()
		{
			return true;
		}

		// Token: 0x060009B6 RID: 2486 RVA: 0x00046B58 File Offset: 0x00044D58
		private string UpdateFilename(PersistentStorage.eFileType fileType, string fileName)
		{
			switch (fileType)
			{
			case PersistentStorage.eFileType.Persistent:
				fileName = Application.persistentDataPath + "/" + fileName;
				break;
			case PersistentStorage.eFileType.Temporal:
				fileName = Application.temporaryCachePath + "/" + fileName;
				break;
			case PersistentStorage.eFileType.Streaming:
				fileName = Application.streamingAssetsPath + "/" + fileName;
				break;
			}
			return fileName;
		}

		// Token: 0x060009B7 RID: 2487 RVA: 0x00046BB8 File Offset: 0x00044DB8
		public virtual bool SaveFile(PersistentStorage.eFileType fileType, string fileName, string data, bool logExceptions = true)
		{
			if (!this.CanAccessFiles())
			{
				return false;
			}
			bool result;
			try
			{
				fileName = this.UpdateFilename(fileType, fileName);
				File.WriteAllText(fileName, data, Encoding.UTF8);
				result = true;
			}
			catch (Exception ex)
			{
				if (logExceptions)
				{
					string str = "Error saving file '";
					string str2 = fileName;
					string str3 = "'\n";
					Exception ex2 = ex;
					Debug.LogError(str + str2 + str3 + ((ex2 != null) ? ex2.ToString() : null));
				}
				result = false;
			}
			return result;
		}

		// Token: 0x060009B8 RID: 2488 RVA: 0x00046C28 File Offset: 0x00044E28
		public virtual string LoadFile(PersistentStorage.eFileType fileType, string fileName, bool logExceptions = true)
		{
			if (!this.CanAccessFiles())
			{
				return null;
			}
			string result;
			try
			{
				fileName = this.UpdateFilename(fileType, fileName);
				result = File.ReadAllText(fileName, Encoding.UTF8);
			}
			catch (Exception ex)
			{
				if (logExceptions)
				{
					string str = "Error loading file '";
					string str2 = fileName;
					string str3 = "'\n";
					Exception ex2 = ex;
					Debug.LogError(str + str2 + str3 + ((ex2 != null) ? ex2.ToString() : null));
				}
				result = null;
			}
			return result;
		}

		// Token: 0x060009B9 RID: 2489 RVA: 0x00046C94 File Offset: 0x00044E94
		public virtual bool DeleteFile(PersistentStorage.eFileType fileType, string fileName, bool logExceptions = true)
		{
			if (!this.CanAccessFiles())
			{
				return false;
			}
			bool result;
			try
			{
				fileName = this.UpdateFilename(fileType, fileName);
				File.Delete(fileName);
				result = true;
			}
			catch (Exception ex)
			{
				if (logExceptions)
				{
					string str = "Error deleting file '";
					string str2 = fileName;
					string str3 = "'\n";
					Exception ex2 = ex;
					Debug.LogError(str + str2 + str3 + ((ex2 != null) ? ex2.ToString() : null));
				}
				result = false;
			}
			return result;
		}

		// Token: 0x060009BA RID: 2490 RVA: 0x00046CFC File Offset: 0x00044EFC
		public virtual bool HasFile(PersistentStorage.eFileType fileType, string fileName, bool logExceptions = true)
		{
			if (!this.CanAccessFiles())
			{
				return false;
			}
			bool result;
			try
			{
				fileName = this.UpdateFilename(fileType, fileName);
				result = File.Exists(fileName);
			}
			catch (Exception ex)
			{
				if (logExceptions)
				{
					string str = "Error requesting file '";
					string str2 = fileName;
					string str3 = "'\n";
					Exception ex2 = ex;
					Debug.LogError(str + str2 + str3 + ((ex2 != null) ? ex2.ToString() : null));
				}
				result = false;
			}
			return result;
		}
	}
}
