﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000177 RID: 375
	public class LocalizeTargetDesc_Type<T, G> : LocalizeTargetDesc<G> where T : Object where G : LocalizeTarget<T>
	{
		// Token: 0x06000AF4 RID: 2804 RVA: 0x00051C99 File Offset: 0x0004FE99
		public override bool CanLocalize(Localize cmp)
		{
			return cmp.GetComponent<T>() != null;
		}

		// Token: 0x06000AF5 RID: 2805 RVA: 0x00051CAC File Offset: 0x0004FEAC
		public override ILocalizeTarget CreateTarget(Localize cmp)
		{
			T component = cmp.GetComponent<T>();
			if (component == null)
			{
				return null;
			}
			G g = ScriptableObject.CreateInstance<G>();
			g.mTarget = component;
			return g;
		}
	}
}
