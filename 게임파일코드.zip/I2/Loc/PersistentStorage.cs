﻿using System;

namespace I2.Loc
{
	// Token: 0x02000158 RID: 344
	public static class PersistentStorage
	{
		// Token: 0x060009A6 RID: 2470 RVA: 0x0004682F File Offset: 0x00044A2F
		public static void SetSetting_String(string key, string value)
		{
			if (PersistentStorage.mStorage == null)
			{
				PersistentStorage.mStorage = new I2CustomPersistentStorage();
			}
			PersistentStorage.mStorage.SetSetting_String(key, value);
		}

		// Token: 0x060009A7 RID: 2471 RVA: 0x0004684E File Offset: 0x00044A4E
		public static string GetSetting_String(string key, string defaultValue)
		{
			if (PersistentStorage.mStorage == null)
			{
				PersistentStorage.mStorage = new I2CustomPersistentStorage();
			}
			return PersistentStorage.mStorage.GetSetting_String(key, defaultValue);
		}

		// Token: 0x060009A8 RID: 2472 RVA: 0x0004686D File Offset: 0x00044A6D
		public static void DeleteSetting(string key)
		{
			if (PersistentStorage.mStorage == null)
			{
				PersistentStorage.mStorage = new I2CustomPersistentStorage();
			}
			PersistentStorage.mStorage.DeleteSetting(key);
		}

		// Token: 0x060009A9 RID: 2473 RVA: 0x0004688B File Offset: 0x00044A8B
		public static bool HasSetting(string key)
		{
			if (PersistentStorage.mStorage == null)
			{
				PersistentStorage.mStorage = new I2CustomPersistentStorage();
			}
			return PersistentStorage.mStorage.HasSetting(key);
		}

		// Token: 0x060009AA RID: 2474 RVA: 0x000468A9 File Offset: 0x00044AA9
		public static void ForceSaveSettings()
		{
			if (PersistentStorage.mStorage == null)
			{
				PersistentStorage.mStorage = new I2CustomPersistentStorage();
			}
			PersistentStorage.mStorage.ForceSaveSettings();
		}

		// Token: 0x060009AB RID: 2475 RVA: 0x000468C6 File Offset: 0x00044AC6
		public static bool CanAccessFiles()
		{
			if (PersistentStorage.mStorage == null)
			{
				PersistentStorage.mStorage = new I2CustomPersistentStorage();
			}
			return PersistentStorage.mStorage.CanAccessFiles();
		}

		// Token: 0x060009AC RID: 2476 RVA: 0x000468E3 File Offset: 0x00044AE3
		public static bool SaveFile(PersistentStorage.eFileType fileType, string fileName, string data, bool logExceptions = true)
		{
			if (PersistentStorage.mStorage == null)
			{
				PersistentStorage.mStorage = new I2CustomPersistentStorage();
			}
			return PersistentStorage.mStorage.SaveFile(fileType, fileName, data, logExceptions);
		}

		// Token: 0x060009AD RID: 2477 RVA: 0x00046904 File Offset: 0x00044B04
		public static string LoadFile(PersistentStorage.eFileType fileType, string fileName, bool logExceptions = true)
		{
			if (PersistentStorage.mStorage == null)
			{
				PersistentStorage.mStorage = new I2CustomPersistentStorage();
			}
			return PersistentStorage.mStorage.LoadFile(fileType, fileName, logExceptions);
		}

		// Token: 0x060009AE RID: 2478 RVA: 0x00046924 File Offset: 0x00044B24
		public static bool DeleteFile(PersistentStorage.eFileType fileType, string fileName, bool logExceptions = true)
		{
			if (PersistentStorage.mStorage == null)
			{
				PersistentStorage.mStorage = new I2CustomPersistentStorage();
			}
			return PersistentStorage.mStorage.DeleteFile(fileType, fileName, logExceptions);
		}

		// Token: 0x060009AF RID: 2479 RVA: 0x00046944 File Offset: 0x00044B44
		public static bool HasFile(PersistentStorage.eFileType fileType, string fileName, bool logExceptions = true)
		{
			if (PersistentStorage.mStorage == null)
			{
				PersistentStorage.mStorage = new I2CustomPersistentStorage();
			}
			return PersistentStorage.mStorage.HasFile(fileType, fileName, logExceptions);
		}

		// Token: 0x040011EE RID: 4590
		private static I2CustomPersistentStorage mStorage;

		// Token: 0x0200023F RID: 575
		public enum eFileType
		{
			// Token: 0x04001607 RID: 5639
			Raw,
			// Token: 0x04001608 RID: 5640
			Persistent,
			// Token: 0x04001609 RID: 5641
			Temporal,
			// Token: 0x0400160A RID: 5642
			Streaming
		}
	}
}
