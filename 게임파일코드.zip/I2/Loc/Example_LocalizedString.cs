﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000153 RID: 339
	public class Example_LocalizedString : MonoBehaviour
	{
		// Token: 0x06000991 RID: 2449 RVA: 0x000462D8 File Offset: 0x000444D8
		public void Start()
		{
			Debug.Log(this._MyLocalizedString);
			Debug.Log(LocalizationManager.GetTranslation(this._NormalString, true, 0, true, false, null, null, true));
			Debug.Log(LocalizationManager.GetTranslation(this._StringWithTermPopup, true, 0, true, false, null, null, true));
			Debug.Log("Term2");
			Debug.Log(this._MyLocalizedString);
			Debug.Log("Term3");
			LocalizedString localizedString = "Term3";
			localizedString.mRTL_IgnoreArabicFix = true;
			Debug.Log(localizedString);
			LocalizedString localizedString2 = "Term3";
			localizedString2.mRTL_ConvertNumbers = true;
			localizedString2.mRTL_MaxLineLength = 20;
			Debug.Log(localizedString2);
			Debug.Log(localizedString2);
		}

		// Token: 0x040011E8 RID: 4584
		public LocalizedString _MyLocalizedString;

		// Token: 0x040011E9 RID: 4585
		public string _NormalString;

		// Token: 0x040011EA RID: 4586
		[TermsPopup("")]
		public string _StringWithTermPopup;
	}
}
