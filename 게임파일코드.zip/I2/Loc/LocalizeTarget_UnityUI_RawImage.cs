﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace I2.Loc
{
	// Token: 0x02000184 RID: 388
	public class LocalizeTarget_UnityUI_RawImage : LocalizeTarget<RawImage>
	{
		// Token: 0x06000B66 RID: 2918 RVA: 0x00052D7A File Offset: 0x00050F7A
		static LocalizeTarget_UnityUI_RawImage()
		{
			LocalizeTarget_UnityUI_RawImage.AutoRegister();
		}

		// Token: 0x06000B67 RID: 2919 RVA: 0x00052D81 File Offset: 0x00050F81
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
			LocalizationManager.RegisterTarget(new LocalizeTargetDesc_Type<RawImage, LocalizeTarget_UnityUI_RawImage>
			{
				Name = "RawImage",
				Priority = 100
			});
		}

		// Token: 0x06000B68 RID: 2920 RVA: 0x00052DA0 File Offset: 0x00050FA0
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.Texture;
		}

		// Token: 0x06000B69 RID: 2921 RVA: 0x00052DA3 File Offset: 0x00050FA3
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06000B6A RID: 2922 RVA: 0x00052DA6 File Offset: 0x00050FA6
		public override bool CanUseSecondaryTerm()
		{
			return false;
		}

		// Token: 0x06000B6B RID: 2923 RVA: 0x00052DA9 File Offset: 0x00050FA9
		public override bool AllowMainTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B6C RID: 2924 RVA: 0x00052DAC File Offset: 0x00050FAC
		public override bool AllowSecondTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B6D RID: 2925 RVA: 0x00052DAF File Offset: 0x00050FAF
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
			primaryTerm = (this.mTarget.mainTexture ? this.mTarget.mainTexture.name : "");
			secondaryTerm = null;
		}

		// Token: 0x06000B6E RID: 2926 RVA: 0x00052DE4 File Offset: 0x00050FE4
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
			Texture texture = this.mTarget.texture;
			if (texture == null || texture.name != mainTranslation)
			{
				this.mTarget.texture = cmp.FindTranslatedObject<Texture>(mainTranslation);
			}
		}
	}
}
