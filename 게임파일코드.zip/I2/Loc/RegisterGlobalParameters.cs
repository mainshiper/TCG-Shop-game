﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02000193 RID: 403
	public class RegisterGlobalParameters : MonoBehaviour, ILocalizationParamsManager
	{
		// Token: 0x06000BB4 RID: 2996 RVA: 0x00053D75 File Offset: 0x00051F75
		public virtual void OnEnable()
		{
			if (!LocalizationManager.ParamManagers.Contains(this))
			{
				LocalizationManager.ParamManagers.Add(this);
				LocalizationManager.LocalizeAll(true);
			}
		}

		// Token: 0x06000BB5 RID: 2997 RVA: 0x00053D95 File Offset: 0x00051F95
		public virtual void OnDisable()
		{
			LocalizationManager.ParamManagers.Remove(this);
		}

		// Token: 0x06000BB6 RID: 2998 RVA: 0x00053DA3 File Offset: 0x00051FA3
		public virtual string GetParameterValue(string ParamName)
		{
			return null;
		}
	}
}
