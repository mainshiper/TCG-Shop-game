﻿using System;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x0200017D RID: 381
	public class LocalizeTarget_UnityStandard_MeshRenderer : LocalizeTarget<MeshRenderer>
	{
		// Token: 0x06000B26 RID: 2854 RVA: 0x00052650 File Offset: 0x00050850
		static LocalizeTarget_UnityStandard_MeshRenderer()
		{
			LocalizeTarget_UnityStandard_MeshRenderer.AutoRegister();
		}

		// Token: 0x06000B27 RID: 2855 RVA: 0x00052657 File Offset: 0x00050857
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
			LocalizationManager.RegisterTarget(new LocalizeTargetDesc_Type<MeshRenderer, LocalizeTarget_UnityStandard_MeshRenderer>
			{
				Name = "MeshRenderer",
				Priority = 800
			});
		}

		// Token: 0x06000B28 RID: 2856 RVA: 0x00052679 File Offset: 0x00050879
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.Mesh;
		}

		// Token: 0x06000B29 RID: 2857 RVA: 0x0005267C File Offset: 0x0005087C
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Material;
		}

		// Token: 0x06000B2A RID: 2858 RVA: 0x0005267F File Offset: 0x0005087F
		public override bool CanUseSecondaryTerm()
		{
			return true;
		}

		// Token: 0x06000B2B RID: 2859 RVA: 0x00052682 File Offset: 0x00050882
		public override bool AllowMainTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B2C RID: 2860 RVA: 0x00052685 File Offset: 0x00050885
		public override bool AllowSecondTermToBeRTL()
		{
			return false;
		}

		// Token: 0x06000B2D RID: 2861 RVA: 0x00052688 File Offset: 0x00050888
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
			if (this.mTarget == null)
			{
				string text;
				secondaryTerm = (text = null);
				primaryTerm = text;
			}
			else
			{
				MeshFilter component = this.mTarget.GetComponent<MeshFilter>();
				if (component == null || component.sharedMesh == null)
				{
					primaryTerm = null;
				}
				else
				{
					primaryTerm = component.sharedMesh.name;
				}
			}
			if (this.mTarget == null || this.mTarget.sharedMaterial == null)
			{
				secondaryTerm = null;
				return;
			}
			secondaryTerm = this.mTarget.sharedMaterial.name;
		}

		// Token: 0x06000B2E RID: 2862 RVA: 0x00052720 File Offset: 0x00050920
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
			Material secondaryTranslatedObj = cmp.GetSecondaryTranslatedObj<Material>(ref mainTranslation, ref secondaryTranslation);
			if (secondaryTranslatedObj != null && this.mTarget.sharedMaterial != secondaryTranslatedObj)
			{
				this.mTarget.material = secondaryTranslatedObj;
			}
			Mesh mesh = cmp.FindTranslatedObject<Mesh>(mainTranslation);
			MeshFilter component = this.mTarget.GetComponent<MeshFilter>();
			if (mesh != null && component.sharedMesh != mesh)
			{
				component.mesh = mesh;
			}
		}
	}
}
