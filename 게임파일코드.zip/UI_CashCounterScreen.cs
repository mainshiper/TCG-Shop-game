﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x02000088 RID: 136
public class UI_CashCounterScreen : MonoBehaviour
{
	// Token: 0x06000554 RID: 1364 RVA: 0x0002D543 File Offset: 0x0002B743
	private void Awake()
	{
		this.ResetCounter();
	}

	// Token: 0x06000555 RID: 1365 RVA: 0x0002D54B File Offset: 0x0002B74B
	public void Init(InteractableCashierCounter cashierCounter)
	{
		this.m_CashierCounter = cashierCounter;
	}

	// Token: 0x06000556 RID: 1366 RVA: 0x0002D554 File Offset: 0x0002B754
	private void Update()
	{
		this.m_PosX -= Input.mouseScrollDelta.y * this.m_MouseWheelScrollSpeed;
		this.m_PosX = Mathf.Clamp(this.m_PosX, this.m_MinPosX, this.m_MaxPosX);
		this.m_LerpPosX = Mathf.Lerp(this.m_LerpPosX, this.m_PosX, Time.deltaTime * CSingleton<TouchManager>.Instance.m_LerpSpeed);
		this.m_CheckoutBarSliderGrp.transform.localPosition = new Vector3(0f, this.m_LerpPosX, 0f);
	}

	// Token: 0x06000557 RID: 1367 RVA: 0x0002D5E8 File Offset: 0x0002B7E8
	public void OnItemScanned(float value, EItemType itemType, float totalItemCost)
	{
		if (itemType == EItemType.None)
		{
			return;
		}
		if (this.m_ItemScannedListDict.ContainsKey(itemType))
		{
			Dictionary<EItemType, int> itemScannedListDict = this.m_ItemScannedListDict;
			itemScannedListDict[itemType]++;
			int index = this.m_ItemTypeList.IndexOf(itemType);
			this.m_CheckoutItemBarList[index].AddScannedItem(this.m_ItemScannedListDict[itemType]);
		}
		else
		{
			this.m_ItemScannedListDict.Add(itemType, 1);
			this.m_ItemTypeList.Add(itemType);
			for (int i = 0; i < this.m_CheckoutItemBarList.Count; i++)
			{
				if (!this.m_CheckoutItemBarList[i].gameObject.activeSelf)
				{
					string name = InventoryBase.GetItemData(itemType).GetName();
					this.m_CheckoutItemBarList[i].SetItemName(name, value);
					this.m_CheckoutItemBarList[i].gameObject.SetActive(true);
					this.m_ActiveBarCount++;
					this.m_MaxPosX = Mathf.Clamp((float)(this.m_ActiveBarCount - 8) * 7.5f, 0f, 240f);
					break;
				}
			}
		}
		this.m_TotalItemCost = totalItemCost;
		this.m_TotalItemListCostText.text = GameInstance.GetPriceString(this.m_TotalItemCost, false, true, false, "F2");
		this.m_ScaledUpTotalText.text = this.m_TotalItemListCostText.text;
	}

	// Token: 0x06000558 RID: 1368 RVA: 0x0002D744 File Offset: 0x0002B944
	public void OnCardScanned(float value, CardData cardData, float totalItemCost)
	{
		if (cardData == null || cardData.monsterType == EMonsterType.None)
		{
			return;
		}
		for (int i = 0; i < this.m_CheckoutItemBarList.Count; i++)
		{
			if (!this.m_CheckoutItemBarList[i].gameObject.activeSelf)
			{
				string name = InventoryBase.GetMonsterData(cardData.monsterType).GetName() + " - " + CPlayerData.GetFullCardTypeName(cardData, true);
				this.m_CheckoutItemBarList[i].SetItemName(name, value);
				this.m_CheckoutItemBarList[i].gameObject.SetActive(true);
				this.m_ActiveBarCount++;
				this.m_MaxPosX = Mathf.Clamp((float)(this.m_ActiveBarCount - 8) * 7.5f, 0f, 240f);
				this.m_ItemTypeList.Add(EItemType.None);
				break;
			}
		}
		this.m_TotalItemCost = totalItemCost;
		this.m_TotalItemListCostText.text = GameInstance.GetPriceString(this.m_TotalItemCost, false, true, false, "F2");
		this.m_ScaledUpTotalText.text = this.m_TotalItemListCostText.text;
	}

	// Token: 0x06000559 RID: 1369 RVA: 0x0002D85C File Offset: 0x0002BA5C
	public void OnStartGivingChange()
	{
		this.m_ItemListGrp.SetActive(false);
		this.m_GivingChangeGrp.SetActive(true);
		this.m_MoneyGuideFollowDrawerAnim.Play();
		if (this.m_CurrentMoneyCurrencyType != CSingleton<CGameManager>.Instance.m_CurrencyType)
		{
			this.m_CurrentMoneyCurrencyType = CSingleton<CGameManager>.Instance.m_CurrencyType;
			this.UpdateChangeGuideText();
		}
	}

	// Token: 0x0600055A RID: 1370 RVA: 0x0002D8B8 File Offset: 0x0002BAB8
	private void UpdateChangeGuideText()
	{
		for (int i = 0; i < this.m_ChangeGuideTextList.Count; i++)
		{
			this.m_ChangeGuideTextList[i].text = GameInstance.GetPriceString(this.m_CashierCounter.m_InteractableCounterMoneyChangeList[i].m_Value, false, true, true, "F0");
		}
	}

	// Token: 0x0600055B RID: 1371 RVA: 0x0002D910 File Offset: 0x0002BB10
	public void UpdateMoneyChangeAmount(bool isChangeReady, float customerPaidAmount, float totalScannedItemCost, float currentMoneyChangeValue)
	{
		this.m_CustomerGiveAmountText.text = GameInstance.GetPriceString(customerPaidAmount, false, true, false, "F2");
		this.m_TotalItemCostText.text = GameInstance.GetPriceString(totalScannedItemCost, false, true, false, "F2");
		this.m_ChangeToGiveAmountText.text = GameInstance.GetPriceString(customerPaidAmount - totalScannedItemCost, false, true, false, "F2");
		this.m_ChangeGivenAmountText.text = GameInstance.GetPriceString(currentMoneyChangeValue, false, true, false, "F2");
		if (isChangeReady)
		{
			this.m_ChangeGivenAmountText.color = this.m_ChangeReadyColor;
			return;
		}
		this.m_ChangeGivenAmountText.color = this.m_ChangeNotReadyColor;
	}

	// Token: 0x0600055C RID: 1372 RVA: 0x0002D9AA File Offset: 0x0002BBAA
	public void ShowScaledUpTotalCost()
	{
		this.m_ScaledUpTotalTextGrp.SetActive(true);
	}

	// Token: 0x0600055D RID: 1373 RVA: 0x0002D9B8 File Offset: 0x0002BBB8
	public void ResetCounter()
	{
		this.m_ItemListGrp.SetActive(true);
		this.m_GivingChangeGrp.SetActive(false);
		this.m_ScaledUpTotalTextGrp.SetActive(false);
		this.m_TotalItemCost = 0f;
		this.m_TotalItemListCostText.text = GameInstance.GetPriceString(0f, false, true, false, "F2");
		this.UpdateMoneyChangeAmount(false, 0f, 0f, 0f);
		this.m_ItemTypeList.Clear();
		this.m_ItemScannedListDict.Clear();
		for (int i = 0; i < this.m_CheckoutItemBarList.Count; i++)
		{
			this.m_CheckoutItemBarList[i].gameObject.SetActive(false);
		}
		this.m_ActiveBarCount = 0;
		this.m_MaxPosX = 0f;
		this.m_CheckoutBarSliderGrp.transform.localPosition = Vector3.zero;
	}

	// Token: 0x0600055E RID: 1374 RVA: 0x0002DA91 File Offset: 0x0002BC91
	protected virtual void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x0600055F RID: 1375 RVA: 0x0002DAB2 File Offset: 0x0002BCB2
	protected virtual void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x06000560 RID: 1376 RVA: 0x0002DAD4 File Offset: 0x0002BCD4
	protected void OnMoneyCurrencyUpdated(CEventPlayer_OnMoneyCurrencyUpdated evt)
	{
		if (this.m_CurrentMoneyCurrencyType != CSingleton<CGameManager>.Instance.m_CurrencyType)
		{
			this.m_CurrentMoneyCurrencyType = CSingleton<CGameManager>.Instance.m_CurrencyType;
			base.StartCoroutine(this.DelayUpdateCurrency());
			this.m_TotalItemListCostText.text = GameInstance.GetPriceString(this.m_TotalItemCost, false, true, false, "F2");
			this.m_ScaledUpTotalText.text = this.m_TotalItemListCostText.text;
		}
	}

	// Token: 0x06000561 RID: 1377 RVA: 0x0002DB44 File Offset: 0x0002BD44
	private IEnumerator DelayUpdateCurrency()
	{
		yield return new WaitForSeconds(0.01f);
		this.UpdateChangeGuideText();
		yield break;
	}

	// Token: 0x040006FC RID: 1788
	public FollowObject m_FollowObject;

	// Token: 0x040006FD RID: 1789
	public GameObject m_ItemListGrp;

	// Token: 0x040006FE RID: 1790
	public GameObject m_ScaledUpTotalTextGrp;

	// Token: 0x040006FF RID: 1791
	public TextMeshProUGUI m_ScaledUpTotalText;

	// Token: 0x04000700 RID: 1792
	public TextMeshProUGUI m_TotalItemListCostText;

	// Token: 0x04000701 RID: 1793
	public Transform m_CheckoutBarSliderGrp;

	// Token: 0x04000702 RID: 1794
	public List<UI_CheckoutItemBar> m_CheckoutItemBarList;

	// Token: 0x04000703 RID: 1795
	private Dictionary<EItemType, int> m_ItemScannedListDict = new Dictionary<EItemType, int>();

	// Token: 0x04000704 RID: 1796
	private List<EItemType> m_ItemTypeList = new List<EItemType>();

	// Token: 0x04000705 RID: 1797
	public GameObject m_GivingChangeGrp;

	// Token: 0x04000706 RID: 1798
	public Animation m_MoneyGuideFollowDrawerAnim;

	// Token: 0x04000707 RID: 1799
	public TextMeshProUGUI m_CustomerGiveAmountText;

	// Token: 0x04000708 RID: 1800
	public TextMeshProUGUI m_TotalItemCostText;

	// Token: 0x04000709 RID: 1801
	public TextMeshProUGUI m_ChangeToGiveAmountText;

	// Token: 0x0400070A RID: 1802
	public TextMeshProUGUI m_ChangeGivenAmountText;

	// Token: 0x0400070B RID: 1803
	public List<TextMeshProUGUI> m_ChangeGuideTextList;

	// Token: 0x0400070C RID: 1804
	public Color m_ChangeReadyColor;

	// Token: 0x0400070D RID: 1805
	public Color m_ChangeNotReadyColor;

	// Token: 0x0400070E RID: 1806
	private float m_MouseWheelScrollSpeed = 10f;

	// Token: 0x0400070F RID: 1807
	private float m_LerpPosX;

	// Token: 0x04000710 RID: 1808
	private float m_PosX;

	// Token: 0x04000711 RID: 1809
	private float m_MinPosX;

	// Token: 0x04000712 RID: 1810
	private float m_MaxPosX = 5000f;

	// Token: 0x04000713 RID: 1811
	private float m_TotalItemCost;

	// Token: 0x04000714 RID: 1812
	private int m_ActiveBarCount;

	// Token: 0x04000715 RID: 1813
	private InteractableCashierCounter m_CashierCounter;

	// Token: 0x04000716 RID: 1814
	private EMoneyCurrencyType m_CurrentMoneyCurrencyType;
}
