﻿using System;
using UnityEngine;

// Token: 0x0200012E RID: 302
[CreateAssetMenu(fileName = "Data", menuName = "Inventory/List", order = 2)]
public class PoolFX_ScriptableObject : ScriptableObject
{
	// Token: 0x040010E3 RID: 4323
	public GameObject m_SlashHitFXPrefab;

	// Token: 0x040010E4 RID: 4324
	public GameObject m_ExplosionFXPrefab;

	// Token: 0x040010E5 RID: 4325
	public GameObject m_FlameHitFXPrefab;

	// Token: 0x040010E6 RID: 4326
	public GameObject m_RocketHitFXPrefab;

	// Token: 0x040010E7 RID: 4327
	public GameObject m_SonicBlasterFXPrefab;

	// Token: 0x040010E8 RID: 4328
	public GameObject m_BasicHitFXPrefab;

	// Token: 0x040010E9 RID: 4329
	public GameObject m_RobotDestroyedExplosionFXPrefab;

	// Token: 0x040010EA RID: 4330
	public GameObject m_ShockBurstFXPrefab;

	// Token: 0x040010EB RID: 4331
	public GameObject m_ShockHitFXPrefab;

	// Token: 0x040010EC RID: 4332
	public GameObject m_FreezeHitFXPrefab;

	// Token: 0x040010ED RID: 4333
	public GameObject m_FreezeExplosionFXPrefab;

	// Token: 0x040010EE RID: 4334
	public GameObject m_ChillMissleHitFXPrefab;

	// Token: 0x040010EF RID: 4335
	public GameObject m_EnergyExplodeFXPrefab;
}
