﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200013A RID: 314
public class IndicatorManager : CSingleton<IndicatorManager>
{
	// Token: 0x06000904 RID: 2308 RVA: 0x00042B5C File Offset: 0x00040D5C
	public void Start()
	{
		if (IndicatorManager.m_Instance == null)
		{
			IndicatorManager.m_Instance = this;
		}
		else if (IndicatorManager.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
		for (int i = 0; i < this.m_ArrowIndicatorUIList.Count; i++)
		{
			this.m_ArrowIndicatorUIList[i].gameObject.SetActive(false);
			this.m_ParentList.Add(null);
		}
	}

	// Token: 0x06000905 RID: 2309 RVA: 0x00042BD8 File Offset: 0x00040DD8
	private void Update()
	{
		for (int i = 0; i < this.m_ParentList.Count; i++)
		{
			if (this.m_ParentList[i] && !this.m_ParentList[i].activeInHierarchy)
			{
				this.m_ArrowIndicatorUIList[i].gameObject.SetActive(false);
				this.m_ArrowIndicatorUIList[i].transform.parent = base.transform;
				this.m_ParentList[i] = null;
			}
		}
	}

	// Token: 0x06000906 RID: 2310 RVA: 0x00042C64 File Offset: 0x00040E64
	public static void HideAllIndicator()
	{
		for (int i = 0; i < CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList.Count; i++)
		{
			CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList[i].gameObject.SetActive(false);
			CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList[i].transform.parent = CSingleton<IndicatorManager>.Instance.transform;
			CSingleton<IndicatorManager>.Instance.m_ParentList[i] = null;
		}
	}

	// Token: 0x06000907 RID: 2311 RVA: 0x00042CDC File Offset: 0x00040EDC
	public static void ShowArrowIndicator(GameObject parent, float posYOffset = 0f, float scale = 1f)
	{
		for (int i = 0; i < CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList.Count; i++)
		{
			if (!CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList[i].gameObject.activeSelf)
			{
				CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList[i].SetPosY(posYOffset);
				CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList[i].SetScale(scale);
				CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList[i].transform.parent = parent.transform;
				CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList[i].transform.localPosition = Vector3.zero;
				CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList[i].gameObject.SetActive(true);
				CSingleton<IndicatorManager>.Instance.m_ParentList[i] = parent;
				return;
			}
		}
	}

	// Token: 0x0400112C RID: 4396
	public static IndicatorManager m_Instance;

	// Token: 0x0400112D RID: 4397
	public List<ArrowIndicatorUI> m_ArrowIndicatorUIList;

	// Token: 0x0400112E RID: 4398
	private List<GameObject> m_ParentList = new List<GameObject>();
}
